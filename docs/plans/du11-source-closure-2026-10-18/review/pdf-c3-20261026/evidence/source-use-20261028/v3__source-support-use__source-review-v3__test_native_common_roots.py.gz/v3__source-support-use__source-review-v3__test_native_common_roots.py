import pytest

from test_independent_source import assessed


@pytest.mark.parametrize('text', ('参与者。','(iv)\n经营租赁'))
def test_person_noun_and_accounting_heading_are_not_unknown_operating_events(text):
    use, packages, evidence=assessed(text)
    assert use[0]!='support' and not packages, (text,use,evidence)


@pytest.mark.parametrize('text', (
    '本期，第七代云设备P7和R8正式发布，\n支持客户在线推理工作负载。',
    'Nimbus训练与推理平台亦已正式上线，为用户提供模型任务管理平台，\n集成开源模型Nova3。',
    '公司参与工业设备生产项目。',
    '公司已向客户交付专用设备。',
))
def test_real_operating_updates_and_functions_keep_support_with_product_codes(text):
    use, packages, evidence=assessed(text)
    assert use[0]=='support' and packages, (text,use,evidence)
