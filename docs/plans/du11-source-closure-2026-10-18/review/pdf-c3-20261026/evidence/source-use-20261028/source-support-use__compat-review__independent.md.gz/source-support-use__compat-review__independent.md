# 跨仓 reading support use 兼容独审

FINAL — PASS（仅detached消费者代码与中性公开wire）。冻结5文件raw/LF SHA测试前后一致，无open实现发现；不是生产端到端或发布验收。

独立定向 **71 PASS**：RF40项/1.01秒（自有15+作者25），StockWiki31项/0.59秒（自有8+作者23）。未重跑作者161/100矩阵或整仓测试。

RF两条公共wire读取都保留/4用途及trace；两个真实参数绑定入口均拒绝context_only/unresolved，显式view、数值table别名、value_range/exact_value都不能绕过。一个scope的support不能借给另一个显式禁用scope；有效数值1240和来源完整closure仍可绑定。负数/布尔/浮点view索引拒绝。旧absent、/1、/2、/3的完整citation_trace与detached基线旧owner逐值相等，没有强塞新字段。

StockWiki仅新增可选source reading_context预览，保留use/reason与opaque policy/proof/trace，不导入CWP engine或新增文本分类/research state。claim的context IDs与factual IDs分开且只允许已运输refs。用途类型及80/81边界、完整partition、513组上限和修改后未重签字节通道拒绝均通过。source_and_locators_verified不意味着摘要语义或投资结论获准。

独立核对了三个PRIMARY源文件SHA与作者初始值一致；两detached HEAD保持原基线，git status与审查前相同。没有修改PRIMARY、worktree、PWF、原件或配置，也未commit/merge/push。工作树保留供ROOT精确集成。

ROOT仍需在SOURCE冻结后，用真实当前CWP /4公共artifact及byte/receipt通道完成combined gate，并集成/同步确切已审消费者后再发布。这里的中性DTO与既有fixture不冒充真实/4 E2E，也不证明预测实际采用或生成摘要质量；不顺手扩展StockWiki bundle/3兼容。

自有.c3cr已按绝对路径检查删除；父环境未变，无后台进程，无SDK/PDF/模型/网络/下载。只在本独立目录新增审查证据。

| 仓库/文件 | LF SHA-256 |
| --- | --- |
| rf / `scripts/company_wiki_narrative_contracts.py` | `c61f014fef63b30ae32018839d587479a872432d77e790bc010183ed9900a358` |
| rf / `scripts/narrative_citation_context.py` | `cd8d01533f539a9a65beb0500300a76915156dda9b39a497c14f0d53add01ed0` |
| rf / `tests/test_reading_support_use.py` | `9a0516d4deec5bb3bb4620fdf765720c7b5b5dca2ad135783d0d2b5a8b6ee6e1` |
| stockwiki / `stockwiki/_narrative_bundle.py` | `81ec5ecc85f5b1eeb8f9b8009201d4f7fa58729fbbb6b92b19fdbe1b403d4bca` |
| stockwiki / `tests/test_narrative_reading_support_use.py` | `32729348cef382d02cf443b257b4700bc090a3d7325c4a9acf518dfbc433a855` |
