# SOURCE v2 独立复核：CHANGES_REQUESTED

原4项 RED 已闭合：完整用途/功能/服务覆盖恢复；“产品名称见词汇表。量产。”不再成为经营事实或 support。新增同子句对象/谓词绑定和跨句反控通过。

仍有一项 **P1**：`We provide option-pricing software to banks.` / `公司向银行提供期权定价软件。` 是主体向客户提供软件的完整经营陈述，真实 session 和 `_candidates` 却因 `_ACCOUNTING` 的 option.pricing/期权定价词汇先命中而得到 accounting_policy、context_only/non_operating_purpose，无 package。这里的财务词是产品修饰语，没有任何会计计量或定义规则。根因仍是条款用途与真实同句业务关系混淆，不能靠行业或词例白名单修复。

冻结反例：`test_common_roots.py::test_actual_product_provision_is_not_an_accounting_definition`，英语/中文2项失败。独立本轮 **129P/2F，共131项，pytest7.85秒**：旧独立10、新共因8、指纹1、ROOT消费能力12、作者71、保存实际scope29。日志/收据为 `recheck.log/xml/json`，全部 SOURCE v2 五文件与 handoff raw/LF SHA在测试前后相符。

ROOT两项增量通过：inventory确实绑定新helper字节；source_cards局部 Optional narrowing 保留语义。另实际 decoder 控制确认单选 p1 basis 仍保留 task全部2个support span和独立context，未发现需要额外门。

公共集成测试已读码，并读取 ROOT `support-public-v3.log/xml` 的 **1P/21.80秒**与清理收据，独审未重复执行。它覆盖当前 CWP batch/worker→一次loopback HTTP→same-run零额外POST/预算相等→真实CLI body/receipt→RF wire validator及StockWiki公共transport。配置位置和真实公共类夹具修正已核。清理通过，原件SHA有断言。这是公共字节/读取兼容正例；单条clean TXT并未证明真实RF事实绑定采用或拒绝，后者仍由先前独立兼容反例约束；更不证明正式摘要质量或未来v3源码运行结果。

`independent.json` 绑定测试时8文件 SHA，并另记公共测试两处夹具修正后的当前SHA，避免把旧测试哈希移签新文件。旧 consumer FINAL inventory SHA未复用。`.c3srv2`已清理、TEMP/TMP复原；产品、作者测试、PWF、Git、兼容primary未写，无模型/SDK/PDF/下载。ROOT已明确唤醒SOURCE作者修v3；保留本轮和首轮RED，待新冻结定向复验。
