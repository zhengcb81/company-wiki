# Source support-use v3 frozen handoff

Status: **FROZEN_READY_FOR_INDEPENDENT_RECHECK**. The same five files are frozen; all raw/LF SHA-256 values are in `handoff-v3.json`. Prior v2 handoff and independent RED receipts remain unchanged. Since v2, only `narrative_source_purpose.py` and the owned `test_source_support_use.py` changed. No other owner, configuration, PWF, original source, Git or consumer files were written.

The common defect was evidence precedence inside the existing source clause-purpose owner: an untyped accounting keyword could override a complete, same-clause product provision/function relationship. The existing shared typed descriptive proof now precedes this weak keyword hint. Actual valuation, incentive, result definition, reporting, audit, allocated-financial and treasury rules still precede it. Broad legacy business-word detection remains below accounting cues. No financial-product phrase whitelist, company/locator/task condition, new text classifier or resource increase was added.

Neutral English/Chinese coverage includes supplied software and actual customer functions with several financial modifiers, against accounting use/measurement, software costs, policy statements and unrelated product words across sentence boundaries. Upstream purpose, real SourceOperatingSession and early candidate/support-use paths are exercised. The /4 citation support-use contract, exact support membership, old schema consumer compatibility, no context donation, no stage inference and shared bounded account are unchanged.

Validation:

- Initial `v3-red` was a collection error because the independent file imports its sibling helper; retained explicitly and not counted as effective RED.
- `v3-effective-red`: 16 passed / 2 failed, reproducing both independent product-provision counterexamples before the source fix.
- `v3-product-role-red`: 7 passed / 5 failed, independently establishing the common modifier-role defect across the new neutral boundary package before the source fix.
- `v3-targeted`: **130 passed**, 5.21 s pytest / 6.185 s runner. This contains 83 owned source cases, 18 independent cases replayed by the author, and 29 saved actual-scope controls. The original first-12 exclusions, ten retained meaningful scopes and accounting/incentive controls remain green.
- Ruff: four source files plus owned test PASS. Mypy: four source files PASS, no cache writes. `git diff --check` PASS (existing line-ending warnings only). Raw evidence is in `v3-static.json`; test commands, timings and temporary-directory cleanup are in each JSON receipt.

Frozen v3 LF hashes for changed files: purpose `eef28a73c6e4cbee98811010845b0541bf11b06209dbdaab9b3008424389e5e8`; test `47e42e559f28e6fc904c92203e36e09623a179a63e53b0f430f82c33d9930867`. The other three match v2. `.c3su` is absent, child checks completed, and nothing was committed by this author.

The saved replay uses the existing 112 spans and 55 sent scopes with real source analysis and original IDs, without expected-metadata fabrication. It does not prove a new full-source selection or final model output. No PDF, SDK, model, network, download or new holdout access was performed. Remaining work belongs to ROOT: non-author v3 recheck, combined impact suite/public worker and RF/SW integration, fresh native-only source replay and eventual actual configured summary validation. Source author is now frozen.
