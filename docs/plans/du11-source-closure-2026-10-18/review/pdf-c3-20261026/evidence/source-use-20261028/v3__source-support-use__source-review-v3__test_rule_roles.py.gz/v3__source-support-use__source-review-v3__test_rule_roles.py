import pytest

from test_independent_source import assessed


@pytest.mark.parametrize('text', (
    'We provide fair-value measurement software to banks.',
    '公司向银行提供公允价值计量软件。',
))
def test_measurement_as_supplied_product_modifier_is_not_a_measurement_rule(text):
    result, packages, evidence = assessed(text)
    assert result[0] == 'support' and packages, (text,result,evidence)


@pytest.mark.parametrize('text', (
    'We measure equity investments at fair value using software.',
    '公司使用软件按照公允价值计量股权投资。',
    'Our auditor tested the valuation software as part of audit procedures.',
    'The treasury approved wealth management products using idle cash.',
))
def test_actual_valuation_audit_and_treasury_rules_stay_context(text):
    result, packages, evidence = assessed(text)
    assert result[0] != 'support' and not packages, (text,result,evidence)
