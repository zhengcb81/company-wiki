# W12 H1跨run重复付费：独立根因与实施建议

结论：不是FMP/LLM供应商或额度问题。这里有两个共享设计问题：文档读取未完成被等同于因果依赖清单未完成；缓存快速判定又把“无法证明可直接复用”压成“没有缓存”，没有在付费前核对当前实际模型输入是否已付过费。

本轮仅只读源码、executor的comparison-v2及实际catalog/trace导出，运行纯内存探针；不改产品/测试/原件/DB，不调用API、下载或重解析PDF。旧账和旧partial记录未更动。初版comparison.json哈希对象选错，已被v2明确撤回，本报告只用v2。

## 已证实链路

1. 两次正式base generation为`274b727b4ec2b1dfff4915f8ed7aa69c226235b7745c71bc001b92419366a2a9`，formal配置、来源、当前根/策略及完整generation一致；visible base候选实际有两个，不能称“找不到来源或产物”。
2. `source_catalog/narrative_reading.py`在`build_decision_trace`完成后，因source WorkBudget耗尽或work_budget_exhausted诊断，覆盖`trace.inventory_complete=False`。实际freezer只报调用方INVENTORY_INCOMPLETE/NOT_COMPLETE，没有freezer自身max_rows/bytes/work截断诊断。
3. `current_decision_trace`继承frozen partial；`current_reading_decision_matches`在status不是complete时直接False；`find_reuse_pin`跳过候选。独立fake-store探针用两个真实metadata重现返回None、公开artifact read调用0次。原文/产物并非已复核后被否定，而是还未读就被partial跳过。
4. `BudgetedNarrativeModelCaller._recover`只恢复同一(run_id,job_id)操作的已付attempt。新run没有本操作旧attempt，正常走reserve/POST；因此上游错过跨run artifact复用后，下游不会替它消重。这个同操作恢复合同本身应保留，不能挪用旧run的lease/收费归属。
5. 用真实已记录的两个scope（root及pdf-native-intent）、profile binding、PDF carrier/frontend/capture、parser matcher、16M work limit重建已知因果域，scopes/components/candidates/versions四组身份行与原partial全部相同，可以完整枚举。这个“complete=True”的**反事实诊断**不改历史，也不等于未读正文已读；把它与旧partial比较，严格比较器依然正确给unavailable/FROZEN_PARTIAL。

细节与SHA见`inventory-and-cache-probes.json`。原始unit_profiles/pipeline运行覆盖仍由executor/ROOT真实小夹具补足：若有真实scope矛盾、缺绑定或缺frontend，build_decision_trace自身的False必须保留。

## 推荐的共同根修

**一、分清两种完整性。** source selection/unread/native frontier/work_budget_exhausted描述“本次读到了多少”，应继续保持partial。dependency inventory描述“已执行的路由/策略/匹配器/版本及候选是否已完整记账”。后者由现有inventory owner实际字段判定，不再仅因正文读取预算耗尽覆盖它。不可把全部source/reading_context补成complete，也不可忽略真正缺scope/矛盾/缺parser或freezer截断。

**二、缓存结果保留same/changed/unavailable语义。** partial与缺证明继续不能得到dependency same；但它们也不能直接等同于允许再次付费。对refresh=false的相同来源请求，在模型预留前走一次现有canonical来源确定性重选。复用原件、当前解析器/策略/配置及相同资源规则，不下载、不提高额度、不另建任务库。

**三、旧partial通过新验证免费兼容。** 当前重选后重新构造真实模型请求，核对当前与已付操作的逻辑model input SHA、实际HTTP字节/哈希、模型/endpoint/参数/协议，以及原件SourceRef、源事实/角色/quality、完整support/context及选择/物料绑定。只有当前实际重选和请求精确一致，才复用对应已验证产物/已存回复；不是“两个partial一样就same”。

优先复用经当前公开source/locator读取和generation物料验证的既有canonical artifact，并留下“reused_after_verified_reselect”诊断及原付费lineage。若当前包装/选择元数据确有变化、须新artifact，则用已存provider回复交给当前decoder/validator重建，不再POST；新产物绑定当前真实选择，并引用原paid attempt。不要覆盖旧manifest、把旧partial重签complete、把旧费用记到新run或把历史原始回复替换成新日期。

**四、真正输入变化才走授权范围内新调用。** source bytes、当前可用性/身份、model/provider配置、协议或精确输入变化不能命中此回退；corrupt候选/回复不能被吞成普通miss后自动收费。实际缺证明要保留原因并完成能做的免费验证，不新增逐材料许可/签收JSON。显式refresh意图仍由现有请求合同处理，不做永久禁止同输入再次运行的全局门禁。

**五、同输入的并发也要归同一责任层。** 复用现有AUTO Store的lease/原子预留/outbox恢复，在查找已付结果与新的付费预留之间避免两个不同run同时重复POST。不要通过改run_id或新建第二缓存/任务库绕过原收费账本。

## 最小必要验收组

- 实际H1小夹具：读取预算耗尽、source仍partial，但已知完整因果inventory可缓存；同时保留真实missing-scope/矛盾/frontend缺失/freezer预算截断的partial拒绝。
- 旧partial不改、不直接返回same；两个run同公开refresh=false入口、不给显式旧pin，第二次当前重选/精确输入验证后0新增POST/费用，保留两笔已发生旧收费。
- 当前输入或角色/限定/quality/来源字节/provider/协议改变必须拒绝旧结果；corrupt exact candidate不能默默触发再次收费。
- 正文partial、112选择/2767候选/4224来源unit和未处理范围不改变成全文完成；源卡正文与归属保持。
- 同输入并发及已付后中断恢复用现有Store证明至多一次POST和正确费用归属；不扩全量测试或小节点审签。

本报告是根因建议，不签未来实现。关键代码修复后再对真实免费delta与跨run公开入口做同节点独审。
