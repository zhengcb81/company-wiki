# 共享缓存重选修复：最终独立审查

**通过。** 未发现本节点主要代码或复用安全问题；限于“已有来源与产物的跨run缓存复用”，不代签全文内容、生成式摘要、完整公司RF/审查循环。

当前源码/测试SHA、实际GREEN绑定和逐项结论见 `final-cache-reuse-review.json`；自有输入重建及正反例见 `material-proof-and-negative-probes.json`。本审查未运行全量、作者脚本、API、下载或原始PDF解析，未写产品/测试/DB。

## 架构与证明

Worker和免费当前选择共用公开`select_source`核心，保留raw/official_json各自原来源路径；调用方只提供既有lease/deadline checkpoint，没有伪造Job或另建selector。raw与canonical official projected缓存入口同用ReadingReuseVerifier。快速依赖证明能成立时保留原快路，否则每次候选扫描最多一次真实当前重选。

证明不止原文quote SHA：`reading_material_sha256`包含subject/ref、source_metadata、selection覆盖/计数、完整evidence的原文/角色/quality/parser/locator、全部reading_context与实际sent-policy/闭包、transcript lineage/byte bindings。formal base另绑模型/endpoint/参数、projection、parser/renderer。候选manifest先校验自身generation/hash；匹配后仍走原有公开pin/source字节/locator回放与generation验证。旧partial没有改成complete，也没有把dependency unavailable改成same。

实际从两份旧H1 JSON bundle＋正式metadata还原Select，在内存中重建真实请求，两者均精确得到原native模型尝试SHA `e45bd06ce12ed100433ec30305dcc2652cbb9db2cdddd0e305a5dec086e89f94`；HTTP33858B/SHA `d2f363f800bd1ec652e8a8eca351e80192f3fbb0ef9aca45a683ae03b288028c`。这直接证明当前共享物料hash所覆盖字段足以还原该次实际model输入，并非仅比较两个partial字符串。

重建时按caller真实形状使用未绑定output budget的logical input SHA；HTTP adapter内部绑定8192。预先with_output_budget会改变logical SHA但不改变HTTP，这是调用包装差异，不是产品不一致。

## 独立反例与证据优先级

当前材料一致能匹配；标题或候选覆盖计数改变拒绝；角色/quality/locator/原文/context字段的hash表面变更均拒绝。后五项明确只是hash覆盖探针，不冒充合法新物理来源观察。canonical重选超时传播，不被吞成可花钱的miss；格式损坏的matching manifest在任何重选/公开read前拒绝。

新增优先级根修正确：一旦已经实际观察当前material，后续候选fast=True不能压过已观察的不匹配。自有内存负例确认两次均拒绝，只重选一次，第二候选不再调用fast证明。ROOT真实GREEN之后仅增加了这条guard；已逆向单行核对与GREEN时源码一致，不需再解析整份PDF。

## 真实公开入口GREEN

`r1-w12-h1-cache-green1-20261101` / capture `bc3a09b0b45a4932a88864a4fe9db0d6` 使用refresh=false、总token预算1，native completed/generation_status=reused，返回原exact `narrative-91d5a6412b364914988805598f62fb9f` / SHA `54ccb82a5e14db1a427dc66e485d58298b55f0e186e44c5e7bcc050ea8a0e895` /473666B。

新增reservation/POST/收费均0；四条旧reservation及时间戳、usage日志SHA、两份旧artifact字节均未改。母账前后同为1,955,397 tokens/$0.760197，unknown8与旧unknown7保留，不退账不重签。真实12.2436秒包含当前source重选/定位回放；“0新增POST”不被写成“0解析或0工作”。

这次公开入口未注入旧pin，覆盖了此前只测同操作恢复/显式确切artifact复用未覆盖的自动发现路径。source仍partial（112选择/2767候选/4224原始单元），未宣称整文件或未处理部分已完成。

ROOT短域137P、公开source/Worker实际输出/5 logical及HTTP等价、canonical projection、宿主candidate/payed-worker16P以及最终证据优先级单测结果已记录核对；不再重复全量。代码/实际GREEN SHA与历史失败分类见JSON。
