"""Offline independent fixture/AST probe; never imports the model runtime."""
from __future__ import annotations

import ast
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))
from tools.changed_unit_tests import _dynamic_execution


def sha(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def canonical(value) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()


def lf(value: bytes) -> bytes:
    return value.replace(b"\r\n", b"\n").replace(b"\r", b"\n")


legacy_path = "tests/fixtures/atomic_recipe_legacy_requests.json"
legacy_bytes = (ROOT / legacy_path).read_bytes()
baseline = subprocess.run(["git", "show", "93f561ef:" + legacy_path], cwd=ROOT,
                          capture_output=True, check=True).stdout
assert lf(legacy_bytes) == lf(baseline), "legacy frozen capture was rewritten"
legacy = json.loads(legacy_bytes)
current = json.loads((ROOT / "tests/fixtures/source_extractive_compact_request.json").read_bytes())
assert current["selected_input_sha256"] == sha(canonical(legacy["selection"]))
assert current["predecessor_input_sha256"] == legacy["requests"]["reading-model-input/5"]["input_sha256"]
old = legacy["requests"]["reading-model-input/5"]
new = current["request"]
assert set(new) == set(old) == {"prompt_version", "instruction", "data_json", "input_sha256"}
assert new["prompt_version"] == old["prompt_version"]
assert new["input_sha256"] != old["input_sha256"]
assert new["data_json"] != old["data_json"]
assert new["instruction"].startswith(old["instruction"])
assert json.loads(new["data_json"])["material"]["schema_version"] == "source-extractive-ranking-view/1"
production_path = "src/company_wiki/automation/narrative_model_extractive.py"
prior_source = subprocess.run(["git", "show", "93f561ef:" + production_path], cwd=ROOT,
                              capture_output=True, check=True).stdout.decode("utf-8")
actual_source = (ROOT / production_path).read_text("utf-8-sig")
restored_source = actual_source.replace("import sys\n", "").replace(
    "'protocol': sys.modules[__name__]", "'protocol': __import__(__name__, fromlist=[''])")
assert ast.dump(ast.parse(restored_source)) == ast.dump(ast.parse(prior_source)), "unexpected product AST delta"
assert _dynamic_execution(ast.parse(prior_source))
assert not _dynamic_execution(ast.parse(actual_source))
assert _dynamic_execution(ast.parse("module = __import__(selected_module)"))
assert _dynamic_execution(ast.parse("from importlib import import_module as load\nload(selected_module)"))
assert _dynamic_execution(ast.parse("import subprocess\nsubprocess.run(argv)"))
result = {
    "schema_version": "independent-p1-contract-probe/1",
    "legacy_frozen_fixture_preserved_lf": True,
    "legacy_lf_sha256": sha(lf(legacy_bytes)),
    "same_selection_current_wire_exact_four_fields": True,
    "predecessor_request_sha256": old["input_sha256"],
    "current_request_sha256": new["input_sha256"],
    "false_dynamic_self_import_removed": True,
    "only_product_ast_delta_is_equivalent_self_module_lookup": True,
    "unknown_import_and_subprocess_remain_dynamic": True,
    "network_calls": 0,
    "model_calls": 0,
    "source_or_config_writes": 0,
}
Path(__file__).with_name("contracts-probe.json").write_text(json.dumps(result, indent=2) + "\n", "utf-8")
print(json.dumps(result, ensure_ascii=False))
