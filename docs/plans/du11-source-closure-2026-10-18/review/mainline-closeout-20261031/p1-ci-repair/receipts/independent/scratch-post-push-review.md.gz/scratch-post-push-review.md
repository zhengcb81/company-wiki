# 正常push新发现的W22临时边界复审（追加，不覆盖原签名）

最终结论：**PASS_NESTED_SCRATCH_TEST_CONTRACT / 0 OPEN**。追加绑定见`scratch-post-push-seal.json`。旧`review.md/json`与`seal.json`继续只签原版本合同及有界选测候选，原文件/签名未改。此次追加只审正常push新暴露的W22夹具/清理共因，不代签下一次正常push或远端CI。

真实结果：本地commit fb2336c1正常push被拦，远端仍93f561ef。`../p1-ci-repair-push.log`显示651项真实运行、642P/9F/120.29秒，后续父scratch清理又报WinError145。选测把此前未选到的W22文件带进来，并在失败时拒绝发布，不能为绿色移出它们、提高60/180或忽略清理异常。

## 共同根因

生产`_open_scratch`检查真实绝对路径的UTF-16 units + 实际命名预留14 <=60。外层gate basetemp45合法，却不为测试中下一层gate再预留14。`mktemp('g')`加3到48，再`/good`加5到53，下一层scratch需67；`/env-temp`到57需71。接收测试的`mktemp('s')`是48需62。它们是正例夹具错误，不是生产应接受这些路径。

三个阶段还被混淆：exact-budget测试basetemp45时padding0，尚未构造其所需独立子目录；late-created-name测试先因root48+14>60被preflight拒，未进入它本来要测的真实创建后超长/清理分支；write-denied测试的denied候选过长，甚至没进入ACL probe。不能只改异常断言从而失去原阶段保护。

`test_non_bmp_parent_uses_win32_length_budget`通过`\\?\\`真实创建约240UTF-16 units parent和>259 units目标文件，却没有finally移除这个自有扩展路径树。普通父TemporaryDirectory清理无法遍历全部子树，留下80emoji目录，报Win145。测试本身写入/替换已经通过，现有证据不指向atomic_output内容替换失败。

## 最小共因修法建议

1. 两个模块共享test-only的短fixture根分配器，不改全局pytest钩子或生产gate。由测试所需最长后缀（当前正例env-temp/checkout各含分隔9）与生产reserve14反算fixture最大units，即60-14-9=37。按真实解析后的UTF-16路径度量，挑足够短且实际可写的宿主父目录，为本例新建唯一小prefix目录，并测量最终创建结果。没有可写合法根应明确失败，不mock成功或skip。
2. 正例先断言candidate units+reserve<=60，真实打开scratch再断言actual<=60与清理为空；负例保留超预算即拒且不probe。exact60按实际长度补齐而非靠描述名，late-name例必须让初始root通过再真实创建超长，然后证明无残留。所有相关断言读生产常量，不抬上限。
3. 所有故意创建长/非BMP目录的测试从创建开始进入try/finally，以自身创建parent的扩展路径执行rmtree并确认不存在。只删本例自有目录，不能删pytest/gate基底，也不使用ignore_errors掩盖泄漏。
4. deep-cwd测试先用monkeypatch.context包chdir/atomic/assert，退出恢复cwd后才能finally删除parent。否则Windows仍在该cwd会拒删。共享fixture的兜底清理也应使用扩展路径且只覆盖它自己的唯一目录。
5. 集中复验两文件（真实成功、失败返回1、timeout124、路径60/61、late-name清理及非BMP/deep-cwd）与一次接近真实外层45-unit basetemp的受影响短域。正反例都恢复测试目录。先不重复32文件/120秒，等短域过绿再正常push；不收费/解析/下载。

本child只读生产/测试和技术日志，未改产品/测试，未运行pytest/网络/模型/原件。最终delta与收据齐备后追加SHA签收；原独审PASS作为历史保留。

## ROOT第一轮候选与实证（仍待最终delta）

共享`tests/support/gate_scratch_fixture.py`按最长missing-a后缀10、生产reserve14和真实已创建路径计量；两个模块已复用。长路径两例从创建起finally扩展清理，deep-cwd用局部patch先恢复cwd再删。生产代码/上限/32文件选择未改。

ROOT模拟真实外层45-unit TEMP/basetemp，19项18P/1F/20.88秒；非BMP/deep-cwd及嵌套真实child/边界项已通过。唯一新失败是旧`test_without_temp_env_the_standard_tempdir_is_a_candidate`写死standard temp必须排第一：新fixture checkout43短于host TEMP45，生产正确将checkout放前。应继续精确断言候选全集及按真实units/path排序，不只放宽为包含，也不强行改变生产排序。

已向ROOT提出helper本身的bounded分配问题：对可能拒写parent直接TemporaryDirectory会重新触发W22正在保护的Windows拒写重试TMP_MAX情形。先测父路径预算并做一次真实mkdir可写探针，随后实际分配/再次计量。没有建议通过换ignore_errors、删文件或提高限制换绿。

## 最终delta审查

三个测试所属文件改变：新增test-only共享分配器及两个W22模块。共享分配器读取生产常量，计算最长子路径UTF-16长度，先排除必然过长父路径、调用已有一次mkdir可写probe拒绝不可写父目录，再真实分配并测量最终root+子路径+reserve，失败即清理。本例完整目录只由创建它的fixture移除，不清理祖先、pytest或gate外层。

既有核心断言全部保留：真实child成功0、失败1、timeout124，TEMP/TMP/TMPDIR/SQLITE_TMPDIR同一owned scratch、不可写根回退、所有根失败列举、超预算在probe前拒绝、精确60接受、61拒绝、真实创建后名字变长必须清理且拒绝。all-unwritable新增`candidate path too deep`不能出现，确保确实测到可写性阶段。系统temp缺省候选测试现在精确检查全集并以独立UTF-16/path排序，不强行假定host temp最短。

非BMP与deep-cwd仍真实创建/替换长路径，不改成mock；finally以扩展路径删除自身创建的parent并确认不存在。deep-cwd先退出局部monkeypatch恢复cwd再删，修复Windows句柄所有权顺序。没有ignore_errors或吞清理异常。

ROOT最终`../p1-nested-scratch-final.log`：**19P/13.28秒**。`../p1-nested-scratch-final-receipt.json`记录真实外层45 UTF-16 units（与失败push相同形态）、返回0、总计17.9139秒、owned_outer_removed=true。原642P/9F/Win145及第一轮18P/1F仍保留，不把它们改写成首次成功。

相对本地fb2336c1，生产src/tools与CI workflow无delta，既定60/180/32限制未改，未移除两个选测文件。child未重新运行两文件或整32，只审ROOT实际短域及清理收据。该节点可正常提交/推送，精确CI与发布状态仍由ROOT后续验真。
