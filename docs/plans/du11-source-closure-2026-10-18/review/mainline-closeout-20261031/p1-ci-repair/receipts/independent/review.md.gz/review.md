# P1 CI版本合同与日常选测独立审查

最终结论：**PASS_P1_CI_CONTRACT_BOUNDED_SELECTION，0 OPEN。** 审查绑定当前HEAD93f561ef之上的工作区候选，14个文件的raw/LF SHA见[seal.json](seal.json)。允许ROOT正常提交、推送并观察精确CI；不代签尚未发布的CI结果。

范围：CI41261403683 / 93f561ef的三个失败及同一发布的pre-push选测共因。审查只读产品、测试、已有技术日志；自有证据仅写本目录。无网络、收费模型、原件、全量测试、共享PWF改写。

## 根因

1. allocator已明确发布`source-card-allocation/2`，旧两项测试继续固定`/1`。ROOT原节点本机3F/6.66s与远端annotations一致，不是Linux特有失败。候选仍精确断言`/2`、真正工作区owner文件路径，并通过版本mutation要求boundary identity变化，保护没有删除。
2. `/5`仍为摘录卡/advisory ranking产品路径，本次有意以`source-extractive-ranking-view/1`替换私有HTTP材料表示并增加列/索引说明。旧测试把“所有旧文种协议不变”误延伸到这项明确迁移。应保留旧捕获、单独冻结当前wire；当前实现保留`/4`、`/6`精确历史比较，`/5`也继续完整四字段精确比较，绑定相同selection和predecessor request SHA。不是允许任意指纹或删HTTP断言。
3. 旧`__import__(__name__, fromlist=[''])`只需取得已加载自身module，却让保守selector在分析依赖前直接推荐全量。日常gate出于既定速度边界把全量推荐折为smoke；该行为本来明确写`full_validation_pending`，但已知受影响测试同时丢失。ROOT该次实际只跑167P/38.45s，两个失败文件未跑。
4. 改`sys.modules[__name__]`等价且消除虚假dynamic，但ROOT实测仍推荐416 unit文件、耗36.878s，然后再次折为35 smoke。后半段将仓内未变dynamic执行种子与已知影响混成同一集合，共同触发>32全丢。故只消自导入不足以修漏检。

## 直接证据

- ROOT原始失败：`../p1-new-ci-red.log`；远端已有公开annotations：`../p1-current-failed-annotations.json`。
- ROOT四个相关文件：`../p1-new-ci-green.log`，54P/5.85s。它证明候选合同短域，不代签全仓/远端CI。
- ROOT旧push范围：`../p1-selector-current-probe.json`；416 unit推荐被折为smoke，两个失败文件均不在actual targets。
- 独立`contracts_probe.py`/`contracts-probe.json`通过。legacy fixture规范LF逐字节等于93f561ef（SHA637098faecaea0996026d43f86e60be461ed09e34506ecdd4950fe6f0f2a0e9f）；新旧完整四字段、同selection、显式predecessor、compact schema均被验证。
- AST独立正反控制：原self-import为dynamic，当前sys.modules不为dynamic；真实未知import、aliased importlib及subprocess仍为dynamic，没有放宽扫描规则。
- 既有精确旧artifact兼容技术日志：`../p1-huali-old-artifact-compat.log`记录0 POST / 0新selection / 0下载及locator replay。此处只审技术收据，不重读原件或重复付费。

## 最终选测修复

ROOT在既有selector增加明确的`known_only=True`日常模式，复用同一AST/reverse graph。默认调用仍保守保留原全量推荐与动态执行保护。日常按changed whole test优先、最短静态距离、路径稳定排序，gate只取32个unit文件并加既有去重smoke。无已知消费者仍推荐smoke，唯可信非运行文档范围可以零测试；语法/图失败仍回退smoke。没有第二套图、此次失败名单、公司特判、逐commit全量或新许可。

ROOT最终实范围`p1-selector-known-probe.json`耗10.637秒，保留32/352个已知unit，延期320个及279个nonunit推荐。旧source_priority在32内，旧atomic_summary_recipe仍在32外，**不能称原三例都保证被旧范围hook发现**。当前修复变更atomic文件自身，按距离0优先。日常只提供有边界的已知保护，最终完整CI保持原责任。

独立`known_probe.py`四组全部通过：混合config/resource/deleted/dynamic输入仍保留changed test与距离1/2消费者；未知-only不变成零目标，docs-only零目标；41取32延期9且whole-file/smoke去重；实际gate.main一次请求known_only并声明`full_validation_pending`。自有微型scratch已恢复，没有启动pytest或触碰原件。

既有gate的启动失败、真实失败、timeout传播与180秒pytest上限未放宽，CI workflow与legacy请求fixture对93f561ef按LF逐字节相同。独立AST验证唯一产品源码变化为`import sys`和等价自身module lookup；未知import及subprocess仍按default保守识别。

## 最终回归与已闭合小点

- ROOT source/wire短域54P/5.85秒，保持完整request四字段与新旧版本合同；非全仓证明。
- known_scope真正TDD为6F/1P→7P/.79秒；真实Git动态源＋已知失败测试阻止push的E2E在后续短域内通过。
- gate相关域185P/1F/68.86秒的唯一失败是旧测试要求“config混显式变更失败unit仍能push”。新策略应阻断该已知失败，不能为了绿保留错误旧要求。ROOT保留覆盖目的，改为先发布绿baseline、仅改config触发既有unit失败、fast明确延期、显式full必红的真实Git E2E。修正单例1P/27.46秒；不是删除该保护。
- 独审发现该新fixture直接import tomllib与>=3.10不兼容，ROOT已改为自身微型fixture固定ready文本开关，无新增依赖；最终单例`p1-gate-unknown-portable.log`为1P/24.33秒。该小点 CLOSED，不要求重复185个已绿项。
- Ruff：`p1-ci-final-ruff.log`通过。
- `p1-final-ci-delta-replay.log`记录两份已付费真实请求data、完整draft、execution完全相同的免费重放。此次self-module lookup自身文件SHA成为额外实现依赖delta，旧已付费签名不重写；不因此重复付费。

计数有重叠，不把上述数字累加成唯一用例总数。历史3F与阶段6F、旧策略1F收据保留，不能改写成初次即绿。

## 签收边界

本次不审P3新公司研究，不替换P1/P2实际摘要/RF采用独审，不签全仓测试或项目全部完成。最终14文件与11个ROOT收据已绑定[seal.json](seal.json)，独立探针结果为[contracts-probe.json](contracts-probe.json)及[known-probe.json](known-probe.json)。远端精确CI须ROOT发布后观察；本报告不预告其成功。
