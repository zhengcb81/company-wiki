"""Independent small synthetic caller-path probe; never launches pytest."""
from __future__ import annotations

import contextlib
import io
import json
from pathlib import Path
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))
from tools.changed_unit_tests import select_unit_tests
from tools import pre_push_gate as gate


def put(root: Path, path: str, data: str) -> None:
    target = root / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(data, "utf-8")


base = Path(__file__).parent
results = []
with tempfile.TemporaryDirectory(prefix="known-", dir=base) as name:
    project = Path(name)
    put(project, "src/pkg/__init__.py", "")
    put(project, "src/pkg/core.py", "module = __import__(target)\n")
    put(project, "src/pkg/wrapper.py", "from pkg import core\n")
    put(project, "tests/unit/test_near.py", "from pkg import core\ndef test_near(): pass\n")
    put(project, "tests/unit/test_far.py", "from pkg import wrapper\ndef test_far(): pass\n")
    put(project, "tests/unit/test_changed.py", "def test_changed(): pass\n")
    put(project, "tests/unit/test_noise.py", "from importlib import import_module\nimport_module(target)\n")
    changes = {"src/pkg/core.py", "tests/unit/test_changed.py", "config/runtime.yaml",
               "tests/fixtures/current.json", "src/pkg/deleted.py"}
    expected = ["tests/unit/test_changed.py", "tests/unit/test_near.py", "tests/unit/test_far.py"]
    selected, reason = select_unit_tests(project, changes, known_only=True)
    assert selected == expected, (selected, expected)
    assert "only" in reason and "deferred" in reason
    assert select_unit_tests(project, changes)[0] == ["tests/unit"]
    assert select_unit_tests(project, {"src/pkg/core.py"})[0] == ["tests/unit"]
    assert select_unit_tests(project, {"src/pkg/core.py"}, known_only=True)[0] == expected[1:]
    results.append({"case": "mixed_unknown_keeps_changed_and_static_distances", "pass": True})

    for unknown in (None, {"config/runtime.yaml"}, {"runtime.ps1"}, {"src/pkg/deleted.py"}):
        result, _ = select_unit_tests(project, unknown, known_only=True)
        assert result == ["tests/unit"], result
        assert gate._push_targets(result)[0] == list(gate.FAST_CONTRACT_CASES)
    assert select_unit_tests(project, {"docs/plans/run/receipt.json"}, known_only=True)[0] == []
    results.append({"case": "unknown_is_smoke_docs_only_is_empty", "pass": True})

    wide = ["tests/unit/test_shared_reading_cache_precheck.py",
            *[f"tests/unit/test_owned_{number:03}.py" for number in range(40)]]
    targets, note = gate._push_targets(wide)
    assert targets[:32] == wide[:32]
    assert not set(wide[32:]) & set(targets)
    assert len(targets) == len(set(targets))
    assert all(node not in targets for node in gate.FAST_CONTRACT_CASES
               if node.startswith(wide[0] + "::"))
    assert "32/41" in note and "9 known files deferred" in note
    assert gate.DAILY_PUSH_MAX_AFFECTED_TARGETS == 32
    assert gate.DAILY_PUSH_TIMEOUT_SECONDS == 180
    results.append({"case": "wide_known_slice_and_whole_file_smoke_dedup", "pass": True})

    prior = (gate.PROJECT_ROOT, gate.changed_paths, gate.select_unit_tests,
             gate._dispatch_gate, sys.stdin)
    calls = []
    options = []
    try:
        gate.PROJECT_ROOT = project
        gate.changed_paths = lambda root, text: changes
        def choose(root, actual, **kwargs):
            options.append(kwargs)
            return select_unit_tests(root, actual, **kwargs)
        gate.select_unit_tests = choose
        gate._dispatch_gate = lambda command, label: calls.append((command, label)) or 0
        sys.stdin = io.StringIO("synthetic refs\n")
        output = io.StringIO()
        with contextlib.redirect_stdout(output):
            assert gate.main(["--push-checks"]) == 0
        assert options == [{"known_only": True}]
        assert len(calls) == 1
        assert all(item in calls[0][0] for item in expected)
        assert "tests/unit" not in calls[0][0]
        assert "full_validation_pending" in output.getvalue()
    finally:
        (gate.PROJECT_ROOT, gate.changed_paths, gate.select_unit_tests,
         gate._dispatch_gate, sys.stdin) = prior
    results.append({"case": "actual_push_main_requests_known_scope_once", "pass": True})

assert not list(base.glob("known-*")), "independent synthetic scratch was not restored"
result = {"schema_version": "independent-known-scope-probe/1", "cases": results,
          "scratch_restored": True, "pytest_processes": 0, "network_calls": 0,
          "model_calls": 0, "original_reads": 0, "source_or_config_writes": 0}
base.joinpath("known-probe.json").write_text(json.dumps(result, indent=2) + "\n", "utf-8")
print(json.dumps(result))
