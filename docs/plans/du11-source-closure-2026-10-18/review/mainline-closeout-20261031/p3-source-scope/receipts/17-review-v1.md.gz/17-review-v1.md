# Independent source-scope review — first actual-source result

**FAIL · 1 OPEN (P2), source-owner scope only.** This does not sign company research, a formal model summary, cache activation or RF adoption.

The real H1 D&M sentence is now selected exactly, with149.9/yoy72.7 and its complete period/business context. Both p14 actual technical service paragraphs remain candidate-but-unresolved and unselected. The simplified adjacent service-list examples pass, but they do not exercise the real comma/function-range word order and shared source owner. See `review-v1.json#/findings/0` and the3 exact original targets in `canonical-source-targets.json`.

Exactly one canonical selection ran in7.632s:112 selected/68closed citation views,15998058/16000000work, partial retained. The handler replayed every selected original locator, all closure IDs exist, source identity is consistent, and DB SHA/mtime/size stayed unchanged. There were0model calls, downloads, raw copies or writable-store opens. Three rounding notes remain separate support views; this observation does not make budget_full the omission's cause.

Independent57case comparison against c405848a preserves every source relation/binding and original text; repeated assessment reads are free. ROOT fixed the independently found dangling-member/new-subject false positives. A combined104cases pass; the added actual service word-order pair still has1failure. Full details,12-target mapping, exact5source/test LF and raw SHA, limitations and evidence paths are in `review-v1.json`.
