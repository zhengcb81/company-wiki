"""Independent boundary contracts for the shared closed-member proof."""
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / 'src'))

from company_wiki.document_understanding.operating_states.assertion_roles import prepare_source_assertions
from company_wiki.source_catalog.narrative_business_policy import prepare_reading_business_assessment


@pytest.mark.parametrize('text', (
    '公司的服务覆盖煅烧，远山公司尚未答复。',
    'Our services cover miralon, Riverton is unavailable.',
    '公司的服务覆盖煅烧、压延和烧结，并',
    'Our services cover miralon, tressiq while',
))
def test_nonmembers_cannot_complete_a_nominal_service_scope(text):
    roles = prepare_source_assertions(text)
    assert not any(clause.material_payload for clause in roles.clauses), roles
    assessment = prepare_reading_business_assessment(text, {'relations': []}, source_roles=roles)
    assert assessment.passage.use != 'support', assessment


@pytest.mark.parametrize('text', (
    '公司的服务覆盖煅烧、压延和烧结。',
    'Our services cover miralon, tressiq and zovren.',
    '公司的服务覆盖煅烧、\n压延和\n烧结。',
    'Riverton services covered miralon, tressiq and zovren in 2024.',
))
def test_closed_unfamiliar_service_scope_is_readable_without_state_proof(text):
    result = prepare_reading_business_assessment(text, {'relations': []})
    assert result.passage.use == 'support'
    assert not set(result.fact.reasons) & {'operating_current_state', 'operating_milestone', 'operating_plan'}


@pytest.mark.parametrize('text', (
    '由于计量错误，陶瓷业务收入并非人民币7.8亿元，同比增长17.6%。',
    'Because of an accounting error, our ceramic services revenue was not USD 7.8 million.',
    '得益于新产品，公司预计陶瓷业务收入将达人民币7.8亿元，同比增长17.6%。',
    'Because of a new strategy, our ceramic services revenue is expected to reach USD 7.8 million.',
    '请问由于新产品，陶瓷业务收入人民币7.8亿元，同比增长17.6%吗？',
    'Example: because of a new strategy, our services revenue was USD 7.8 million.',
))
def test_measurement_rescue_preserves_nonobserved_or_nonassertion_boundary(text):
    result = prepare_reading_business_assessment(text, {'relations': []})
    assert result.passage.use != 'support'


@pytest.mark.parametrize('text', (
    '得益于未核实的原因，陶瓷业务收入人民币7.8亿元，同比增长17.6%。',
    'Because of a speculative explanation, our ceramic services revenue was USD 7.8 million, up 17.6% year over year.',
))
def test_measurement_rescue_does_not_manufacture_cause_or_state(text):
    result = prepare_reading_business_assessment(text, {'relations': []})
    assert result.passage.use == 'support'
    assert 'business_revenue_measure' in result.fact.reasons
    assert not set(result.fact.reasons) & {'operating_causal_driver', 'product_operating_driver', 'operating_current_state', 'operating_milestone'}


@pytest.mark.parametrize('text', (
    '公司已具备研发及生产能力，提供从原料到成品的端到端服务，涵盖煅烧及压延。',
    '公司能够利用薄膜、过滤及沉淀技术，为客户提供覆盖发现、研究及生产的一站式服务。',
))
def test_actual_service_range_word_order_remains_source_support(text):
    result = prepare_reading_business_assessment(text, {'relations': []})
    assert result.passage.use == 'support', result
    assert not set(result.fact.reasons) & {'operating_current_state', 'operating_milestone'}


@pytest.mark.parametrize('text', (
    'Tables software processes reports whose totals differ because of rounding.',
    'The figures our software processes may differ in the totals due to rounding.',
    'Figures may not sum to totals due to rounding, and our services cover miralon and zovren.',
    '注：上表各项加总有四舍五入差异，公司已经完成工厂建设。',
))
def test_rounding_note_cannot_erase_a_real_function_scope_or_independent_business_statement(text):
    result = prepare_reading_business_assessment(text, {'relations': []})
    assert result.passage.use == 'support', result


@pytest.mark.parametrize('text', (
    '注2：上表中单项之和与合计不等为四舍五入造成。',
    '表中金额受四舍五入影响，分项之和不等于合计。',
    'Note 12: the amounts shown in the table may differ from the sum due to rounding.',
    'Totals in the table do not equal the sum of components because of rounding.',
))
def test_arithmetic_rule_stays_context_after_mixed_business_guard(text):
    result = prepare_reading_business_assessment(text, {'relations': []})
    assert result.passage.use == 'context_only' and not result.passage.relevant
