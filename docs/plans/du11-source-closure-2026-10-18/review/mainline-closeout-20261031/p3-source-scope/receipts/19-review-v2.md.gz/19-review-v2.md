# Independent source/selection review v2

**FINAL PASS · 0 OPEN within the reviewed source/selection scope.** This closes the v1 P2 actual source-retention gap. It does not sign a formal model summary, cache activation, RF adoption, investment analysis or full-document completeness.

D&M149.9亿元/+72.7% is selected as the exact original sentence. Both p14 technical paragraphs are retained as original members of the selected519character native range at `page14/paragraph3/chars65-584`. I independently recomputed all8member text SHA values and sliced their absolute ranges against the carrier:8/8exact, contiguous0–519. High-activity/oral-injection[297,347), TFF/precipitation/continuous-purification[347,450), and final future wording are intact. Its support view and3context spans are same-source and closed. Equality against standalone paragraphs was an incomplete later oracle; it does not invalidate the earlier failed candidate, which remains frozen.

The final canonical observation is112selected/67closed views,15991162/16000000work,7.019seconds, partial coverage preserved. Three original rounding cards are no longer separately selected. The DB stayed unchanged during that read-only probe. I inspected the saved final evidence without another source selection or PDF parse.

Independent mixed-function/rounding regressions now pass.268related tests pass in3.92seconds;57original controls and30additional local cases preserve all source relation/binding arrays, original text and free repeated reads. The source-purpose behavioral override was removed. Exact raw and Git-LF SHA for6changed files plus the unchanged source-purpose dependency are bound in `review-v2.json` and match the tested code and final canonical observation.

The12target matrix remains9covered/3partial; it is not full-document recall. Full disclaimer/restatement-table/automated-bioanalysis detail boundaries remain explicit. The v1 failure and initial v2 regression evidence are preserved. No model/provider/download or production write was performed by this review.
