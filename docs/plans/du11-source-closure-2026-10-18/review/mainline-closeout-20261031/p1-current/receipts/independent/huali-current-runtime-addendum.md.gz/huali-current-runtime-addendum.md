# P1 当前版本华利：最终增补

**通过：当前版本华利15张原文卡、真实MiMo排名与恢复。** 不改此前Berkshire签收，也不以旧华利兼容读代签本次。

- 新run `phaseC-090-670ced72c918` 的完整production boundary与已验Berkshire一致，当前13个实现依赖SHA逐一相同；allocator/compact视图版本均一致。
- 当前严格observer对实际capture通过12/12业务原子。最终15卡文本、support/context归属逐项符合native闭包，与此前已逐项语义审查的华利原文卡内容完全一致：部分品牌/预计改善、部分订单2–3周/不提价、土地手续后1–2年、两期合计预计产能及分期/订单/建设/审批条件、汇兑币种/期间/正负、客户各<20%等限定未丢。
- 实际15决策：14 consider、1 unclear；当前decoder原始回复重放与保存draft/execution完全一致。原文没有由模型改写成新事实。
- 真实1POST，3304输入＋326输出＝3630 tokens，预算代理费用660microUSD（$0.000660，非供应商发票）；原始回复和实际wire事件SHA一致。HTTP12849B，沿用50000单次上限。
- 新body SHA `a466262de5251f0b4e2619eb88f1ba90e8188f5070bb1ea9881a7d5be08b3a45`。activation pending恢复、同run/跨run均保持相同active ref/body和计费；跨run收费记录为空。RF真实来源/叙述读取通过且内容相同，受保护文件未变、临时湖已清理。
- 母账1,849,869 tokens/$0.739510＝Berkshire后账加本次3630/660micro；unknown6/旧unknown7与累计限额保留。旧华利ec183…的精确兼容0POST结论也继续有效。

范围仍是已曝光开发样本的source quote＋advisory ranking，原始文档selection为partial；不是生成式摘要、全文完成或完整公司研究。新exact artifact的RF v6实际参数/公式/报告采用由P2另行独审，本增补不代签。

全部新请求/回复/原子映射/当前boundary/恢复/母账SHA绑定见 `huali-current-runtime-addendum.json`。本审查未调用API、解析原始PDF、运行作者脚本或修改源码/PWF。
