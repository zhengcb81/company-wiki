# P1 Berkshire根修：代码候选独审

未发现生产代码主要问题；正式运行待验收。文件SHA见同名JSON。未执行作者脚本、全量测试、PDF解析或API。

分层与保真检查通过：source-hint优先、同source同级按support坐标、不用context抢序、未知槽保留；原task/claim身份与canonical顺序不随预算分配重写。完整卡64KiB准入未改。新私有紧凑表仅呈现实际编译卡，原文/role/quality/source_key与support/context均保留；plan/execution/完整strategy哈希绑定仍在，新allocation与serializer依赖进入model generation。decoder仅认实际发送key，15未发任务不冒充模型已读，公开source/summary和其他生成协议未改。

测试检查覆盖行为而非镜像实现：group排列不变、hint与未知槽、完整闭包去重、只发送可发布卡、拒绝未发key及保留未完成状态。旧异常类型/旧material字典读法改为现typed拒绝和declared columns，没有删拒绝检查。

一项测试侧小孔已独立复现并通知ROOT：`reading_hints`字段用Python dict相等，score整数0改成False仍被observer接受。应改为type-aware/canonical比较并补负例。生产builder并不发错误类型，正确真实请求可以继续，不需要重复整域。

真实DeepSeek、10项业务的最终输出闭包、费用和activation/同跨run恢复、旧Huali exactartifact0POST兼容仍待同一节点实证；39520B请求形状是实际serializer免费检查，尚不是付费通过。
