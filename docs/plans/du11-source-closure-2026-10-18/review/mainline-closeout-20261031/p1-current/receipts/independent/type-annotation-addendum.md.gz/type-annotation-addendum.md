# P1 最终类型注解增补

**通过。** 唯一新增生产变化为`ordered = []`→`ordered: list[SourceCard] = []`，无算法、预算或来源语义变化。当前文件SHA：`d4feb3ce9465e4d111e03eb82aa186e1b3865c95018a8e42eb31558830ba4c6e`。

独立证据：在内存中仅撤销这一行注解，文件SHA恰好等于真实付费capture中的allocation实现SHA，证明没有顺带改变其他代码。当前boundary相比旧付费版累计改变source_cards、execution_contract、source_card_allocation三个依赖；旧source-use报告“两依赖”保持当时事实，不改历史签名。

已核对`p1-final-typed-replay.log`中Berkshire及华利的请求data、完整draft和execution免费重放均PASS。负例夹具现在使用models._to_plain复制不可变DTO，ROOT报告两份新测试23P；该项不改变产品。

本增补不做全域、网络、收费或原始PDF读取。此前source quote＋advisory ranking、开发曝光、全文partial、Berkshire15条延期和P2独立采用审查等边界保持。所有SHA与具体依赖差异见同名JSON。完成后停止本项审查。
