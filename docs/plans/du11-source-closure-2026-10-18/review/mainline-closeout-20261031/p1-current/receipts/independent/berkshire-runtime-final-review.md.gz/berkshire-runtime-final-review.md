# P1 Berkshire有界根修：最终独立验收

**通过：原文卡片＋真实DeepSeek建议排名＋预算＋恢复＋旧artifact兼容这一范围。** 这是已曝光开发来源回归，不是blind holdout，不是全文完成、生成式摘要或整家公司研究。没有新增人工门禁。审查只读产物/代码，执行自有免费artifact检查，未运行作者脚本、PDF解析、API或收费。

## 已证实

- 源捕获为88任务，实际请求仅发送73张能完整进入canonical的卡片。当前严格observer逐fragment、source_key、role、quality、support/context索引核对原typed闭包，10/10业务原子均在；再对最终73张卡逐一证明正文等于support原文连接、上下文与native task完全一致。不是用全局原文有数字代替输出验收。
- BRK04的87.4%稀释持股、UK/Iowa/西部美国及管道归属现在在t78；BRK07的25年至2007年行业8.5%/Fortune50014.0%在t80，没有改成Berkshire或GEICO的实际2008回报。PacifiCorp的33→794MW、MidAmerican两项运营的$1.8billion风电支出、GEICO份额/续保/摩托及小基数/新商用车均保留，主体、流量存量、单位、相对时期和条件未改写。
- 实际DeepSeek回复含73决策：64 consider、3 unclear、6 redundant。原始回复SHA与native收费记录匹配；当前decoder对同一回复复现的draft及execution与实际保存结果完全一致。
- 15未发任务仍deferred/unprocessed，完整任务数88、source/model coverage均false，RANK_INCOMPLETE保持。余项逐task绑定及support/context locator列在JSON，不把剩余任务当无业务信息。整文件selection仍partial，96/246候选，原始272单元；即使页面计数22/22也不代表全文召回完成。
- 实际HTTP39520B，SHA `8b5b7d97d175652e2760cd7be585324d8f1ba104e298af5b9858e262f4415eff` 同时匹配捕获原字节和实际POST事件；输入界39648＋输出8192＝47840，低于原50000。canonical draft56995B低于原57344B子限额；未提高64KiB整体限制。
- 实际1POST：9342输入＋1122输出＝10464 tokens，预算代理费用4611microUSD（$0.004611，非供应商发票）。母账准确为1,846,239 tokens/$0.738850，等于旧账加华利8217/$0.001425及本次10464/$0.004611；unknown6和旧unknown7保留，无重置。
- activation held→resume、完成后同run/跨run复用，均保持相同active ref/body和同一回复/计费，native尝试仍1、跨run收费记录为空。最终body357059B，SHA `66c264bacdc562038fdfe15f2c9a8076d84b71cd694e37b7413be1feb05f234c`。真实RF来源读取成功，RF叙述返回的summary/evidence/context与此body完全一致。
- 当前生产boundary与付费capture generation完全一致。旧华利精确body `ec1831a2fdf2952a9a80aba0c9e5db65c8bc581ea5c0a10d53d01ef2faba52d8` 在新代码可正常读取，0新POST/费用/来源选取；必要locator回放执行、次数未计量。两个隔离运行清理和受保护文件检查通过。
- observer类型漏洞已闭合：当前严格检查对真实capture的score False、score0.0、priority2.0变体均拒绝；ROOT对应TDD红绿日志已核对。测试侧补强未改变生产付费body或版本，无需重付费。

## 排名建议的边界

唯一含87.4%的t78被模型标low/unclear，唯一含行业8.5%/14%的t80标low/redundant。这些建议并非删除证据的裁决，现有代码仍保留两卡，10项业务也全部通过；不构成当前内容遗漏。下游不得把这些标签直接变成破坏性过滤。

## 不代签

- 15条未处理余项及全文件完整性；
- 生成式自然语言概述；
- 用2008股东信做当前公司预测、完整SEC10-K或新share class识别；
- 这份新Berkshire artifact进入经济意义RF参数/公式/最终报告；
- 后续多市场公司holdout和完整买方研究循环。

来源仍为US/investor_relations，security_id、FY和publication均null；当前verified-open不能冒充历史publication。FF本例是精确SourceRef已登记，NOT_REQUESTED_ALREADY_REGISTERED，不能因此称下载矩阵已重跑。旧P2另有签收，不代签本次新产物。

当前代码SHA、原始请求/回复/selection/generation/bundle绑定、每卡闭包、15余项、账本与兼容恢复细节见 `berkshire-runtime-final-review.json`。
