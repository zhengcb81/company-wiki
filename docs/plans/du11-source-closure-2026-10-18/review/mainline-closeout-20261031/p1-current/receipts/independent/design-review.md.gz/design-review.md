# P1 Berkshire余项：设计独审

设计方向合理，尚不签代码或真实运行。只读原型及其JSON，没有执行作者脚本。

根因区分正确：真实选择88任务、72完整卡仅覆盖8/10必需业务，BRK04/07在后发现的native range中而非PDF缺失。原型73卡/10项与39458B请求仅证明设计可行，15个未处理任务和实际付费尚未通过。

集中实现/测试应覆盖六类风险，详见同名JSON：

1. source hint先于同级support坐标；context不能抢序，未知/非PDF坐标保留槽位，不把prototype的全坐标assert带入生产。
2. 紧凑表逐任务还原原文、source_key、角色、quality及support/context归属；负数/bool/越界索引和串任务不能通过，observer不调用生产builder生成自己的期望。
3. 现有observer把任何子集称repair_subset；需证明“因canonical预算发送已编译整卡”的独立范围，不放宽旧generative/真实repair合同。
4. decoder只认实际发送key；未发15个和模型未答项保持unprocessed，不靠改available_task_count冒成全源完成；原文卡正文不能由模型改。
5. HTTP owner量完整wire并预留，保持单次50000、canonical64KiB和累计旧账；不截断支持或提高限额。
6. 新视图/分配版本进入model generation/cache key；旧Huali精确artifact/P2读取继续兼容，其余PDF/来源schema/generative路径不变。

完成代码及真实DeepSeek后，在同一节点检查10项业务、实际卡片闭包、费用、activation及同跨run零重复POST、15条剩余任务。先前P2通过不代签新artifact。
