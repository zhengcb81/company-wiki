# P1 source-use验证修复：独立增补

**通过，无需再次付费。** 不改写Berkshire及新版华利已经完成的真实运行签名；本报告独立记录后续代码delta。

根因判断成立：compiler按source-owned generation reason区分“原文可读”和“可作为事实支持”，execution wrapper却重复用physical availability，并且只允许两种物理原因。新代码由共享support-use集合派生不可生成原因，wrapper复用同一个generation-reason owner并校验精确reason；并未把context-only/unresolved放行为事实，也没有新增审批门禁。

免费独立核对：

- 当前实际HTTP serializer重算Berkshire39520B及华利12849B请求，与各自真实POST捕获逐字、SHA完全一致。
- 当前decoder对两份原始回复重算的draft、每个claim及execution与各自原capture完全一致。
- 当前boundary只改变`source_cards`和`execution_contract`两个实现依赖及其复合decoder SHA；其余boundary字段不变。旧capture签名保留，不伪称新代码又做过一次付费运行。
- 在禁止联网的自有探针中，实际NarrativeSummarizeHandler分别处理context_only＋support与unresolved＋support均成功；仅生成真正support的卡，另一项保持unsupported/source_context_only或source_unresolved/unprocessed。
- 两个伪造反例把非support硬改admitted并添加对应事实卡，均被当前wrapper以source-owned whole-card availability不一致拒绝。

当前源码、测试SHA和原始请求对齐、负例拒绝信息、TDD红绿日志见 `source-use-delta-addendum.json`。本审查无API、模型推理收费、PDF解析或下载。

此前范围不变：已曝光开发样本的source quote＋advisory ranking；Berkshire15条余项/全文partial、生成式摘要及完整公司研究不代签。P2数值采用继续归独立P2审查。
