# 配置身份与generation执行权恢复：独立根因设计

状态：DESIGN_READY v2，供ROOT实施；不是对候选实现或真实公司新attempt的PASS。范围只读scripts/config.py、原生AUTO/run/paid-response/lease/outbox合同及相关测试。未读取.env、生产配置内容、数据库、原件或密钥；无网络、收费、产品/测试修改。

v2审查更正：初稿将任意response_sha256等同可恢复完整响应，过于宽泛。ROOT指出且caller源码证实，异常_settle也会将failed_final.final_content_sha256写入此字段；它可能只是截断/无效最终正文的诊断hash，不能恢复canonical HTTP response。不能据此一刀切永久锁住显式新run。下文以paid_response_json所绑定的实际完整响应作为重用证据，诊断hash原样保留、原费用不退；这一更正保留为设计审查记录。

## 应修的两个共享根因

1. Config.load目前以参数是否为None决定初始化受管dotenv。同一canonical config从默认路径加载会取项目受管MiMo/MiniMax key，显式传入相同文件却沿用进程旧环境。问题是配置身份被调用方式代替，不是供应商模型应临时换名或再试一个key。应先取得Path并解析canonical身份，相同配置走同一初始化；模型/endpoint/生成参数继续取现有表。
2. `_generation_owner_finished`把“每条usage已知”当作执行权已结束。原生ledger已经将unknown作为保守计费终态：charged_tokens仍为input bound+output bound，费用仍为reserved_micro_usd，不退款。unknown与reserved不同，不能因计费永远未知就把来源generation永远锁住。反面也存在：原谓词允许known但输出失败的已付响应释放，可能绕过原run的零POST恢复。因此不能只将`!=known`改为允许unknown。

## 配置层的最小规则

- 解析默认`WIKI_ROOT/config.yaml`与显式config_path；resolved Path相同（含相对、`..`、平台大小写语义的合法别名）才沿用canonical项目dotenv初始化。
- 其他显式配置保持独立，不能因文件同名或后缀相同而加载host受管.env，更不能从任意父目录寻找密钥。不得为本公司加独立key路径。
- 沿用`_ensure_dotenv`/`_load_dotenv`一个owner，保留MiniMax/MiMo受管覆盖、DeepSeek环境优先/.env补缺、`PYTHON_DOTENV_DISABLED`与测试隔离，不向raw_config、提示或报告写key。
- 不扩展为全局重载框架、凭证指纹数据库或每次请求重读；若进程初始化已经正确，后续运行沿用原配置合同。真实轮换是新进程/既定配置生命周期的问题，不在本次额外设计。

## 核心决策：不是所有settled terminal都可无条件释放

新显式run可以接手**已明确完成、无待交付、无待回收已付响应的失败执行**，即使原计费unknown。原账原样保留，新run是新的明确请求，正常独立预算与母账继续执行。不能自动重试旧attempt、把旧unknown改known0，或通过改run_id抹掉旧消耗。

释放条件应在原生AUTO单一只读快照中成立：

| 责任 | 条件 | 不满足时 |
|---|---|---|
| run与job范围 | 原run存在、job成员全集/immutable绑定一致，所有job为既有terminal；无missing job、READY/RUNNING/VERIFYING/RETRY_WAIT | 保留原owner恢复 |
| attempt执行 | 所有attempt已finished且outcome完整；有reservation的attempt须有原生完成结果/已验终态receipt，而非仅reaper填时间 | 保留活跃/崩溃恢复，不因lease过期就放行 |
| usage | reservation是known或unknown且usage_settled_at存在；reserved或缺结算信息仍未结束 | 保留原请求的held reservation |
| output | 输出已独立settled；失败输出0/null SHA可成为完成失败，NULL输出仍是待恢复空间/发布责任 | 保留原owner，不能写0伪造结算 |
| effect/outbox | 通过实际effect_id→job/run外键检查，所有交付责任已完成；pending/leased/failed outbox、未清lease或缺应有ack仍待恢复 | 原outbox接着投递，不建第二队列 |
| 已付响应 | paid_response_json存在但没有完整发布/输出闭包时，必须原run零POST恢复；invalid/missing pinned bytes也不能当成无响应。单独response_sha可能为局部诊断，不是可恢复完整响应证明 | 有pin时保留owner并给现有机器诊断，禁止绕开再买；只有诊断hash的完整失败不新增永久锁 |
| 已发布正例 | 完整正数output+SHA及其成功summary→verify/ack闭包已由原生owner结算，既有catalog artifact复用已证明实际可见 | 不阻碍正常读取/跨run复用；显式refresh继续原规则 |

**crash不能只看finished_at。** `store.reap_expired_attempts`能填finished_at/outcome而不写result_json；caller可能恰在finish_attempt前已经结算usage和零输出。故`finished + settled + terminal`仍可能是reaped未交接。使用已有原生完成结果/终态receipt作为交接证据，无需按HTTP状态或错误消息分支。未完成attempt即使lease已过期仍拒绝。相反，不要求普通已finished attempt保存的历史lease_until必须小于现在：正常快速结束时lease_until仍在未来，真正活跃性由未结束attempt/当前generation及outbox lease判断。

VERIFIED effect本身不是pending的同义词：正常ack会在同一事务将effect置verified、outbox置delivered、清lease、verify job置succeeded。要读完整交付闭包；也不能只因outbox delivered就忽略catalog activation尚未完成。现有`_find_item_reuse_pin`/`_completed_read_history`已有实际可见artifact职责，继续复用，不让ledger自行读取物理来源根。

## 最小实现边界

1. 配置身份判断留在Config.load。无W12/公司名/401/provider响应字符串特判。
2. 执行完成事实归既有AUTO/run store，batch只消费其“可释放/仍需恢复”结果。优先复用同一只读连接/transaction读取run、jobs、attempts、reservations、effects/outbox，避免先读known再读另一时刻jobs的混合快照。可保留既有private函数作为薄适配，不引入新状态库、签收文件或审批。
3. 保留已有每DB batch mutex及每generation mutex；检查与pointer移交继续在原锁范围。只删除/替换经过核对的recovery pointer，保留原AUTO、paid对象、失败收据、预算和原文。不存在/损坏/不支持的历史DB fail closed，不初始化“空库”后宣称已结束。
4. `BudgetedNarrativeCaller._recover`保持same immutable operation、request/body/model/adapter/prompt校验；有charged历史但无可验证pin仍不能在旧run申请新HTTP allowance。新显式run的允许范围与旧attempt自动重发是两件事。
5. 完整发布路径继续优先读catalog的真实reuse pin；不要复制`settle_published_summary_output`已经负责的summary/verify/FinalArtifactPin证明到配置层或另一个contract层。仅output>0而无相应发布责任完成不是复用证明。

## 集中TDD与验收检查点

**配置短域**：fake临时项目与fake credentials，implicit/explicit absolute/relative canonical等价；受管MiMo/MiniMax覆盖继承旧值；DeepSeek既有环境优先，缺值才dotenv补；显式其他目录同名config与禁用标志不能加载host dotenv。检查model、endpoint、purpose options不变，序列化无fake key，临时配置/环境恢复。ROOT已报告正确RED4F7P→配置39P，待最终审候选时绑定实际日志，不在此设计签实现通过。

**原生unit**（一组参数化足够，不加小节点签收）：

- 原生finish+unknown/known+双结算、无response/effect责任：允许显式新run，旧reservation逐字段与budget逐值不变。至少两种一般错误，证明不认401字符串。
- known与unknown各自的reserved/usage timestamp缺失/output未settled/未finished/live lease/expired unfinished/reaped-no-result：均保留owner。特别模拟先settle usage/output后reap的race，不能凭finished时间放行。
- known-billing failed paid pin、unknown-billing paid pin、invalid pin：均不绕开原run重买；已完整发布/ack正例不被paid存在永久锁住。只有responseSHA的已完整settled失败应为正例，保留诊断/费用，证明不因局部hash误造死锁；旧attempt仍不自动resend。
- 真实effect/outbox的pending、leased、failed、delivered仍带lease、prepared/activation pending等保留；正常verified+delivered无lease可结束，外run的outbox不影响此scope。
- same run仍按原恢复，missing/corrupt owner/DB或job缺失不误放；predicate无数据库/账本写入。

**一个有界真实子进程/loopback集成**：模拟HTTP拒绝→原生未知费用/零输出→同AUTO新的显式run正常成功→同/跨run缓存复用不再POST，旧hold/attempt/error/pin不变；总两POST均为本机fixture、零收费。沿用已有prepared-activation恢复、已付响应decoder故障零POST恢复测试，确保新owner分类不能绕开它们。测试新来源/DB全部独立目录并恢复，不复制生产库或读密钥。

**大节点独审**：读最终delta、上述短域与原先paid/lease/outbox测试；必要只补最小反例，不全量重跑或提高额度。通过后正常提交/推送/精确CI，再由ROOT继续真实W12新attempt。两次旧真实401的unknown费用与第三次0POST拒绝原样保留，不将它们标成功或退款。

## 本次设计的事实范围

实读：scripts/config.py/common.py；automation/narrative_batch.py、narrative_run_store.py、narrative_model_caller.py、narrative_paid_response.py、store.py、supervisor.py、models.py、migrations.py；config/run-store/paid-recovery与新generation tests。未执行pytest、网络、收费或生产资料操作。后续ROOT实现与独审应另绑定新SHA；本文件不是新增人工许可条件。
