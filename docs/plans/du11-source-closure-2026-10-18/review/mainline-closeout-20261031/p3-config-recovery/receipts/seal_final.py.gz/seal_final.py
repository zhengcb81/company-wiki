"""Bind final reviewed source and local technical receipts without mutations."""
import hashlib
import json
from pathlib import Path
import subprocess

BASE = Path(__file__).parent
ROOT = BASE.parents[2]
paths = [
    "scripts/config.py", "src/company_wiki/automation/narrative_batch.py",
    "src/company_wiki/automation/narrative_run_store.py",
    "src/company_wiki/automation/narrative_model_caller.py",
    "src/company_wiki/automation/narrative_paid_response.py",
    "src/company_wiki/automation/migrations.py", "src/company_wiki/automation/store.py",
    "tests/unit/test_narrative_model_config.py", "tests/unit/test_narrative_generation_owner.py",
    "tests/unit/test_narrative_model_caller.py", "tests/unit/test_narrative_run_store.py",
    "tests/integration/test_narrative_generation_outbox.py",
    "tests/integration/test_du11_paid_response_recovery.py",
]


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


files = []
for name in paths:
    raw = ROOT.joinpath(name).read_bytes()
    files.append({"path": name, "bytes": len(raw), "sha256": sha(raw),
                  "lf_sha256": sha(raw.replace(b"\r\n", b"\n").replace(b"\r", b"\n"))})
receipts = []
for name in ["config-loader-red.log", "config-loader-green.log", "generation-owner-red.log",
             "generation-owner-e2e-red-host.log", "config-recovery-green3.log",
             "generation-owner-e2e-green2.log"]:
    raw = BASE.parent.joinpath(name).read_bytes()
    receipts.append({"path": "../" + name, "bytes": len(raw), "sha256": sha(raw)})
for name in ["independent-probe.json", "independent_probe.py", "final.md", "final.json"]:
    raw = BASE.joinpath(name).read_bytes()
    receipts.append({"path": name, "bytes": len(raw), "sha256": sha(raw)})
head = subprocess.run(["git", "rev-parse", "HEAD"], cwd=ROOT,
                      capture_output=True, text=True, check=True).stdout.strip()
result = {"schema_version": "independent-config-recovery-seal/1", "head": head,
          "verdict": "PASS_CONFIG_IDENTITY_EXECUTION_RECOVERY", "open_findings": 0,
          "files": files, "receipts": receipts,
          "independent_cases": 8, "child_pytest_processes": 0,
          "child_product_test_config_edits": 0, "child_network_calls": 0,
          "not_signed": ["subsequent publication", "exact remote CI", "real W12 completion", "entire project"]}
BASE.joinpath("final-seal.json").write_text(json.dumps(result, indent=2) + "\n", "utf-8")
print(json.dumps({"head": head, "verdict": result["verdict"], "files": len(files)}))
