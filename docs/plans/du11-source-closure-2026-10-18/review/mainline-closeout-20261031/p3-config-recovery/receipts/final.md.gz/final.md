# 配置身份与generation恢复：最终独立审查

结论：**PASS_CONFIG_IDENTITY_EXECUTION_RECOVERY / 0 OPEN**。当前代码和收据绑定[final-seal.json](final-seal.json)。此结论允许ROOT正常发布及观察精确CI，不代签尚未执行的真实W12新attempt、远端CI或整家公司审查完成。

## 共因修复与分层

`scripts/config.py::Config.load`用resolved canonical配置身份决定沿用受管dotenv：默认、显式绝对、相对同一文件执行同一凭证规则；真正custom配置和禁用标志继续隔离。MiMo/MiniMax项目受管、DeepSeek环境优先的既有规则未改，没有供应商/公司临时补丁、密钥复制或新增许可。

执行完成谓词现在归`NarrativeRunStore.generation_execution_finished`，batch只消费布尔结果。run、成员job、attempt、reservation、effect/outbox通过既有readonly opener同一snapshot判断，不自行加BEGIN，也不在配置层或source层操作AUTO状态。原DB和generation mutex、实际catalog artifact reuse及付费响应caller继续各自负责。

已完整记录的失败可让新的显式run接手，计费unknown仍保留原token/cost reservation；reserved、未完成attempt（即使lease已过期）、未结算输出、reaper只有时间无原生完成结果、待恢复paid pin或未交付outbox仍拒绝接手。正常finished attempt的历史lease_until仍可能在未来，不因此误造新的权限门。无数据库/账本更新、退款或原attempt自动重发。

paid_response_json才绑定完整canonical HTTP响应。单独response_sha256也可能来自`failed_final.final_content_sha256`，只是截断/无效正文诊断；我在初稿建议过宽的SHA-only阻断，ROOT指出后已对照caller源码撤回，在design v2留痕。最终保留诊断SHA及费用，允许已完整记录失败后的显式新run；已有pin（包括known-billing失败）仍要求原run零POST恢复，missing/corrupt pinned bytes不变成另一次HTTP。

正常发布由既有`settle_published_summary_output`和catalog owner证明，effect VERIFIED需结合delivered outbox、清lease和实际activation；不是把任何status或output>0当作可见artifact。成功但usage unknown的artifact仍可跨run复用，旧计费不改。

## 验证证据

- 原配置fake凭证RED为4F/7P；最终配置39P/3.40秒。默认/absolute/relative × 三供应商及custom/禁用隔离有真实临时配置控制。
- 原生owner正确业务RED为3项；最初4F中另1项是假设“未手工settle_output就未结算”，但原生finish失败本来自动结算零输出，已明确改成保护正例。没有删账或捏造SQL状态。
- 最终四个受影响unit文件 **96P/20.46秒**，覆盖配置、owner、caller和run store。
- 两个真实loopback集成文件 **4P/64.12秒**：拒绝后新显式run成功且旧hold逐字段不变；prepared activation拒绝otherDB、原run恢复不二次POST；已发布unknown跨run复用不再POST；真实完整paid pin在decoder中断后仅原一次POST并复用。全部是本机fake key/隔离来源，非收费供应商。
- 本child额外做8形态native probe，[independent-probe.json](independent-probe.json)：known/unknown完整失败、known/unknown仅诊断hash可移交；known/unknown实际paid pin、reserved、expired unfinished保留。逐例旧reservation与budget完全相同、观察pointer未创建新AUTO DB，临时目录已恢复；无pytest/HTTP/收费/密钥/原件访问。

最初sandbox未真正HTTP的失败不计有效业务RED；中间重复BEGIN错误、legacy `/4`夹具误要求paid pin、原生finish结算误期望均按原失败保留。最终96/4及配置39有重叠，不累计成虚假唯一测试总数。独立probe复用原生fixture构造状态，期望、pointer移交与不变性由独立脚本验证。

## 范围与剩余责任

本次变更不改模型/endpoint/预算，不增加数据库表、任务队列、授权JSON、签收或小节点审批；没有重跑收费真实材料。原两次W12真实401未知费用与其后0POST拒绝不能改成成功或退款。后续ROOT先正常提交/推送/精确CI，再继续同一PWF的真实W12新attempt、RF采用和公司四审；本报告不代签那些节点。
