"""Small native AUTO ownership probe: no pytest, HTTP, credentials, or originals."""
from dataclasses import asdict
import json
from pathlib import Path
import sys
import tempfile

BASE = Path(__file__).parent
ROOT = BASE.parents[2]
for path in (ROOT, ROOT / "src", ROOT / "tests"):
    sys.path.insert(0, str(path))

from company_wiki.automation.narrative_batch import BatchResumeError, _check_generation_owner
from unit.test_narrative_generation_owner import _finished_run

cases = [
    ("unknown_completed", {}, True),
    ("known_completed", {"known": True}, True),
    ("unknown_diagnostic_hash", {"diagnostic_sha": True}, True),
    ("known_diagnostic_hash", {"known": True, "diagnostic_sha": True}, True),
    ("unknown_canonical_paid_pin", {"paid": True}, False),
    ("known_canonical_paid_pin", {"known": True, "paid": True}, False),
    ("reserved_usage", {"usage_settled": False}, False),
    ("unfinished_expired_native_lease", {"finish": False}, False),
]
rows = []
with tempfile.TemporaryDirectory(prefix="own-", dir=BASE) as name:
    scratch = Path(name)
    assert scratch.resolve().parent == BASE.resolve()
    for label, options, expected in cases:
        case = scratch / label
        case.mkdir()
        auto, ledger = _finished_run(case, **options)
        before = tuple(asdict(record) for record in ledger.reservations_for_run("run-one"))
        budget = ledger.budget_snapshot("run-one")
        assert ledger.generation_execution_finished("run-one") is expected
        pointer = case / "generation.json"
        pointer.write_text(json.dumps({"schema_version": "narrative-generation-recovery/1",
                                      "automation_db": str(auto.db_path), "run_id": "run-one"}), "utf-8")
        frozen_pointer = pointer.read_bytes()
        new_database = case / "fresh-explicit.sqlite"
        if expected:
            _check_generation_owner(pointer, new_database, "explicit-independent-rerun")
            assert not pointer.exists()
        else:
            try:
                _check_generation_owner(pointer, new_database, "explicit-independent-rerun")
            except BatchResumeError as error:
                assert error.code == "BATCH_GENERATION_RECOVERY_REQUIRED"
            else:
                raise AssertionError("recovery-owned operation was released")
            assert pointer.read_bytes() == frozen_pointer
        assert not new_database.exists(), "pointer observation created a new AUTO database"
        assert tuple(asdict(record) for record in ledger.reservations_for_run("run-one")) == before
        assert ledger.budget_snapshot("run-one") == budget
        rows.append({"case": label, "released": expected, "ledger_and_budget_unchanged": True,
                     "new_database_not_created": True})

assert not scratch.exists()
result = {"schema_version": "independent-config-generation-probe/1", "cases": rows,
          "scratch_restored": True, "pytest_processes": 0, "network_calls": 0,
          "model_calls": 0, "original_reads": 0, "product_test_config_writes": 0}
BASE.joinpath("independent-probe.json").write_text(json.dumps(result, indent=2) + "\n", "utf-8")
print(json.dumps(result))
