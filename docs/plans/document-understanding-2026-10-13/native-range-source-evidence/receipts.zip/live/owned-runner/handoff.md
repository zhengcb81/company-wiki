# Phase C 执行器交接（2026-10-14）

当前状态：**CWP → FF → RF 的完整离线工程联调 PASS，执行器 SOURCE STOP；尚未外部 POST。** 没有改生产源码、默认 selector、真实模型配置、其他仓库或共享 PWF。`phase_c_runner.py` 默认只跑 127.0.0.1 loopback，socket 明确拒绝外网；真实模式由 ROOT 刷新 preparation 后显式启动。这里没有新增授权文件或人工签收链。下方旧 FAIL 段落是保留的历史记录，不是当前阻点。

## 0. 冻结源码后的最终工程验收

`handoff-receipt.json` 是当前归总。真实命令：`C:\Miniconda\python.exe -B -X utf8 .planning/shared-reading-production/live/owned-runner/phase_c_runner.py --mode loopback`。一次集中节点 **exit 0 / 41.293 秒**；真实 `stdout.log`、`stderr.log` 与源码冻结结果在 `receipts/frozen-node-20261014T135324/`，完整 outcome 在 `receipts/loopback-20261014T135326-8cc547/overall.json`。

- 520 个 CWP / FF / RF 代码与资产文件的前后聚合 SHA 都是 `4c433b8347bfde1e4df93bb21f135fa46288803e2b7c466b2e9cbcdc54e16982`，没有边写边验。
- 0.9→0.8 各一次本机假模型初次 POST，共 2；**外部 0 / 付费 0**。两版本 same-run 恢复、跨 run cache 均 0 新增 POST，账记录保持或新 run 零 reservation，公开 replay verified。
- 0.8 成为 LATEST 后，public reader 和 FF/RF 消费者仍钉住保存的历史 0.9 exact Ref。RF source+narrative 与独立 narrative CLI 都 exit 0；独立 RF Context 的 `reading_context`、全部 `evidence_spans`、`summary`、`source_ref` 与实际 public Bundle 逐值完全相同，且 replay verified。不是丢掉新字段后得到绿灯。
- 缺少 gold 支持及同页分属不同真实组的 AND 支持均正确拒绝，**各 0 reservation / 0 POST**；保留实际 selected 单独 anchors 全在但不成同组的证据。
- 三个自有 Temp 湖 finally 删除；原件 / gold / 临时配置 / sentinel 指纹、生产配置指纹都不变，母费用账前后实读不变。native fixture usage 不是现金账单或真实供应商用量。
- Observer 已移除 `_norm` / `_supports` / `_native_contiguous` 第二套支持规则，唯一调用 `tools.document_understanding_benchmark.closed_group_support.score_facts`。实际 envelope 的别名 / 原文 / source role / quality flags / 分组顺序与成员都严格对应真实 selection；旧 0.8 model group 仅适配它的实际闭包，不冒充新 native proof。
- 15 个 pure 反例：8 FAIL / 6 PASS → 15 PASS（最终 2.14s）；涵盖真实 native range CJK 与未来限定、共享闭组与跨组、English 不能造 word、source/page/role、别名分组/角色/flags 篡改拒绝，以及唯一 canonical oracle 权威性。真实 XML 为 `oracle-behavior-red.xml`、`oracle-authority-node.xml`。最早 `oracle-integration-red.xml` 是 ROOT 预接尚未发布预算 alias 的 collection ERROR，ROOT撤回接口后才跑行为 RED，未改变断言。
- 三家实际配置的 HTTPS omitted port、三份 official header/语言和 primary URL 语法共 13 pure PASS；Ruff PASS。历史 FAIL、旧合同拒绝和中间 harness 错误原样保留，并在 `failure-classification.json` 新增 resolved_followup，而不是改写成当时通过。

**验收范围**：真实工程入口与消费者契约；synthetic source / 本机 fake 模型不证明供应商效果或买方研究质量。CN/HK/US 真样本、真实配置模型、gold 原文支持及完整 RF driver/model/数字审查仍由 ROOT Phase C 完成。本 lane 不抢源代码 / planner / 共享 PWF，也不运行真实模型。

## 1. 当前集中节点的实际结果

入口：`python -B -X utf8 .planning/shared-reading-production/live/owned-runner/phase_c_runner.py --mode loopback`。

最新完整证据：`receipts/loopback-20261014T115149-cdcb1a/overall.json`，**保留 FAIL**。ROOT 批准执行次序 0.9→0.8：先让 0.9 付费前检查真实支持，避免为明知新材料缺失的样本先付旧基线费用；两版本原件/模型/公开预算不变。

- 真实 official-import → configured batch CLI 的 0.8 / 0.9 各完成一次本机假模型 POST；无外部 POST，无现金/订阅用量。实际 Native Store 记录完整保留，fixture usage 不是母账或发票。
- 两版本 public reference/read 字节 SHA 与原件 replay 验真均通过；0.9 typed material SHA、Store final、artifact metadata generation manifest 相同，reading_dependencies=complete。
- 两版本 same-run restart 原始 reservation 的完整记录不变；两版本 cross-run cache 正式 receipt 为 reused，tokens=0、native=[]、POST 增量=0。不同 run 使用不同 work-dir，没有删除或修改工作目录 marker。
- 0.8 最后发布并被正式 reference CLI 确认为 LATEST；随后按之前保存的 0.9 exact Ref 读取历史 artifact，body SHA/typed material/reading_context 与先前完整值相同，**没有 trim 字段**。FF/RF 消费者钉住这个 0.9 read-request，未因 LATEST 变旧而偷偷测 0.8；复读相同 Bundle 只留命令/receipt/SHA，没有复制第二份全文。
- 缺 gold 支持与“两段 quote 各自被选中但实际分属两个 group”的反例均由正式 0.9 selector 生成。后者保留 `all_anchors_individually_present=true`，但没有单组完整 AND 支持；两例均 PHASE_C_GOLD_SUPPORT_MISSING、native=[]、0 reservation / 0 POST。
- FF 真实 `fetch_filing.py --source-ref-v2` 返回 source_candidate、reused_existing、calls=2、downloads=0。
- 原件/gold/临时配置/sentinel 保 SHA、size、mtime；三个独立 Temp 湖均 finally 删除。生产配置指纹复查不变，母 usage.jsonl 前后实读指纹相同。
- RF raw source 已读取；随后 RF narrative consumer 阻断，详见下一节。不能把前述绿节点算作全链通过。

纯观察器反例：`verify_observer.py`，`observer-pure-receipt.json` 共 **13 PASS / 0 POST / 0 reservation**：同页跨组不可拼支持，真实闭组可支持，英语空格不可拼新词，中文断行仅在同原生 block+真实连续 offsets+同实际 group 下合并；三家实际 HTTPS 配置的 omitted port 与 Native model 一致；三个 actual official-import header 和 typed narrative metadata 合法；三份真实 primary descriptor URL 通过现 RF 语法合同，但没有网络或 public-provenance 验真声明。

Ruff 对本目录脚本已通过。没有重跑全仓测试。

## 2. ROOT 要修复的真实跨仓缺口

RF `scripts/company_wiki_narrative_contracts.py` 的 `BUNDLE_FIELDS`（43–47）和 `_bundle`（484）仍使用旧 exact 字段集合；正式 CWP 0.9 additive `reading_context` 被拒绝为 `blocked: invalid_narrative_bundle`。

这是生产消费接口问题。最新证据 `receipts/loopback-20261014T115149-cdcb1a/success/rf-narrative-underlying-error.json` 由 `diagnose_rf_narrative.py` 将**实际 public request + 实际已发布 Bundle 原字节 + 实际 receipt**送给 RF 的真实 `validate_narrative_response` 得出，未改变字节或 hash；唯一顶层未接受字段为 reading_context。正式 RF source CLI 的 stderr 也记录 stage=narrative_reader、calls=2、downloads=0。

修复应覆盖 raw / projected 共同正式上下文，不只忽略未知字段：严格有界 decode reading policy、evidence groups / alias 与来源 scope；支持非空 group claim 引用；版本字段和 RF Context 输出也需联动，保持旧 0.8 字节/DTO 兼容。现 RF `_claim`（366）是旧 exact claim 集合，`_diagnostics`（472）是旧 exact versions，Context 投影也不输出 reading_context。不得在 runner strip 新字段、截掉 group 或改模型答案来凑 PASS。ROOT 拥有 RF 改造；本包不改 RF。

ROOT 修复后用同入口重跑这一集中节点；满足 CWP + FF + RF 三项后再实际 Phase C。当前尚未运行 RF narrative-only CLI 到成功，因为组合 source+narrative 已在前一个正式合同处失败；不是把未执行项视为成功。

## 3. 所有中间失败归因

见 `failure-classification.json`；旧失败文件保持原样。

- launcher 缺 `__main__` guard 导致 Windows spawn 重入，是 harness 构造错误。
- material hash helper 要 typed SelectResult，却传 dict，是接口误用。
- public raw Ref/receipt 没有 generation_sha256/body_sha256；改用真实 Ref.artifact_sha256，并到 actual artifact metadata 验 final，是接口误用修正。
- cross-run 沿用旧 run 的 work-dir 被 input hash marker 正确拒绝，是 harness 目录绑定错误。
- sqlite3 connection 的 `with` 只提交事务，没有关闭句柄；Windows finally 删库被自己的连接挡住，是 harness 资源释放错误，现显式 closing。该轮唯一遗留 Temp 已按绝对路径核验后清除；不伪造不存在的 overall receipt。
- IR 假夹具给 exact 但缺 fiscal_year，FF 正确拒绝；改为明确本 fixture 的 2026 期次，真实三份的实际期间保持不变。
- 隔离湖没有 identity snapshot，identify 正确拒绝；loopback 显式写虚构 ACME fixture，live 只逐字复制当前选中市场既有官方 snapshot 到 Temp，核实源 SHA/mtime不变并验证现有合同，不 refresh、不手造真实身份。
- RF 正确拒绝假夹具 `.example`。其 valid_source_url 当前只排 `.example` 和固定黑名单，允许 `.test` / `.invalid`。现明确 synthetic reserved `.test` **只证明离线协议**，沿现 e2e 夹具方式，不称公开来源真实性；真实三份 URL 没有更改。
- 最后一项 RF reading_context 拒绝才是当前真实生产缺口；保留 FAIL。

URL 黑名单仍有共同合同风险：URL 语法、原件 custody/identity 与公开来源真实性是不同责任；只排一种 reserved TLD 不能证明 public provenance。交 ROOT 记 PWF 后续范围，本包不改 URL validator 或新增门禁。

## 4. 实际执行前的配置与资料冻结

ROOT 先运行 `live/prepare.py`。CN gold 已经修正原文多“已”问题，新 SHA 为 `10d1dc12e251e57354599c58abd55d5ee3d010259a8bf04415a73fb55cb2a335`；本轮 metadata 仍是旧 SHA，真实模式会诚实拒绝，不绕过校验。loopback 只使用自己的假原件/gold。

- CN：published_date 原观察 None；实际 filing_date 2026-08-19 用作公开可用日，receipt 记录来源，绝不借 mtime。注册语言 zh。
- HK：实际原件英繁双语，typed 分类 mixed，gold 原始语言标记 zh-Hant 另留 receipt；不翻译。官方 HKEX URL 是同文档 descriptor，remote SHA / 历史下载地址仍 UNKNOWN。
- US：实际 SEC archive URL / FY2025 / en 保持。
- MiMo / DeepSeek / MiniMax model、endpoint、8192、temperature、thinking/reasoning 字段只读当前 Config。observer 比较真正待发 HTTP body；省略字段仍省略，不擅自调参数。密钥不写入命令、材料、日志、报告。
- 母预算沿 metadata 的 20 USD / 2M tokens、prior413778 / 334463µUSD + FXhold2764。新 live Native reservations 以 database+attempt_id 去重，失败/unknown/unsettled 都照计；proxy≠实际 cash invoice，MiMo subscription Credits 另述。loopback永不写母账。

## 5. ROOT 的显式命令

依顺序只跑一份，前一份有 unknown/OOB/异常就停，不自动换 provider/endpoint/配置或重发：

```
python -B -X utf8 .planning/shared-reading-production/live/owned-runner/phase_c_runner.py --mode live --sample cn-h1
python -B -X utf8 .planning/shared-reading-production/live/owned-runner/phase_c_runner.py --mode live --sample hk-annual
python -B -X utf8 .planning/shared-reading-production/live/owned-runner/phase_c_runner.py --mode live --sample us-10k
```

每份固定原件、实际 scope、provider、公开 span96、模型8192、预算/timeout/bytes cap。0.8 没有内部48000字符硬限；0.9 有48000，差异透明保留，不裁旧材料。本执行器不把 gold 或旧答案送模型，不重 parse/select 来观察。

母费用账已在唯一 `BudgetedNarrativeCaller` 前检查，新 unknown 阻止后续付费；已完成同 run 恢复与跨 run cache明确禁止调用原模型。真实 provider 失败由 Native Store 保守入账后返回失败，不盲重发。当前没有在本包真实诱发 OOB 或 kill-in-flight；这些边界不能称已由本 loopback 验收，沿既有工程错误/lease/outbox 测试，实际遇到先保 native 账与状态再处理。

这些测试只验上游资料、正式摘要发布/恢复与只读消费者。loopback 内容不是分析质量；没有完整 RF driver tree/情景/DAG/币种与数量审核/买方独审，就不能声称母研究全流程通过。每份实际正式摘要的原文字节/引用均在单份 gzip Bundle 中，供 ROOT 真模型后独审；不要复制全文 MD 或旧研究答案。

所有可执行和证据只在本 owned-runner 目录。源码、共享 PWF、外包 DU3 目录均未更改。ROOT 决定归档与提交。
