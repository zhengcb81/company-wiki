# Balanced reading planner /3 — independent major-node review

Date: 2026-10-14. Reviewer: ROOT / quality_rf. **PASS for the scoped pure planner; no new actionable defect found. Read-only review complete / STOP.**

## Reviewed cause and implementation

The previous /2 ranking put actual scope priority before normalized theme visits. Within the same value/novelty tier, a large high-priority theme could keep displacing a lower-priority but less visited theme. In /3, the rank is `(value, novelty, mean_visits, priority, repetition, remaining tie-breakers)`. The source-owned value/novelty distinction remains first; actual priority still decides equal visitation. The planner neither reads payload text nor attaches business labels itself.

`narrative_budget.py` now counts **accepted unlabelled value bundles**, rather than treating every future empty-topic bucket as permanently zero-visited. All empty-topic buckets receive the changed real count and are refreshed, including buckets at different priorities. No invented topic string is attached to caller data. A table counts once for this visitation purpose while retaining every actual row's unique span and character charge. Context-only headings/dependencies do not contribute topic visits or become separate value anchors.

The source's explicit `reading_plan/1` and `reading_plan/2` branches remain separate replay paths. This independent review checks representative controls; the author's reported 4,000-case exact historical parity and 119-pass concentrated node are separate evidence and were not rerun here.

## Independent acceptance

The reviewer prepared the probes while the author worked, waited for SOURCE STOP, then ran **one** concentrated six-group node against the frozen current source:

```powershell
python -X utf8 -B .planning/shared-reading-production/recall-root/balanced-review/probes.py
```

| Group | Independent counterexamples / checks | Result |
|---|---|---|
| 01 | Busy previously seen theme, two previously seen rare themes, truly new theme and unknown-topic fact all get slots within a six-slot synthetic budget; caller labels remain unchanged | PASS |
| 02 | Unlabelled selection updates all priority buckets, allowing a covered labelled theme to re-enter; a three-row unknown table is one visitation but pays three actual slots/character costs | PASS |
| 03 | Same normalized coverage preserves real scope priority, even against a much larger numeric score; richer multiple labels use their mean rather than an unfair sum | PASS |
| 04 | Shared heading does not mark its topic as covered; duplicated dependency refs charge unique IDs once; exact/one-character-too-small closure costs are respected; valuable facts beat novel high-scoring descriptions | PASS |
| 05 | 20,000 candidates with a real shared CoverageSignature object preserve late rare/new/unknown candidates, fill 96 unique slots, stay within 48,000 chars and 2,000,000 work units | PASS |
| 06 | Explicit low work budget reports a stop without half-groups; returned groups remain atomic at a larger bounded work budget; representative /1 and /2 outputs remain unchanged while /3 changes the intended busy-theme outcome | PASS |

Observed: **6 tests /0 failures /0 errors /0 skips; process exit 0**. Unit-run output reports 0.377 seconds; the receipt's full run including owned temporary cleanup is **0.393933 seconds**. Payload objects deliberately raise if stringified, independently proving the pure planner did not read/reclassify their content. No test imposes an exact internal work-operation count: a more efficient implementation may finish before a larger work ceiling.

## Frozen evidence and isolation

- Budget source SHA: `44d2a739f4a1db6efcf0aa7fc33bb2227537b03f2659ec430c8220c838ca75b8`.
- `receipt.json` captures the budget, semantic coverage, finalizer, reading adapter and decision-inventory source SHA/size/mtime before and after. All five were unchanged throughout the run.
- `probe-output.txt` contains complete observed output. `probes.py` is reproducible and independent of the author's test helpers.
- Test files live only in this review directory. The independent Temp sentinel was unchanged, its owned root was removed, and no owned Temp remains. Python bytecode writes were disabled. No source, configuration, original, gold, PWF, installed skill, other harness, Git branch or commit was changed.
- Zero models, downloads and whole-original parsing. No new approval, identity validation, permission file or runtime gate is introduced by the review.

## Scope limits

This verifies deterministic ranking, accounting and finite-work behavior for caller-supplied metadata. It does not establish the truth of a topic/value assessment, promise every theme can fit under any hard cap, certify all possible dependency graphs, or replace ROOT's real-source coverage/gold and semantic/model acceptance nodes. The remaining CN p13 allocation/meaning is not diagnosed from these toy IDs and is not patched with a company/product rule. New labelled themes still precede unknown novelty when the source cannot prove unknown content is novel; unknown content receives an actual turn among comparable covered themes rather than a permanent privilege or blanket exclusion.

ROOT may continue its planned real-source integration against this frozen implementation. STOP.
