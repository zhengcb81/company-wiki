# Native range and carrier — independent source-integrity review

Date: 2026-10-14. Reviewer: ROOT / quality_rf. **PASS after the one identified P2 was repaired by ROOT. Review complete / SOURCE READ ONLY / STOP.**

## Scope and observed responsibility boundaries

Read the current source-native and semantic-value handoffs, the source factory/parser/replay path, and ROOT's final material/group mapping. Independently exercised eight probe groups rather than repeating the authors' large suites. All test PDFs are small synthetic inputs generated in memory; no real company original, provider or model was called.

- `narrative_native_ranges.py` creates an exact substring of a named NFC native page view from the existing DICT snapshot. Its coordinates are **view characters**, not PDF byte offsets. Each record retains original block text/hash and view offsets; real member/source/page/order/role/language proof belongs to this source layer.
- Typed geometry and scope closure are established upstream; the factory consumes those admitted body members. It does not independently reclassify business meaning, infer facts, repair words or create investment judgments. Distinct original native blocks may legally form one contiguous range in their shared page view.
- Full original-member bindings and the source-view hash remain in durable EvidenceSpan metadata for fresh replay. Full page text and transient `native_source_view` do not enter a durable span. Existing ordinary unit/span identities are unchanged when views are available.
- `_candidates` replaces body fragments with one source-proven carrier at their original material position. Unrelated ordinary material, including headings, stays unique; it clears transient material/origin maps before a fresh calculation. Missing proof or optional view budget exhaustion preserves the ordinary source path.
- ROOT's `_selected_unit_spans` binds original policy members to actual selected material. `_context` deduplicates the selected carrier refs in original order. Public selection, final reading context and the model envelope use the same selected evidence table; they do not send the old body fragments a second time.
- Source replay verifies the immutable original bytes first, then reconstructs the pinned base parser and named view. Source byte proof does not establish semantic completeness or certify investment intent. A completely rewritten **otherwise valid** shorter selection must be rejected by its owning selection/generation identity, not by guessing missing investment meaning in the byte-range verifier.

## One actionable defect and its repair

**P2, now resolved:** generic public `EvidenceSpan.create` permits `structured_value=None`, arrays and strings. A span declaring the native range parser with such a deleted/malformed narrative binding reached `.get()` unguarded in `verify_native_range_span`, raising `AttributeError`. Replay code had the same structural assumption. Additionally a declared native parser must not escape its source binding by borrowing the ordinary locator/text match branch.

Initial independent run: probe groups 01–06 and 08 passed; group 07 had three errors (`None`, list frozen as tuple, string). **Actual exit 1, 1.691530 seconds**, with source SHA/mtime unchanged and no temporary residue. `initial-output.txt` and `initial-receipt.json` retain the RED evidence.

ROOT repaired the common source/replay cause; this reviewer did not edit production code:

1. `verify_native_range_span` rejects non-Mapping narrative metadata with `False`.
2. `_narrative_metadata` gives replay preparation a defined `ValueError` for absent/non-schema narrative binding.
3. `_has_native_range` recognizes either the declared native parser name or the native unit kind. A mismatched/stripped declaration is sent to the native verifier and fails; it cannot pass via the old bare locator key.
4. `verify_replayed_pdf_spans` classifies malformed metadata as failed evidence.

These checks classify unsupported source evidence; they introduce no identity verification cycle, permission request, geometry classifier, investor-review gate or stronger interpretation of legitimate ordinary spans.

## Eight independent probe groups

Command from company-wiki:

```powershell
python -X utf8 -B .planning/shared-reading-production/recall-root/native-carrier-review/probes.py repaired
```

| Group | Independent checks | Final result |
|---|---|---|
| 01 | Legal three-block shared-view range; exact full member order and substring; negation/future wording retained; different source/page/role or reversed members refused | PASS |
| 02 | Non-whitespace omitted qualifier refused even with falsified paragraph counter; missing/unknown member, altered binding/page/text/parser fail replay | PASS |
| 03 | Real small PDF reads one source snapshot; units share one view reference; old unit IDs and ordinary EvidenceSpan dictionaries are exactly unchanged | PASS |
| 04 | Actual unmocked public 0.9 selector emits native carrier and unique other material; groups contain unique sent refs; actual typed model request has exactly one evidence table and no view/member/hash proof payload | PASS |
| 05 | Deleted optional view removes stale private mappings and restores old source candidates; zero view budget preserves original evidence/read errors and exposes explicit incomplete view coverage | PASS |
| 06 | Persist canonical native plus ordinary spans; fresh separate process reopens original PDF using public verifier; both refs verify; changed original bytes fail; sentinel and original test bytes preserved | PASS |
| 07 | None/list/string binding returns False; replay classifies failed evidence; preparation gives typed refusal; native parser borrowing an otherwise exact legacy span cannot fake PASS | PASS |
| 08 | Actual PDF trace contains native view/parser versions; changed current parser version alters causal inventory; changed member binding changes material identity even when text is unchanged and fails fresh range verification | PASS |

Final observed result: **8 PASS /0 failures /0 errors /0 skips, 1.588430 seconds, process exit 0**. No full-suite rerun or whole-company parse was added. ROOT's and authors' broader counts are separate evidence and are not represented as reviewer-run tests.

## Frozen source and test isolation

- `repaired-receipt.json` records all eleven source files with exact SHA/size/mtime before and after. All eleven were unchanged during each review run.
- Only two production files changed between RED and GREEN, by ROOT: `narrative_native_ranges.py` from `6388858f4e19da0c2abd4ae30131a7bb06c7b061103bf01401b7f7393d64dab7` to `b42aeb4b09896de059b0130957040e16baaf04415aa0d3e98093fb0662343dda`; `narrative_replay.py` from `b227e0639ed2cad4abd725b84e1b34413aa1955b0a59b491ccd60aae3f1fa651` to `94d3e5a18d3122b7a829e10d9a0fbbdafddba82c2efa7e86bee75535c2a28517`.
- Test source, RED/GREEN output and receipts live solely in this independent review directory. The small PDF, persisted span JSON and child script were created inside its owned temporary subtree, checked, removed, and the temporary root no longer exists. Python bytecode writes are disabled; network connections are blocked within the probes and credentials are removed from the process environment.
- Zero model calls, zero provider calls, zero downloads. No source, gold, production configuration, shared PWF, another harness, original, skill installation, Dayu, Git commit or branch was changed by this reviewer.

## Limits and remaining ownership

- This passes the **finite source provenance and carrier consumption** seam. It does not certify all PDF table/geometry/reading meanings, generated summaries, coverage on an unseen issuer, financial forecasts or buy-side analyst quality.
- The public unmocked selector and typed compact model request were exercised without a model POST. Fresh-process persistence tests the canonical span/ref/source replay. This review does not claim a fresh complete AUTO publication/reuse/worker/outbox test; ROOT's existing owning large nodes cover that path.
- Version inventory and material-hash invalidation were checked. The separate dependency module/owner, whole-generation cache acceptance and remaining CN p13 allocation/fairness are not replaced by this source review. The budget owner was not touched.
- CodeGraph context returned unrelated older symbols. Current specifically identified source files and producer handoffs supplied the actual behavior under review; no structural completeness claim is made from that query.

The identified P2 is fixed and independently verified. No remaining actionable defect was observed within this bounded review. ROOT may continue its planned integration and real-source acceptance. STOP.
