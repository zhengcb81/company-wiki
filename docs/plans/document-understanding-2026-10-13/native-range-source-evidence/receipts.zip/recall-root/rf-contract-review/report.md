# RF shared reading consumer — independent major-node review

Date: 2026-10-14. Reviewer: ROOT / quality_rf. **PASS for the scoped consumer change; no actionable new P1/P2 found. SOURCE READ ONLY / STOP.**

## Reviewed object and actual contract

- Author worktree: `C:/Users/郑曾波/Projects/_harness_worktrees/shared-reading-completion-20261014/rf-reader`; branch `codex/shared-reading-rf-reader-20261014`, base/HEAD `f0d694d69a05ef3f7a449e87cd91cdb44d1ff8ce`.
- Reviewed actual source diff: only `scripts/company_wiki_narrative_contracts.py`; 143 additions /4 removals. New author tests and saved handoff also read, but their assertions were not used as the review oracle.
- Actual saved public CWP 0.9 bundle: 11,549 bytes; SHA `7d403b7e12bc3c4c094a08855190d8e422a09f88d2e465e89150d26cfb0bb2d2`. Its sole new public root field is optional `reading_context`. Public claims and `versions` remain their six published fields. The model's `evidence_group_ids` declaration is validated and removed by CWP before canonical public draft emission; it is not an extra public claim field.
- Cross-checked current producer contract and construction, read-only: `src/company_wiki/automation/narrative_contracts.py:760`, `src/company_wiki/source_catalog/narrative_reading.py:359`, `src/company_wiki/automation/narrative_model.py:540`. No CWP implementation is imported by the independent probes.

## Source review conclusions

1. `_bundle_fields` adds precisely the optional field for raw v2 and projected v3 bundles. `_reading_extension` preserves it in both DTOs. Existing schemas and financial outputs remain unchanged; legacy absent-field DTO shape is preserved.
2. `_reading_context` uses the already transported, independently validated EvidenceSpan table. Ref uniqueness, membership, group-ID uniqueness and a single original source parent per group are enforced. It does not resolve directories, open originals, look up policies, request identity again, acquire missing documents, or add a permission workflow.
3. Entire ordered context is bound to the original bundle's artifact SHA/size and emitted unchanged. Membership and source scope are checked; RF does **not** newly certify the producer's semantic grouping or recompute `reading-group` identity. The current CWP typed wire follows the same responsibility boundary. Re-signing adversarial inputs in probes challenges local structural validation; it does not represent a successful mutation of an authorized original reference.
4. The context's iterative bounded walk rejects oversize/deep/wide payloads before projection/deepcopy. Existing UTF-8 JSON decode, duplicate-key/nonfinite rejection, BODY_LIMIT and typed exception handling remain. Existing recursive path scanning still precedes the context walk, but its RecursionError is converted into a typed refusal and the body is bounded; the deep wire probe confirms no raw exception. No newly permissive decoder was introduced.
5. Native text coverage, semantic structure coverage and fine layout coverage stay separate. Truncated diagnostic examples retain full counts and `limited`; partial coverage passes through as data, without becoming a new human approval gate or a fabricated complete-read statement.
6. Policy payload content is bounded data, never executed. Exact policy/facet envelope fields match the current producer. This review does not impose unadvertised generic extensions, stricter policy semantics or another issuer/period verification cycle.

## Eight independent probes

Command, from company-wiki:

```powershell
python -X utf8 -B .planning/shared-reading-production/recall-root/rf-contract-review/probes.py
```

| Probe | Independent checks | Result |
|---|---|---|
| 01 | Exact actual 0.9 wire SHA; complete context/claims/spans retention; detached DTO; original-reference order mutation rejected | PASS |
| 02 | Saved 0.8 DTO shape; earlier unsampled DU1; incomplete structure/layout do not become complete | PASS |
| 03 | v3 context and all original parent refs retained; two valid separate parent groups accepted; cross-parent group and wrong parent binding refused | PASS |
| 04 | Unknown, duplicate, empty evidence refs and duplicate group IDs refused; accepted ordered group remains byte-for-byte ordered data | PASS |
| 05 | Truncated diagnostics retain counts and flags; malformed counts/limited refused; native vs structure/layout completeness remains separate | PASS |
| 06 | Duplicate JSON keys, NaN, 2,000-level JSON, global body cap, reading depth/string/byte/node caps produce typed refusals | PASS |
| 07 | Unpublished bundle/claim/version fields and physical path payload refused rather than silently dropped | PASS |
| 08 | Real bounded child-process reader transports raw v2 and multi-parent ref3 contexts; controlled request/bytes/receipt; no configuration file is opened or created | PASS |

Observed: **8 tests /0 failures /0 errors /0 skips; 0.412199 seconds; process exit 0**. The author already recorded its concentrated 153 PASS /2 existing skips in 15.80s; this independent review did not rerun that suite.

## Isolation and evidence

- `receipt.json` records full before/after SHA manifests and real observed exit/time. `probe-output.txt` retains complete test output. `probes.py` is the reproducible review package; only these independent review files were written.
- Author source SHA: `78aa128da01e0a711699ca8b478627132344eee84ccef0af4b96ad5fe52d42bb`; new test SHA: `901d91fc0ba0dbb7ef4cb691455ea156f668eebf4c606f17c4f3eb216d131d98`. All captured author files match before/after, with no changed paths.
- Author Git status before and after is identical: one modified contract file, the untracked author plan directory and the untracked new test. HEAD is unchanged. Initial sandbox Git read returned not-a-worktree; a normal escalated read-only Git check succeeded. No Git mutation was run.
- Controlled temporary subtree was empty before disposal and no owned temp roots remain. Python bytecode writes were disabled. Zero model calls, zero downloads; no installed skill, RF canonical WIP/output, config, original document, other harness or Dayu writes.

## Limits of this result

- The saved 0.9 public bytes exercise the actual raw producer on synthetic Acme data. Projected v3 probes start from RF's existing independent projection fixture and construct new multi-parent counterexamples; they do not claim a new live official-JSON producer run.
- Scope is consumer compatibility and transport integrity. Semantic grouping quality, table/header interpretation, extracted-fact truth, buy-side model quality and a live complete-company forecast are **NOT_EVALUATED** here. The mother project's producer/replay and real-company nodes own those checks.
- RF's CodeGraph context query returned unrelated older validation symbols, so current author source/diff and the specifically identified producer files were used; no completeness claim is made from that index query.

ROOT may receive and commit this consumer change at its planned integration node. No new permission, contract-signoff file or blocking gate is requested. Review complete; STOP.
