# Source-native range carrier handoff

Status: SOURCE STOP. No commit, raw/config/gold/automation/DU3/PWF edits. ROOT owns consumer/finalize/context/generation and real whole-document replay.

## Public source seam

Module: `company_wiki.source_catalog.narrative_native_ranges`.

- `NATIVE_PAGE_VIEW_FEATURE_VERSION = "native-pdf-page-view/1"` for causal inventory.
- `build_native_page_view(blocks, *, max_chars=200000) -> immutable Mapping | None`.
- `native_range_unit(members: Sequence[NarrativeUnit]) -> NarrativeUnit | None`.
- `verify_native_range_span(span, replay_units: Sequence[NarrativeUnit] | Mapping[str, NarrativeUnit]) -> bool`.
- `native_range_limits(limits=None)` accepts only `max_total_chars` / `max_page_chars` and only lowers default **2,000,000 / 200,000** character limits.

Public `parse_pdf` / `parse_pdf_bytes` add `native_ranges=False`, `native_range_limits=None`. Explicit selector 0.9 constructs views automatically; default 0.8 parsing does not. Replay preparation adds `PdfReplayPlan.native_ranges` and resolves a range's underlying base parser version; ordinary 0.1.1 spans can coexist with native range parser 0.1.0. Unknown version mixtures still fail. Both public verify facades propagate the flag to the pinned fresh parser.

## Named coordinate view and binding

The existing single native DICT snapshot already returns original `(raw_block_number, bbox, text)` tuples. A page view formats those blocks in original order, preserving within-block newline sequences and inserting a defined `\n` boundary between native blocks. This is a named parser view, not a substring of PDF bytes. NFC/CRLF normalization matches the existing parser; no inferred/repaired words or model wording enter it.

View fields: `schema_version`, `text`, `page_view_sha256`, immutable `blocks`, immutable `by_block`. Each block retains original block SHA, original source-text reference, original bbox, and its view character start/end. Nested mappings and arrays are immutable. All original units on a page share **one Python reference** under `metadata.native_source_view`; no per-unit full-text copy is made. The temporary source strings are referenced rather than duplicated. Normalization/allocation is bounded before constructing a new string, then the resulting view is bounded again.

The maker accepts only already geometry/scope-closed typed body members from the shared engine. It does not classify, route, perform IO or independently redo geometry. It verifies same source/page/role/language/shared view, base parser 0.1.1, consecutive original paragraph order, exact source block SHA/offset/wording, and absence of unbound non-whitespace gaps. Bounds are **8 original units / 4 original blocks / 2048 exact view characters**, including original/defined newlines. Missing or bad source proof returns None for the consumer's existing full-member fallback.

NFD original block offsets map into the NFC view through actual original source prefixes; ranges are never located by fuzzy matching or concatenated member text. Returned raw text is exactly `view.text[char_start:char_end]`.

Returned unit:

- parser `native_pdf_range_parser` / `0.1.0`, kind `pdf_native_range`;
- coordinates: original physical page, first original paragraph index, exact named-view `char_start` / `char_end`;
- canonical unit ID uses source, parser/version, coordinates, raw SHA and new kind;
- metadata `native_range` contains schema `native-pdf-range/1`, base parser `0.1.1`, `coordinate_space=native_page_view`, page-view SHA, complete ordered `source_unit_ids`, and up to eight member bindings (`unit_id`, original locator, original text SHA, block SHA/number, original block offsets, exact view offsets).

Neither the new unit nor its durable EvidenceSpan contains the full view/source text. `NarrativeUnit.to_evidence_span` strips both `reading_layout` and `native_source_view` before hashing/export. Original unit and EvidenceSpan IDs remain exactly unchanged.

## Resource fallback and replay

Optional page/total view budget exhaustion keeps every original unit and immutable-byte read status unchanged. Compact summary is `layout_coverage.native_ranges = {feature_version, complete, captured_chars, deferred_page_count, deferred_pages[:128]}`; `NATIVE_RANGE_VIEW_BUDGET` diagnostics explain no-range pages. No optional-view failure is written as a raw-reading error. No new persistent task/cache/view store exists.

Fresh replay verifies the requested immutable bytes/source first, then reconstructs the pinned old-parser units and shared view from one native read. Every recorded member must exist and rebuild exactly the same range substring, coordinates, complete binding, role, language, text SHA and quality flags. Changed wording/stage, removed member binding, wrong source/page/locator, unknown parser name/version and malformed frozen IDs fail. One reusable native-member index is built for all range spans; the old full-unit list is not rescanned for each range. Default/old Q&A behavior remains unchanged.

Replay establishes byte/range provenance of the declared selection. If an adversary rewrites the *entire* selection into a different otherwise valid short span, its generation/material identity must be caught by the existing owning integrity layer; byte replay does not guess missing investment intent. Geometry and semantic completeness remain the shared closure owner's responsibility. In particular a direct caller may not manufacture a range from unvalidated foreign members merely because they are adjacent.

## TDD and acceptance

- Initial formal suite: **28 FAIL in 5.60s**, real exit 1. New module/flags absent; old EvidenceSpan identity was also demonstrably changed by unstripped transient metadata; old replay plan lacked native range support.
- Implementation: 28 PASS; four additional defensive/resource/index controls bring source-only suite to **32 PASS**.
- One final isolated source/replay node: new32 + PDF bytes + selection architecture + existing narrative parser/QA tests = **142 PASS in 5.36s**, pytest exit **0**, wrapper exit **0**.
- The real CJK PDF fixture is created only in memory; it verifies unchanged old units/spans, shared view references, named native range and coexistence/reopening with old 0.1.1 spans.
- Source/view snapshot counter confirms no second native snapshot is read.
- Wrong member source/page/order/kind/role/SHA/word/view/version, non-whitespace skipped stage, 9-unit/5-block/2049-character range and changed binding/locator/parser tests all reject.
- Zero/page/total resource limits preserve original source spans and expose no-range diagnostics. Full replay list iteration is bounded to two passes for multiple native ranges.
- Ruff five files PASS; mypy four source files PASS; owned diff whitespace check PASS.
- Independent TEMP sentinel restored, test tree removed; pytest's relocated TEMP was also removed by its cleanup hook. Receipt/logs: `source-node-receipt.json`, `source-node-stdout.log`, `source-node-stderr.log`.
- Source hashes in that receipt remained unchanged throughout the node. No real company original parsing, model or provider calls were made here.

## ROOT integration remaining

Consume maker only for actual shared-engine native windows; None preserves all old member spans/closed dependency groups and explanatory diagnostics. Add actual feature/coverage to causal/compact context. Keep original body membership/roles/order in carrier origins. Use the public fresh-source range verifier instead of requiring a new range to equal an old individual parsed unit. Strip source bindings from model prompts where not useful; preserve them in canonical evidence. Do not persist/deep-copy `native_source_view` during selection preparation or snapshots. Whole-original real three-market replay and paid formal summaries remain ROOT's acceptance nodes.
