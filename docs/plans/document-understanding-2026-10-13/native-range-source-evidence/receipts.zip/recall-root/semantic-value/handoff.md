# Semantic value and source-proven native carriers — ROOT handoff

Status: SOURCE STOP. No commit, paid POST, whole original parse, original/config/gold write, planner change, or PWF write by this lane.

## Root cause and boundary

The actual CN diagnostic reports 96 selected original fragments / 3,339 characters: 27 meaningful anchors plus 69 dependent fragments. Recognized important groups were `budget_full`, not missing from source understanding. A PDF line/block fragment is therefore an unfair counting unit compared with an HTML/TXT paragraph. Increasing priorities or the 96 / 48,000 limits cannot establish a true source unit.

This lane first separates independently complete issuer assertions only when neither side contains a reference, negation, condition or forward qualification. It keeps original units and their charges. It also prevents a weaker package from overwriting a proven meaningful anchor or adding scope labels as factual novelty. These fixes alone do not claim CN coverage acceptance.

The subsequent carrier adapter uses `narrative_native_ranges.native_range_unit` solely on already admitted geometry/scope-closed `native_continuity` body members. The source factory returns a true named native page-view substring, pinned parser identity and original member bindings, or `None`. There is no guessed text join, virtual geometry, second understanding/classification pass, planner discount or company/product allowlist.

## Owned production changes

- `src/company_wiki/source_catalog/narrative_reading.py`: only `_prose_reading_packages` / `_candidates`; the ROOT-owned context/finalize integration is separate.
- Original eligible packages remain original-ID packages for sent reading policies.
- Budget packages privately remap member/anchor/context IDs to the actual carrier; missing optional keys remain missing (legacy Q&A anchor compatibility).
- `pipeline['_material_units']`: all ordinary units retained in original order; each carrier replaces body fragments at the first body member's position.
- `pipeline['_carrier_origins']`: original member ID → actual carrier ID. Both are transient, produced only after successful source proof, and cleared on a fresh candidate calculation to prevent stale material reuse.
- Headings and shared dependencies are unique ordinary material. All native substring characters, including genuine line breaks, retain their full charge. Same wording at different parents remains separate source identity.
- Missing/invalid source proof preserves the old fragment closure. The source factory import is explicit; an unavailable feature is not hidden by an import-failure fallback.

Algorithm/dependency version publication is ROOT-owned (pipeline 1.5 and actual source carrier versions), not a planner `/2` version change here.

## TDD and verification evidence

All commands use `C:\Miniconda\python.exe -B -m pytest ... -q -p no:cacheprovider`; XML files are in this directory. Intermediate failures remain preserved.

| Evidence | Actual result | Meaning |
| --- | --- | --- |
| `red.xml` | 3 FAIL / 6 PASS, 1.37s | Independent statement / weaker package common causes |
| `qualification-counterexample-red.xml` | 2 FAIL / 9 PASS, 0.80s | A preceding real qualification could detach from an eligible positive assertion |
| `selection-node.xml` | 125 PASS, 3.90s | Original semantic, native continuity, value and priority node |
| `carrier-red.xml` | 5 FAIL / 3 PASS, 4.10s | Real source-proof conversion absent; negative/forward, heading, source and classification cases |
| `carrier-green.xml` | 8 PASS, 2.39s | Initial carrier implementation |
| `carrier-compatibility-red.xml` | 2 FAIL / 8 PASS, 4.50s | Mixed Q&A optional-key semantics and stale private source material |
| `carrier-selection-node.xml` | 134 PASS / 1 environment setup ERROR, 9.53s | New carrier 10 + semantic 11 + native 43 + value 50 + priority 21 |
| `carrier-temp-bridge.xml` / `.log` / `.json` | 1 PASS, exit 0 | Only the environment-error geometry bridge case rerun in independent native Temp; sentinel preserved, own Temp deleted |

The combined focused node is therefore 135 passing cases across the original run and the one isolated environment retry, **not** a falsely claimed single 135-pass run. Initial carrier and compatibility outputs are tool-output-only plus real XML; no nonexistent log is referenced. Ruff, single-source mypy and owned-path `git diff --check` passed.

Tests: `test_reading_semantic_value.py` (11 pure cases) and `test_reading_native_carriers.py` (10 pure cases). The latter proves 96 real fragments from twelve source windows become twelve genuine source-range slots while keeping the original 96 / 48,000 caps, all original evidence IDs, exact substring characters, stage qualifiers, parent separation and one semantic classification path.

## Remaining ROOT acceptance

Actual CN/HK/US same-source replay, gold support/alias closure, public reopen, dependency invalidation, full configured model material and paid Phase C remain ROOT integration work. This lane has not claimed a live quality result or changed the default selector.

## Follow-up: actual-script linguistic boundaries (SOURCE STOP)

ROOT found that the HK production language is `mixed`, while an earlier replay script used `zh`. The previous temporary classifier join relied on this category: it inserted spaces into mixed CJK words, but could concatenate English or numeric fragments when labelled zh.

The two classifier joins and the preceding-statement guard now share one local pure `linguistic_text` helper inside `_prose_reading_packages`. It chooses boundaries from actual adjacent CJK characters / Chinese punctuation. English words, number fragments and numeric-unit tokens retain a space. It does not inspect or change language categories, translate, alter raw unit text, change ModelRequest, reclassify a document, or create a carrier. Source scope/geometry closure remains the existing continuity owner's responsibility.

- `linguistic-boundary-red.xml`: 7 FAIL / 12 PASS, 3.77s. Six real new boundary failures; the seventh was the prior explicit `/2` version expectation after ROOT published the `/3` budget alias.
- The owned semantic test now expects actual `reading_plan/3`; its original fragment, cap and identity assertions remain unchanged. This lane did not edit the budget algorithm.
- `linguistic-boundary-node.xml`: semantic 19 + native continuity 43 = **62 PASS / 2.38s / exit 0**.
- Tests cover mixed CJK wrap and punctuation, original negative/forward qualification, incorrectly labelled English `owner||ship` and `prod||ucts`, decimal/number and unit boundaries, identical shared rule at the sentence/window joins, and different sources with different language labels never joined.
- Ruff and single-source mypy PASS. No Temp, original/config/gold writes or model POSTs. Real HK replay with actual mixed metadata remains ROOT acceptance.
