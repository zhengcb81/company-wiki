# Reading budget /3 — SOURCE STOP

## Scope and implementation

Owned production changes: `src/company_wiki/source_catalog/narrative_budget.py` only.
Owned new formal test: `tests/unit/document_understanding_selection/test_reading_balanced_coverage.py`.
No edits to source documents, config, gold, other source layers, model callers, automation, external lanes or PWF; no commit by this agent.

The one existing reading planner now takes a small ranking-mode parameter:

- `reading_plan/1`: explicit historical scope-priority replay, unchanged.
- `reading_plan/2`: explicit historical value/novelty/scope-priority replay, unchanged.
- Current `reading_plan/3`: value band, actual novelty, normalized topic visits, actual scope priority, repetition/score/marginal complete cost/source order.
- Legacy and semantic planners are unchanged.

`READING_BUDGET_POLICY` is `/3`; `REPLAY_VALUE_READING_BUDGET_POLICY` is `/2`; original `REPLAY_READING_BUDGET_POLICY` remains `/1`. ROOT owns the producer/finalize dispatch and inventory integration.

There is no copied planner, text inference, fake topic, reserved company slot or higher cap. The same closure, original-ID accounting, signature index, bounded work charging, lazy heap and diagnostic path serve all three reading strategies.

### Missing labels

Unlabelled meaningful facts do not count as demonstrably novel, but may receive a turn. In `/3`, their visit rank is the number of actual accepted unlabelled value bundles, rather than permanent zero. One complete three-row operating table increases this counter once while paying all three original rows' span/character costs. The finite index of unlabelled buckets is dirtied on an accepted unlabelled bundle; these visits and heap refreshes are charged against the existing work budget. `/1` and `/2` do not use the new count.

## RED evidence and final verification

- Old `/2` fairness failure is saved in `fairness-red.json`: seed + two repeatedly covered detail facts crowded out an equally valuable but less covered overview.
- New initial strategy tests: 10 FAIL / 1 PASS before `/3` implementation, then 11 PASS.
- Missing-label independent edge: 2 FAIL / 1 PASS before real unlabelled visits; original observations are saved in `unlabelled-red.json` (true command exit 1).
- Final new suite: 15 PASS, including labelled and unlabelled 20K-item shared-50-token-signature inputs, late sparse facts, no work-budget exhaustion at unchanged 2M/96/48K, explicit low-work stop, complete group fees and shared-context unique fees.
- Final affected node: **119 PASS, 18.59 seconds pytest time, actual child exit 0**. `pytest-final.log` and `pytest-final.json` record the exact command, process duration and stable before/after SHA.
- Historical parity: **1,000 deterministic generated graphs × 4 policies = 4,000 exact comparisons PASS**, including selected IDs and full diagnostics. `historical-baseline.json` was captured before implementation and is preserved; `historical-parity.json` and `parity-final.json` record final evidence.
- Ruff: PASS, true exit 0.
- mypy: PASS on the owned production module, true exit 0. Its disposable task-local cache was removed after the receipt was captured.
- Original parse/select calls: 0. Model POSTs: 0. Tests use pure planner fixtures; existing immutable/config guards remain active.

Final production SHA-256:
`44d2a739f4a1db6efcf0aa7fc33bb2227537b03f2659ec430c8220c838ca75b8`

Final new test SHA-256:
`57e7734e0a4808f1d7a072514d435a0ade40de2825fd4be3d2df318bd87ae377`

## Remaining ROOT acceptance

This node proves the shared ranking/closure/resource invariants and historical replay behavior. It does not claim CN 10/10 or any improved real-document result. ROOT must run the next same-original/same-gold/same-cap replay through the current producer and the already canonical quote oracle, then obtain independent review and commit/push with the rest of the node. Source is frozen for that review.
