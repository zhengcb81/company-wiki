"""Audit immutable captured model bytes only; no parser, original or API IO."""
import gzip
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
RUN = HERE.parent
bundle_path = next(RUN.glob('*.bundle.json.gz'))
input_path = next((RUN / 'materials').glob('*.input.json.gz'))
response_path = next((RUN / 'materials').glob('*.response.json.gz'))
paths = [bundle_path, input_path, response_path, RUN / 'overall.json']
before = {str(p.relative_to(RUN)): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
bundle = json.loads(gzip.decompress(bundle_path.read_bytes()))
request = json.loads(gzip.decompress(input_path.read_bytes()))
model_input = json.loads(request['messages'][1]['content'])
response = json.loads(gzip.decompress(response_path.read_bytes()))
assert len(model_input['evidence']) == len(bundle['evidence_spans']) == 96
# The captured canonical sequence and alias sequence agree exactly. Do not map
# only by text: EPI appears at two genuine distinct original locators.
alias_to_span = {}
for row, span in zip(model_input['evidence'], bundle['evidence_spans'], strict=True):
    assert row[1] == span['raw_text']
    alias_to_span[row[0]] = span
span_to_alias = {s['span_id']: alias for alias, s in alias_to_span.items()}
units = {row[0]: {'members': row[1], 'support': row[2]} for row in model_input['citation_units']}

# Human semantic judgments, keyed by immutable claim ID. These are observations,
# not edits to the paid output and not a new canonical truth state.
annotations = {
 'c1': ('FAIL', 'P1', ['e15'], '所引e14标题/e16持续改善段没有20.41、5.50、36.86%、30.51%；整组数字及研发验证概况在同一selected input的e15。数字本身与全输入吻合，逐claim出处不成立。'),
 'c2': ('PASS', None, [], 'e11明确报告期内完成众硅控股收购及干法+湿法跨越；没有改成筹划收购。'),
 'c3': ('WARN', 'P2', [], '正文保留现状超30%与未来五年60%/70%，未写已达成。单条forecast混合当前事实和管理层未来计划，宜拆成actual与planned；不应将覆盖率当市占率或模型预测。'),
 'c4': ('WARN', 'P2', [], '原文先说UD-RIE迭代，再以“同时，公司积极开拓…产品…重复订单”表述CCP整体动作。摘要收紧为UD-RIE在所有列举领域取得重复订单，具体产品归属强于原文；应保留公司/系列范围。'),
 'c5': ('PASS', None, [], 'Alpha实验室测试/Beta客户端验证均保留，未升级为量产。'),
 'c6': ('PASS', None, [], '保留实验室客户工艺开发、2026年内预计运付验证；没有写成已交付或量产。'),
 'c7': ('PASS', None, [], '三个ICP系列、50多个客户生产线及量产状态均有e22支持。'),
 'c8': ('WARN', 'P2', [], '文字事实有e23支持；一条混合LUX-Cryo稳定量产和Angnova实验室/客户端认证/订单，宜按产品拆开以保留阶段关系。'),
 'c9': ('PASS', None, [], 'Twin-Star装机增长、海内外应用范围和量产均有e24支持。'),
 'c10': ('FAIL', 'P1', ['e29', 'e31'], 'e30支持存储/逻辑客户验证和订单，但开头“该系列”需要e29的CVD/HAR/ALD名单；特殊器件现场验证在e31。两者均在输入但未被本claim引用。'),
 'c11': ('FAIL', 'P1', ['e34', 'e35'], '本claim实际所引e33是ALD氮化钛设备及其应用，不是Uniflash系统；Uniflash/SA&SU/SPTi/ALD TiNM定义和系统交付进展在e34/e35。'),
 'c12': ('FAIL', 'P1', ['e40', 'e44'], '本claim只引用MOCVD标题+e47红黄光LED样机；所述Micro-LED Preciomo Udx和新型GaN设备分别在e40/e44，实际引用不支持任一所述产品。'),
 'c13': ('FAIL', 'P1', ['e45', 'e47'], '本claim只引用MOCVD标题+e48 InP开发/未来计划，却断言SiC重复订单和红黄光LED验证；真实支持在e45/e47。'),
 'c14': ('FAIL', 'P1', ['e48'], '所引e46是红黄光LED开发及实验室波长均匀性，不能支持InP启动/下半年付运计划；InP完整支持在e48。'),
 'c15': ('WARN', 'P2', [], 'e50支持TSV300E服务/重复订单和第三代TSV研发/未来验证，未写验证完成；actual字段混合已发生与即将发运。该同段Primo Matrix被遗漏。'),
 'c16': ('WARN', 'P2', [], '所有面积/日期和临港二期拟开工均有e58支持；planned字段同时包含2024投用与2026落成事实，宜按基地/阶段拆。明确日期属后续披露，不应统一视为6月末已发生。'),
 'c17': ('WARN', 'P2', [], 'e59/e60支持广州/成都封顶及2027计划，保留已/计划区别；两基地应分别原子化。7/8月事件不等于报告期截止6月末状态。'),
 'c18': ('PASS', None, [], 'e84亿元、e85列头与e87/e92各列一致：43.46/6.11/29.91及ICP1.35/0.59/1.16。拟达到目标未冒充实现。引用覆盖整9行组，较宽但充分。'),
 'c19': ('PASS', None, [], 'PVD1.71/0.01/1.00及下一代钨3.40/0.17/0.96与e88/e89列头/单位吻合，均仍客户端验证。引用偏宽不构成数字错误。'),
 'c20': ('PASS', None, [], 'e96支持12英寸CMP核心技术/量产与干法互补，交易后能力表述为公司原文，未增加市占率或收入。'),
}

def evidence(alias):
    s = alias_to_span[alias]
    return {'alias': alias, 'span_id': s['span_id'], 'locator': s['locator'],
            'source_id': s['source_id'], 'source_role': s['structured_value'].get('source_role'),
            'raw_text': s['raw_text']}

claims = []
for raw, canonical in zip(response['claims'], bundle['summary']['draft']['claims'], strict=True):
    assert raw['claim_id'] == canonical['claim_id']
    expanded = {alias_to_span[a]['span_id'] for uid in raw['citation_unit_ids'] for a in units[uid]['support']}
    assert expanded == set(canonical['evidence_ids'])
    verdict, severity, needed, reasoning = annotations[raw['claim_id']]
    support = [span_to_alias[s] for s in canonical['evidence_ids']]
    context = [span_to_alias[s] for s in canonical.get('context_evidence_ids', [])]
    claims.append({'claim_id': raw['claim_id'], 'text': canonical['text'],
        'modality': canonical['modality'], 'canonical_needs_review': canonical['needs_review'],
        'citation_unit_ids': raw['citation_unit_ids'], 'decoder_expansion_exact': True,
        'actual_support': [evidence(a) for a in support],
        'actual_context': [evidence(a) for a in context],
        'semantic_verdict': verdict, 'severity': severity, 'reasoning': reasoning,
        'additional_true_support_already_in_model_input': [evidence(a) for a in needed]})

omissions = [
 {'topic': 'PRISMO PD5 GaN功率设备', 'severity': 'P1', 'aliases': ['e43'], 'reason': '既有gold关键要求；2022推出、目前生产验证及重复订单全未写，不能用未命名的新型GaN设备代替该代际产品。'},
 {'topic': 'Primo Matrix先进封装等离子切割', 'severity': 'P2', 'aliases': ['e50'], 'reason': '既有gold正常要求；同一已引用原文中有“即将发往”客户验证，c15只保留另两种产品。'},
 {'topic': 'EPI减压与常压不同阶段', 'severity': 'P2', 'aliases': ['e37', 'e83'], 'reason': '独立设备业务；成熟制程验证成功/先进量产验证/常压晶圆验证均未进摘要。'},
 {'topic': 'Primo Domingo气相刻蚀', 'severity': 'P2', 'aliases': ['e26'], 'reason': '新产品及Alpha实验室验证未覆盖。'},
 {'topic': '中微惠创/DAS尾气处理设备', 'severity': 'P2', 'aliases': ['e52'], 'reason': '非传统主业/合作及已在客户应用的重要新业务描述被遗漏。'},
 {'topic': '中微汇链数字平台', 'severity': 'P2', 'aliases': ['e54'], 'reason': '第二曲线具体规模超80场景/超900微服务全未覆盖。'},
 {'topic': '行业最新设备需求', 'severity': 'P2', 'aliases': ['e3'], 'reason': '报告引用SEMI预测2026全球1659亿美元/23.2%增长，输入有出处；可压缩为行业背景，不应当作已实现或公司预测。'},
 {'topic': 'Micro-LED样机首次付运时间', 'severity': 'P2', 'aliases': ['e40'], 'reason': '既有gold要求2023年底；c12删去起始时间，未谎称2026首次付运，但代际/历史阶段信息变薄。'},
]
for row in omissions:
    row['evidence'] = [evidence(a) for a in row['aliases']]

assert before == {str(p.relative_to(RUN)): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
result = {'schema_version': 'independent-real-summary-semantic-review/1',
    'sample': 'cn-h1', 'source_sha256': bundle['source_ref']['content_sha256'],
    'run_id': 'phaseC-090-b516fd38801c', 'mechanical_protocol_status': 'PASS',
    'semantic_quality_status': 'FAIL', 'semantic_counts': {v: sum(c['semantic_verdict'] == v for c in claims) for v in ('PASS','WARN','FAIL')},
    'decoder_expansion_exact_claims': 20, 'claims': claims, 'omissions_from_selected_input': omissions,
    'source_inputs_unchanged': True, 'input_fingerprints': before,
    'reviewer_api_calls': 0, 'reviewer_parse_calls': 0, 'reviewer_original_reads': 0,
    'all_key_fact_values_found_in_selected_input': True,
    'limitations': ['This is selected-input semantic review, not full-document recall certification.',
                    'Mechanical original replay inspected from existing receipt, not independently re-executed.',
                    'Overall run FAIL includes a separate old 0.8 HANDLER_EXCEPTION and is not the cause of these semantic failures.']}
(HERE / 'claim-review.json').write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n', encoding='utf8')
print(json.dumps({k:result[k] for k in ('semantic_quality_status','semantic_counts','decoder_expansion_exact_claims','source_inputs_unchanged')}))
