"""Pure observer adapter counterexamples; no model, source IO or reservation."""

from hashlib import sha256
import json
from pathlib import Path
import sys
from types import SimpleNamespace

import pytest

ROOT = Path(__file__).resolve().parents[4]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "src"))
from phase_c_observer import gold_observation  # noqa: E402
from company_wiki.automation.narrative_model import _group_mapping  # noqa: E402
from company_wiki.source_contract import EvidenceCoordinates, EvidenceSpan, source_id_for_sha256  # noqa: E402

SOURCE = source_id_for_sha256("a" * 64)


def span(text, index=0, *, native_range=False, page=1, block=None, source=SOURCE, role="company_filing", group=None):
    return EvidenceSpan.create(source_id=source, raw_text=text,
        coordinates=EvidenceCoordinates(page_number=page, paragraph_index=index),
        parser_name="native_pdf_range_parser" if native_range else "selective_narrative_parser",
        parser_version="0.1.0" if native_range else "0.1.1", parse_status="parsed", quality_flags=(),
        structured_value={"unit_kind": "pdf_native_range" if native_range else "pdf_text_block",
            "source_role": role, "language": "zh", **({"selection_group_id": group} if group else {}), "selection_reasons": ["reading_plan"],
            "pdf_block": index if block is None else block,
            "block_sha256": sha256(str(index if block is None else block).encode()).hexdigest(),
            "block_char_start": 0, "block_char_end": len(text)})


def context(groups, *, kind="background"):
    values = []
    for members in groups:
        ids = [row.span_id for row in members]
        digest = sha256(json.dumps(ids, separators=(",", ":")).encode()).hexdigest()
        values.append({"group_id": "urn:company-wiki:reading-group:sha256:" + digest,
            "evidence_ids": ids, "kind": kind, "section_role": "business"})
    return {"schema_version": "du-production-reading/1", "groups": values}


def observe(rows, supports, *, ctx=None, envelope_mutation=None):
    selected = SimpleNamespace(evidence_spans=tuple(rows), reading_context=ctx,
        source_ref=SimpleNamespace(source_id=SOURCE, content_sha256="a" * 64),
        subject=SimpleNamespace(kind="raw_pdf"), source_metadata=SimpleNamespace(document_kind="annual_report"))
    aliases = {row.span_id: f"e{i}" for i, row in enumerate(rows, 1)}
    envelope = {"schema_version": "narrative-model-request/1.4", "evidence_columns": ["id", "raw_text", "source_role", "quality_flags"],
        "default_source_role": "company_filing", "default_quality_flags": [],
        "evidence": [[aliases[row.span_id], row.raw_text] + ([row.structured_value["source_role"]]
            if row.structured_value["source_role"] != "company_filing" else []) for row in rows],
        "evidence_group_columns": ["id", "evidence_ids"],
        "evidence_groups": [[alias, [aliases[sid] for sid in members]]
            for alias, (_, members) in _group_mapping(selected).items()]}
    if envelope_mutation:
        envelope_mutation(envelope)
    gold = {"source_sha256": "a" * 64, "facts": [{"id": "fact", "importance": "critical",
        "target_kind": "required_business", "role": "company_filing", "any_support_sets": [supports]}]}
    return gold_observation(gold, selected, envelope)


def anchor(text, *, page=1):
    return {"location_kind": "page", "page": page, "exact_quote": text}


def test_verified_native_range_support_includes_real_cjk_wrap_and_future_condition():
    row = span("公司将通\n过合作开发产品。\n下半年将送样验证。", native_range=True)
    result = observe([row], [anchor("公司将通过合作开发产品。下半年将送样验证。")], ctx=context([[row]], kind="native_continuity"))
    assert not result["missing_ids"]


def test_closed_native_window_reuses_canonical_cross_block_support():
    rows = [span("公司新产品进入客户生产验", 0), span("证，尚未量产。", 1)]
    result = observe(rows, [anchor("公司新产品进入客户生产验证，尚未量产。")], ctx=context([rows], kind="native_continuity"))
    assert not result["missing_ids"]


def test_actual_separate_groups_cannot_satisfy_one_and_even_when_all_quotes_are_selected():
    rows = [span("新设备已开展客户验证。", 0), span("另一设备尚未量产。", 1)]
    result = observe(rows, [anchor(row.raw_text) for row in rows], ctx=context([[row] for row in rows]))
    assert result["missing_ids"] == ["fact"]
    assert result["facts"][0]["all_anchors_individually_present"]


def test_one_actual_closed_group_can_satisfy_its_and_support_set():
    rows = [span("新设备已开展客户验证。", 0), span("另一设备尚未量产。", 1)]
    assert not observe(rows, [anchor(row.raw_text) for row in rows], ctx=context([rows]))["missing_ids"]


@pytest.mark.parametrize("native_range", [False, True])
def test_observer_does_not_join_english_words(native_range):
    row = span("We provide owner\nship services.", native_range=native_range)
    assert observe([row], [anchor("ownership")], ctx=context([[row]]))["missing_ids"]


def test_legacy_single_span_stays_legacy_without_borrowing_new_native_proof():
    row = span("设备已进入客户验证，尚未量产。")
    assert not observe([row], [anchor(row.raw_text)])["missing_ids"]
    split = [span("设备已进入客户", 0), span("验证，尚未量产。", 1)]
    assert observe(split, [anchor("设备已进入客户验证，尚未量产。")])["missing_ids"]


def test_model_envelope_cannot_recombine_true_source_groups():
    rows = [span("设备已进入客户验证。", 0), span("另一设备尚未量产。", 1)]
    with pytest.raises(AssertionError):
        observe(rows, [anchor(row.raw_text) for row in rows], ctx=context([[row] for row in rows]),
            envelope_mutation=lambda env: env.update(evidence_groups=[["g1", ["e1", "e2"]]]))


def test_model_envelope_group_order_and_membership_must_equal_actual_source_context():
    rows = [span("设备已进入客户验证。", 0), span("尚未量产。", 1)]
    with pytest.raises(AssertionError):
        observe(rows, [anchor(rows[0].raw_text)], ctx=context([rows]),
            envelope_mutation=lambda env: env.update(evidence_groups=[["g1", ["e2", "e1"]]]))


@pytest.mark.parametrize("change", ["role", "quality_flags"])
def test_actual_evidence_columns_do_not_silently_change_source_role_or_quality(change):
    row = span("设备已进入客户验证。")
    with pytest.raises(AssertionError):
        observe([row], [anchor(row.raw_text)], ctx=context([[row]]),
            envelope_mutation=lambda env: env.update(
                default_source_role="analyst" if change == "role" else "company_filing",
                default_quality_flags=["locator_unstable"] if change == "quality_flags" else []))


@pytest.mark.parametrize("boundary", ["source", "page", "role"])
def test_observer_canonical_oracle_keeps_actual_source_page_and_role(boundary):
    changes = {"source": {"source": source_id_for_sha256("b" * 64)},
        "page": {"page": 2}, "role": {"role": "management"}}
    row = span("设备已进入客户验证。", **changes[boundary])
    assert observe([row], [anchor(row.raw_text)], ctx=context([[row]]))["missing_ids"]


def test_one_canonical_oracle_is_authoritative_without_local_matching_fallback(monkeypatch):
    from tools.document_understanding_benchmark import closed_group_support
    row = span("设备已进入客户验证。")
    seen = []
    def controlled(facts, *, evidence_spans, reading_context, source_id):
        seen.append((facts, evidence_spans, reading_context, source_id))
        return [{"id": "fact", "supported": False, "all_anchors_individually_present": True}]
    monkeypatch.setattr(closed_group_support, "score_facts", controlled)
    ctx = context([[row]])
    result = observe([row], [anchor(row.raw_text)], ctx=ctx)
    assert result["missing_ids"] == ["fact"] and len(seen) == 1
    assert seen[0][1:] == ((row,), ctx, SOURCE)


def test_legacy_native_order_group_does_not_require_selection_rank_order():
    first = span("新设备已进入客户验证。", 0, group="actual-source-group")
    later = span("后续计划推进量产。", 1, group="actual-source-group")
    rows = [later, first]  # old selection is ranked; model group is native ordered
    groups = _group_mapping(SimpleNamespace(evidence_spans=tuple(rows), reading_context=None,
        subject=SimpleNamespace(kind="raw_pdf"), source_ref=SimpleNamespace(source_id=SOURCE, content_sha256="a" * 64),
        source_metadata=SimpleNamespace(document_kind="annual_report")))
    assert next(iter(groups.values()))[1] == (first.span_id, later.span_id)
    result = observe(rows, [anchor(first.raw_text), anchor(later.raw_text)])
    assert result["missing_ids"] == []


def test_new_production_context_still_rejects_reordered_members():
    rows = [span("新设备已进入客户验证。", 0), span("后续计划推进量产。", 1)]
    with pytest.raises(ValueError, match="original selection order"):
        observe(rows, [anchor(rows[0].raw_text)], ctx=context([list(reversed(rows))]))
