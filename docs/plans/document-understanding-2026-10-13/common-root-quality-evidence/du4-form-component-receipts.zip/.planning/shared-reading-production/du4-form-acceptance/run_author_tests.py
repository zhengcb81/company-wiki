from pathlib import Path
import hashlib,json,os,sys,tempfile,time
from company_wiki._bounded_process import run_bounded,ChildFailed
ROOT=Path(__file__).resolve().parents[3]
AUTHOR=ROOT.parent/'company-wiki-du4-form'
OUT=Path(__file__).parent
before={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in (ROOT/'config.yaml',ROOT/'config/source_catalog.yaml')}
start=time.perf_counter()
with tempfile.TemporaryDirectory(prefix='.cw-form-',dir=ROOT) as name:
 folder=Path(name);sentinel=folder/'existing.txt';sentinel.write_bytes(b'prior test contents')
 env=dict(os.environ,PYTHONPATH=str(AUTHOR/'src'),PYTHONDONTWRITEBYTECODE='1',TEMP=name,TMP=name)
 try:
  result=run_bounded([sys.executable,'-B','-X','utf8','-m','pytest','-q','-p','no:cacheprovider','--basetemp',str(folder/'p'),'--junitxml',str(OUT/'author-root-junit.xml'),'tests/unit/du4_source_signals'],cwd=str(AUTHOR),env=env,timeout_seconds=120,stdout_cap_bytes=256*1024,stderr_cap_bytes=64*1024)
  code,stdout,stderr=result['returncode'],result['stdout'],result['stderr']
 except ChildFailed as exc:code,stdout,stderr=exc.returncode,exc.stdout,exc.stderr
 finally:
  assert sentinel.read_bytes()==b'prior test contents'
  assert before=={p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in before}
 (OUT/'author-root-stdout.log').write_bytes(stdout);(OUT/'author-root-stderr.log').write_bytes(stderr)
 print(stdout.decode('utf8',errors='replace'))
assert not folder.exists()
r={'exit_code':code,'seconds':time.perf_counter()-start,'author_source':str(AUTHOR/'src'),'supplier_calls':0,'production_config_unchanged':True,'temp_removed':True}
(OUT/'author-root-receipt.json').write_text(json.dumps(r,indent=2),encoding='utf8');print(json.dumps(r));raise SystemExit(code)
