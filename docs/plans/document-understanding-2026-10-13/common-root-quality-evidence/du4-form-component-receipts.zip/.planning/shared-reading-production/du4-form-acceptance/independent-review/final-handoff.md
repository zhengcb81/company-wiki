# DU4-FORM ROOT集中修复：独立复核收尾

2026-10-15；审查者`attribution_release_review`。

## 结论

**PASS_COMPONENT：初审两项P2与一项P3已关闭，未发现阻断本组件接收的新问题。** 本结论针对ROOT工作树的source_signals修复，不替换作者树最初交付的REQUEST_CHANGES记录。作者目录没有改动，原`handoff.md/json`、`probe.py`和`probe-results.json`完整保留。

已只读审查ROOT最终`source_signals/__init__.py`与新增`test_root_bounded_carriers.py`，并把原纯探针复制到本审查目录，**强制导入ROOT/src**后执行少量精确观测和断言。`final-probe.py`的11组观察全部通过，`final-probe-results.json`保存实际import路径和所有值。没有读原件/生产配置/密钥，没有API/供应商、真实AUTO或parse，没有写ROOT/作者源码、测试、PWF、配置、Git或其他DU4目录。

ROOT报告原72条加9条真实RED对应回归为**81PASS/1.76秒**，Ruff与mypy通过；这部分属于ROOT执行，本审查没有重复全suite。新增测试直接替换真实input中的计数列表，确实观察collector工作，避免builder先复制列表导致的假覆盖。

收尾后ROOT又将本测试目录设为独立Python包，并把共享名字`builders`/`conftest`改为包内`.builders`/`.conftest`相对导入，避免与兄弟施工卡同名helper相互污染。已只读核对包标记与实际相对导入，没有重跑suite。ROOT此前327PASS属于此namespace修正之前，最终全部验证待正常pre-push；不能用先前绿结果冒充修改后已跑。生产模块随后只补“必须连续”的文档声明，ROOT报告行为未变；本审查读到该声明，未重新执行11组探针。JSON分别保留探针时源码指纹和最终静态快照。

## 问题关闭证据

| 初审问题 | ROOT修复责任 | 独立复核实际结果 |
|---|---|---|
| P2-FORM-01：同owner非连续refs制造表单 | refs排序后同时拒绝重叠与非相邻覆盖，不删除原文缺口 | `FORM 10-notaform-Q`两个切片返回`DISCONTINUOUS_VALUE_REFS`、unavailable、零form/零reservation；连续refs即使输入倒序仍正确输出`FORM 10-Q`/complete |
| P2-FORM-02：预算前扫描、raw JSON复制、平方reservation | carrier入口先charge；单位校验合并到有预算循环；只提取固定native attribute；dedup只序列化已成功解析的entry；保序list配套set | budget0原10000个ID→0遍历；200units/200chars/index耗尽后原200个ID→0遍历；ignored 100KB payload→零serialization；200turn reservation比较19900→0，仍保留200个有序ID |
| P3 kind容器抛TypeError | 先检查str再集合成员判断 | dict/list均为合同规定ValueError |

额外边界也通过：成功载体中的20000个ignored值零遍历；预算不够的ref payload没有被读取；重复hidden载体两次均drop，resolved=0、unavailable，没有经dedup洗成“已解决”。

dedup现在位于成功解析以后，以生成的有限事实entry为身份；被忽略字段和raw扩展值不再影响去重，也不会在工作预算之前被递归序列化。hidden、缺ref、错误parent等未解决载体不会进入成功索引。具体字符串/列表格式化仍随已读取材料与已生成输出规模工作，并不宣称每个CPU操作都恰好是一个work unit；耗尽后只收尾已确定输出，不遍历未付费输入尾部。原200units/64k字符调用cap没有扩大。

## 保持的架构与范围

仍是消费已经观察native carriers的纯组件，不新parse DOM、不扫描整份文档、不决定family/route/置信度，不从冒号或黑名单推断speaker，不增加第二预算/queue/审批合同。原Unicode偏移、父来源、显式可见性、未知字面值及冲突诊断规则保持。

**本次通过不表示normalize→structure→adapter→router→selector生产接线已经验收。** 真实VRSK新鲜有界重放、真实电话会与8-K附件holdout仍由ROOT后续接线节点负责；不能用这11组纯反例或作者局部保存观察替代真实E2E。原正式摘要错引/覆盖的母质量问题也不属于本FORM组件通过范围。

源码与证据SHA、独立/ROOT测试所有者见`final-handoff.json`。

## 补充独审：Git传输必须保持retained fixture原字节

ROOT在推送前发现并停止发布的字节问题，经本审查独立只读确认。没有改fixture、gold、manifest或Git索引，只使用`git show :<path>`读当前已暂存blob并与工作区bytes计算SHA，收据`git-byte-boundary-readonly.json`：

| 文件 | 工作区bytes | index blob bytes | 独立结论 |
|---|---:|---:|---|
| adapter-identity-observation.json | 2157 | 2098 | 工作区SHA符合manifest；index恰是59处CRLF被转LF后的SHA |
| us-10q-observation.json | 6725 | 6536 | 工作区SHA符合manifest；index恰是189处CRLF被转LF后的SHA |
| manifest.json | 951 | 927 | 同样有24处CRLF被转LF；manifest正文语义不变，但字节已变 |

这是**Git存储/checkout边界**的覆盖缺口。仅在Windows工作区跑原72条测试能全部绿，不能证明Linux从blob检出的retained bytes仍匹配声明SHA。本组件纯逻辑修复通过不等于发布载体正确；也不应通过修改gold SHA迎合自动换行来掩盖事实。

对ROOT拟议方案的结论：**设计合理，无新增阻断建议。** 在既有.gitattributes的字节证据职责处加入通用`/docs/plans/**/fixtures/** -text`，依据保存证据的目录角色保留字节，不依赖公司、日期、这两份文件名或特定hash，因此不是逐fixture特判。它不关闭内容测试、放宽身份或费用规则，也不要求新审批。只将当前三份FORM fixture按实际保留字节定点重新入index，避免全库renormalize改动其他历史证据；未来别的已存blob若有SHA问题，应逐项按其声明的真实保存字节核实，不能批量假定。

ROOT计划新增独立临时Git仓库的`core.autocrlf=true/input/false`往返TDD是恰当的回归边界。有效断言应核对add后实际blob及新checkout字节，不只是原工作区hash；保留无属性会改变CRLF的负控和有属性保持CRLF/LF的正控。每个临时仓库配置必须局部，清理仅自己创建的tmp，不动用户全局Git配置。`-text`本身不要求禁止diff；ROOT应由现有集中门确认CRLF与diff/whitespace检查兼容，不能以关闭CI代替字节保真。

本补充是设计审查和当前坏blob的独立复现；**未执行拟议新Git往返测试、未重新暂存或发布，也未验证修改后远端blob**。这些属于ROOT正常修复/集中测试/推送流程，不增加第二次人工小节点审批。两项原P2与P3的组件关闭结论维持，发布字节回归由新测试和最终blob核对验收。
