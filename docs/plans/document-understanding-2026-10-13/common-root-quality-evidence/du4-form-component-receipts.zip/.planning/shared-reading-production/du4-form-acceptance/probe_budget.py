import json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(ROOT.parent/'company-wiki-du4-form'/'src'))
from company_wiki.document_understanding.source_signals import collect_source_signals
from company_wiki.document_understanding.layout_hints.contract import WorkBudget
class CountedList(list):
 def __iter__(self):
  for x in super().__iter__():
   self.visited+=1
   yield x
 def __init__(self,seq):super().__init__(seq);self.visited=0
unit={'text':'FORM 10-Q','parent_id':'p','role':'company_filing','kind':'html_paragraph','locator':'loc:v1/paragraph:0'}
def obs(ids,refs,**ext):return {'schema_version':'du4-source-signal-observation/1','units':{'u':unit},'carriers':[{'kind':'visible_own_form_label','unit_ids':ids,'value_refs':refs,'parent_id':'p','attributes':{},**ext}]}
ids=CountedList(['u']+[f'unknown-{i}' for i in range(20000)])
a=collect_source_signals(obs(ids,[]),work_budget=WorkBudget(1))
refs=CountedList([{'unit_id':'u','char_start':0,'char_end':9} for _ in range(20000)])
b=collect_source_signals(obs(['u'],refs),work_budget=WorkBudget(2))
r={'unit_ids_visited_with_budget1':ids.visited,'value_refs_visited_with_budget2':refs.visited,'first_result_work':a['work_used'],'second_result_work':b['work_used'],'statuses':[a['status'],b['status']],'supplier_calls':0}
print(json.dumps(r));Path(__file__).with_suffix('.json').write_text(json.dumps(r,indent=2),encoding='utf8')
