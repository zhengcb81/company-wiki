# DU4-FORM 作者交付：独立只读大节点审查

2026-10-15；审查者 `attribution_release_review`。

## 结论

**REQUEST_CHANGES_COMPONENT：发现两项P2共因问题，建议修复后接收该组件进入生产接线。** 没有证据表明已经产生生产错误：当前交付是尚未接入normalize→router的纯组件，不能将缺少生产接线本身当作缺陷。作者树HEAD经正常主机只读Git确认是`2cde9de9118273b3e74b7612131cb635a6d016b0`。

审查按ROOT固定`du4-interfaces/1`，阅读作者source_signals两个源码文件、卡/交接、预算合同和主要测试。CodeGraph提供共用WorkBudget结构入口，其余结论引用作者当前源码。只运行报告目录中的纯内存探针，显式将作者src置于import首位，并保存真实`__file__`；没有修改作者树/源码/测试/PWF/Git/DU4 sibling，没有供应商/API、真实AUTO、原件或配置读取。作者72绿测试是作者交接证据，ROOT正集中复核，本报告没有冒充独立重跑72条。

## P2-FORM-01：同owner但不连续的TextRef可以拼出原文不存在的已知表单

责任位置：`source_signals/__init__.py:312–329`，尤其`value = "".join(span[3] for span in ordered)`。

可执行反例已经保存于`probe.py`及`probe-results.json`：

```text
unit.text = "FORM 10-notaform-Q"
value_refs = u[0:7], u[16:18]
实际输出：value="FORM 10-Q", normalized_value="10-Q"
status="complete", diagnostics=[]
```

原parent/单位/Unicode偏移均合法，同一unit只表示同一native owner，**不表示中间9个真实原文字符可以消失**。当前只拒绝重叠和跨owner，允许任意缺口。该反例不涉及路由、文件名或provider声明，却已经在collector输出层把不存在的已知表单包装为完整observed事实；未来唯一router若依赖该值，会继承错误。

共同根因是把“相同owner”当成“打印值连续”的充分条件。作者的inline wrapping正控仅覆盖两段**相邻**refs；跨owner负控不能发现同owner缺口。

建议在本组件已有refs处修复，不增加身份审批、不重parse：对同owner多段refs检查实际覆盖关系。相邻片段可合并；非连续片段须保留实际原文缺口，或报告具体ambiguous/unavailable诊断而不输出无损连续表单值。如果未来有真实native exclusion/continuation可证明缺口不属于打印值，应由同一次解析产生显式结构证据，再由固定接口约定消费，不能仅凭同owner补这种证据。

TDD最低反例：相邻inline正控；乱序输入按原位次保留；同owner非空正文gap不能产出已知表单；空白gap必须保留实际写法或明确诊断；跨owner和重叠原有负控继续成立。未知原始表单本身仍可观察保留，不把词汇表变成拒绝门。

## P2-FORM-02：WorkBudget没有覆盖实际循环，去重还序列化被忽略的数据

责任位置：`_process_carrier`首次charge之前的unit_ids循环（约153–161）、`json.dumps(raw)`（179）、`_reserve`的list membership（465–468）。这是同一有界工作责任问题，建议一起修复。

| 纯探针 | 实际观测 | 为什么现有200/64k cap不足以替代修复 |
|---|---|---|
| 空units、budget=0、10000个待检查unit_ids | 遍历10000个ID，work_used=0，carriers_seen=0 | 此例证明组件入口自身无工作上限；不是声称该畸长carrier会由正常parser产出 |
| 合法200units、200个原文字符、budget=200已被index耗尽 | 仍在首次carrier charge前完整遍历200个ID | 已在原200units/64k字符内，预算耗尽后仍执行可避免循环 |
| 1unit/9字符、budget=2、未使用attribute `ignored_blob`有100000字符 | dedup序列化100173字节，然后才因下一charge返回partial | cap约束unit原文，不约束被忽略attribute或raw carrier额外字段；未知内容不应先被递归复制 |
| 200units/200字符、200个真实turn carrier | work_used=600，reserved=200；仅_reserve就执行19900次字符串相等比较，最后一次199次 | 此例在cap内；实际规模有上界，但固定cap不能使有界预算计数或线性复杂度声明变真 |

前两项以CountingList统计真实yield次数，第三项包装实际json.dumps记录生成字节，第四项用str子类只计`_reserve`中的相等比较；没有用机器耗时猜测复杂度。所有载体/单位构建均在调用前完成，不计入组件运行。

建议：在实际遍历/索引工作发生前消费同一个caller预算，不能在循环后记账；对unit_ids的一次带预算遍历同时校验、构建集合、核对parent，避免重复扫描。dedup仅从已检查、确实使用的native字段建立有限不可变键，不对raw任意嵌套payload做JSON全文复制；忽略字段不能参与证据身份或迫使遍历其值。保留reserved list的确定顺序，同时用伴随set做O(1)去重。保留耗尽前完整确定的证据/冲突，不创建第二个预算/queue，也不提高route cap。

现有`test_large_observation_work_is_honestly_metered`将“每unit+每carrier+每carrier成员+每ref”的旧计数公式写死，只能证明计数器自洽，不能证明计费前未做额外循环。新增耗尽后的操作计数、未知attribute值不被遍历/复制、线性reservation的控制；原来的精确数字应随真正责任操作调整，不能用旧公式框住不完整实现。

## 非阻断P3：畸形kind产生TypeError，而非合同规定ValueError

`kind in CARRIER_KINDS`在dict/list输入上会抛`TypeError: unhashable type`。已分别复现。字符串未知kind现有测试正常，但没覆盖合法JSON容器类型。可先检查kind是str再集合比较，沿用结构错误ValueError，不必增加许可/身份规则。此项不导致来源伪造，单独不阻断接收。

## 其余检查与证据边界

- 没有第二router、文件/网络/配置/模型访问或再解析；输出没有family/route/confidence。来源角色和TextRef保留，不从冒号或大写形状推断发言。
- 原单位parent与carrier parent核对；refs必须落在carrier自身unit且不越界，不能借封面候补。显式hidden/excluded/external DEI被剔除；缺visibility依赖已观察kind本身，这是现接口语义，不能误报成必须重复证明visibility。
- 未知表单保留字面值和诊断，同parent冲突保留多值并partial；跨parent记录不合成同一表单。耗尽后已确定冲突仍输出是合理目标，但result中的聚合并非注释声称的严格O(1)，应解释为对已输出数据的有界收尾。
- native speaker turn依赖上游真实carrier，不新造Q/A关系；table形状不被一律排除。source-owned turn_id的同unit speaker+body当前可能保留空body_refs，作者已明确known limit，不将此报告为新发现；真实transcript/8-K holdout尚未覆盖。
- 两份所谓真实fixture是保存的**局部观察**，不包含新鲜完整parse/原件验证；测试真实SHA/引用与合成流装配有价值，但不等于normalize→structure→adapter→router→selector的生产E2E。
- 作者conftest的`parents[3]`确实指repo，**没有**此前猜测的tests/src路径缺陷；本审查未沿该错误线索报问题。

## 接收建议

ROOT可在自己的整合阶段用同一大节点TDD关闭P2两项和低成本P3，不需再发小节点审批。集中回归已有72条与新增反例，确认原refs、输入不变、同一预算累计与partial留证保持。随后依固定接口接一次native观察/现router，并独立进行真实VRSK与跨公司/电话会/附件验收。**组件修复通过不表示生产接线或真实文档路由已验收。**
