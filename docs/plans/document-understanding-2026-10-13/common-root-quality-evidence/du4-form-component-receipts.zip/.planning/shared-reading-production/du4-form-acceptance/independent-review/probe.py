"""Independent pure probes against the explicit DU4-FORM author tree."""
from pathlib import Path
import json
import sys

AUTHOR = Path('C:/Users/郑曾波/Projects/company-wiki-du4-form')
sys.path.insert(0, str(AUTHOR / 'src'))
import company_wiki.document_understanding.source_signals as ss
from company_wiki.document_understanding.layout_hints.contract import WorkBudget

def unit(text='FORM 10-Q'):
    return dict(text=text,parent_id='p',role='company_filing',kind='html_paragraph',locator='paragraph:1')
def carrier(ids,refs,**attrs):
    return dict(kind='visible_own_form_label',unit_ids=ids,value_refs=refs,parent_id='p',attributes=attrs)
def ref(uid,start=0,end=9):
    return dict(unit_id=uid,char_start=start,char_end=end)
def obs(units,carriers):
    return dict(schema_version=ss.SCHEMA_IN,units=units,carriers=carriers)

out={'imported_from':str(Path(ss.__file__).resolve()),'api_calls':0,'original_reads':0}

class CountingList(list):
    yielded=0
    def __iter__(self):
        for value in super().__iter__():
            self.yielded+=1
            yield value

# With no units to index, a zero work budget still walks all unit IDs.
ids=CountingList('missing-'+str(i) for i in range(10000))
b=WorkBudget(0)
r=ss.collect_source_signals(obs({},[carrier(ids,[])]),work_budget=b)
out['precharge_iteration']={'unit_ids_iterated':ids.yielded,'work_used':b.used,'status':r['status'],'carrier_seen':r['observed_counts']['carriers_seen']}

# Same issue exists with a legal 200-unit/200-char input after budget is spent.
ids=CountingList('u'+str(i) for i in range(200))
b=WorkBudget(200)
r=ss.collect_source_signals(obs({uid:unit('x') for uid in list.__iter__(ids)},[carrier(ids,[])]),work_budget=b)
out['within_route_cap_precharge_iteration']={'units':200,'source_chars':200,'carrier_unit_ids_iterated':ids.yielded,'work_used':b.used,'status':r['status']}

# A semantically ignored attribute is fully serialized for dedup before refs
# can be reserved. Source chars are still 9, so a source-text cap cannot bound it.
serialized=[]
original_dumps=ss.json.dumps
def record_dumps(value,*args,**kwargs):
    result=original_dumps(value,*args,**kwargs)
    serialized.append(len(result.encode('utf-8')))
    return result
ss.json.dumps=record_dumps
try:
    b=WorkBudget(2)
    r=ss.collect_source_signals(obs({'u':unit()},[carrier(['u'],[ref('u')],ignored_blob='z'*100000)]),work_budget=b)
    out['ignored_attribute_serialization']={'units':1,'source_chars':9,'work_used':b.used,'serialized_bytes':serialized,'status':r['status'],'evidence':len(r['source_form_evidence'])}
finally:
    ss.json.dumps=original_dumps

# Instrument exact list membership comparisons in _reserve, not elapsed time.
class CountStr(str):
    comparisons=0
    __hash__=str.__hash__
    def __eq__(self,other):
        type(self).comparisons+=1
        return str.__eq__(self,other)
reserve_comparisons=[]
original_reserve=ss._Collector._reserve
def record_reserve(self,ids):
    before=CountStr.comparisons
    original_reserve(self,ids)
    reserve_comparisons.append(CountStr.comparisons-before)
ss._Collector._reserve=record_reserve
try:
    ids=[CountStr('u'+str(i)) for i in range(200)]
    units={uid:unit('x') for uid in ids}
    carriers=[]
    for i,uid in enumerate(ids):
        c=carrier([uid],[],turn_id='t'+str(i))
        c['kind']='native_speaker_turn'
        carriers.append(c)
    b=WorkBudget(800)
    r=ss.collect_source_signals(obs(units,carriers),work_budget=b)
    out['reserve_membership']={'units':200,'source_chars':200,'work_used':b.used,'status':r['status'],'reserved':len(r['reserved_unit_ids']),'reserve_str_eq_calls':sum(reserve_comparisons),'last_reserve_eq_calls':reserve_comparisons[-1]}
finally:
    ss._Collector._reserve=original_reserve

text='FORM 10-notaform-Q'
refs=[ref('u',0,7),ref('u',text.rfind('-Q'),len(text))]
r=ss.collect_source_signals(obs({'u':unit(text)},[carrier(['u'],refs)]),work_budget=WorkBudget(100))
out['discontinuous_same_owner_value']={'source_text':text,'refs':refs,'result':r}

for kind in ({},[]):
    c=carrier(['u'],[ref('u')]);c['kind']=kind
    try:
        ss.collect_source_signals(obs({'u':unit()},[c]),work_budget=WorkBudget(100))
    except Exception as exc:
        out['malformed_kind_'+type(kind).__name__]={'exception':type(exc).__name__,'message':str(exc)}

target=Path(__file__).with_name('probe-results.json')
target.write_text(original_dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(original_dumps(out,ensure_ascii=False,indent=2))
