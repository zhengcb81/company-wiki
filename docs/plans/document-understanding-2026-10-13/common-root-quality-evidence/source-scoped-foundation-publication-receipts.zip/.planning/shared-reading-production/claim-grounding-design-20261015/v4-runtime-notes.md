# ROOT下一正式接线的已核源码接口（2026-10-15）

当前commit5f54f81b源码冻结，正常push验证正在跑，不改工作树源码。以下是下一节点设计，不是已实现/验收。

1. `narrative_generation._bind_reading_projection`在selector0.9且未显式冻结projection时，目前选v3。`generation_manifest(... reading_model_projection=...)`已有显式测试端口，不另造env override/config模型开关。新v4注册完成后才更新0.9新generation默认；历史manifest的projection按原值，公开selector默认0.8保持。
2. `narrative_model.resolve_model_boundary`、`reading_model_boundary_identity`和request `from_selection/with_output_budget`需要有限v4独立分支；request schema用新版本，不就地改v3。新compiler/sourceplan实现哈希必须进入v4因果身份，最终HTTP字节沿原reservation hash；当前view.binding_sha只证明引用映射，不是完整wire或实现哈希。
3. `_validate_model_software`在summarize前比较所需模型软件身份；已paid/verify/outbox阶段继续stage-scoped恢复。全narrative_model文件SHA会被新增v4改变，因此需要真实旧v3 paid/no-POST恢复反例，不能凭新metadata声称兼容。未知版本仍0POST拒绝；不得伪装修改后的软件等于旧SHA。
4. `narrative_summarize`从subject冻结projection，先validate_model_execution，然后唯一caller.generate，再decode。复用这条线，不新增model任务/第二费用账。
5. v4输出建议固定`sparse drafts_by_task: {tN: [clause...]}`，clause只含text/basis_parts/modality；claim_id按source plan/task+ordinal由程序生成，claim_type按source-owned support roles推导，source/hash/language/context全部来自程序。减少让模型重复抄已知字段；不把错误文字因task合法就当真。claim_type/modality必须复用原统一规则，不能再造分类分支。
6. response_schema不要为64个task复制64份schema；使用有限object +同一clause schema，未知key由程序精确映射验证。所有clauses先计总数再校验，21条不能按任务拆开绕过20条限制；key重复由现有strict JSON reader拒绝。坏条整条恢复，不静默删错引用或补邻居。
7. 当前source task仅保存原group scope；该系列定义/产品/阶段关系和重要方向分配仍需在唯一共享引擎native结构/策略层补有证据的依赖。native窗口8成员/4块等已有边界不能直接放大或把整章变事实。不要因source span原文相邻就自动归同一产品。
8. v4 request observer/测试response fixture必须同步真实shape，不能旧schema假数据装作新正式调用。下一次真实MiMo/DeepSeek/MiniMax遵守已有配置、统一2M/$20账，先冻结候选、0盲目重发；同时检验原6错引和重要业务遗漏/新公司。

正常prepush的全单元触发原因已经只读确认：changed_unit_tests将tools/及tests/fixtures/一律global；当前这批包含两者所以必走全suite。作为后续效率审视线索，不在推送过程中改规则或跳过检查。
