# Explicit v4 public request — implementation / execution recipe

## Public input (both batch schemas)

Keep the existing request and its supplier/pricing/resource settings. Add only:

```json
{
  "selector_version": "0.9.0",
  "reading_model_projection": "reading-model-input/4"
}
```

For schema /1 use existing `sources`; schema /2 uses existing `items` (raw or official_json). Null, empty, whitespace-padded, unavailable projections or selector 0.8 are rejected before execution. Omit the field to preserve the current production defaults exactly. This is ordinary request intent, not another permission/canary.

## Composition and single owners

1. `NarrativeBatchRequest.from_dict/to_dict` retains the optional explicit protocol field. Omitted requests keep all old normalized bytes and hashes (six pre-edit frozen forms).
2. `_item_generation` only supplies the request field when its explicit argument is UNSET. Existing resume calls supply the recorded manifest protocol and retain precedence.
3. Existing generation owner binds current protocol implementation, prompt, schema and validator hashes. Existing common-settings freeze, generation SHA and artifact reuse pin bind these automatically. Do not add cache tables or change run-container compatibility prompt versions.
4. Configured launcher remains Config -> model_options_from_config(purpose=narrative) -> batch CLI. Config owns model ID, endpoint, output cap, temperature and reasoning controls. Request supplies its supported timeout/byte caps. Never put projection selection in the provider dict or switch vendors in this recipe.

## Actual local test command

```powershell
python -B -m pytest tests/integration/test_shared_scoped_public_request.py tests/unit/test_narrative_scoped_runtime_binding.py tests/unit/test_narrative_scoped_runtime_legacy.py -q
```

All test original bytes/official projections/catalog/AUTO/LLM config are created inside owned Temp. Actual configured script, spawned workers, local HTTP, public narrative reader and exact original replay are used. Mocked model text is copied original fragment, so this verifies engineering transport/recovery, not paraphrase quality. Parent fixtures remove Temp and compare original/config bytes. The runner/observer are tracked under tools/document_understanding_benchmark; their regression tests always execute in a clean checkout without paid history or suppliers.

## Existing Phase C runner (ROOT production execution)

```powershell
python -B tools/document_understanding_benchmark/phase_c_runner.py --mode loopback --output <new-owned-receipt-dir> --reading-model-projection reading-model-input/4
```

Historical preparations/ledger remain external .planning inputs; old runner/observer paths are thin compatibility forwarding only. The argument applies only to 0.9; legacy 0.8 still runs as the baseline. This runner retains one usage ledger and exact source/gold/config guards. Observer now uses the actual runtime dispatcher and compares the complete request/5 canonical material before passing the same closed-group oracle. Missing-gold/split-group input refusal stays before reservation/POST; malformed output stays charged and rejected, with captured original final and failed-native material.

To run real configured suppliers, ROOT must first review current source/deep-PDF/table readiness, recompute mother totals, verify unchanged real materials/config/gold and create a fresh explicit preparation revision if fingerprints legitimately changed. Then use `--mode live --sample cn-h1|hk-annual|us-10k --metadata <exact revision> --usage-ledger <existing single live/usage.jsonl> --output <new receipt dir> --consumer-projects <Projects>` and the explicit projection argument. Do not change configs to satisfy frozen metadata. Do not retry an unknown or failed paid attempt blindly. Cumulative 2M tokens/$20 includes all prior costs/holds. No live calls were made by this subtask.

## Acceptance checkpoints

- The actual per-item manifest says /4, prompt reading-source-scoped/4.0.0, request schema /5 and current decoder dependencies. Run container defaults need not be globally rewritten.
- Same-run complete restart: same artifact/native reservations and budget, zero new POST, zero new scratch peak.
- Cross-run exact v4 generation reuse: same artifact and zero reservations/tokens/POST.
- Omitted selector0.9 request remains /3, cannot reuse /4 artifact; pinned prior /4 stays readable after LATEST changes.
- Changing/removing explicit protocol for an existing run fails intent binding without POST.
- Stale decoder is rejected by the actual worker factory before caller/reservation; existing concentrated runtime regression covers this.
- Failed-output diagnostics/usage and original input/final remain; no refund of used tokens and no automatic fallback.
- Public read performs source byte/locator replay. FF reuse_only and RF actual readers can then consume the saved exact ref without downloads/model fallback.
- AUDIT importer can consume the same exact bundle/read receipt with actual run and summarize-attempt IDs before Temp deletion. Whole-original recall remains not_evaluated without an independent blind source inventory.
- Independent semantic review must still inspect every claim, important omitted facts, source role/period/currency/scale and stage qualifiers; legal local citations alone are insufficient. Follow with another-company holdout.

## Scope / NOT_RUN

No provider calls, translations, new registry/identity system, production originals/config edits, Git writes or budget reset. This port does not repair table ambiguity or deep PDF capture; ROOT owns those source-layer changes. This subtask does not certify current supplier quality, whole-source recall, new-company holdouts or full RF forecasts.
