# 独立审查发现后的ROOT授权修复交接

状态：IMPLEMENTATION_COMPLETE_PENDING_ROOT_REVIEW；原独立审查结论保留REQUEST_CHANGES，本文件不自签独立PASS。

## 原问题与TDD

- 原独立内存控例`independent-probes.json`与`independent-review.md/json`冻结：同表Cash/900借Capacity表头进入binder/正式材料；partial table被closure洗complete。
- 在所属ROOT测试`test_native_table_production.py`先写真实normalize→pipeline→select行为与partial闭包断言，**2 FAIL**，保存`independent-repair-red.log/xml`。
- 首轮所属**9 PASS/4.75s**。随后补source/table/page同native row隔离和实际`position_complete=false`经真实binder→closure的控例，所属共13项。

## 共因实现（ROOT窄扩展后为五份源码和一份新ROOT测试）

1. `structure/table_purpose.py`：共享`qualify_native_rows`按原source/table/page/row形成分类视图，复用既有`qualify_table`，将准入结果映射回原unit索引。只在分类视图拼接，不造数字/新unit/新locator，不按文字相同或相邻猜同行，缺native row时仍独立；版本`operating-table-purpose/4`。
2. `structure/tables.py`：最早结构用途判定即使用该同行语义，不再先丢会计label、留下其数字。package准备也复用同服务，不在后段修补文本。
3. `native_table_bridge.py`：仅向原数字binder投影准入原生行及真实header/rowgroup依赖，保留原槽位编号/范围/refs/parent/page；拒收行数字不再进入昂贵binder或被闭包补作context。header行一次付费set建索引，扫描按原work实例收费，无新预算。closure同时保留来源table状态，不能仅由存活bound宣称complete；版本`2.1.0`。
4. `test_native_table_production.py`：上述6项新增控例（2失败根因、3种row scope隔离、1实际truncated binder），原已有测试断言未改。

进一步同根因审查按ROOT要求补两组真实RED：

- 入口0/小额度时旧helper先展开全部header，2 FAIL；已改为入口先检查0、header/caption逐条先核成本后保存，超限不访问body/后续header。body原本就是逐条核成本、未先物化全部body；原错误日志保留。
- 原生Cash row-header已观察rowspan=2时，初版仍会选910（诚实ambiguous但仍是错误经营候选），独立探针`independent-rowspan-probe.json`和1FAIL日志保留。ROOT明确要求本节点修完：`structure/contract.py`在原输入单遍借用native_tables引用，`structure/__init__.py`调用同层薄服务；`table_purpose.attach_native_row_headers`使用原row/rowgroup及已观察span形成一次调用内上下文。按原source/table/page验实ref范围，未知span不向后延续；排序、span展开与关联输出在原work余额中预扣，0剩余能停止。没有另造table副本/缓存注册表/业务关键词。
- 当前最早用途判定因此同时拒收900/910，正常18保留；阳性真实经营rowspan下18/24保留，row label都精确回切为Overseas plants。未知PDF角色/span保持未知。

未写pipeline、narrative_reading、decision_inventory、observation_adapter、数字binder、旧金标、配置或外包工区；无Git写/模型调用/原件复制。ROOT扩展白名单内仅五份源码和所属测试，之外仅本线收据。

## 验证

- 修复后的原独立探针另存`independent-probes-green.json`，旧RED不覆盖：binder与正式selected保留18/Overseas plants/原表头和期间；Cash/900未进入facts或required；原900仍在源units。partial closure仍partial。
- 集中相关原结构、native observation、DU7 PDF、原binder、真实HK packet、purpose provenance **186 PASS/18.98s**，`independent-native-row-repair-frozen/`；前一轮186PASS亦保留（header收费索引整理前）。没有跑全仓重复1016项。
- 上述0/小额度与真实span扩展后，最终所属17项先GREEN，再在冻结实现上集中 **190 PASS/14.67s**，`independent-native-row-span-budget-final/`，不是用早先186项替代新增行为；正常宿主总21.17s。五源码最终mypy、六文件Ruff均通过，精确SHA见JSON交接，原typing narrowing错误另存日志。
- 集中wrapper在独立Temp有sentinel和配置SHA/mtime guard，test root删除、sentinel/config保持；0供应商。新控例全部内存，无真实下载。

## ROOT后续范围

ROOT另行独立复核、正式worker/RF结果与缓存恢复收口、正常提交/推送/PWF。用途判断只处理实见行，不保证任意混合行所有字段的研究意义；原unknown/merged/span/条件仍由既有结构/binder如实保留。默认PageIntent/深页auto饥饿仍OPEN，未以本次186项通过代替。
