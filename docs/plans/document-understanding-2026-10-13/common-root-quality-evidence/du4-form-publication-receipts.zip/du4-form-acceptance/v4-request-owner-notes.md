# ROOT read-only next-node source observations — 2026-10-15

Observed while the final DU4-FORM/OCR normal push runs. No source is changed by this note; v4 is NOT implemented. This refines the existing source_scoped_summary_implementation.md, not a new parallel plan.

## Actual request ownership

- `narrative_http_model.NarrativeHTTPModel.request_bytes` requires `isinstance(request, legacy NarrativeModelRequest)` and invokes `request.with_output_budget(configured max_output_tokens)` before encoding the exact HTTP body. A plain replacement object or a v4 envelope held in the unchanged legacy dataclass would miss one of these requirements: the legacy method recognizes only old request schemas and would silently retain the unbounded v4 plan. No whole new HTTP adapter is warranted.
- A finite runtime frontdoor can expose a subclass of the original four-field frozen request. Its factory delegates all None/v1/v2/v3 construction to the actual original class; only explicit v4 constructs the subclass. Its budget method delegates legacy to the original and v4 to the new protocol. This retains the common caller/response, old actual file bytes, HTTP `isinstance`, configured cap, and existing exact-body reservation. Tests must exercise actual HTTP, not a hand-written envelope.
- The original `narrative_model.py` remains byte-identical. Runtime resolve/identity/decode wrappers dispatch only the explicit v4 constant; unknown versions delegate to the original rejection. No monkeypatch, mutable plugin registry, duplicated legacy decoder, or claimed historical SHA.
- Current production construction/identity seams are `narrative_summarize` (factory/decode and language observation), `narrative_generation._bind_reading_projection` and `narrative_worker_factory._validate_model_software`. The HTTP and budget caller can continue accepting the original base type. Change only actual execution imports, not indiscriminate repo-wide replacements.

## Canonical role and recovery

- The actual source role sets live in `source_catalog/narrative_evidence._validate_claim_roles`: filing/management vs analyst/investor_question. Extract/reuse these finite sets through a source-owned inference helper and preserve old validation messages/semantics. Do not copy these sets into the new protocol. Question-only support must retain question modality; mixed/unknown support derives uncertain and remains source-quality diagnostic.
- New v4 only generates text/basis_parts/modality inside drafts_by_task. The program assigns IDs in source task order, resolves only local support, restores original full support/context closure and canonical metadata, validates typed claims and projects the existing quality once. Unknown task/part or invalid clause is discarded as a whole under the established recoverable-claim policy; total >20 is rejected before per-clause recovery. Empty final output fails. A valid basis still does not prove the proposition.
- V4 identity must include runtime/protocol/view/task/compiler and the real source-role implementation dependency; the view.binding_sha is a per-selection mapping, not software identity. Preserve the frozen pre-runtime v3 request/HTTP/boundary fixtures and actual paid post-model 0-POST stage recovery tests.

## Source limits still open

The current task view preserves selected closures; it has not solved cross-product referents or allocation among 64 scopes under 20 claims. Schema/legal task recovery cannot close the six known semantic failures or PD5/Matrix omissions. Keep default0.8 and explicit0.9 default v3 until explicit v4 source/semantic evidence exists. DU4 TABLE/STATE author trees remain untouched.
