# ROOT handoff — semantic reading model projection

Status: **SOURCE STOP**, 2026-10-14. No commit/push; ROOT is the sole publisher.
Owned frozen source and test bytes are enumerated in `owned-source-final.json`.
No production configuration, public Bundle schema, claim schema, CLI, source reader,
original document, RF repository or installed skill was changed by this package.

## Common cause and implemented boundary

The source audit view and the model-facing business view had been serialized as
one object. A real MiMo request sent matcher descriptions, per-unit identifiers,
unread directories and layout diagnostics alongside the useful reading guidance.
The fixed short target also encouraged unrelated current progress and next actions
to be compressed together. The independent real-output review is in ROOT's
`recall-root/live-summary-review`; that observed quality failure is not declared
fixed merely because these transport tests pass.

The source selector still owns selection, groups and the complete public
`reading_context`. The model boundary now renders a semantic view that retains
the complete actual focus, questions, context requirements, absence/confusion
rules, negative hints and constraints, without regex, UUID directories or policy
design diagnostics. Duplicate semantic guidance is collapsed by complete content;
business text, nonduplicate semantic risks and gN/eN membership are not truncated.
Unread/deferred counts, bounded-directory limitations, structure/native scan and
layout completeness remain distinct factual coverage observations. Coverage is
never presented as proof that a business fact is absent.

Only the new rendering adds the reading instruction and output sizing hint. It
asks for material product/current and next actions with one modality, exact own
support for names/numbers/units/periods/conditions, and narrow actual citations.
Group count helps choose a target, not a per-group claim quota. Coherent actual
validation and received orders can stay together. The existing 20-claim schema and
configured output-token bounds remain. Selected operating tables, metrics and
business causes inside financial notes remain eligible; pure statement totals
and boilerplate are excluded. No digit-matching blocker or human approval was added.

## Frozen software version and cache contract

- New current selector 0.9 generations add the internal scalar
  `reading_model_projection: "reading-model-input/1"`.
- The field is software generation identity, not a request flag, source/public
  version, review receipt or new manual gate.
- Missing field means the exact legacy input renderer. A nonempty
  `reading_context` is **not** evidence of a new rendering version.
- Present null, unknown scalar or wrong types fail explicitly before a new model
  call. They never silently select legacy. Historical manifests may reconstruct
  their identity without claiming an unavailable implementation is executable.
- Global prompt remains `1.7.0`; model request schema remains
  `narrative-model-request/1.4`. Explicit 0.8 inputs retain old manifest shape,
  instruction and data bytes. Existing public history remains readable.
- New rendering changes generation SHA, actual data/instruction/input SHA and
  the actual HTTP reservation SHA. A new current run misses old cache once;
  same-run and another AUTO database then reuse it with zero extra POST.
- Batch manifests, locks, resume identity, worker construction and summarize
  use the one frozen per-subject choice, rather than current default inference.
- Future changes to this rendering's semantics must bump the software projection
  version. Do not edit the new instruction later under the same published version.

The batch boundary also catches an actual runtime-gate-close race as a normal
pause, together with KeyboardInterrupt. Both execution loops share this boundary;
pending work and usage remain, and the existing finally stops workers. This
represents explicit runtime pause/cancel, not a permission or approval mechanism.

## Real saved-input replay: scope and result

`final_verification.py` reconstructs the previously saved MiMo input read-only.
Its legacy instruction **and** actual configured-budget user data match the saved
HTTP request byte for byte. It then runs the actual new request builder, without
calling a supplier or storing a second full prompt.

| Observation | Saved legacy | New semantic rendering |
|---|---:|---:|
| Compact UTF-8 reading strategy bytes | 111,932 | 27,543 |
| Actual configured-budget user data bytes | 136,913 | 52,618 |
| Evidence rows | 96 | 96, exactly equal |
| gN/eN groups | 64 | 64, exactly equal |

Full public context stayed equal. Config and saved input/Bundle SHA, size and
mtime stayed equal. Legacy real provider input was 64,804 tokens. **New supplier
token usage and new supplier output quality are NOT MEASURED; external POST = 0.**
Byte savings are not represented as billed token savings. Final measurements and
protected file fingerprints: `saved-mimo-semantic-sizing-final.json`. Earlier
sizing remains recorded; it preceded a compact layout-count label correction.

## Executed nodes and truthful acceptance

| Node | Actual result | What it establishes |
|---|---|---|
| `binding-green` | 41 passed, exit 0 | Initial software binding and legacy unit coverage |
| `concentrated-valid` | 111 passed / 18.65s, exit 0 | Semantic model 11, frozen generation then 3, old reading/model/alias/generation/worker/caller, corrected official JSON end-to-end |
| `lifecycle-green` | 7 passed, 1 failed, exit 1 | Initial paid lifecycle and 6 existing production cases passed; official JSON retained a third old full-context oracle, later corrected and actually rerun in `concentrated-valid` |
| `recovery-final` | 16 passed / 57.30s, exit 0 | Final frozen-field 7, paid + pre-model-paused legacy lifecycle 2, default-switch recovery 7 |
| `static-final` | Ruff exit 0; mypy exit 0 | Final frozen 6 source + 4 tests Ruff; 6 source mypy, cache NUL |

This does not claim a single all-green run of the intermediate lifecycle node.
Its 7 passing tests plus the corrected failing official case's actual passing
rerun provide the affected coverage. Late present-null and pause-boundary source
changes were specifically rerun in `recovery-final`; the unrelated 111-test set
was not repeated merely to increase counts.

Integration uses real parser/select/worker/budget/HTTP loopback/outbox/public read:

1. Old missing-field 0.9 run sends one legacy loopback request, activation is
   genuinely held, then current software resumes the same paid outbox with no
   second POST; frozen binding and known usage/attempt/request SHA persist.
2. New current run creates a different artifact and actual request SHA with one
   new POST. Same-run and independent AUTO reuse add zero POST and zero budget.
3. Old missing-field run pauses before reservation/HTTP with zero POST and zero
   reservations. Resume sends exactly the previously observed legacy instruction
   and data, one POST total, unchanged frozen binding; public read completes.
4. Missing/unknown/present-null/wrong-type field controls are explicit.

All executed pytest nodes used independent Temp, sentinel and production config
fingerprints; each receipt records cleanup and zero external supplier calls.
The actual final static commands are retained, not inferred from pytest.

## Failures preserved and explained

Every actual failed exit/stdout/stderr/JUnit remains in its node directory:

- `model-red`: 10 fail (new argument absent). One initial fixture also lacked the
  required counts/limited pair, corrected in fixture.
- `model-green`: 47 pass, 1 fail: overly broad test substring `unit_id` mistook a
  legitimate integer count key for a per-unit directory. Corrected to exact
  JSON field keys; the directory-elimination and coverage-count checks remain.
- `binding-red`: 2 fail (missing generation option).
- `lifecycle-red`: 1 fail: new generation renderer not bound; run incorrectly
  reused old input instead of producing the genuine second request.
- `lifecycle-green`: old official JSON oracle KeyError, described above. New
  semantic assertions independently check real guidance fields and full public
  context/selection/material/g/e/hash integrity; they do not call the projector
  as a self-validating oracle.
- `operating-guidance-red`: 1 fail: old blanket financial-table instruction.
- `concentrated-final`: exit 4 with zero collection: guessed nonexistent
  `tests/unit/test_narrative_runtime.py`. Corrected to actual affected files;
  this is a harness path error, not evidence of a source test failure.
- `unpaid-legacy-resume` / `unpaid-diagnostic`: temporary test clock regressed the
  runtime gate and correctly caused IntegrityViolationError. Fixed the isolated
  fixture clock to the real gate time, without weakening source checks.
- `unpaid-monotonic-clock`: real dispatcher RuntimeGateClosedError after genuine
  pre-model pause. Fixed at the shared batch execution boundary with ROOT's
  explicit authorization, not by changing the expected paused state.
- `frozen-invalid-red`: 6 pass, 1 fail: present null incorrectly selected legacy.
  Fixed typed frozen-field handling; final 7 controls pass.

The earlier default-switch repair remains a separate receipt in
`default-resume-root`; its original N6 bootstrap baseline did not actually
activate because cached startup sitecustomize was used. Its notes correct this
attribution. Do not describe those old failures as purely an oracle conflict.

## ROOT next action

Use the frozen source for the already planned real provider quality node. Audit
the new material summary for product completeness, actual/planned separation,
own citation entailment, numbers/units/periods, and financial-note operating
evidence. Record actual provider input/output usage. If quality passes, ROOT
updates shared PWF and publishes all stopped writers together. This package adds
no small-node signoffs and no additional paid or production execution request.
