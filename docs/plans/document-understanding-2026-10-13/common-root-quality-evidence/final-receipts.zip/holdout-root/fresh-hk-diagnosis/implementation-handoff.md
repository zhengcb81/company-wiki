# Shared script / source-business relations — engineering handoff

ROOT-authorized implementation after the separately preserved read-only diagnosis. **SOURCE STOP**. No commit, models, download, original/gold/PWF or author-worktree modification by this worker.

## Source ownership and behavior

- New lower `document_normalization/text_matching.py`: one process-local OpenCC converter, `SCRIPT_MATCHING_VERSION=source-script-match/1`; no document-string cache. Legacy `narrative_matching.matching_text` delegates only the original script conversion, retaining whitespace/numbers/punctuation. Original units/IDs/locators/raw exports remain untouched.
- `narrative_business_policy.py` reading policy **/5**: match-only view, concrete source-owner brand portfolios, named shareholder scope without inventing consolidation, operating-volume/utilization/product-mix causes even in a profit explanation, regional product-sales decrease/offset relationships. Old `detect_business_fact` remains unchanged. New relation rules stay same-clause/bounded, with generic/financial/hypothetical/unrelated-sentence negatives.
- `profiles/registry.py`: same installed catalog; signals and document views share script interpretation. Only fixed catalog phrases are memoized (4096 entries, phrase length ≤256); source/document strings are folded each time, not retained globally. Content keys plus live flag/record reads permit mutated/replaced catalogs without stale decisions.
- `structure/table_purpose.py` **/3**: turnover days are an operating measure; mixed table retains only operating rows, with actual source header/period/unit closure still owned by existing structure. Account totals, routine financial rows and glossary definitions do not borrow an operating header.
- Existing `facet_operating_metrics` **1.4.0**, exactly one source record and its single compiled runtime asset. Added turnover-days signals and days-versus-ratio/period confusion. Original compiler `tools/import_reading_policies.py` regenerated runtime; `--check` passes. All other catalog records, fields and inventories equal HEAD.

Owned paths and exact SHA/mtime/size: `implementation-source-freeze.json` (9 files, including 2 new test files). ROOT owns pipeline/decision-inventory version wiring and publication. No second matcher registry, queue, source permission or per-document gate was added.

## TDD and concentrated verification

- Initial 53 new tests: **31 FAIL / 22 PASS**, real exit 1, pytest1.87s. Counterexamples were written before implementation.
- First implementation: **53 PASS**, exit0,1.99s.
- Additional concrete native-line regression: existing admission must survive a long wrapped tail. It failed (exit1) under the initial clause rewrite; fixed by keeping legacy per-native-line fallback on the script view. The original 3 legacy snapshots remain exact after JSON tuple/list projection.
- Concentrated 8 related files: **264 PASS**, exit0,3.83s, before the final cache-only/performance change. Subsequent new cache behavior test was RED (fixed phrase converted twice), then GREEN; same-scope functional behavior remains covered in the final node.
- Final new55 + actual20K late-scopes case: **56 PASS**, exit0,17.38s; actual20K case15.95s. Existing source/config/sentinel fixture Temp is restored. No artificial CI wall-time threshold introduced.
- Ruff: PASS. Mypy 5 affected source files: PASS, exit0,2.56s. Compiler `--check`: PASS24families/14facets. Both own HK observer Temp dirs and production fixture Temp are absent.

## Systemic performance root cause and evidence

The new portfolio/ownership regex initially scanned broad prefixes even in sentences with no brand/shareholder words. Actual cProfile on 2000 inputs of the real20K test's shape attributed ~56% to those scans. Mandatory literal seeds now skip impossible relations without changing matching semantics. Duplicate definition guard removed.

- cProfile total **1.656→0.750s**; unprofiled same2000 output pass **2.0967→0.5893s**.
- Full aggregate fact SHA unchanged: `a751a97c0bf7a40c0c85a8cee34da2415da3ab3e0e6a43b5f0f40e62ff2ca6d4`.
- 300 table-discovery calls: repeated OpenCC calls **5400→317** (300 source texts still converted each time); only small static signals cached.
- ROOT separately measured pre-optimization real20K case38.668s; this worker final case15.95s. These are measured local snapshots, not a controlled universal benchmark or CI limit. Logs: `predicate-profile-{before,after}.txt`, `catalog-profile-{before,after}.txt`, `performance-facts-{before,after}.json`.

## Retained limits / ROOT acceptance

- This engineering pass is not actual ANTA0/3 recall certification. Literal “including brands...” without repeated owner wording must be evaluated against real native source context; do not infer issuer ownership, add company-specific words or waive closure. ROOT will run the old3 + development-fresh sources once after complete source STOP.
- Two earlier HK observer postprocessing failures remain in `harness-failures.json`. Actual native candidate/window/closure attribution was not obtained, and no third parse was executed here.
- Apple original quote literal error and SMIC dividend scope dispute are separately reported. ROOT's explicit Apple correction is acknowledged; no smart-punctuation folding or gold write here. Dividend remains outside the new positive grammar, and old frozen12 denominator/FAIL stays visible.
- ROOT must bind actual matching helper feature plus business/5, table/3 and facet1.4 into existing selection dependency generation, then verify real recovery/0POST and actual summaries. No claim of new default activation, paid summary fidelity, whole forecast or analyst-quality completion.
