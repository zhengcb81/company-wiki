"""Read-only finite source-shape counterexamples. Never open/parse an original."""
from pathlib import Path
import hashlib
import json
import sys
from copy import deepcopy

ROOT = Path(__file__).resolve().parents[6]
OUT = Path(__file__).parent
sys.path.insert(0, str(ROOT / 'src'))
from company_wiki.document_understanding.profiles import route_document
from company_wiki.document_understanding.profiles.observation import parse_observation
from company_wiki.document_understanding.profiles.signals import is_speaker_turn
from company_wiki.document_understanding.observation_adapter import build_observation
from company_wiki.source_catalog.narrative_document import NarrativeUnit
from company_wiki.source_contract import EvidenceCoordinates


def fingerprint(paths):
    return {str(path.relative_to(ROOT)): {'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
        'bytes': path.stat().st_size, 'mtime_ns': path.stat().st_mtime_ns} for path in paths}


paths = sorted(p for p in (ROOT / 'src/company_wiki').rglob('*') if p.is_file() and p.suffix in {'.py', '.yaml', '.json', '.yml'})
paths += [ROOT / 'config.yaml', ROOT / 'config/source_catalog.yaml',
          ROOT / '.planning/shared-reading-production/type-matrix-root/root-cause-followup/us-10q.json']
before = fingerprint(paths)
saved = json.loads(paths[-1].read_text(encoding='utf-8'))
source_id = 'urn:company-wiki:source:sha256:' + '1' * 64


def unit(text, index, *, kind='paragraph', role='company_filing', parent=None, **hints):
    return {'unit_id': f'generic-{index}', 'ordinal': index, 'locator': f'generic:paragraph:{index}',
            'text': text, 'kind': kind, 'role': role, 'language': 'en', 'page': None,
            'layout': {}, 'hints': {'source_id': parent or source_id, **hints}}


def observation(units, **metadata):
    return {'schema_version': 'du-input/1', 'source_ref': {'source_id': source_id, 'source_sha256': '1' * 64},
        'metadata': {'title': '', 'declared_kind': 'unknown', 'mime_type': 'text/html', **metadata},
        'coverage': {'native_scan': 'complete', 'opaque_pages': [], 'deferred_pages': []}, 'units': units}


cases = []
def run(name, data, *, intended, note='', limits=None):
    original = deepcopy(data)
    parsed = parse_observation(data, limits)
    result = route_document(data, limits=limits)
    assert data == original
    cases.append({'name': name, 'actual': result, 'intended': intended, 'note': note,
        'units': len(parsed.units), 'probes': len(parsed.probes), 'probed_chars': parsed.probed_chars,
        'form_probe_ids': [u.unit_id for u in parsed.probes if 'FORM ' in u.text],
        'colon_candidates': [{'unit_id': u.unit_id, 'kind': u.kind, 'role': u.role, 'text': u.text,
                              'text_shape_speaker': is_speaker_turn(u.text)}
                             for u in parsed.probes if ':' in u.text and len(u.text) < 60]})


# Preserve the real unit IDs/text/DOM already saved; surrounding units are
# explicitly synthetic morphology, not a reconstruction of all 2,274 units.
dense = [unit('Ordinary accounting discussion for the current quarter.', i) for i in range(2274)]
for i in range(3):
    dense[i] = unit('Table of Contents' if i == 0 else 'Incidental front matter', i)
actual = saved['actual_form_units'][0]
dense[4] = {**unit(actual['text'], 4), 'unit_id': actual['unit_id'], 'locator': actual['locator'],
            'hints': {'source_id': source_id, 'dom_path': actual['metadata']['dom_path']}}
available = [u.ordinal for u in parse_observation(observation(dense)).probes if u.ordinal > 20]
for index, row in zip((available[5], available[20]), saved['reason_units'][:2]):
    dense[index] = {**unit(row['text'], index, kind='table_row'), 'unit_id': row['unit_id'],
                    'locator': row['locator'], 'hints': {'source_id': source_id, **row['metadata']}}
run('saved-form-shape-outside-bounded-probe', observation(dense, declared_kind='quarterly_report'),
    intended='quarterly / actual FORM carrier / no speaker signal',
    note='Saved anchors plus synthetic surrounding units; real original decision already saved separately.')
run('same-shape-plain-form-metadata-fallback', observation(dense, declared_kind='quarterly_report', form_type='10-Q'),
    intended='quarterly with actual carrier provenance; supplied metadata alone is not observed proof')

run('visible-short-own-form-control', observation([unit('FORM 10-Q', 0, kind='heading'),
    unit('PART I FINANCIAL INFORMATION', 1, kind='heading'), unit('Current quarter discussion.', 2)]), intended='quarterly')
run('financial-cell-colons', observation([unit('Current quarter accounting.', 0),
    unit('Revenues:', 1, kind='table_row'), unit('Headcount:', 2, kind='table_row')]), intended='not earnings_call')
run('header-caption-colons', observation([unit('Current quarter accounting.', 0),
    unit('Utilization:', 1, kind='table_header'), unit('Volumes:', 2, kind='table_caption')]), intended='not earnings_call')
run('genuine-native-speaker-prose', observation([unit('Quarter earnings discussion.', 0),
    unit('Alice Holt: Customer orders increased after validation.', 1, role='management', speaker='management', turn_id='a'),
    unit('Nora Bell: New capacity will open next year.', 2, role='management', speaker='management', turn_id='b')]), intended='earnings_call')
run('genuine-speaker-table-format-control', observation([unit('Quarter earnings discussion.', 0),
    unit('Alice Holt: Customer orders increased after validation.', 1, kind='table_row', role='management', speaker='management', turn_id='a'),
    unit('Nora Bell: New capacity will open next year.', 2, kind='table_row', role='management', speaker='management', turn_id='b')]),
    intended='earnings_call; do not ban all table-shaped native turns')
run('genuine-ir-under-policy-title', observation([unit('投资者关系活动记录表', 0),
    unit('问：公司是否生产该产品？', 1, role='investor_question', speaker='investor', turn_id='q1'),
    unit('答：公司现无生产该产品的情况。', 2, role='management', speaker='management', turn_id='q1')],
    title='投资者关系管理制度', declared_kind='ir_policy'), intended='investor_qa with title conflict')
run('unrelated-parent-qa-markers', observation([unit('问：是否开拓新市场？', 0, parent='parent-a', role='investor_question', turn_id='a'),
    unit('答：项目仍在验证。', 1, parent='parent-b', role='management', turn_id='b')]),
    intended='no QA pair across parents; production parent-splitting is already a control')
run('cross-reference-form-control', observation([unit('See our annual report on Form 10-K for details.', 0),
    unit('This document discusses a supplier meeting.', 1)]), intended='not own annual form')
run('declared-wrong-form-vs-visible-own', observation([unit('FORM 10-Q', 0, kind='heading'),
    unit('PART I FINANCIAL INFORMATION', 1, kind='heading')], form_type='10-K', declared_kind='annual_report'),
    intended='quarterly with genuine own-carrier and declaration conflict')
run('metadata-only-unproven-form', observation([unit('Ordinary unrelated business update.', 0)], form_type='10-Q'),
    intended='metadata may suggest; must not cite unrelated unit as observed form proof')
run('outer-8k-with-native-call-attachment', observation([unit('FORM 8-K', 0, kind='heading'),
    unit('Current report.', 1), unit('Exhibit 99.1', 2, kind='attachment'),
    unit('Full Conference Call Transcript', 3, kind='heading'),
    unit('Alice Holt: Quarter orders increased.', 4, role='management', speaker='management', turn_id='a'),
    unit('Nora Bell: Capacity will open next year.', 5, role='management', speaker='management', turn_id='b')]),
    intended='outer 8-K preserved; same-source child earnings_call')
run('outer-8k-with-10k-attachment', observation([unit('FORM 8-K', 0, kind='heading'), unit('Current report.', 1),
    unit('Exhibit 99.2', 2, kind='attachment'), unit('FORM 10-K', 3, kind='heading'),
    unit('Business and risks.', 4)]), intended='outer 8-K preserved; child annual')
run('outer-bare-dei-shape-with-child-form', observation([unit('10-Q', 0, kind='heading'), unit('Current quarterly report.', 1),
    unit('Exhibit 99.2', 2, kind='attachment'), unit('FORM 10-K', 3, kind='heading'),
    unit('Business and risks.', 4)], form_type='10-Q'),
    intended='bound parent fact must not be replaced by printed child form; plain metadata is insufficient proof')
run('tightened-probe-budget-control', observation(dense), limits={'max_probe_units': 5, 'max_probe_chars': 60},
    intended='bounded and honest limitation; no budget increase or false full coverage')

# One actual adapter-only observation, no normalization/parser call. It shows
# which already-known native fields reach the current wire and UnitRef.
row = saved['reason_units'][0]
native = NarrativeUnit(row['unit_id'], source_id, 'saved-observer-fixture', '1.0.0',
    EvidenceCoordinates(table_index=13, row_index=2, column_index=0), row['text'], row['kind'], row['role'], 'en',
    metadata=row['metadata'])
wire = build_observation((native,), source_id=source_id, source_sha256='1' * 64)
adapter = {'actual_native_kind': native.unit_kind, 'wire': wire,
           'parsed_router_unit': vars(parse_observation(wire).units[0])}
after = fingerprint(paths)
assert before == after
assert len(cases) <= 20
payload = {'status': 'READ_ONLY_SOURCE_STOP', 'counterexample_count': len(cases), 'cases': cases,
           'adapter_observation': adapter, 'original_parses': 0, 'normalizer_calls': 0,
           'source_config_receipt_drift': [], 'supplier_calls': 0, 'models': 0}
(OUT / 'observations.json').write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding='utf-8')
(OUT / 'protected.json').write_text(json.dumps(before, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps({'cases': len(cases), 'family_results': {x['name']: x['actual']['family'] for x in cases},
                 'source_drift': [], 'original_parses': 0, 'supplier_calls': 0}, ensure_ascii=False))
