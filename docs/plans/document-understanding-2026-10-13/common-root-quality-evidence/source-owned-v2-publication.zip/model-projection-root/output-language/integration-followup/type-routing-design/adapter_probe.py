"""One additional pure adapter observation with saved identity fields, no parser."""
from pathlib import Path
import hashlib
import json
import sys

ROOT = Path(__file__).resolve().parents[6]
OUT = Path(__file__).parent
sys.path.insert(0, str(ROOT / 'src'))
from company_wiki.document_normalization.units import build_unit
from company_wiki.document_understanding.observation_adapter import build_observation
from company_wiki.document_understanding.profiles.observation import parse_observation
from company_wiki.source_contract import EvidenceCoordinates

path = ROOT / '.planning/shared-reading-production/type-matrix-root/root-cause-followup/us-10q.json'
before = hashlib.sha256(path.read_bytes()).hexdigest(), path.stat().st_size, path.stat().st_mtime_ns
saved = json.loads(path.read_text(encoding='utf-8'))
row = saved['reason_units'][0]
digest = saved['source_before']['sha256']
dom = row['metadata']['dom_path']
native = build_unit(source_id='urn:company-wiki:source:sha256:' + digest, source_sha256=digest,
    format_name='html', coordinates=EvidenceCoordinates(table_index=13, row_index=2, column_index=0),
    raw_text=row['text'], unit_kind=row['kind'], source_locator='cwp-html-dom/1|n=' + dom,
    transform='html_visible_text_v1', extra_metadata=row['metadata'])
wire = build_observation((native,), source_id=native.source_id, source_sha256=digest, mime_type='text/html')
result = {'scope': 'single saved shape with native identity recomputation, not a reparsed source',
    'canonical_unit_id_matches_saved': native.unit_id == row['unit_id'],
    'saved_unit_id': row['unit_id'], 'constructed_unit_id': native.unit_id,
    'native_kind': native.unit_kind, 'wire': wire,
    'router_unit': vars(parse_observation(wire).units[0]),
    'normalizer_calls': 0, 'original_parses': 0, 'supplier_calls': 0}
assert before == (hashlib.sha256(path.read_bytes()).hexdigest(), path.stat().st_size, path.stat().st_mtime_ns)
(OUT / 'adapter-identity-observation.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps({'identity_matches': result['canonical_unit_id_matches_saved'],
    'native_kind': native.unit_kind, 'wire_kind': wire['units'][0]['kind'],
    'router_fields': sorted(result['router_unit']), 'source_writes': 0, 'original_parses': 0}))
