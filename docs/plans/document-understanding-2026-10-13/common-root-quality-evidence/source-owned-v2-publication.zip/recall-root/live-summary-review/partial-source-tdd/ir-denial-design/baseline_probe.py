"""Read-only predicate observations from retained IR units and synthetic prose.

No media parser, test runner, provider, configuration write or original reopen.
The expectations are specifications; results record current behavior, not tests.
"""
from dataclasses import asdict
import hashlib
import json
from pathlib import Path
from types import SimpleNamespace

from company_wiki.source_catalog.narrative_business_policy import detect_reading_business_fact
from company_wiki.source_catalog.narrative_reading import _admitted

ROOT = Path(__file__).resolve().parents[6]
OWNED = Path(__file__).resolve().parent
PROTECTED = (
    "src/company_wiki/source_catalog/narrative_business_policy.py",
    "src/company_wiki/source_catalog/narrative_reading.py",
    "src/company_wiki/document_normalization/text_matching.py",
    "src/company_wiki/document_understanding/profiles/reading_catalog.json",
    ".planning/shared-reading-production/type-matrix-root/root-cause-followup/cn-ir.json",
)


def snapshot():
    return {name: {"sha256": hashlib.sha256((ROOT / name).read_bytes()).hexdigest(),
                   "mtime_ns": (ROOT / name).stat().st_mtime_ns} for name in PROTECTED}


def observe(text, role="management", kind="background", reading=None):
    fact = detect_reading_business_fact(text)
    unit = SimpleNamespace(raw_text=text, source_role=role, unit_kind="prose")
    admitted, _ = _admitted(unit, reading or {"family": "investor_qa", "section_role": "unknown"}, kind, fact=fact)
    return {"fact": asdict(fact), "admitted": admitted}


def main():
    before = snapshot()
    receipt = json.loads((ROOT / PROTECTED[-1]).read_text("utf8"))
    rows = receipt["target_units"]
    group = next(package for row in rows for package in row["packages"] if package["package_id"] == "m41")
    actual = [{"unit_id": row["unit_id"], "role": row["role"], "locator": row["locator"],
               "text": row["text"], "text_sha": row["text_sha"],
               "saved_fact": row["fact"], "current": observe(row["text"], row["role"], "qa_exchange", row["reading_profile"])}
              for row in rows if row["unit_id"] in group["member_unit_ids"]]
    cases = (
        ("cn_current_production_denial", "公司现无生产 QJ-11 的情况。", True),
        ("cn_wrapped_current_denial", "本公司现无生\n产椿石添加剂的情况。", True),
        ("cn_traditional_denial", "本公司目前並未生產梧石添加劑。", True),
        ("en_current_manufacture_denial", "We do not currently manufacture Novalon.", True),
        ("en_named_actor_denial", "Arbor Ltd. does not manufacture Novalon filters.", True),
        ("cn_no_business_involvement", "公司目前未涉及星纤存储业务。", True),
        ("en_no_business_involvement", "The company is not involved in storage services.", True),
        ("cn_not_commercialized", "青梧设备仍在研发阶段，尚未商业化。", True),
        ("en_not_commercialized", "The platform remains a research prototype and is not available for commercial sale.", True),
        ("cn_suspend_production", "子公司因客户验证未通过暂停滤芯生产。", True),
        ("en_suspend_production", "Unrelated supplier Dusk suspended production of its filters after unsuccessful validation.", True),
        ("cn_parent_pending_qualification", "母公司青梧尚未取得客户对其膜产品的认证。", True),
        ("en_parent_pending_qualification", "Our parent Rowan has not obtained customer qualification for its membrane.", True),
        ("en_restricted_approval", "Third-party Mica is approved only for pilot use; production qualification remains pending.", True),
        ("cn_contact_intention", "公司与谷石就涂覆设备进行了技术接洽，并希望开展合作。", True),
        ("en_contact_intention", "We held technical discussions with Vale about coating equipment and hope to cooperate.", True),
        ("cn_parent_contact_intention", "控股股东青梧与暮石已建立联系，并希望开展涂覆设备业务合作。", True),
        ("en_parent_contact_intention", "Our controlling shareholder Rowan has contacted Vale about coating equipment and hopes to cooperate.", True),
        ("en_concrete_conditional_plan", "We plan to commercialize Product N next year if customer qualification is obtained.", True),
        ("cn_positive_control", "公司新产品完成客户验证，第四季度开始批量交付。", True),
        ("cn_definition", "商业化是指产品形成销售的过程。", False),
        ("en_owned_glossary", "Our glossary: product qualification is defined as approval before commercialization.", False),
        ("cn_admin_negative", "本次调研未收到有关平台商业化的股东提问。", False),
        ("en_admin_negative", "No shareholder questions were received about commercializing the platform.", False),
        ("cn_financial_total", "公司产品分部包括营业收入10亿元、利润2亿元。", False),
        ("en_financial_total", "Our products segment comprises revenue of $100 million and profit of $20 million.", False),
        ("cn_bare_nouns", "产品认证与商业化。", False),
        ("en_bare_nouns", "Product qualification and commercialization.", False),
        ("cn_generic_hope", "我们期待产品商业化与客户导入一切顺利。", False),
        ("en_generic_hope", "We expect product commercialization and customer adoption to go well.", False),
        ("cn_polite_cooperation", "感谢您的关注，希望未来保持沟通与合作。", False),
        ("en_polite_cooperation", "Thank you for your interest; we look forward to continued communication and cooperation.", False),
    )
    synthetic = [{"case_id": name, "text": text, "specified_eligible": expected,
                  **observe(text)} for name, text, expected in cases]
    role_controls = [{"role": role, **observe("Has Wren stopped product shipments pending customer qualification?", role, "qa_exchange")}
                     for role in ("investor_question", "qa_text_shadow")]
    after = snapshot()
    result = {
        "status": "READONLY_OBSERVATION_NOT_TDD",
        "original_reopens": 0, "original_parses": 0, "supplier_calls": 0, "llm_calls": 0,
        "source_sha_from_previous_receipt": receipt["source_before"]["sha256"],
        "previous_source_guard_pass": receipt["source_guard_pass"],
        "previous_source_before_equals_after": receipt["source_before"] == receipt["source_after"],
        "actual_group": group, "actual_material": actual, "synthetic": synthetic, "role_controls": role_controls,
        "protected_before": before, "protected_after": after, "protected_unchanged": before == after,
    }
    output = OWNED / "baseline-observations.json"
    if output.exists():
        raise RuntimeError("do not replace a prior observation")
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf8")
    print(json.dumps({"actual_denial": next(row["current"] for row in actual if row["unit_id"].endswith("c0b087")),
                      "positive_spec_misses": [row["case_id"] for row in synthetic if row["specified_eligible"] and not row["fact"]["eligible"]],
                      "negative_spec_hits": [row["case_id"] for row in synthetic if not row["specified_eligible"] and row["fact"]["eligible"]],
                      "role_controls": role_controls, "protected_unchanged": before == after}, ensure_ascii=False))
    if before != after:
        raise RuntimeError("protected source/retained evidence changed during observation")


if __name__ == "__main__":
    main()
