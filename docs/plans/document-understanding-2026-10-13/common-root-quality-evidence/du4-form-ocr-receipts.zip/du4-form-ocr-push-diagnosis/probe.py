from pathlib import Path
import json,os,socket,sys,tempfile,time
ROOT=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(ROOT/'tests'))
from document_normalization.test_isolated_ocr import NativeFake,cfg,warm
from company_wiki.document_normalization.isolated_ocr import IsolatedOCRAdapter
class Observed(IsolatedOCRAdapter):
 def _stop_worker(self):
  proc=self._process
  if proc is not None:
   self.observed_before_stop={'returncode':proc.poll(),'worker_pid':self.worker_pid,'response_files':[p.name for p in self._directory.glob('response-*.json')] if self._directory else []}
  return super()._stop_worker()
results=[]
with tempfile.TemporaryDirectory(prefix='.cw-crt-',dir=ROOT) as name:
 for i in range(6):
  folder=Path(name)/str(i);folder.mkdir()
  adapter=Observed(cfg(folder,'crt-_fstat64'),_backend_factory=NativeFake,scratch_dir=folder)
  try:
   warm(adapter);start=time.monotonic();adapter.validate_environment(deadline=start+1.0)
   row={'case':i,'result':'PASS','seconds':time.monotonic()-start}
  except Exception as exc:
   row={'case':i,'result':type(exc).__name__,'detail':str(exc),'process':getattr(adapter,'observed_before_stop',None)}
  finally:adapter.close()
  row['marker_exists']=(folder/'crt-inspected').exists();row['temp_workers_remaining']=len(list(folder.glob('cwp-ocr-*')));results.append(row);print(json.dumps(row),flush=True)
assert not Path(name).exists()
Path(__file__).with_suffix('.json').write_text(json.dumps({'supplier_calls':0,'temp_removed':True,'cases':results},indent=2),encoding='utf8')
