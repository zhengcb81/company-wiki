# Windows OCR探针与默认fast门：独立只读审查

2026-10-15；`attribution_release_review`。仅审查ROOT当前source、测试、fast选择器与已有诊断收据；没有运行整库/真实OCR/原件/API，也未改源码、测试、PWF、Git或作者目录。

## 结论

**同意把默认fast smoke中的直接UCRT `_fstat64`项替换为已有`os.isatty(0)` preflight项；保留三个直接CRT探针在完整Windows OCR大节点。** 这是按测试责任分层，不是删除失败测试、自动重试或延长产品期限。建议node为：

```text
tests/document_normalization/test_isolated_ocr.py::test_native_stdin_probe_does_not_deadlock_liveness_monitor[preflight]
```

**目前没有足够证据要求修改产品行为，也没有证据宣布crash已经修好。** 唯一全库失败为worker提前退出的`OCR_WORKER_FAILED`，不是已证实deadline/deadlock或已确定的ctypes ABI错误。此建议可改善默认门职责和平台耦合，但不能宣称大幅缩短500秒的完整unit运行。

## 已有证据能证明什么

- ROOT报告正常pre-push：5775PASS/24SKIP/1FAIL，500.93秒；失败的是`test_native_crt_stdin_probe_does_not_deadlock_liveness_monitor[_fstat64]`，并非FORM源码失败。
- 已读ROOT的`du4-form-ocr-push-diagnosis/probe.py/json`：同NativeFake/同1秒验证期限做6次，每次约29–51ms通过，marker存在、scratch清理完成。这只能说明小范围重复未复现，不能反推全库失败不存在、自动归因机器慢或认为崩溃已消失。
- `IsolatedOCRAdapter._await_file`对期限耗尽抛`NormalizationLimitError("deadline")`；对process已退出抛`LocalOCRError("OCR_WORKER_FAILED")`。本次分类是后者，不能把它说成超时。
- 产品child的stdout/stderr进DEVNULL，公开错误码未带实际退出code；原失败收据没有实际exitcode。ROOT正在单独重现同Job CRT三项，尚不能从6次PASS补出那次未知退出原因。

## 两类探针的职责不同

| 项目 | 既有os.isatty preflight | 直接ucrtbase ctypes三项 |
|---|---|---|
| 执行边界 | 真正IsolatedOCRAdapter child、配置/命令/response、同一个fd0元数据检查、worker存活和owned scratch回收 | 相同隔离child，加直接Windows CRT DLL调用 |
| 目标 | 捕获worker内stdin监视器与native初始化检查互相阻塞的回归类别 | 扩展检查`_isatty`、`_get_osfhandle`、`_fstat64`的具体平台兼容性 |
| 平台/ABI依赖 | 使用Python os封装，仍是Windows专属回归测试 | 直接CDLL、没有显式argtypes/restype；fstat使用256字节opaque buffer |
| 适合位置 | 默认fast的短、稳定职责smoke | 完整Windows OCR大节点/原生运行时升级节点 |

os.isatty测试实际验证marker、同worker PID仍活着以及context退出后清理，保留了真实进程边界，不是仅mock一个Python函数。它**不声称等价证明三个UCRT函数所有ABI/行为**；直接探针因此继续保留。产品`_worker_main`明确不启动读fd0的liveness线程，Windows由已有Job/等待bootstrap负责owner存活；不能为了某一探针重新加入会阻塞descriptor的读线程。

ctypes没有原型是测试卫生/平台耦合风险，并非此次exit的已证实根因：当前第一个int参数、byref buffer等调用并不因为未声明原型就必然错误，返回值也没有参与产品逻辑。未来若要改善完整CRT测试，可按实际Windows ABI显式定义签名并保存原生return/errno、阶段marker；不要在缺exitcode时武断修改缓冲区、产品OCR配置或请求期限。

## 保持真正产品回归，不新增慢门

- 默认fast保留非协作/GIL阻塞时的绝对deadline回归、ROI预算与渲染预检、默认proxy传递期限；只替换这一个直接平台探针。
- `test_native_crt_stdin_probe...`三参数原样保留在完整`tests/document_normalization/test_isolated_ocr.py`，由Windows OCR大节点真实运行并留证。不增加逐commit全CRT矩阵，也不把失败标xfail/skip或吞异常。
- 现`.github/workflows/ci.yml`只有Ubuntu Python3.12的fast job，两个stdin测试均有Windows skip。因此此调整主要作用于Windows本地pre-push；不能说修复了Linux上的fstat crash，也不能拿它解释所有慢CI。
- 当前500秒主要包括被选择的完整unit范围；改一条几十毫秒平台探针不能解决整体时长。大范围unit选择源于另一个`changed_unit_tests`责任边界，本次不建议夹带重构该选择器或放松既有数据测试。

## 是否需要改product

当前没有复现表明普通backend、已有os.isatty路径、deadline执行、结果验证或进程树清理存在新缺陷，因此**不要求为此改product**。native worker异常退出本来就应失败、不发布OCR结果；已有失败/清理测试也覆盖这种分类。

若后续同Job重现仍是提前退出，下一项有效证据是停止清理前的真实returncode、最后完成marker/response状态，以及是否只有直接CRT路径失败。可在owned诊断adapter捕捉这些元信息；无需开放生产密钥或保存全文。发现可复现的产品生命周期缺陷再按其根因做TDD。不能通过自动重试、延长1秒产品期限或移出fast，宣称未知crash已经被修复。

本报告为**职责调整设计通过**；没有执行替换后的集中测试或完整Windows节点，也未证明事故根因。源码与既有诊断指纹见同名JSON。

### 后续证据更新

上述结论对应首次未知退出与六次未复现阶段。随后完整OCR复核发现真实response文件`PermissionError`，ROOT通过read/publish故障注入复现并统一修复；独立复核还关闭了成功IO漏查deadline。详见`ocr-file-handoff-final.md/json`（PASS_CODE_REVIEW，ROOT最终96项通过）。因此不能再引用本旧阶段的“无证据改product”阻止已有实证修复；首次旧worker退出的真实原因仍未知。
