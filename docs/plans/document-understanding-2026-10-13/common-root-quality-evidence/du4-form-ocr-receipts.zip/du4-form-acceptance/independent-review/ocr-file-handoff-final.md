# OCR owned-file IPC：独立产品修复审查

2026-10-15；`attribution_release_review`。本报告审查ROOT的统一owned IO修复，不修改源/测试/PWF/Git/作者树。纯探针只在本报告目录运行，强制ROOT/src导入，无native调用、真实原件、配置/密钥或供应商。

## 结论与当前关闭状态

**PASS_CODE_REVIEW：统一owned-file IO修复通过本次独立代码审查，未发现剩余阻断问题。** 审查发现的成功IO返回后漏查绝对deadline已由ROOT按RED修复，独立假钟重新执行后确实抛出`NormalizationLimitError`；原RED观察保留，不能用最终PASS覆盖。输入/输出超cap错误码的一次共同helper误分类也已归位，本审查读到归位后的实现，不能继续把旧瞬时版本当作当前缺陷。

ROOT最终冻结源码集中回归**96项PASS/55.64秒**，Ruff五路径与mypy一源通过；配置/sentinel保持、Temp删除、0供应商。这是ROOT执行证据，不冒充独立重跑。独立只运行假钟和小字节文件探针并只读复核最终代码。

此前`ocr-gate-followup`是默认fast职责调整的设计审查，并未证明worker未知退出已修好。新的真实IPC失败与注入RED属于产品证据，必须单独修复，不能仅靠移动CRT测试解决。

## 三类证据必须分开

1. 首次正常pre-push 5775PASS/24SKIP/1FAIL，CRT `_fstat64`为`OCR_WORKER_FAILED`。没有实际exitcode，**原始退出原因仍UNKNOWN**。
2. 完整OCR复核85PASS/1FAIL，另一`_isatty`场景在父进程已看到`response-0.json`后，打开该文件得到真实`PermissionError`。这是确切文件IPC缺陷，不是单纯测试时限或CRT原型推测。
3. ROOT对父read与真实child publish分别做故障注入，两项原实现RED；publish失败可使child以1退出。它证明这种IPC缺陷具有worker提前退出机制，**不证明第一次旧退出必然就是同一原因**。ROOT随后报告94项通过，但其中测试启动后源码有输入cap错误码归位，最终冻结版本还需ROOT正常集中回归。

上述运行属于ROOT执行；本审查未重跑完整OCR/全库。

## 成功IO漏deadline：独立反例

初审代码为`return operation()`，只有调用前和PermissionError分支检查期限。

```text
假钟开始10，deadline=11
operation执行后将时钟推进12并返回成功
实际helper返回SUCCESS，未抛期限错误
```

`ocr-file-deadline-original-red.json`保留最初独立执行的实际成功越界观察（从该次工具输出留存，非最终源码重跑）；`ocr-file-probe.py`和`ocr-file-probes.json`保存强制ROOT源码导入的最终重放。正常文件IO可能在调用中延迟，不能因最后一次操作成功就把已到期任务当作成功。尤其worker的image read之后会继续调用backend，而config publish之后会继续准备spawn。

共同修复已在helper完成：先得到operation返回值，再核对同一absolute deadline，过期则抛`NormalizationLimitError`，否则返回该值。最终静态复核及独立同一假钟重放得到deadline异常，ROOT新增等于期限/超过期限两参数测试并先留下2RED。不是在各调用者分别补规则，没有重新调用native或扩大期限。Python不能硬中断正在执行的OS IO，但现在会在返回后阻止进一步spawn/native或发布成功。

## 已核对的系统边界

- **重试范围**：只捕获PermissionError，并限定Windows、EACCES和允许的winerror集合。非Windows权限错误、ENOENT、EIO等原样抛出；每次休眠不超过余下期限与既有poll间隔。Windows access-denied缺少更细winerror时仍只能由有界等待决定，不宣称能预先分辨临时锁与永久ACL。
- **不是native重试**：被闭包重试的是文件open/read/write/replace/unlink。native validate/transcribe位于这些闭包外，一次请求没有被重新dispatch；文件重写先截断自己的pending/image，随后原子发布command/response，不会生成第二次native请求。
- **绝对期限和预算**：parent沿用既有`_effective_deadline=min(...)`，child收到启动时已有absolute deadline。没有新增超时配置、第二预算或续期。具体“成功后复核”是上文需要关闭的遗漏。
- **POSIX生命周期**：新增argv将deadline放在directory之前，directory仍是最后参数；现guardian的`sys.argv[-1]`清理对象没有改变。Windows仍在Job分配后释放bootstrap，不重新加入worker stdin读线程。
- **大小上限/错误码**：读仍只取cap+1；JSON在调用者检查`OCR_RESULT_BYTES_EXCEEDED`，image在worker检查`OCR_INPUT_BYTES_EXCEEDED`，parent仍在写image前检查原输入长度。JSON写按实际UTF-8累计后再写入，控制与大数据的原cap没有提高。
- **失败清理**：pending文件交由既有owned worker-directory统一清理，避免在异常路径用新的unlink覆盖原错误。parent失败仍stop/reap同一owned tree后在原cleanup grace中清理；正常请求unlink也在请求原deadline内完成。没有全局临时目录清理或删除生产原件。
- **诊断**：`OCRWorkerExitedError`保留原machine code `OCR_WORKER_FAILED`，仅增加scalar exitcode。现有受控exit7回归能验证诊断，不含stderr、模型配置或材料内容。不能用exit7测试补写首次失败的未知code。

## 测试检查点与范围

新增假钟测试覆盖持续共享冲突到期、到期不再操作、非共享/非Windows错误立即抛、只重试文件闭包；真实child注入覆盖response read/publish后仍同PID、同期限且清理完成。这比仅调整1秒测试deadline更能约束共因。

ROOT已按最终冻结源码完成上述96项集中回归，包括实际read/publish注入和原隔离生命周期大节点；本审查不另造全库重复测试或小节点人工审批。独立小文件观察确认读取上限仍为cap+1，JSON超cap仍报`OCR_RESULT_BYTES_EXCEEDED`；image的`OCR_INPUT_BYTES_EXCEEDED`在当前worker源码中保留。真实本地模型、Linux运行时实测与真实文档质量不在本报告证明范围；POSIX这里只读核对argv/guardian结构。

最终边界复核已收尾，冻结指纹和证据所有者见同名JSON；原两次不同失败及独立假钟RED保留。首次worker退出原因仍UNKNOWN，不因这些修复和集中绿测试改写历史。
