"""Pure boundary probes; no native OCR, subprocess, supplier or production files."""
from pathlib import Path
import json
import sys
import tempfile
from types import SimpleNamespace

ROOT=Path(__file__).resolve().parents[5]
sys.path.insert(0,str(ROOT/'src'))
from company_wiki.document_normalization import isolated_ocr as boundary

base=Path(__file__).parent
out={'imported_from':str(boundary.__file__),'api_calls':0,'native_calls':0,'original_reads':0}
clock=SimpleNamespace(now=10.0)
original_time=boundary.time
boundary.time=SimpleNamespace(monotonic=lambda:clock.now,sleep=lambda _:None)
try:
    def late_success():
        clock.now=12.0
        return 'file-operation-finished-after-deadline'
    try:
        value=boundary._retry_owned_io(late_success,deadline=11.0)
        out['late_success']={'result':'RETURNED_SUCCESS','value':value,'returned_at':clock.now,'deadline':11.0}
    except Exception as exc:
        out['late_success']={'result':type(exc).__name__,'detail':str(exc)}
finally:
    boundary.time=original_time

with tempfile.TemporaryDirectory(prefix='ocr-file-probe-',dir=base) as temp:
    image=Path(temp)/'image-0.bin'
    image.write_bytes(b'12')
    try:
        raw=boundary._read_bytes(image,1,deadline=boundary.time.monotonic()+1.0)
        out['input_image_read']={'bounded_bytes_read':len(raw),'cap_plus_one':2}
    except Exception as exc:
        out['input_image_cap']={'type':type(exc).__name__,'code':getattr(exc,'code',None),'detail':str(exc)}
    try:
        boundary._read_json(image,1,deadline=boundary.time.monotonic()+1.0)
    except Exception as exc:
        out['json_cap']={'type':type(exc).__name__,'code':getattr(exc,'code',None),'detail':str(exc)}
out['owned_temp_removed']=not Path(temp).exists()
(base/'ocr-file-probes.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(out,ensure_ascii=False,indent=2))
