"""Single bounded source-owner timing observation, never a second parser."""
from __future__ import annotations

from datetime import UTC, datetime
import hashlib
import json
import os
from pathlib import Path
import socket
import sys
import tempfile
import time

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).parent / "hk-ipo-performance-20261015"


def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf8", newline="\n")


def child(temp: Path) -> int:
    import faulthandler
    from company_wiki.source_catalog import narrative_evidence as native

    def blocked(*_args, **_kwargs):
        raise RuntimeError("owned source profiling has no network")

    socket.socket.connect = blocked
    socket.create_connection = blocked
    sample = next(s for s in json.loads((ROOT / "docs/plans/document-understanding-2026-10-13/sample_manifest.json").read_bytes())["samples"] if s["id"] == "hk-ipo")
    original = Path(sample["path"])
    data = original.read_bytes()
    digest = hashlib.sha256(data).hexdigest()
    assert digest == sample["sha256"] and len(data) == sample["bytes"]
    start = time.perf_counter()
    state = {"source_sha256": digest, "source_bytes": len(data), "original_reads": 1,
             "parse_calls": 1, "selector_version": "0.9.0", "phase_timings": {},
             "slow_calls": [], "active": None, "complete": False, "supplier_calls": 0}
    last_flush = [0.0]

    def flush(force=False):
        elapsed = time.perf_counter() - start
        if force or elapsed - last_flush[0] >= 1:
            state["elapsed_seconds"] = elapsed
            write(temp / "progress.json", state)
            last_flush[0] = elapsed

    def observe(name, original_function, page_getter=None):
        def wrapped(*args, **kwargs):
            begun = time.perf_counter()
            page = page_getter(args) if page_getter else None
            previous = state["active"]
            state["active"] = {"phase": name, "page": page}
            flush()
            try:
                result = original_function(*args, **kwargs)
                if name == "_pdf_table_scan_pages":
                    state["planned_table_pages"] = len(result)
                return result
            finally:
                duration = time.perf_counter() - begun
                record = state["phase_timings"].setdefault(name, {"completed_calls": 0, "inclusive_seconds": 0, "max_seconds": 0})
                record["completed_calls"] += 1
                record["inclusive_seconds"] += duration
                record["max_seconds"] = max(record["max_seconds"], duration)
                if duration >= 0.2:
                    state["slow_calls"].append({"phase": name, "page": page, "seconds": duration})
                    state["slow_calls"] = sorted(state["slow_calls"], key=lambda row: row["seconds"], reverse=True)[:24]
                state["active"] = previous
                flush()
        return wrapped

    for name, page_getter in (
        ("_pdf_text_blocks", lambda args: args[0].number + 1),
        ("_scan_pdf_pages", None), ("_pdf_table_scan_pages", None),
        ("_emit_pdf_tables", lambda args: args[2]),
        ("_emit_pdf_page", lambda args: args[2]),
    ):
        setattr(native, name, observe(name, getattr(native, name), page_getter))
    fitz = native._fitz_module()
    fitz.Page.find_tables = observe("native_find_tables", fitz.Page.find_tables, lambda args: args[0].number + 1)
    flush(True)
    with (temp / "active-stack.log").open("w", encoding="utf8") as trace:
        faulthandler.dump_traceback_later(40, file=trace)
        try:
            result = native.parse_pdf_bytes(data, source_id="urn:company-wiki:source:sha256:" + digest,
                                            source_sha256=digest, language="mixed", selector_version="0.9.0")
            state.update(complete=True, page_count=result.page_count, pages_read=result.pages_read,
                         units=len(result.units), planned_table_pages=len(result.table_scan_pages),
                         errors=list(result.errors)[:16], coverage_complete=result.coverage_complete)
        finally:
            faulthandler.cancel_dump_traceback_later()
            flush(True)
    return 0


def main() -> int:
    from company_wiki._bounded_process import ChildFailed, ChildTimeout, run_bounded

    OUT.mkdir(exist_ok=False)
    sample = next(s for s in json.loads((ROOT / "docs/plans/document-understanding-2026-10-13/sample_manifest.json").read_bytes())["samples"] if s["id"] == "hk-ipo")
    original = Path(sample["path"])
    original_stat = (original.stat().st_size, original.stat().st_mtime_ns)
    protected = [ROOT / "config.yaml", ROOT / "config/source_catalog.yaml", ROOT / "src/company_wiki/source_catalog/narrative_evidence.py", ROOT / "src/company_wiki/source_catalog/narrative_pdf_layout.py"]
    before = {str(p.relative_to(ROOT)): (hashlib.sha256(p.read_bytes()).hexdigest(), p.stat().st_mtime_ns) for p in protected}
    started = time.perf_counter()
    code = 99
    with tempfile.TemporaryDirectory(prefix=".cw-ipo-", dir=ROOT) as name:
        temp = Path(name)
        sentinel = temp / "existing.txt"; sentinel.write_bytes(b"keep original test baseline")
        env = {k: v for k, v in os.environ.items() if not k.endswith("API_KEY")}
        env.update(TEMP=name, TMP=name, PYTHONDONTWRITEBYTECODE="1", PYTHON_DOTENV_DISABLED="1")
        try:
            result = run_bounded([sys.executable, "-B", "-X", "utf8", str(Path(__file__)), "--child", name],
                                 cwd=str(ROOT), env=env, timeout_seconds=60,
                                 stdout_cap_bytes=65536, stderr_cap_bytes=65536)
            code, stdout, stderr = result["returncode"], result["stdout"], result["stderr"]
        except ChildFailed as error:
            code, stdout, stderr = error.returncode, error.stdout, error.stderr
        except ChildTimeout:
            code, stdout, stderr = 124, b"", b"Owned 60-second profiling deadline"
        (OUT / "stdout.log").write_bytes(stdout); (OUT / "stderr.log").write_bytes(stderr)
        for filename in ("progress.json", "active-stack.log"):
            if (temp / filename).exists():
                (OUT / filename).write_bytes((temp / filename).read_bytes())
        assert sentinel.read_bytes() == b"keep original test baseline"
        assert original_stat == (original.stat().st_size, original.stat().st_mtime_ns)
        assert before == {str(p.relative_to(ROOT)): (hashlib.sha256(p.read_bytes()).hexdigest(), p.stat().st_mtime_ns) for p in protected}
    assert not temp.exists()
    receipt = {"observed_at": datetime.now(UTC).isoformat(), "exit_code": code,
               "elapsed_seconds": time.perf_counter()-started, "status": "COMPLETE" if code == 0 else "BOUNDED_PROFILE_PARTIAL",
               "original_stat_unchanged": True, "source_config_unchanged": True, "temp_removed": True,
               "network_or_supplier_calls": 0, "scope": "one actual native parser timing observation; inclusive times overlap, not selection/quality certification"}
    write(OUT / "receipt.json", receipt)
    print(json.dumps(receipt))
    if (OUT / "progress.json").exists():
        state = json.loads((OUT / "progress.json").read_bytes())
        print(json.dumps({k: state.get(k) for k in ("complete", "active", "planned_table_pages", "phase_timings", "slow_calls")}, ensure_ascii=False))
    return 0 if code in (0, 124) else code


if __name__ == "__main__":
    raise SystemExit(child(Path(sys.argv[2])) if len(sys.argv) == 3 and sys.argv[1] == "--child" else main())
