# DU6 STATE ROOT 实施交付（源码已冻结）

## 已完成

四个源码文件：

1. `src/company_wiki/document_understanding/operating_states/relations.py`：调用内 prepared session 按来源单元缓存 MatchingView/name classes，合并 context 时复制名字分类防止污染；相同 unit+固定 scope 的结果只算一次。前置条件沿原逗号闭合，原句号/分号/contrast 阻断，并保留条件原文 qualifier_refs。修复既有 English shipment 的动作组只有 qual 没有 pred 导致整个语法被丢弃：复用已绑定 verbal group，不加公司特判、不改 pattern 文件。
2. 新 `source_catalog/narrative_operating_relations.py`：source owner 的一次 session 只使用传入 WorkBudget；按最终 native range 或原 continuity group/单元归属缓存事实。真正 native range 先物化再分析；已批准 continuity 无完整 page view 时，只建 transient analysis view，一次拼接、分段 scalar offset 映回原 unit，多来源父级不能混组；不造 NarrativeUnit/EvidenceSpan 或新持久 schema。每个 group member 的 factual admission 都有全组依赖。已闭合 partial relations 保留，耗尽不重启全文 detector。
3. `source_catalog/narrative_business_policy.py`：薄投影把计划/条件/否定/相关方/未知/当前状态与 issuer milestone 分开；未知关系下仍保留业务/行业/机制和未覆盖业务动作描述，但不冒充已实现进展。策略因果版本升级到 `reading-business-policy/7`。旧 0.8 三个函数源码文本未变，独立比较收据见 `legacy-functions.json`。
4. `source_catalog/narrative_reading.py`：先固定结构和 material owner，再共享 session；admission/topic/dropped 统计复用同一 facts，不再按文本跨 parent 缓存。优先花预算分析已有高优先级材料，再恢复原始材料顺序；20k 候选的重要晚期 scope 原测试已绿。QA 原生 citation views 只允许真实 answer anchors 做 support，问题保留完整 context。没有 source-state 完整性时不把空结果报成 finance-only skipped。

新增唯一测试：`tests/unit/document_understanding_root/test_operating_relation_production.py`（28 项），覆盖中英条件、断句/contrast、计划/否定/供应商/股东、真实量产进展、普通描述、真实 native range、已证明 continuity 的逐原 unit offset、跨 parent、context view 复用、耗尽恢复与真实 QA support。

## RED / GREEN

- 初始实际 RED：19 项 12 FAIL / 7 PASS。保留条件闭合、计划误标、量产漏召回等实证；后续一项新测试错误使用非 canonical 临时 unit_id，已改用既有 canonical fixture maker，不是产品缺陷。
- 旧 native continuity 的 3 个 meaningful_fact 合同原样保留，通过有真实分段映射的 shared owner 全部恢复，未降低 expected、未新增 native_source_view 门禁。
- `continuity-qa.log/json`：228 PASS / 2.95s，含真实 official catalog/projection QA、native continuity 原测试、native carriers、semantic、DU4 旧包及新增测试。
- **最终集中 `final.log/json`：771 PASS / 1 FAIL / 25.48s。唯一 FAIL 是旧 `test_reading_portfolio_disclosure.py:64` 硬编码 `reading-business-policy/6`；实际正确新版本 `/7`。ROOT 请集中升级这个版本断言后验收。** 所有旧测试、fixture、金标本次均未修改。
- Ruff：四源码＋新测试共 5 文件全部通过。

## 复跑命令

正常宿主 PowerShell 执行，避免 Windows 深层 sandbox TEMP 超长路径：

```powershell
$env:DU6_TEST_TEMP_ROOT = Join-Path $env:LOCALAPPDATA 'Temp'
python .planning/shared-reading-production/du6-state-design/implementation/run_tests.py final tests/unit/document_understanding_root/test_operating_relation_production.py tests/unit/du4_operating_states tests/unit/document_understanding_selection
```

runner 在 import/任何实际调用前给子进程设置独立 registry/TEMP，关闭无关自动插件，每项测试 45 秒、总运行 240 秒，保存日志/收据后严格删除本次 own Temp。最终 Temp 已清理。0 外部 API；没有修改生产 registry/catalog/config/原件、Git、作者树或旧测试。

诊断过程曾有两项环境问题：宽包人工中断（不作为验收）、深层 TEMP 导致 Windows 原子临时文件长路径错误。改用宿主短 Temp 后同一真实 official projection 测试通过。一次 sandbox Temp 删除被系统拒绝，已精确路径验证后在宿主删除，未遗留该目录。最终 `final.*` 才是权威验收快照。

## 接线边界

FORM 两源未改；没有改 profiles/router/pipeline/structure/narrative model/worker/作者目录。独立结构 agent 与 ROOT 的源文件白名单没有重叠。所有本次 source SHA、新测试 SHA 及收据入口在 `handoff.json`，现在保持冻结等待 ROOT 统一接收和提交。
