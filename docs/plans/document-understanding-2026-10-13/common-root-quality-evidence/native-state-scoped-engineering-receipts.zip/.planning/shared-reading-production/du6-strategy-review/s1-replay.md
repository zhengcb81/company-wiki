# S1 producer-boundary replay

Original `probe.py` and `identity_controls.py` copied byte-identically to `*-fixed.py`; no original RED or output overwritten. All four original collection cases now stop with zero collection visits. Six scope/identity/nonmutation/legacy/call-local controls remain PASS. Recursive JSON material construction retains the existing same-budget owner, no cross-call global state found, and the legacy None branch still takes its original deepcopy/matching route.

Two same-owner tails remain open, not a request for a broader pipeline hard bound:

- `diagnostics.extend(deepcopy(chosen.get("policy_diagnostics", [])))`: a valid 20K diagnostic list is visited 20K times while the call completes with budget100, used29.
- Final `_unique(components)` retains uncharged quadratic equality checks. 1000 distinct immutable str-subclass values (only instrumentation is an equality counter, same string equality) cause499500 comparisons while a20K budget records3029 and returns complete.

`policy-tail-probe.py/json` contains exact pure inputs and results. The first can join the existing bounded policy-material owner; the second can reserve actual comparison candidates before equality dedup while preserving old mixed JSON equality semantics. No operation proxy or new quota is required. No further sample expansion is planned; follow up these exact remaining common-owner boundaries.
