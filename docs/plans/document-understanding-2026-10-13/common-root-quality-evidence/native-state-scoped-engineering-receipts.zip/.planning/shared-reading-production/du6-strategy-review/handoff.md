# Independent ROOT strategy preparation review

**REQUEST CHANGES — one P2 common cause.** Read-only production source/tests; probes and this report only in owned scratch. No API, original, Git, shared PWF, configuration or author-tree access/write.

## S1 — preparation happens before iterator charging

Current `strategy_binding.py` charges `visit`, fold and matching, but several variable carriers are fully materialized before those charges can stop work:

- Lines 219: child scope `set(unit_ids)`.
- Lines 94 / 111: `_rules` filters the whole sequence before the per-rule charge.
- Lines 247, 293: heading join and owner lists are created before their consumer visit.
- Lines 309, 316: question dedup and first family/context/policy material deepcopy are uncharged. Per-identity caching avoids repeated copies but does not bound the initial one.

Finite, valid-reference probes (`probe.py`, exact observations in `probe.json`):

| Case | Budget | Observed collection visits | Result |
|---|---:|---:|---|
| 20K duplicate valid child scope IDs | 5 | 20,000 | eventual budget stop, after unpaid full set construction |
| family_policy.features with 20K values | 100 | 20,000 | **complete, used only 19** |
| 20K rules | 30 | 20,000 | eventual stop, after full `_rules` materialization |
| 20K valid heading IDs | 30 | 40,001 | eventual stop, after joins/owner list copies |
| ordinary one-unit control | 2M | n/a | complete, used 19 |

These cases do not assert per-instruction or wall-clock bounds. They directly show that the claimed strategy preparation scope can perform arbitrarily growing collection work before paying it. A single root fix should put reservations at the producer/materialization boundary, keep known sizes/character blocks within the call-local preparation object, and avoid flattening/copying the same rules per section. The first policy JSON preparation needs bounded recursive copy work or an explicitly read-only already-prepared view; wrapping every Python operator would recreate the rejected structure design. `_unique` still uses equality membership and may be quadratic for distinct question/component values; reserve/replace only within its actual JSON contract without changing legacy equality semantics by accident.

## Positive controls and pipeline

`identity_controls.py/json` all six checks PASS: shared and standalone values agree, inputs unchanged, different child keys sharing profile_id and owner section retain distinct business/risk roles and policy material, child materials are distinct, and a changed second-call profile does not inherit the first call cache. No cache identity or cross-call contamination defect found in these cases.

Static pipeline review confirms the same budget is passed into structure and strategy; a strategy WorkBudgetExceeded returns a thin deferred result with existing observation and structure retained. No new quota/reset found. Source zero/used checks precede enumeration. Root's six supplied tests and old regressions were read, not redundantly rerun. Existing pipeline routing/child-profile work outside the strategy caller still has no new full-pipeline hard-limit guarantee; `full_pipeline_hard_bound=false` is honest and this report does not broaden the tranche to require one.

## Evidence boundary

Pure synthetic in-memory reproduction only, no real source/model semantics evaluated. Exact reviewed file hashes are in handoff.json. No tests or source modified. After the single common preparation fix, rerun these probes and existing concentrated node; no additional user approval or micro-review node needed.
