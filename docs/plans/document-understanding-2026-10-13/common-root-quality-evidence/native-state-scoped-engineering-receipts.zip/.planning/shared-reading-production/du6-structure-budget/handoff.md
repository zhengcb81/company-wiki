# Structure shared budget — converged delivery

**READY FOR ROOT INTEGRATION; not a claim of full-pipeline hard limits.** No commit, network, API, original read, production configuration write or author-tree write.

## Design and rejection retained

The initial operation proxy design was rejected after representative-scale measurement. Preserve `pre-convergence.patch`, `first-candidate-scale.json` and initial RED/green receipts. With 6K synthetic units, that candidate consumed 2M and retained only 200/1900 semantics and zero/3200 relations. Small green tests were insufficient. The replacement restores the original algorithms and uses four existing responsibility files plus the 40-line private `_work.py`; no construct/operator/reducer/comparator proxy remains. The small layout changes read already-non-null bbox coordinates directly so mypy can prove existing geometry guards. QA/project/table/paragraph/section/table-purpose algorithms are unchanged HEAD bytes.

## Current boundaries

`build_structure(observation, limits=None, work_budget=None)` uses the caller's same WorkBudget without constructing or widening a quota. `None` preserves standalone limits and output. Shared zero/exhausted/tiny remainder interrupts before raw unit iteration/parser. Parsing reserves actual sequence/shell lengths before copying, including the empty-input coverage tail, and collects text blocks once before unit parsing. Major stages reserve logical linear/text-pass and n*bit_length(n) sort work using those observed sizes. Language-pair expansion reserves actual candidate cardinality before expansion, stays lazy, and graph reachability reserves visits/edge sorting before work. Per-page footnote candidate scans reserve their actual row scope.

Completed sections, closed semantic packages and validated relation stages are transactionally retained if later work cannot be paid. Open unanswered QA is omitted from a partial result, not published as support. Source native state/counts survive, complete=false and unobserved_ids_limited=true avoid claiming that missing tail IDs were inspected. This is in-memory partial retention, **not** a persistent checkpoint or a second queue.

The work unit is a logical enhancement budget. Stage pass reservations are a conservative scheduling policy, not proof of every Python instruction. Regex time, arbitrary scalar/hash behavior, imported semantic implementations and other pipeline layers have no new wall-clock guarantee. Do not label this tranche full_pipeline_hard_bound=true.

## Evidence

- Genuine original behavior RED: zero budget reads raw sequence; shared 19/20 balance ignored (`behavior-red.txt`).
- Additional genuine converged RED: empty-input opaque-page tail copied unpaid (`converged-empty-red.txt`); fixed by the same input-reservation owner.
- Final 137 PASS / 6.57s includes 19 new tests, all original structure tests, root DU2 integration and reading child/table regressions. Ruff PASS; mypy 11 structure sources PASS. Retained `converged-related-final-first.txt` records a temporary variable-rename implementation mistake (20 FAIL/116 PASS), fixed before final green; this was not treated as a product defect.
- Permanent 6K mixed-fixture regression ensures unchanged 2M budget produces complete output equal to standalone, including >1000 semantics and relations.
- `converged-final-scale.json` compares actual HEAD originals imported from owned scratch, current standalone, and current shared. Inputs are explicitly **synthetic expansions of eight frozen shapes**, not real filings. Saved native benchmark summaries did not preserve a complete source unit list. No PDF was reopened.

| Units | Original HEAD | Current None | Shared | Shared work | Output |
|---:|---:|---:|---:|---:|---|
| 2,000 | 0.148s | 0.141s | 0.138s | 417,930 | exact same output SHA, 634 semantics / 1064 relations |
| 6,000 | 0.520s | 0.481s | 0.404s | 1,428,909 | exact same output SHA, 1900 semantics / 3200 relations |

These are single-run wall times with visible warmup/noise; **no speedup claim**. Earlier converged 6K shared measurement was 0.575s. The meaningful outcome is full original output inside the unchanged cap, instead of proxy-driven truncation.

## Handoff

Final source/test hashes: `final-source-sha256.json`. ROOT owns same-instance pipeline integration and concentrated independent review, normal commit/push and PWF. Root caller must honor partial coverage and unknown tail IDs. Real model summary quality and real-document production integration remain separate open acceptance nodes.
