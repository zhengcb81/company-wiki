# Findings

- Ten responsibility files total approximately 3,287 lines, 105 functions and 158 loop/comprehension sites. CodeGraph lists only part of these imported modules; current known files were read directly.
- Current build_structure parses/order all units before estimated-work diagnostic, so shared zero currently has no port or actual stop.
- Structure includes potentially quadratic language pairing/graph reachability; metering must charge candidate/edge loops, not only number of input units.
- Expensive text operations include native text normalization, regex matching, joins/splits, and table-purpose catalog delegation. They need input-dependent charge before execution.
- Semantic builders mutate local consumed/group drafts. Interrupted drafts must not be exported or used to fabricate complete coverage; already closed stage results should survive.

## Implemented boundary

- Existing WorkBudget is passed explicitly through all ten responsibility modules. No global context, alternate source type, quota or runtime AST/tracing exists.
- Private operation helpers charge before next/iteration/materialization/slicing/containment, text and regex input blocks, actual sort comparisons, graph candidate traversal. The one-time editing script is not runtime and now refuses a second execution.
- Standalone work_budget=None retains old output and positive limits contract. Seven frozen structure input shapes produce exact equal shared/standalone outputs at sufficient budget.
- On shared interruption, committed sections and only closed semantic groups survive with stable unique IDs; no graph relations are committed before the acyclic pass completes. Failure projection uses bounded new diagnostics and source counts, never scans deferred ID tails.
- Native regex and imported text matching/catalog operations consume input-dependent logical work, not wall-clock cancellation of a C/Python native operation. Pipeline/strategy/candidate hard metering remains ROOT work; no real 2M default-budget corpus throughput was measured here.
