# Progress

2026-10-16: Read actual call graph/modules. ROOT approved exact write scope and explicit same-instance helper scheme. No production/source changes yet; proceeding to real behavior RED.

Port scaffold first showed 3 missing-keyword failures; this was not counted as behavior RED. After the neutral port, actual behavior RED was 2FAIL/2PASS: unpaid unit iteration and ignored remaining shared balance. Receipt behavior-red.txt.

Explicit source operation migration preserved comments/docstrings. Several syntax mistakes in the one-time editor were caught before its all-file write phase; the initial one-file partial attempt was restored only from that file's existing HEAD bytes (no index/Git writes), then all-file preflight was made atomic. Candidate text files are editor diagnostics, not delivered runtime modules.

First source pass: 47 old structure PASS, expected 2 new failures pending the public exception boundary; after transaction wrapper, 51PASS. Strong boundary/frozen-shape suite expanded to 17PASS. Related structure/root/child/table suite: 135PASS/17.99s. Then sorting helper changed from comparison upper-bound reservation to actual comparison charging; final 17 shared boundary tests and Ruff/mypy completed on that final source, see final receipts. The earlier 135 result is not mislabelled as rerun after that small helper change.

ROOT requested a temporary shared-source freeze for another agent's protocol tests. Paused all source/test writes and new test launches, waited for explicit release, then continued. No writers touched non-owned source files.

## Representative-scale rejection of first candidate

ROOT requested convergence before acceptance. Saved pre-convergence.patch (tracked diff) and original-structure HEAD files read-only. Ran scale_probe.py on eight frozen structure fixtures repeated with distinct unit/locator/page/table/turn references to exactly 2K and 6K units. This is SYNTHETIC, not a retained full real filing. Native-run summary has carrier labels and selected observations, not a complete unit source. No original was opened.

Actual HEAD original and current standalone output SHA agree at both sizes. 2K original 0.258s, standalone 0.213s, shared 0.917s/1,004,600work, complete equal SHA. 6K original 0.734s, standalone 1.247s, shared 1.801s/2M exhausted: 200 of 1900 semantics and zero of 3200 relations, complete false. Single-run wall times are observations, not benchmark confidence intervals. This candidate fails practical full-structure completion and is NOT deliverable. Shared usage includes per-operation accounting overhead; cap unchanged. ROOT informed and source frozen pending design decision.

## Converged delivery

ROOT approved original-algorithm restoration and stage reservation. Final tracked source delta 290 insertions/79 deletions across four existing files plus 40-line private helper. Permanent new tests19; final related137PASS6.57s, Ruff/mypy11PASS. Final same-scale exact HEAD equality with 2M shared: 2K417930, 6K1428909. Source frozen and handoff records logical not instruction/wallclock boundary. No source outside assigned scope changed.
