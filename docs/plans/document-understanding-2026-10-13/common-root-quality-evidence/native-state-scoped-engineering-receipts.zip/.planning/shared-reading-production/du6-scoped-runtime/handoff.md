# Explicit reading-model-input/4 runtime: ROOT handoff

Status: implementation frozen for ROOT cross-review, 2026-10-16. No Git writes,
installation, supplier API calls, config/PWF changes, or production originals changed.

## Scope and actual integration

Seven source paths plus four new test files are frozen in
`frozen-source-sha256.json` (actual byte and normalized LF hashes). The old
`narrative_model.py` remains byte-exact:
`2306aa70f532e508f8a470fb03088bce52bf1e340f4a44dc623f3d7d95e4f702`.

- New finite runtime dispatch delegates None/v1/v2/v3 to that original module.
- Explicit v4 produces request schema 5, sparse `drafts_by_task`, and one shared
  clause schema. Local basis maps only to its source task's support; canonical
  reconstruction retains the whole native scope and separate QA context.
- All rows count toward one twenty-clause limit before clause recovery. IDs
  derive from native task order and ordinal. Illegal clauses drop whole, mark
  recovery quality, and receive no automatic repair or second model call.
- Claim type uses the source owner role rule shared with existing validation.
  Mixed/unknown roles remain uncertain; analyst actual claims cannot pass.
- Existing generation manifest, factory software validation, summarize handler,
  and verify entry points use the finite dispatch. HTTP/model caller, billing,
  public contracts, worker, store, and shared source task compiler are unchanged.
- v4 causal implementation identity includes its runtime, protocol, source task
  plan, role/quality owner, old utilities, canonical contracts and encoders.
  It never pretends an updated implementation has an old SHA.
- Public selector default 0.8 and new selector 0.9 default v3 remain unchanged.
  `generation_manifest(...reading_model_projection='reading-model-input/4')`
  is the existing explicit integration port; no env/config permission flag added.

## TDD and exact compatibility

`runtime-red`: 8 FAIL / 17 PASS before v4 implementation (missing boundary and
shared role helper). `runtime-first`: 54 PASS with old runtime/view coverage.
`translation-red`: 1 FAIL / 2 PASS: explicit translation in a bad clause used to
be swallowed by recovery; fixed by reusing the original whole-response language
owner before local recovery.

The unchanged pre-v4 archive is embedded in the new portable legacy test:
gzip SHA `789c3e64d4d73656b85864b44c258cc1e9626bc36e0693a1e2ce2c999bc84a79`.
Raw and official v3 exact request, HTTP body, and boundary identity are checked.
First comparison mistakenly used an unbudgeted request against the archived
post-`with_output_budget(8192)` object; the sole wire difference was output cap.
Only the test call was corrected; no archive/gold/old implementation was rebuilt.
Existing None/v1/v2 frozen gold tests also run in the final node.

## Final concentrated node

`frozen-acceptance/receipt.json`, `stdout.log`, `junit.xml`:

- **238 PASS / 44.26s** pytest time, 52.36s bounded wrapper wall time.
- 13 selected new/old suites. No whole-repository test run added.
- Includes real explicit v4 generation → spawned worker → original HTTP caller
  → verify → published artifact → completed recovery. One initial loopback HTTP
  POST, **zero extra POST on recovery**. The loopback body copies a selected
  excerpt; this is lifecycle/transport evidence, not real paraphrase quality.
- Includes real v3 completed typed artifact → CLI under simulated current
  validator identity change. Zero new model construction/POST; original run,
  historical binding, databases, charges, and raw originals remain exact.
- Pending stale software validation still refuses; historical stage-scoped
  identity seam is separately tested, not presented as execution of old code.
- Temp restored/deleted, pre-existing sentinel intact, protected production
  config SHA/size/mtime unchanged, **0 supplier API calls**.
- `static-checks.json`: Ruff all seven sources/four tests PASS; mypy runtime and
  scoped protocol PASS. Tracked source `git diff --check` PASS.

Four actual decoder role-set fixtures initially edited immutable parser output
without rebuilding EvidenceSpan hashes, causing four fixture errors. The new
fixtures now create proper native spans before building reading groups. Product
hash checks were preserved; `concentrated-final` retains the failure snapshot.

## Concurrent snapshots retained honestly

- `bindings-first` ran during ROOT's pre-commit automatic unstaged-file hiding;
  33 import/old-boundary failures are an environment snapshot, not v4 RED or a
  product regression. ROOT confirmed automatic stash restored before continuation.
- `formal-v4-first` genuinely completed/published but its test wrongly compared
  the compatibility run-container prompt to the per-source protocol prompt.
  Correct assertion now checks both according to their actual owners.
- `formal-v4-second` observed a select HANDLER_EXCEPTION while ROOT temporarily
  returned None from parse_observation. ROOT reported the defect and fix;
  `formal-v4-diagnostic` then PASS, followed by the frozen 238 PASS node.
  Old failures remain in their original directories, never overwritten.

## Not closed by this implementation

No real supplier run or general semantic entailment claim is made. Legal local
basis still does not prove rewritten prose; an explicit wrong-text/right-task
negative control remains accepted structurally with `semantic_status=not_evaluated`.
The six real wrong citations and PD5/Matrix/other important business omissions
remain OPEN for the shared source dependencies/coverage and real semantic node.
No historical review is relabelled, and default production v4 was not enabled.

ROOT owns final combined cross-review, broader source/form integration, PWF,
normal commit/hooks and publication. This lane stops source edits here.
