# FORM production routing independent review

2026-10-16. Read-only source review. No source/test/PWF/Git changes or network.
Reviewed byte hashes are in `reviewed-source-sha256.json`. Runtime implementation
from this agent's separate lane remained frozen and was not reviewed here.

## Confirmed P2 findings — ROOT owns fixes

### F1: conflicting native siblings become an unqualified first form

`profiles/signals.py::_detect_sec` computes `native_owner_values` only from
entries whose **carrier_unit_ids equal the first carrier's list**. Two separate
visible `dei:DocumentType` fields in the same observed primary scope (10-Q and
10-K) correctly produce collector `status=partial` and `FORM_VALUE_CONFLICT`.
Production routing nevertheless chooses `family=quarterly, form_type=10-Q`.
The same conflicting values in a single unit become unknown correctly.

Reproduction: `python -B -X utf8
.planning/shared-reading-production/du6-form-route-review/probe_routes.py`.
Cases `native_conflicting_siblings` (bad) and `native_conflicting_sameunit`
(existing negative control). Saved complete output: `probe_routes.json`.

Expected: process the native evidence conflict within the actual source scope;
do not select a certain form merely from the first native carrier. A true
containing filing plus separately bounded attachment must not be flattened into
one conflict domain. This is an existing scope/provenance root cause, not a
new approval, permission, score, or whole-file identity requirement.

### F2: parent borrows a native attachment's form

HTML with a primary `Current report` heading and ordinary body, then an
`Exhibit 99.1` heading followed by a visible native DEI 10-Q field, produces a
correct 10-Q child route **and a parent quarterly/10-Q route**. The attachment's
actual observed range authorizes itself, not the primary document.

Reproduction: case `native_external_child` in the same script/output. The input
is normalized through the real HTML normalizer, language structure, observation
adapter, collector, capped probes, and production `understand_units`; this is
not the old standalone Mapping compatibility path.

Root cause: native form selection runs over all prepared document probes before
excluding the already recognizable attachment range from the primary scope.
The parent metadata-clearing change only addresses child policy inheritance in
the other direction; it does not fix this borrowing.

Negative control `native_outer8k_child` keeps the explicit outer form 8-K and
the child 10-Q. Preserve this case while separating primary and child scope.
When a necessary range boundary is not observed within the configured cap, its
absence is unknown; do not infer the parent's form from a surviving child value.

ROOT acknowledged both P2s and is implementing a shared primary/child scope
fix with TDD. This review does not modify the implementation or discard RED.

## Other examined boundaries — no further blocker found

`probe_positive_budget.py` and `probe_positive_budget.json` retain the actual
small experiments, without rewriting production fixtures:

| Case | Observed result |
|---|---|
| Retained real MSFT FY2026 Q4 TXT via existing `parse_transcript_text` | complete, earnings_call, 447 native body/turn evidence entries; 76,963 / 2,000,000 work units |
| Retained VRSK visible DEI excerpt via real HTML normalization | complete, quarterly/10-Q, one form evidence, 70 work units |
| Caller WorkBudget cap 0 | deferred, used 0, exhausted |
| Same caller WorkBudget already used 7, cap 8 | deferred, used 8, exhausted; no reset |
| Adequate caller WorkBudget | complete quarterly/10-Q, used 113 / 100,000 |
| Native DEI value beyond a 32-character clipped probe | collector retains native fact, routing remains unknown/unknown; capped route cannot use unread value |

The real TXT uses its dedicated parser; `normalize_document` does not support
text/plain and was not used to invent a new text normalization route. The first
probe attempt surfaced that dispatch mismatch and was corrected in this review
script only. The 447 entries are not asserted to be 447 independent speaker
exchanges. The VRSK experiment uses an honestly labelled saved raw excerpt,
not a new download or a claim to have parsed the whole original SEC filing.

Source-signal and layout stages receive the same mutable WorkBudget. Small
budget probes show deferred output without overrun or resetting consumed work.
The existing output correctly declares `full_pipeline_hard_bound=false`; this
review does not convert the legacy structure/policy estimates into a proven
whole-pipeline hard bound.

`plain_colon_table` is a production negative control: financial labels with
colons produce no turns and do not route as earnings_call. Real TXT provides
the requested positive control, so no invented table turn metadata was added.
Native DEI reasons in the current production test point at the carrier's real
unit; reference character bounds are checked against the retained probe text.

## Scope and replay

No full suite, supplier/API, download, installation, or production-directory
mutation occurred. Own scratch scripts and bounded JSON observations are the
only files written. No temporary source originals were created.

Await ROOT's stable scope fix, then replay these exact two scripts. Preserve
`probe_routes.json` as the original RED snapshot before creating a separate
fixed replay receipt. Do not turn structural routing success into semantic
summary quality PASS or close the prior six real wrong citations/omissions.

## Stable fix replay — F1/F2 closed at this review boundary

ROOT froze the shared native attachment scope change, and this reviewer reran
the **same byte-identical two probe scripts** under `_fixed.py` names so their
new outputs are separate `_fixed.json` files. The original RED files remain.
`fixed-replay-receipt.json` contains assertions, evidence hashes and eight final
reviewed source/test hashes.

- F1 native sibling conflict now routes unknown/unknown. The collector's
  partial conflict evidence is retained byte-for-byte as JSON data; no native
  fact is deleted to manufacture a clean route.
- F2 primary document now routes unknown/unknown while its actual Exhibit
  remains a 10-Q child. Unknown output remains a complete readable pipeline
  result, rather than becoming a rejection or new permission gate.
- Existing explicit parent 8-K plus child 10-Q preserves both form identities.
  Same-unit conflict and financial colon-table negative controls still behave
  as before.
- All six real-positive/character-cap/shared-budget observations are identical
  before and after the fix, including exact caller budget consumption. Real
  MSFT still routes earnings_call; retained VRSK DEI still routes quarterly.

Focused source review confirms `primary_scope` is shared by production signal
detection and policy selection; it filters observed attachment ranges before
the parent consumes form/turn evidence. Child scope retains its initial actual
attachment marker. Native reservation puts the actual marker before the child
carrier within the original probe cap; a missing boundary is not silently
resolved by borrowing a child form. Distinct native form base values conflict
within the actual scope, while a same-base `/A` does not invent a second type.
Existing standalone Mapping behavior is intentionally unchanged.

No additional P1/P2 was found in this finite replay/review. No suite, source
edit, new API call, production original, PWF or Git change was performed.
This closes only FORM production routing F1/F2; summary semantic quality and
the other in-progress STATE/structure work remain separate. Reviewer stops here.
