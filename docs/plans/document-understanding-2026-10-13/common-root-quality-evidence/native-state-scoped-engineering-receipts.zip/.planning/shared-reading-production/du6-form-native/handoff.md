# 原生 FORM carrier → adapter 接收交接

状态：**IMPLEMENTED_AND_FOCUSED_TESTED，等待 ROOT 接唯一 router/共享预算**。没有修改 pipeline/profiles/source_signals、Worker/model/PWF、原件/config/Git。

## 接口与行为

实际源路径为 `src/company_wiki/document_normalization/html_parser.py`，并非另一个HTML前端。

1. 复用现有 `_scan_children/_scan_cell_body` 可见文字积累，在写入每个 normalized fragment 时记录真实visible `ix:nonnumeric[name=dei:DocumentType]` 所属fact及该owner中的字符范围。不重新parse，不通过provider声明/attribute value捏造文字，不新增whole-document get_text。
2. 完整独立owner文字为FORM+printed literal才产生own-label carrier；正文提及、外链及外链内嵌套标题不会当own label。链接上下文随同一次遍历传递，不能污染之后的独立兄弟标题。
3. offset绑定原 `NarrativeUnit.raw_text`（现有NFC/空白规范化之后）；inline fragments之间原parser插入的空格保留。例如实际unit文字`10- Q`不会被编成`10-Q`。同一DEI跨多个原生owner时，保留多owner真实refs，原DU4collector产生SPLIT_OWNER_VALUE，不能挑一个owner假装完整。
4. metadata：`unit.metadata['native_source_view']['carriers']` 为已接收的DU4 carrier完整对象：kind/unit_ids/parent_id/value_refs/attributes。parent_id就是原parser收到的source_id，原unit ID/text/locator不改；两个独立原件拼在一个observation时各自归属不变。
5. `NarrativeNormalization.language_structure` 原有replace自然保留该metadata；adapter只把它深拷贝至对应unit的 `hints['native_source_carriers']`，不做collect/route、重算hash或第二次身份验证。
6. 既有 `NarrativeUnit.to_evidence_span` 已pop `native_source_view`。本测试证实去掉transient metadata前后旧EvidenceSpan完整对象相等，没有让它进入durable structured_value。
7. 可见性共同修正：`ix:hidden` 与 HTML Comment 不再贡献visible owner文字，不能制造伪FORM/DEI；其他既有hidden/script排除沿用原路。可见合法原文的unit IDs和locators保持，旧HTML/replay测试全部通过。

## 避免新增效率缺口

第一次实现逐fact attach会反复复制同一owner逐渐变大的carrier list。真实128-fact owner反例先测到128次NarrativeUnit materialization；现按owner批量attach，128个facts只物化一次。没有再扫DOM/全文，没有新的任务库或schema。own-label本身最多一次，fact批量最多一次，所需metadata工作随真实carrier/ref数量线性增长。

## 实际验证

- `native-red`：实际native parse→language_structure→adapter链，9 FAIL/9 PASS，确认为没有生产carrier观察。
- `native-first-green`：17 PASS/1 FAIL，失败是测试用了非64hex的source ID，legacy EvidenceSpan正确拒绝；改成从实际HTML字节SHA构造合法ID，没有放松产品合同。
- `native-link-red`：嵌套链接1 FAIL/18 PASS，真实误标own label；单次遍历链接上下文修复。
- `native-concentrated`：第一集中140 PASS/9.11s。
- `carrier-copy-red`：ROOT正常commit hook暂时隐藏unstaged源码，导致patch目标replace不存在。ROOT随后明确完成恢复；该结果是环境竞态，不是产品行为RED，保留原日志。
- `carrier-copy-real-red`：恢复后同一真实128-fact样本得到128!=1，才作为性能行为RED；批量owner attach后通过。
- **最终 `native-final`：142 PASS，8.95s，实际pytest exit0。** 其中独占native测试21条，加旧HTML、原文replay/determinism、DU4 source_signals全套和normalization handoff。没有改旧expected，没有真实API/LLM。
- Ruff两源及新测试All checks passed；config/source_catalog.yaml前后SHA不变，owned TEMP与仓内basetemp relocation hook产生的TEMP均报告removed。

精确命令/退出码、原始stdout/stderr、最终指纹见本目录receipt JSON。未运行全部CI、未实际VRSK/8-K完整production route/selector/正式Worker摘要；ROOT必须在其大节点验收，不能把本native/carrier集中测试叫作生产接线完成。

## ROOT 下一步

消费已确认的 `hints['native_source_carriers']`，与对应unit真实source/role/kind/locator组成现有 `du4-source-signal-observation/1`；由ROOT唯一owner把同一WorkBudget传给collector和router/allocator，按200unit/64000char cap预留真实carrier，不事后追加。不更改carrier parent或从声明信息补FORM。legacy旧付费/旧span验收由ROOT总体回归保证；新cause identity应包含实际两源变动，避免缓存把旧“无carrier”观察冒充新版结果。

源码已稳定，可以由ROOT继续整合。本子任务没有stage/commit/push。
