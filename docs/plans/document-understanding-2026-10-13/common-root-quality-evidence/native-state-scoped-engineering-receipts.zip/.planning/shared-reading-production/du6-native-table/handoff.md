# Native TABLE observation bridge — ROOT handoff

2026-10-16. Source frozen for ROOT normal review/commit. Exactly three source
paths plus one new test file: byte/LF hashes in `frozen-source-sha256.json`.
No Git writes, PWF/config changes, downloads, APIs or installed copies changed.

## Implemented path and ROOT integration port

Actual HTML bytes → one BeautifulSoup parse / existing visible owner walk →
cached native table grid → transient `NarrativeUnit.metadata.native_source_view.tables`
→ existing `language_structure` → adapter hint `native_tables` →
`native_table_bridge.bind_native_tables(observation, *, work_budget)` →
existing **`bind_operating_table`** with that exact same caller WorkBudget.

Thin result: `{status, tables: [unchanged du4-table-bindings/1 results],
diagnostics, work_used}`. Each existing result retains native table/parent/page
scope and precise original refs for ROOT's existing dependency closure. This
lane does not persist a table catalog, add a second budget, modify the binder,
or change pipeline/selection/public contracts. ROOT still owns that closure
integration; the bridge is deliberately not claimed as already selected into
formal production summary input.

The native cached descriptor supplies scope, cells and header_rows. Each cell
retains native logical row/column/rowspan/colspan, presence, whole-owner
`text_refs`, same-owner precise `fragment_refs`, and actual native header/id/scope
attributes. Canonical DOM sibling coordinates are kept separately and unchanged.
Native grid preparation reuses row/cell caches and original text emission;
the test observes one DOM parse, one table-row cache and one lookup per row.

Whole original owner refs are sent to the binder. Transparent inline fragments
remain provenance: they do not become guessed values/columns. A multi-column
value remains ambiguous. Native th/thead/headers/row-scope and actual caption
refs supply interpretation; all-td year order does not invent a header. Caption
text is never manufactured as row zero. Nested tables keep their own slots and
do not lend their value text to the outer empty cell.

Empty td has a native empty slot and no NarrativeUnit/ref. Hidden cells retain
an unavailable DOM slot without hidden text or refs, so later cells are not
silently moved into the gap. Invalid span dimensions make present slots
merged_unknown and mark the observation truncated. No coarse PDF box or text
order becomes a native value/column.

All native tables are attached once on an existing visible source unit as a
transient anchor, including an all-empty table if other visible text exists.
If the entire document has no visible NarrativeUnit, the old DocumentStructure
cannot carry per-table state. It remains honestly unavailable; no placeholder
raw text, fake unit/locator, or new DocumentStructure field was introduced.

## Tests, preserved failures and actual verification

Before changing parser/adapter, `freeze_before.py` recorded canonical unit IDs,
text, source locators, coordinates and full EvidenceSpan payloads, plus actual
None/v1/v2/v3 requests/HTTP bytes. Its original JSON remains unchanged. The new
portable test embeds only these frozen hashes, not re-generated expectations.
Canonical fixture fingerprint remains
`6edd45a159404099507ebba9d62ef5e820784633f3237c67ad38130bb26b76f4`.
The transient native source view stays excluded by the unchanged evidence owner.

- `red`: 19 FAIL / 1 PASS. Eleven are new native slot/bridge absence. Eight old
  FORM tests ran during the other lane's temporary structure work_budget versus
  RelationBuilder signature mismatch. This environment snapshot is retained,
  not presented as TABLE regression. Old canonical/wire freeze was already PASS.
- `first-green`: 11 PASS / 1 FAIL. The negative test expected unavailable for a
  missing header, but the original binder's documented behavior is ambiguous
  with period=None. Only the new test assertion was corrected to that actual
  owner behavior and required no_header_path; old binder/fixtures not changed.
- `bridge-green`: 64 PASS / 2.52s: new twelve + original binder fifty-two.
- `native-boundaries`: 17 PASS / 3.07s: adds finite actual single-parse/cache,
  caption refs, empty table anchor, nested scope and prepaid tail-access checks.
- **`frozen-acceptance`: 100 PASS / 1.84s** (wrapper 6.06s): new17, old FORM8,
  old HTML23, original binder52 including retained real HK packet and existing
  holdout/component CLI tests. No whole-repository suite was run.
- Ruff three sources/new test passed before the final finite boundary additions;
  final lint remains ROOT's combined node. Final mypy three sources PASS. The sole old
  root_path tuple inference issue needed an explicit type annotation; no wire
  or behavior change. Actual static outcomes recorded in static-checks.json.

Budget0 / already fully spent budget do not read even observation metadata.
Partial preparation reserves before fetching the next unit; an unread 100000
unit poison tail is never accessed. Real binder receives the same object with
pre-existing spend intact. No second budget, model, numeric/period interpreter
or retry path was added. Inputs remain unmodified. The bounded test wrapper
restores/removes its independent Temp, preserves its sentinel, and checks
production config SHA/size/mtime; all final checks PASS and supplier_calls=0.

## Limits / remaining ROOT work

New production path tests are explicitly synthetic HTML, not relabelled real
company filings. Existing retained HK/holdout binder tests remain regression
evidence, not a new whole-original HTML or PDF end-to-end run. ROOT owns an
additional actual source/holdout read, selection dependency closure, v4 summary
transport/public export integration and real semantic acceptance. In particular
the old six wrong citations and important business omissions remain OPEN.

No native th/thead/headers means unknown interpretation; the bridge does not
guess from newest year or table appearance. Fine PDF value geometry remains
unavailable where the upstream parser did not actually observe it. This stage
does not claim whole-pipeline hard resource metering or semantic entailment.

ROOT may commit/push now. This agent will not modify the frozen four paths or
start another test process during hooks. Only its own scratch documentation is
being completed, and no author/external harness tree was touched.
