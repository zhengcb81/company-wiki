# Default resume source node

Owner: /root/default_resume_tdd. Exclusive source: narrative_batch.py; one new integration test file. Parent owns shared PWF and all other code.

PWF completion B requires old runs to retain frozen versions and paid accounting. Found mismatch: _run_owned reads frozen selector for source validation, then builds manifests using new current default; _run_prepared rejects supported old selector because it compares all frozen fields to current defaults.

TDD scope: actual configured CLI, real source import/normalize/selection/model loopback/AUTO/outbox. Old 0.8 model paid, activation interrupted, fixture-only default 0.9. Resume exact run across process boundary without second POST, metadata/job IDs/known usage retained, publish/public locator reopen, completed same-run and explicit old-generation cross-run zero POST. New omitted-selector run should use new default, not steal old generation. Unsupported prompt/parser/handler and explicit input change remain typed errors. Source/config SHA/mtime/size and sentinel checked, whole test lake removed in finally. No live model calls.

Initial reads had two wrong path guesses (unit/test_n6_batch_upgrade_identity.py and nonexistent test_narrative_reading_production.py); corrected with rg --files, no code or test executed by those failed reads.

## Result / errors

SOURCE STOP. Source frozen after new 7 tests PASS, Ruff owned source/test PASS, mypy owned source PASS. Added actual configured temperature-change refusal, and source protection covers all original directory files, including sidecars.

- `red/receipt.json`: exit 1, 7 failed / 13.25s. One true schema-1 inability to resume; five expected absent resolver failures; schema-2 harness incorrectly used documents instead of its actual items.
- `red-v2-valid/receipt.json`: exit 1, schema-2 alone truly fails after fixing actual result/ref interface, 6.28s.
- `green/receipt.json`: exit 0, 7 PASS / 23.07s, 0 supplier POST; each fixture executes exactly 1 real loopback model POST then published/restored old generation.
- `affected/receipt.json`: exit 1, 38 PASS + 2 FAIL / 61.89s. New7, unit batch17, unit generation12, old paid-outbox1, whole-code-upgrade completed-history1 all PASS. Both failures in legacy N6 test line103 demanding already-completed history refuse a code upgrade.
- `baseline-probe-v2.receipt.json`: exit1, exact same 2 legacy N6 failures /10.56s using HEAD complete coordinator code loaded in private CLI wrapper only. Both baseline failures were real, but later diagnosis proves the legacy bootstrap did not actually apply the advertised upgrade. These failures alone do not prove only an oracle conflict. Separately, ROOT reviewed PWF B and the real existing completed-history integration and confirmed completed artifacts must remain a pure read. At that initial handoff the old test was untouched; the later explicitly assigned follow-up below records its oracle and harness correction.
- `baseline-probe.stderr.log`: first comparison wrapper lacked repo root in import path (`tools`); corrected isolated bootstrap path only, preserved old error and v2 real failure output.
- Initial Ruff found unused new-test import, removed; static receipt both exit0.

No commits/pushes/default constant/global model config edits. Only narrative_batch.py and test_reading_default_resume.py source changes. Workspaces, original production configs and imported fixture originals remain protected. All private test lakes removed by existing finally cleanup; basetemp plugin records independently confirm removal.

## Implementation and resumption contract

`_effective_execution_versions` supplies one frozen execution view to source preparation, generation manifests/locks and unfinished-run availability. A new run uses current request/default. An old omitted-selector request can execute a supported frozen selector even after the default moves to0.9; it does not override current prompt/parser/handler/model configuration. Explicit changed selector/model config still changes request identity and is refused before new model work. Fully terminal history stays read-only, even after unavailable code component changes, because no unavailable code is executed.

The old0.8/new0.9 fixture changes only coordinator request-module default in temporary launcher. Production default remains0.8. Actual source→normalization→selection→model→AUTO/outbox→NarrativeRef/public source-locator replay path is real. Cross-run reuse is explicitly old selector0.8; a genuinely new omitted-selector run belongs to new0.9 and must not steal old output. Known usage, reservation IDs, job IDs and frozen binding preserved; output-size settlement is the intended publication completion change.

## Parent handoff

Use `source-stop.receipt.json` hashes and existing test logs. Carry both legacy baseline failures into PWF; do not report full affected suite green. Test cases can be consolidated into root majorB node without adding a new gate. Parent handles old N6 oracle and final source node commit/push/default quality decision. Remain STOP unless parent assigns the legacy test explicitly.

## ROOT follow-up / legacy oracle node

ROOT explicitly reviewed and assigned updating old N6 completed-history assertion only. Changed rejection expectation to successful completed historical read with identical original documents and budget; all existing old-run/job/public bytes/usage and later new-run separate generation assertions retained.

`historical-oracle/receipt.json`: actual exit1, 7 PASS + 2 FAIL /36.84s. Old cases now pass historical read and retained invariants, but next-run jobs are actually0 instead of3 atline119. Did not change this assertion.

Read-only root cause: legacy `_invoke` now puts scripts/ on PYTHONPATH. Python startup imports repo scripts/sitecustomize.py. `_upgrade_launcher` later prepends its temporary bootstrap path then `import sitecustomize`, which returns already cached repo module instead of running its upgrade fixture. Therefore selector/parser did not actually change, and cross-run same generation reuse is correct. This also explains the HEAD baseline failure at earlier rejection assertion. It is a harness deficiency, not a production cache failure.

Requested ROOT authorization to fix only oldtest temporary bootstrap using explicit runpy path so coordinator and spawned workers really see the upgrade marker. Not modified yet. New default-resume test modifies request-module default directly in temporary launcher and has no cached sitecustomize ambiguity. Source remains unchanged/frozen.

`historical-bootstrap-real/receipt.json`: actual exit1, new7 PASS, old2 fail later /44.53s. Bootstrap now truly executes:

- selector marker0.8.0.n6-test-next is genuinely unsupported and correctly raises NarrativeSelectorVersionError on the next new run; it cannot honestly be described as an installed new selector implementation.
- parser case creates a real distinct next run with3jobs and new artifact, but public parser version remains actual format-owner0.1.1. Patching request/evidence/select version labels does not upgrade `narrative_formats.parser_component` source-of-truth. Expected fake0.1.1.n6-test-next is invalid fixture expectation.

Requested ROOT choose supported real versions for this migration fixture (selector0.8→0.9; parserlegacy0.1.0→current0.1.1), preserving unchanged new generation/jobs/artifact/public-version/0POST assertions. Did not register nonexistent versions in production or relax job counts. Production source remains STOP.

## Final supported upgrade node / SOURCE STOP

ROOT explicitly assigned further edits to the old N6 temporary fixture. Kept actual supported versions rather than registering fictional production versions:

- selector old0.8.0→new0.9.0;
- parser old0.1.0→current0.1.1, bound to the real parse_pdf_bytes keyword default and narrative_formats parser_component owner in isolated coordinator/worker bootstrap. The real parser function body is not substituted and returns actual parsed units. A temporary sys profile observer reads actual received parser_version and actual result unit versions, and checks both versions were executed, unit versions match actual API arguments and the whole real fixture PDF page was read.

The existing ir_policy is a genuinely generated one-page PDF; test asserts the actual indexed MIME. No new production provider, parser alias, supported-set entry or fake output callback. Both generations remain source-byte/read-policy bound. The fixture deliberately has administrative/no-narrative content, so generation identity/replay/cache are tested with0 model calls rather than pretending to certify PDF business-summary quality.

`supported-upgrade/receipt.json`: actual exit0, **9 PASS /44.63s** pytest, runner47.34s. Old2 scenarios preserve all former new-run3job, independent input hash/job membership/artifact, public actual parser/selector version, historical bytes/jobs/budget and0modelPOST assertions. Completed history now has the PWF-approved completed/document/budget equality oracle. New7 also PASS, including genuinely unsupported unfinished execution and explicit changed intent/model configuration refusal, known paid outbox recovery and schema1/schema2 cross-process reads.

All private temporary lakes/basetemps removed; original file+config hashes, bytes, timestamps and sentinel protected;0supplierPOST. `supported-ruff.receipt.json` exit0 for all3 files. Previously recorded mypy source exit0 applies to the byte-identical frozen batch source, independently checked in `source-stop-final.receipt.json`; no optional repeated typecheck needed. Two now-unused constants imports removed from oldtest, no behavioral changes from that cleanup.

**Corrected baseline attribution:** baseline2 failed because the supposed upgrade fixture never actually ran. It therefore could not by itself prove only an oracle conflict. PWF and ROOT independently reviewed the completed-history requirement; all earlier FAIL receipts remain untouched. After fixing startup caching, true fake-version incompatibility and parser ownership mismatch were measured and preserved before replacing the fixture with actually supported migrations.

Final SOURCE STOP receipt includes3 exact hashes. No source change after original frozen batch repair; follow-up edits onlyold N6 integration test and owned notes/receipts. No commit/push, no production default switch. ROOT can perform final majorB acceptance/publication.
