# CLI stdout boundary fix — handoff

2026-10-14. SOURCE STOP. Owned only `src/company_wiki/automation/narrative_batch_cli.py` and new `tests/unit/test_narrative_cli_stdout.py`. No batch/model/other-source change, no harness JSON stripping, no commit/push/PWF edit, and no paid replay.

## Root cause and implementation

The CLI promised a JSON-only stdout channel but executed `run_batch` directly in that channel. Lazy parser/provider dependencies could print an advisory such as `Consider using…`; the source summary and its public replay could finish successfully, yet a downstream strict `json.loads(stdout)` rejected the receipt.

The finite CLI operation now owns one diagnostic boundary. Python stdout prints are redirected to stderr, as are writes to the actual process stdout descriptor **1**. The descriptor is saved/restored in `finally`; the Python stream is restored by its context manager. This distinction matters because a capture/embedded stream may have a private descriptor different from 1. In-memory callers without diagnostic descriptors retain the Python-stream route.

All handled `run_batch` failures and failure-ledger projection execute inside the boundary. The boundary returns an ordinary receipt and original exit code; only then does the CLI print the canonical receipt once on stdout. Success remains exit0, returned partial/failed/storage receipts remain exit2, typed refusal codes retain exit2, and unclassified errors retain static public codes/exit1. The invalid-request route still emits one static JSON and never enters the operation. Third-party hints are preserved as diagnostics rather than removed by matching PyMuPDF words.

The redirect is process-scoped and belongs to this finite CLI entry point. It is not a cross-thread logging policy for imported library code. This lane did not change `run_batch`, provider behavior, business requests, model configuration, cache generations or costs.

## TDD evidence

- `cli-stdout-red.xml`: actual **13 FAIL / 1 PASS**, exit1, establishing Python parser/provider printing, descriptor writes, error projection and embedding polluted stdout.
- `cli-stdout-green.xml`: preliminary implementation **7 FAIL / 7 PASS**. Native writes exposed the private-stream-FD distinction; these failures remain preserved. The language fixture used an unknown taxonomy code and was corrected to the existing `SOURCE_LANGUAGE_UNDETERMINED` code without changing production taxonomy.
- `cli-stdout-descriptor-green.xml`: unchanged behavioral assertions **14 PASS**, exit0 after the actual process descriptor fix.
- Final concentrated node: the new 14 plus 4 existing CLI static-error/language-error regressions, **18 PASS in 1.91 s**, exit0 (process6.124 s). No full suite rerun.
- Ruff source/new-test `--no-cache`: exit0, 0.277 s.
- mypy source `--cache-dir NUL`: exit0, 2.121 s.

`cli-stdout-final-node.json` and per-command JSON/log/JUnit capture exact commands and source/config SHA, byte size and mtime. The isolated Temp root is removed, a pre-existing sentinel is unchanged, and there are **zero model POSTs and zero downloads**. All batch calls in the new tests are explicit local fakes; no original was parsed or copied.

## Frozen SHA-256

- CLI source: `268c047d8c5d6b72716ecf6e77a74165c38afc268cd72b8b94590b3ea85b3d0d`.
- New test: `97d30051ce18f4e5b69bb00392ce8b4c975db155d4d240885c4961ada109a5d9`.

ROOT can now verify actual same-run/cross-run cache recovery with strict stdout JSON and **zero additional model POST**, keeping its already saved successful paid result. This does not close the independent summary citation/coverage gaps in `cn-h1-quality-review.md`.
