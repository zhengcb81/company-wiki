# Named issuer segment scope — SOURCE STOP

Owned source: `src/company_wiki/source_catalog/narrative_business_policy.py`.
Only new test: `tests/unit/document_understanding_selection/test_reading_named_segment_scope.py` (40 cases).
Version: `reading-business-policy/4`; the existing decision inventory reads this actual constant. No planner, source units, raw/gold, other layer, shared PWF or commit changes by this lane. Zero model/network POSTs.

## Common cause and implementation

The old scope pattern recognized `our segment` but not `Our <named> segment`. Its membership relation omitted `consists` / `comprises` / `includes` and their source tense forms. Already eligible descriptions therefore lacked the source-owned `business_reporting_scope` dimension. Conversely, generic typed `reportable segments` could receive the same relation by keyword co-occurrence without issuer ownership.

The opt-in relation now uses bounded generic owner/name matching (English and simplified/traditional Chinese), finite membership verb forms and Chinese 包括 / 包含. One `_segment_reporting_relation` helper binds the relation's actual segment target to its issuer-owned scope or direct issuer reporting action. Another segment's predicate, external definitions, glossary descriptions or separate sentences cannot supply that proof. Composition payloads beginning with financial totals—including quantity-before-financial-noun forms—do not become reporting scope. No issuer/product names, sample gold, higher cap, second ranker or LLM interpretation are used.

Actual negatives and forward plans are still source composition when they describe the issuer's segment; the original text is never altered. This is admission/topic meaning, not a claim of factual truth or a forecast calculation. The explicit legacy `detect_business_fact` is unchanged.

## TDD evidence (real files here)

| File | Actual result |
| --- | --- |
| `named-segment-red.xml` | 15 FAIL / 20 PASS, 2.96s: missing named scopes/forms and existing external generic over-admission |
| `named-segment-green.xml` | 2 FAIL / 33 PASS, 3.67s: initial implementation wrongly treated Chinese nested business-board payload as a second relation target; retained, not called passing |
| `named-segment-node.xml` | 155 PASS / 1 sandbox Temp setup ERROR, 9.36s: initial focused node; environment failure retained |
| `named-segment-adversarial-red.xml` | 5 FAIL / 35 PASS, 2.80s: a guide/glossary predicate borrowed ownership and financial quantities preceded financial nouns |
| `named-segment-final-node.xml` / `.log` / `.json` | **161 PASS / 5.22s pytest**, command wall 8.027s, exit 0; independent native Temp and sentinel restored/deleted |

Final command: `C:\Miniconda\python.exe -B -X utf8 -m pytest` with the new 40 tests plus `test_reading_mechanism_coverage.py`, `test_reading_semantic_value.py`, `test_reading_value_coverage.py`, `test_reading_priority_coverage.py`; `-q -p no:cacheprovider`, explicit own Temp and real XML. The final JSON contains the exact full command. Earlier stdout was tool-output-only plus real XML; the final `.log` is actual captured output.

Ruff and owned-path diff check PASS. Mypy runs with `--follow-imports=silent --cache-dir NUL`, so no regenerating tens-of-MB engineering cache is retained. Actual real-source US/HK/CN replay, publication and model quality remain ROOT acceptance, not self-signed by this author.
