# Independent table-purpose admission review

Date: 2026-10-14. Scope: the one source/table qualification change, not a whole-project or supplier-quality acceptance.

## Result: two reproducible P2 defects

Eight independent probe groups ran against frozen source. **6 PASS / 2 FAIL**, pytest 0.80 s; actual process exit **1**. `initial-receipt.json` records exact command and source/config SHA-256, size and mtime before/after. These probes use clearly synthetic table rows to test semantic APIs and table scoping. They do not claim to be bytes extracted from an original filing.

### P2-1 — chronology-only project tables are incorrectly declared no business value

`table_purpose.qualify_table` observes `_PROJECT_BUSINESS_FIELD` but still requires an unrelated `_OPERATING_FIELD` hit at the final `if not operating` branch. Thus construction duration and commissioning timetable are discarded unless a capacity/customer/store word happens to coexist.

Reproductions (all return `not_business / NO_OPERATING_TABLE_PURPOSE`):

- Header `Project | Construction timeline | Expected commissioning`; row `Production line A | 24 months | H2 2027`.
- Header `项目名称 | 建设周期 | 预计投产`; row `生产基地A | 24个月 | 2027年下半年`.
- Header `項目名稱 | 建設週期 | 預計投產`; row `生產基地A | 24個月 | 2027年下半年`.

This is useful source-level project timing, including a future qualification. Requiring an additional capacity column loses information the plan explicitly wants. Remedy should treat actual, scoped business-stage/time/product fields as purpose evidence with read row values; keep pure fund-allocation/book-balance tables excluded. Traditional `建設週期` is also absent from the current simplified/variant time aliases. Do not add company names, gold facts or larger selection limits.

### P2-2 — any account column erases genuinely operating columns in the same table

The current `account` boolean is a whole-table unconditional veto. Both `_operating_header` and the final qualification suppress a genuine operating count when a table also shows its associated accounting balance.

Reproductions (both return `not_business / ACCOUNTING_TABLE_PURPOSE`):

- Header `Number of stores | Lease liabilities | As of 2026-06-30`; row `Directly operated stores | 62 | 125 million`.
- Header `門店數量 | 使用權資產 | 2026年6月30日`; row `直營門店 | 62 | 125百萬元`.

Store counts are operating information even inside financial notes. A mixed disclosure should retain the actual operating measure and its complete native table context; neither the amount nor the account label alone establishes an operating fact. Remedy requires distinguishing real operating measure/stage fields from weak bare lexical hits, rather than deleting the accounting exclusion. Pure retained earnings, OCI, expense and option-estimation tables must remain rejected. Preserve the bound unit/date/footnote closure and the no-new-source-text rule.

## Controls that passed

1. Pure retained earnings/OCI/income tax/administrative expense/risk-free-rate and dividend-yield tables are rejected.
2. Store/capacity/RPO/order tables in a `financial_notes` profile retain all actual row IDs and their header + qualified-footnote dependencies; each row stays meaningful and originals are untouched.
3. An external business heading, business words in a bound explanatory note, and the structural `operating_table` name do not promote a generic balance table.
4. Empty/unread body and resource limits yield `incomplete`; missing referenced body stays deferred. Wrong scalar types and negative/bool/float/string limits are rejected.
5. Source and structure use the same `qualify_table` object, and actual DU grouping keeps adjacent table IDs separate; the financial table does not borrow the store table's purpose.
6. Explicit historical selector 0.8 does not invoke the new service and reproduces its result under a raising monkeypatch.

## Architecture assessment

The direction is sound: one pure bounded purpose service and one common value planner, with source IDs and table scope owned by callers. This review found no layer cycle, extra model/download call or second ranker. A discovery `table_scan` signal is not itself a physical body read; the current caller/body controls correctly keep empty tables unknown. Lexical matching still needs the two purpose distinctions above. No claim is made here about supplier semantic quality, original-PDF reopening, cache/outbox recovery or whole-document coverage; ROOT has separate nodes for those.

## Evidence and test environment

- `probes.py`: 8 independent groups, including the failing expected-eligibility assertions.
- `initial-output.log`, `initial-junit.xml`, `initial-receipt.json`: exact failures and frozen inputs.
- Normal execution Temp removed and pre-existing sentinel unchanged; production configs/source unchanged; zero model POST, zero downloads, zero physical-original parses.
- First sandbox attempt failed before tests because its isolated Windows Temp rejected sentinel creation. This is an environment failure, not a repository test result. Its empty, exactly named temporary directory was subsequently checked and removed; an unsandboxed rerun is the recorded actual 6/2 result.

STOP for ROOT implementation. This agent changed only its independent scratch review files.
