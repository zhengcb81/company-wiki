# Table admission /2 — ROOT handoff

2026-10-14. SOURCE STOP. No commit/push, PWF change, provider call, download or production-original modification performed by this lane.

## Implementation

Owned files:

1. `src/company_wiki/document_understanding/structure/table_purpose.py` — one pure shared qualification, feature `operating-table-purpose/2`. Additive immutable `TablePurpose.eligible_row_indices` maps the actual input body rows; all rejected/incomplete outcomes have an empty tuple. Construction chronology/commissioning is an operating field without an unrelated capacity word. Traditional `建設週期` is included. Account columns do not veto a strong real operating measure, but independent accounting rows and pure named-project amounts/book balances remain excluded. Every input entry costs at least one work unit, so empty values cannot evade the character/work bound.
2. `src/company_wiki/document_understanding/structure/tables.py` — bind eligible indexes to actual native body row IDs, preserve native header/caption/period/footnote IDs, and exclude unrelated financial rows from the TableDraft. Correct old first-operating-row inference: a numeric RPO data row does not become a header merely because it is the first operating signal after a neutral header. Explicit typed headers, native row-0 year columns and actual neutral period labels stay headers.
3. `src/company_wiki/source_catalog/narrative_reading.py` — `_candidates` uses `_qualified_table` once over the actual original table before building its context graph; the filtered original package is also the one returned for final reading-context assembly. This prevents financial row cost from being hidden as context and prevents original unfilted members from leaking back into public reading groups. External headings remain dependencies but cannot qualify the table, since purpose is read only from actual scoped members. Incomplete/missing-member tables remain deferred.
4. `tests/unit/document_understanding_selection/test_reading_table_rows.py` — 26 new cases for field coverage, selective rows, actual DU→source filtering, pure-account/project-money controls, empty body and resource results.

Source text, raw unit/span identity, locator, original table order and real qualifiers are unchanged. A mixed native row containing both an actual store count and its associated balance remains the entire original row; no cell splitting or rewritten evidence is introduced. A separate `Lease liabilities | 125 million` row is removed from the table fact/closure rather than promoted or made free context. There is no second ranker, extra classifier, company/gold keyword, new permission chain or larger selection cap.

## TDD and final concentrated node

Evidence is append-only in this scratch directory:

- Initial independent review: 8 groups, **6 PASS / 2 FAIL**, exit 1. `initial-*` and `report.md` remain unchanged.
- New test contract before implementation: **26 FAIL**, `rows-red-junit.xml` records failures against the old source.
- First implementation: **25 PASS / 1 FAIL** — the remaining generic-header/RPO inference defect was found, not hidden. `rows-first-green-junit.xml` keeps that failed result.
- Corrected implementation: **26 PASS**, then 4 strengthened actual DU→source assertions PASS. These were preliminary development checks, not the final acceptance claim.
- One final concentrated node: **286 PASS in 3.94 seconds** (actual subprocess 6.63 seconds), exit **0**. This contains the original 8 independent probes, the new 26 cases and the related structure/source regression pack. `pytest-fixed.json/log/junit.xml` list the exact command and results.
- Ruff `--no-cache`: exit **0**, 0.129 seconds. `ruff-fixed.json/log`.
- mypy `--cache-dir NUL`: exit **0**, all 3 source files, 1.297 seconds. `mypy-fixed.json/log`.

`fix-node.json` and command receipts confirm source + production config SHA/size/mtime stable during final checks, a pre-existing sentinel unchanged, temporary directory removed, zero model POST and zero downloads. The table fixtures are synthetic contract inputs, not original-filing evidence. Original-PDF fidelity, whole-document gold recall, final supplier summary and cache/outbox recovery remain ROOT's separate real-data nodes.

## ROOT next action

The owned source is frozen and can now be used for actual A/H/US replay under the unchanged 96-span/48,000-character limits. Confirm the causal dependency inventory includes `table_purpose` version /2 (ROOT owns that file). If the real observation reveals a remaining general issue, preserve the observed miss and fix the shared interpretation rather than adding an issuer term or increasing limits. ROOT controls final PWF update and normal commit/push after its release node.
