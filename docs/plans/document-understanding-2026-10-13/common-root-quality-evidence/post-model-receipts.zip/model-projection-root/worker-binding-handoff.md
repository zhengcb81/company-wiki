# ROOT follow-on handoff — Worker frozen binding decode

Status: **SOURCE STOP**, 2026-10-14. ROOT's full pre-push suite caught a genuine
efficiency regression: three historical selector factory cases decoded the same
frozen JSON twice. The new model projection helper independently decoded it;
model/mixed workers also decoded it a third time for HTTP configuration checking.
The count assertion was correct and remains `== 1`.

## Implementation and exact scope

Only `src/company_wiki/automation/narrative_worker_factory.py` and
`tests/unit/test_narrative_selector_binding.py` changed. The original semantic
projection source freeze/hash receipt is historical; for this factory and test,
the authoritative final bytes are in `worker-binding-static/receipt.json`:

| File | SHA-256 |
|---|---|
| narrative_worker_factory.py | `4ac3afa87f874fcb272aa190948e9846fb5dfde087f8050304382fcb6d83e531` |
| test_narrative_selector_binding.py | `184f3f0834a26cae2baa4fd717b14f1923e255d5f437b77a3508fa634ae32bd7` |

The production factory now creates one frozen `_WorkerBindingSnapshot` after
one decode. It derives selector, generation values, per-subject reading renderer
and frozen model settings from that decoded binding. The snapshot's maps/model
maps are read-only and it holds no credential values. Selector/projection errors
still reject before constructing a model; actual constructed HTTP semantics are
still checked against the same frozen model settings. The final selection
generation resolver retains its existing live committed-selection read behavior.

Existing private compatibility helper entry points retain their old standalone
behavior for isolated callers/tests; the production factory does not call them
and does not repeatedly decode the binding. No batch/model/generation/CLI/config
code, original documents, selector supported set or public schema was changed.

ROOT's live MiMo pair had exited before the implementation window was opened;
source was not altered while a subsequent live worker could spawn.

## TDD evidence, actual exits and cleanup

| Node | Actual result | Meaning |
|---|---|---|
| `worker-binding-baseline-red` | 3 failed, 2 passed / 2.35s; exit 1 | Unmodified original historical count assertions reproduce the pre-push defect |
| `worker-binding-new-red` | 8 failed / 2.20s; exit 1 | New factory roles prove 2/3 decodes; rejected unknown/null/False also repeat decode; immutable snapshot entry point absent |
| `worker-binding-concentrated` | 68 passed / 59.04s; exit 0 | Original selector matrix, new snapshot/roles/rejections, factory17, frozen renderer7, generation store18, paid/unpaid integration2 |
| `worker-binding-static` | Ruff exit 0; mypy exit 0 | Both owned files Ruff; sole source mypy with cache NUL |

New controls actually construct a local HTTP object with synthetic credentials,
without calling any supplier. A true output-token setting mismatch is rejected
before budget-caller construction. Unknown renderer, present null and wrong type
reject before model construction. Legacy missing renderer and new renderer both
use exactly one decode. Generation/model/projection map mutation is rejected.

The two integration cases execute real parser/select/worker/loopback/outbox/public
read, preserve the old missing-field request's exact bytes during pre-model pause
recovery, preserve paid-outbox usage, and retain same-run/cross-AUTO zero extra
POST reuse. Config SHA/size/mtime and sentinel unchanged; Temp removed; all these
nodes have **zero external supplier POSTs**. Every failed output/JUnit/exit is
retained. The original count test was not loosened or replaced by a mock count.

No commit or push was performed by this child owner. ROOT can now include the
stopped two-file fix in its concentrated final node and normal commit/push flow.
