# Read-only diagnosis: completed response rejected by summary still holds final-output quota

Status: source/tests STOP. Only this scratch report, one probe and its small JSON
receipt were written. No live ledger, original document, production configuration,
source or test was modified. No model objects, HTTP or supplier calls were used.

## Observed fact

The saved real MiMo receipt and ROOT's already-saved invalid-summary loopback
receipt both show a known paid complete response, no accepted artifact, a terminal
summary failure, and no final-output settlement:

| Saved observation | Known tokens | Budget-proxy micro-USD | Output held |
|---|---:|---:|---:|
| `live-20261014T194545-a96abd/overall.json` | 15,729 | 2,973 | 2,097,152 bytes |
| `loopback-20261014T200649-767051/invalid-summary/*.native-usage.json` | 80 | 57 | 2,097,152 bytes |

These money figures are native budget proxy observations, not supplier invoices.
The original live Temp database was already removed; no claim is made to have
opened that deleted database. Its persisted native records were decoded with the
actual `ReservationRecord` type. `output_bytes=null` and `output_settled_at=null`
mean `ReservationRecord.charged_output_bytes` returns the full output bound.

This is **final-output quota**, not an actual 2 MiB file allocation or extra model
charge. The existing physical-storage guard separately counts files/SQLite.
`usage_status=known`, `unsettled_reservations=0`, and native `error_code=null` are
not contradictory: transport completed and its usage was settled correctly;
`SUMMARY_INVALID` belongs to the later AUTO attempt, not that transport receipt.

## Single root cause and responsibility

1. `narrative_model_caller.py` settles known response usage with `no_output=False`
   after successful transport. It cannot yet know whether the summary/verify path
   will produce a valid public artifact. This separation is correct.
2. `AutomationStore.finish_attempt` commits the strict failed HandlerResult and
   transitions the summary job to dead letter, under the current attempt lease.
   It does not settle its final-output reservation.
3. `settle_finished_attempt_reservations` only changes `usage_status='reserved'`
   to unknown for lost workers. Known usage is excluded, and it never settles
   output. That conservative lost-worker behavior must remain unchanged.
4. Batch publication settles the actual final artifact's bytes/hash only on the
   completed-artifact branch. The failed summary never reaches that branch.
5. `_budget` takes the maximum charged output per summary job, then sums job
   slots. A retry does not multiply one job's slot, but the old failed 2 MiB can
   still dominate a later small final artifact, and multiple failed documents
   retain independent slots. This can falsely exhaust a run's final-output cap
   and deny otherwise affordable work.

## One native Store probe, not a test-suite rerun

`probe.py` ran exactly one independent temporary SQLite scenario using the real
AutomationStore/NarrativeRunStore APIs, valid current lease and known native
usage. It never instantiated or called a model. Result: exit 0.

| Step | Output quota | Known usage |
|---|---:|---|
| Known complete response, before finish | 2,097,152 | Preserved |
| `finish_attempt(terminal_failure)` | 2,097,152 | Unchanged |
| Existing coordinator reconciliation | 2,097,152 | Unchanged; no rows reconciled |
| Existing `settle_output(0, None)` in the Temp DB | 0 | Tokens/cost/status/response SHA/error unchanged |
| Repeat same no-output operation | 0 | Idempotent, unchanged |

The Temp probe uses its own fixture pricing (80 tokens / 51 proxy micro-USD);
this is not substituted for the saved loopback's 57 or live 2,973. Source/tests,
config and both saved receipts retained SHA, size and mtime; sentinel stayed
unchanged and Temp was removed. Details: `observation.json`.

## Recommendation: one lifecycle rule in the existing same-DB transaction

This is a real missing finalization connection; do not change the correct usage
accounting or remove the output cap. No second store, model resend or new approval
is needed. The eventual implementation should settle **this attempt's** no-final-
artifact fact when its failed summary HandlerResult is durably committed:

- Reuse `AutomationStore.finish_attempt`'s existing active lease/runtime/latest-
  attempt checks and single SQLite transaction. It already calls a narrative
  transaction helper for frozen select generation; follow that pattern with one
  narrative accounting helper, rather than a second independently committed API.
- Limit the rule to `source.narrative_summarize`, a returned non-success result,
  no accepted artifacts/effects, and that exact attempt's unsettled output slot.
  Diagnostics in HandlerResult are control data, not an accepted final artifact.
- Set only `output_bytes=0`, `output_sha256=null`, and `output_settled_at`. Retain
  every provider token/cost reservation, known/unknown usage status, response SHA,
  transport error and attempt error. Do not refund unknown provider usage.
- Keep successful summaries' slot reserved until verified final publication.
  Do not settle a successful, paused/unreported, crashed, lost or stale attempt
  to zero merely because a public artifact is not visible yet.
- Preserve existing output settlement conflicts/idempotence; do not overwrite an
  already settled positive artifact or blindly close another attempt's slot.
- The same single helper could later be reused by bounded existing reconciliation
  for historical **durably failed-result** receipts, after proving no artifacts/
  effects. This is optional recovery work; do not rewrite lost-worker uncertainty
  or repair historical live receipts during the current running paid sessions.

Meaningful later acceptance should prove atomic rollback and stale-lease refusal,
terminal and retryable explicit failure, successful/pending and lost-response
negative controls, known and unknown money preservation, per-job retry slots,
and idempotent historical repair. These belong to one focused engineering node,
not a new per-document approval chain. No implementation was performed here.

## Code anchors reviewed

- `narrative_run_store.py:215` — output bound versus charged bytes.
- `narrative_run_store.py:415` — per-job output slot aggregation.
- `narrative_run_store.py:612` — reserved-to-unknown lost-attempt reconciliation.
- `narrative_run_store.py:962` — idempotent output settlement.
- `narrative_model_caller.py:255` — successful transport usage settlement.
- `store.py:275` / `store.py:1321` — lease checks and atomic finish transaction.
- `narrative_batch.py:2172` — accepted artifact's actual output settlement.
