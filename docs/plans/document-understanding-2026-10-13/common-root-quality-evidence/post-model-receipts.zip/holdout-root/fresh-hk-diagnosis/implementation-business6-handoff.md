# Business `/6` and test-only source-display adapter — SOURCE STOP

Implementation is complete in exactly four owned files:

1. `src/company_wiki/source_catalog/narrative_business_policy.py`
2. `tools/document_understanding_benchmark/closed_group_support.py`
3. `tests/unit/document_understanding_selection/test_reading_portfolio_disclosure.py` (new)
4. `tests/unit/document_understanding_selection/test_reading_display_adapter.py` (new)

No Git, PWF, gold, catalog/profile, CLI, factory, config, original-document, model or download writes/calls were made. Full source-before/after SHA/size/mtime, commands and test history are in `implementation-business6-handoff.json`.

## Root causes repaired

The business reader now recognizes the ordinary optional comma in the bounded concrete portfolio relation and does not demand a repeated issuer pronoun. Admission does not rename a disclosed foreign actor to the issuer or consolidate it. Raw text, identifiers, locators and independent-listing/non-consolidation qualifiers remain unchanged.

Generic/hypothetical/negated/bare lists still stay out. Three new explicit glossary/definition-prefix counterexamples first produced actual RED, then received a bounded relation-context guard. Different names/scripts and a disclosed foreign actor are tested; there is no issuer/brand/ticker allowlist.

`READING_BUSINESS_POLICY_VERSION` is now `reading-business-policy/6`. The actual `decision_inventory._versions()` dynamically reads it; its test also monkeypatches a next version to prove this is not a stale imported value. No other source file or inventory schema needed modification.

The shared benchmark oracle now observes a real typed PDF table row through complete ordered cells only after the exact source pipe-rendering/body agreement. Invalid row metadata cannot escape through the old literal path. Source/page/table/row/role remain bound. Headers and separate rows cannot supply missing body values. Original empty columns and literal pipes within cells are preserved; no whole-table flattening or global pipe deletion occurs.

The native-range observation handles only an actual newline after the CJK enumeration delimiter `、` within a source-owner-verified native range. It does not erase intentional inline spaces, join English word parts, turn `8.\n2` into `8.2`, change punctuation or create new continuity. This is a test-only representation repair; production raw and gold stay exact.

## TDD and concentrated verification

- Initial 58 cases: 25 FAIL / 33 PASS. One of those failures was an invalid non-NFC fixture, not a production defect.
- First implementation: 59 cases, 58 PASS / 1 invalid fixture failure. `EvidenceSpan` correctly rejected decomposed `row_cells`; the test fixture was corrected to the real typed NFC format, without changing the contract.
- New explicit glossary cases: 3 FAIL / 23 PASS, then guarded by the policy.
- Final concentrated five-file suite: **128 PASS**, exit0, test XML 3.813s. This includes both new files and the original named-portfolio/causal, cross-script and closed-group controls.
- Final Ruff (four files): PASS, exit0, 1.9371s.
- Final Mypy (two source files): PASS, exit0, 7.3159s.

No full-document parse, new DU/candidate/planner run, model call or download was repeated. Synthetic unit selection in the actor-preservation test is an isolated HTML fixture; it is not a production source run.

## Actual saved-source support, original gold unchanged

`business6-real-saved-support.json` uses the original saved production spans/closure and original unmodified gold. It reports:

| Fact | Current oracle on unchanged saved selection |
|---|---|
| Largest shareholder | TRUE |
| Portfolio | FALSE — source sentence was absent from that historical selection |
| Inventory days | TRUE — the already selected real row now matches its native-display quote |

That is **2/3 on the unchanged saved selection**, solely distinguishing the oracle repair from production selection. The historical frozen **1/3** artifact remains preserved. The actual bounded portfolio sentence now passes the new predicate and native layout observation, but this does not declare that a new production carrier was selected. ROOT owns the once-only original3/fresh3 actual source replay.

Original/gold SHA, byte size and mtime remain exactly equal to the baseline. The three unowned parser/reading/native-range source files also remain SHA/size/mtime identical. No diagnostic Temp directories remain. No company originals were copied.

Gold `quantity_basis='ratio'` for the days row remains deliberately unchanged, documented as a separate gold metadata inconsistency. Source support does not certify day-unit interpretation, calculated direction, a model summary or analyst quality.

SOURCE STOP. ROOT may now freeze the four source/test SHAs, run its single actual replay and publish.
