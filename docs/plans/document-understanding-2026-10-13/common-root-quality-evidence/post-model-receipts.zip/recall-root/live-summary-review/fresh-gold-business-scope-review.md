# Fresh gold 的业务范围：只读独审

日期：2026-10-14；独审：ROOT/table_admission_review。仅检查已保存 gold/replay/aggregate；没有原文 PDF 重解析、模型调用、gold 或生产 selector 改动。

## 范围判断

SMIC FY2025 p2 的“**公司2025年度拟不进行利润分配**”不应作为本项目业务阅读的强制召回事实。用户任务集中于行业动态、主营业务进展、新业务、第二/第三曲线与出海；该普通分红提案属于资本分配，后续 `invest-distribution` 负责。它不是无价值资料，仍应保留原件并允许按需检索。

不能将该判断变成“金融 API 一定能获取未来分红提案”。范围理由是责任边界，不是接口能力猜测。若上游摘要主动写入这项内容，仍必须正确保留 2025、**拟不**和提案/尚需审批的状态，不得改成已实施的零分红或永久不分红。

此范围判断发生在已发现 missed fact 之后，应明确披露为用户需求范围复核，不能声称是此前就已冻结的 untouched holdout 规则。

## 原始材料与精确评分

SMIC gold：`tools/document_understanding_benchmark/gold/fresh-cn-smic-fy2025.json`；SHA `0b571d953a92d644c6e7c73537c3ae8fd16b5dc2a2a8a3f7323041768b1514ef`。原件 SHA `c022cf9323967f66a239ce4f60b30507bc341db6e660a53db9c2966a9ef35531`，1,697,396 bytes。原 gold 的 `smic-no-profit-distribution` 保持 `required_business/critical`，本审查没有静默改写。

实际聚合文件：

- `.planning/shared-reading-production/holdout-root/frozen-090/summary.json`
- `.planning/shared-reading-production/holdout-root/generalized-170/summary.json`
- `.planning/shared-reading-production/holdout-root/portfolio6/summary.json`（后续最新回放；本独审只读既存结果，没有再次解析）

| 公司 | frozen-090 原范围 | generalized-170 原范围 | portfolio6 最新原范围 | portfolio6 最新业务范围 |
|---|---:|---:|---:|---:|
| SMIC | 3/5 | 4/5 | 4/5 | 4/4 |
| ANTA | 0/3 | 1/3 | 3/3 | 3/3 |
| Apple | 2/4 | 4/4 | 4/4 | 4/4 |
| 合计 | **5/12** | **9/12** | **11/12** | **11/11** |

12/11 是三公司总分母，不是 SMIC 一份的分母。历史 generalized-170 为原范围 9/12、业务范围 9/11；其 ANTA 两项遗漏在后续 portfolio6 保存回放中已恢复，**最新原范围 11/12、单列业务范围 11/11**。原金标准的唯一未召回项仍是 `smic-no-profit-distribution`，没有静默改分母。这些是保存原文的 quote recall；收据明确 `semantic_quality=NOT_EVALUATED`，不能当作正式摘要、预测或全部文档质量签收。

逐项只读核对 portfolio6 的三个 `{sample_id}.json.gz`，事实 ID 和 supported 状态如下：

- SMIC：`smic-monthly-capacity-8inch`、`smic-capacity-utilization-up`、`smic-rd-ratio-decline`、`smic-profit-driver-causal` 均 true；`smic-no-profit-distribution` false，仍为原 `required_business/critical`，单列说明为 `capital_allocation_plan_and_negation`。
- ANTA：`anta-amer-largest-shareholder`、`anta-brand-portfolio`、`anta-inventory-days-up` 均 true。主体“最大股东”、品牌组合、库存周转天数方向的原要求仍保留。
- Apple：`apple-five-geographic-segments`、`apple-greater-china-decline`、`apple-tariffs-q2-2025`、`apple-outsourced-manufacturing` 均 true，仍是相同四项要求。

portfolio6 三个 gold SHA 分别仍为 SMIC `0b571d95…`、ANTA `afd4a89f…`、Apple `97854100…`，与 generalized-170 对应样本相同；每份回放记录原件和 gold SHA/size/mtime 不变、model_calls/downloads/production_writes 均 0。原三家公司集合另见 `.planning/shared-reading-production/recall-root/three-portfolio6-summary.json`：CN H1 **10/10**、HK annual **7/7**、US 10K **8/8**，合计 **25/25**；也只证明 quote recall，不替代供应商正式摘要质量。

两个历史 aggregate 的 Apple gold SHA 有显式差异：`9271433d02c6a178083f1db7890ee405ba956cfc6155a7ffc2eead76764f2bd1` → `978541002b16f6aff2e5c4ddf203792f9778d4637fa7303e5c8676175f3e6462`。对保存的四个 `target_review` 逐项比对，唯一差异是 `apple-outsourced-manufacturing` 的精确 quote `Company's`（ASCII apostrophe）改为原文 `Company’s`（U+2019），事实 ID、重要性、范围和语义不变。这是来源字形纠正，但仍应公开两份 gold 身份，不能将 5/12→9/12 描述为 gold bytes 完全相同的无条件实验。

这些样本已经 author/replay，收据明确 `development-fresh: already authored/replayed quotes and legacy baseline; not untouched holdout`。保留此限定。

## 可采用的验收记账方式

保留原 gold 文件、所有 facts、各次 SHA、原 5/12 和 9/12 FAIL 记录。另加版本化的 scope note，只把 `smic-no-profit-distribution` 标为资本分配范围，不覆盖旧 target。报告应按 run 区分：历史 generalized-170 原范围 9/12、业务范围 9/11；最新 portfolio6 原范围 11/12、业务范围 11/11；SMIC 两次均分别 4/5 和 4/4。新 selector 回放通过仍保留旧结果，不抬 span/字符 cap，不灌预设答案。

业务范围规则应能一致应用于 A/H/US，并按内容含义判断，不能以公司名、页码、会计附注标题或纯数字外观排除。其他业务遗漏须继续修根因，不能为了全绿再缩小范围。

## 仍然必须保留的财务附注内容

SMIC 此次四项真正业务 facts 为标准化月产能、产能利用率、R&D 强度及同比、晶圆销量/利用率/产品组合驱动利润变化。这些即使出现在会计或经营财务章节，也直接解释业务，应保留原文因果及单位/期间：

- 产能“折合 8 英寸标准逻辑/月”的口径，不能当成原生 12 英寸产能。
- 93.5% 与上升 8 个百分点，不能混成相对增长 8%。
- R&D 金额、营收占比及下降幅度，保留币种和百分点。
- 库存天数、周转、研发强度、订单/RPO、产能等真实业务信号及其原因，不因 financial notes 标签被整节丢弃。

普通历史财务 totals 可由下游金融 API 获取；经营原因、定性解释、项目阶段和有业务意义的财务指标仍是来源智能平台的工作。该边界同时符合用户重点与上游职责。

**SOURCE STOP：独审及已保存结果增补完成；零模型/下载/原文解析，仅更新两份独审 scratch 报告，未修改 gold、源码、测试、配置、PWF、Git 或原件。**
