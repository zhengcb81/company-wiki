# MiMo 正式摘要截断：只读架构复核

日期：2026-10-14；独审：ROOT/table_admission_review。范围：已保存真实请求、失败收据、当前配置端口和摘要输出协议。没有模型 POST、下载、重解析 PDF、源码/测试/配置/PWF 改动。此前有效摘要的事实独审见同目录 `cn-h1-quality-review.md`；本报告不为 RF 预测质量签收。

## 结论

先采用中央配置的 **narrative purpose 显式关闭 thinking**，保留供应商、模型、endpoint、temperature、8192 上限及现有语义投影。这是当前最小且共同的根因修复。暂不增加第二套多批协议或任务库。

这项配置改动解决“总生成额度被推理消耗、误当完整答案额度”的问题；**不自动证明摘要完整、引用充分或事实正确**。若现有大节点的真实质量验收仍失败，再按失败类型决定有界多调用，而非盲重试或恢复 JSON。

## 后续已保存真实结果增补：disabled 防截断，摘要尚未签收

增补依据：`.planning/shared-reading-production/live/owned-runner/receipts/live-20261014T194545-a96abd/overall.json` 及同目录收据，run `phaseC-090-596a9a814390`。这是后一笔独立真实请求，不替换或改写上一笔截断记录。

| 项目 | disabled 后实际结果 |
|---|---|
| 配置 | `mimo-v2.6-flash`、`max_completion_tokens=8192`、`temperature=1.0`，显式 `thinking=disabled` |
| 输入 / completion / reasoning | **13,626 / 2,103 / 0 tokens** |
| 传输 | 完整模型 transport；native usage `error_code=null`，此次没有 `MODEL_OUTPUT_TRUNCATED` |
| 后续结果 | **`SUMMARY_INVALID`**，`dead_letter`，`artifact_ref=null` |
| 费用/调用 | 1 POST，15,729 charged tokens，2,973 µUSD 预算代理；unknown/unsettled reservations 均 0 |
| request SHA | `573368e5a8a862b3c94ab970a8f623fbb5c56919185cb426eb129e29c7908d9a` |
| response SHA | `14c0b39d4189f66646115902ec14d89f703d33b19031ffdf750b490b3ae0ee16` |
| 环境 | 收据记录 protected/sentinel/all_prepared 不变，temporary lake 已删除 |

这一次实际结果支持最小配置修复：reasoning 为 0，8192 上限内返回 2103 completion，**已解除本次的 token 截断**。不能扩大为“所有供应商均已成功”，也不能宣称 DTO、引用、业务覆盖或最终摘要质量已通过。

目前保存的收据只报告 `SUMMARY_INVALID`，没有保留模型 final 内容和具体合同规则失败详情。因此本独审不能断言是缺字段、文本超长、group 引用错误、事实错误或其他具体条件。下一步先完成统一 post-model 诊断和失败前 response/job detail 留证，利用这些证据定位共用根因；**不靠重复付费试错，不绕过合同，不立刻启用多批协议**。ROOT/default agent 正负责这一诊断补齐，本独审没有动其 source 窗口。

## 已保存的实际证据

以下为 **disabled 配置之前的历史失败**。失败目录：`.planning/shared-reading-production/live/owned-runner/receipts/live-20261014T191829-008d86/`，主要证据为 `overall.json`、`materials/phaseC-090-560f6d1b4c24.input.json.gz`、对应命令及 native-usage 收据。

| 项目 | 实际结果 |
|---|---|
| 实际请求 | `mimo-v2.6-flash`；`max_completion_tokens=8192`；`temperature=1.0`；JSON object 输出 |
| thinking | **实际失败请求没有 thinking 字段**；当时配置没有 narrative 覆盖，并非适配器丢掉已配置的 disabled |
| 输入 / completion / reasoning | 13,624 / 8,192 / 6,547 tokens |
| 推理占 completion | 79.92%；按供应商口径余下约 1,645 final tokens |
| 终态 | `MODEL_OUTPUT_TRUNCATED`，`dead_letter`，`artifact_ref=null` |
| 模型调用 | 1 次；已知费用，unknown/unsettled reservation 均 0；未盲重发 |
| 记账 | 21,816 tokens＝input＋completion；reasoning 不再重复相加；5,002 µUSD 为预算代理，非现金账单 |
| final | 6,186 bytes，末尾截在 `c16`；`clipped=false`，保存的是实际完整 final 字段，不是诊断截取器截短 |
| final SHA | `09049124bd408337c4cbf059408e1b52278afafb473d5fc63fb713273d7625f7` |
| provider response | 29,552 bytes；SHA `6eaae2f8032c1daf1b17a84b27358cf0a9f2f33bf3a5c652acaa0fa9d3780374` |
| 原件 / 测试清理 | 收据记录 protected/sentinel 不变，temporary lake 已删除 |

新输入 13,624 对旧有效 9-claim 请求 64,804 tokens，下降 **78.98%**。reading strategy 从 103,645 字符缩到 18,169 字符，实际原文约 7,769 字符，96 spans、64 groups。这个输入优化已经发生；新的正式输出失败不能被描述为“输入缩小没有效果”，也不能把输入缩小当成最终质量已经通过。

当前 `reading-model-input/1` 的目标为 20 claims、每项约 240 字符；schema 为最多 20 项/每项 280 字符。输出规划采用配置的 8192，但该计算没有为供应商默认 thinking 预留额度。JSON mode 约束格式，不保证在生成上限内输出完整 JSON。实际 final/response 均远小于传输字节上限，本次不是 transport 截断。

## 为什么中央 purpose 配置是合理的第一步

`scripts/config.py::LLMConfig.generation_options(purpose)` 是既有统一端口；物理 YAML 名称为 **`llm.generation_policy`**，按 general＋purpose 合并。`narrative_http_model.py::model_options_from_config(..., purpose="narrative")` 和请求构造已经传递显式 thinking 并纳入请求哈希。

当前 ROOT 已将三个 provider 的 narrative 配置记录为 `thinking: disabled`；本独审没有改写该文件。general/research 不需要随之改变，模型名、endpoint、token 上限和 temperature 继续由配置负责。

- MiMo 官方文档说明 thinking 默认开启，`max_completion_tokens` 包含思考与最终答案；明确支持 disabled。[MiMo deep thinking](https://mimo.mi.com/docs/en-US/quick-start/usage-guide/other/deep-thinking)
- DeepSeek 官方文档明确支持 `thinking.type=disabled`，示例采用 deepseek-flash；无需在此工程里增加供应商特例重试。[DeepSeek thinking mode](https://api-docs.deepseek.com/guides/thinking_mode/)
- 当前配置的 MiniMax-M3 支持 disabled；M3.1 Flash Preview 则始终 thinking、disabled 会错误。此次只对实际当前配置判断，未来换模型应在配置/适配器兼容验证时处理。[MiniMax OpenAI-compatible API](https://platform.minimax.io/docs/api-reference/text-openai-api)

不是“强行少思考就必然更准确”。这里是来源型摘要的工作负载明确选择：保留详细来源、角色和限定，给最终证据摘要足够生成空间。真实质量仍需独审。

旧成功 artifact 应保持冻结、原样回读，不因中央配置更新而付费重生成；新生成必须记录实际 generation options 和 request hash。新的 0.8/0.9 比较应采用相同当前配置，不能将旧 thinking-on 收据当作当前配置的公平 A/B。

## 仍然存在的独立质量风险

截断 prefix 中可独立解出 15 个完整对象，仅供诊断；**未补 JSON、未创建 bundle、未将这些对象发布为正式结果**。

与旧 9 项相比，新 prefix 已将现有覆盖 30% 和未来 60%/70% 分开，且加入 MicroLED/PD5 名称。但仍观察到：

- `c2` 的 `actual` 同时包含“双方将在研发、供应链、客户资源维度深度协同”的未来安排；主体/阶段/模态仍需一致。
- `c13` 对 MicroLED 省去原文“2023 年底”样机送交时间，若把这项完整时间链作为质量目标，仍有缺口。
- prefix 在 c16 截止，不能从当前 prefix 计算整份 summary 的完整 gold recall，更不能把原文选择 10/10 当摘要 10/10。

所以关闭 thinking 后至少还要检查完整 JSON、每个产品的现状/下一步、日期、单位、限定、否定、逐 claim 直接支持范围。不能给每条 claim 灌所有 96 个引用以冒充覆盖。

## 在现有大节点完成验收，不增加小节点许可

工程验收沿用现有测试节点，集中覆盖：

1. 三个配置 provider 的 narrative request 显式发送 disabled；general/research 仍沿配置；模型/8192/endpoint/temperature 没有绕过配置。
2. generation options 进入新请求身份；历史冻结 bundle 回读不触发 POST。fake length/error 仍如实记账、没有 accepted artifact/JSON 修复/自动盲 retry。
3. 用不同虚构主体/产品的有限样本检验 actual/planned/forecast、角色、否定和币种单位；一个产品验证中并获重复订单可以同属 actual，下一代研发/预计送交必须保持各自阶段。正确引用自身 identity 和 support，不能按 group 数机械要求 64 条事实。

供应商质量验收沿用既有真实大节点：实际 MiMo/DeepSeek/MiniMax 请求配置与 finish reason 留证，完整结果由独立审查逐 claim 检查，公开 summary 覆盖与原文 quote recall 两种分数；计费、缓存恢复零 POST、原件不变和 Temp 清理一起记录。供应商不提供 reasoning token 明细时记 unknown，不伪造为 0。

## 若显式 disabled 仍不能完成

先分清：字段未发送/供应商不支持 → 配置或 adapter 修正；有效 JSON 但漏事实/错引用 → 覆盖/语义修正；完整高价值内容确实超过 final 容量 → 才采用有界多调用。不得针对同一失败请求反复付费赌运气。

有界多调用应复用现 AUTO store/lease/outbox/预算：**一次共享选择和解析**，按真实 section/closed group 划分有限 chunk，保留标题、单位、期间、footnote 与必要 identity；全局 source/span/locator 稳定，局部别名映射明确。完成的 chunk 可恢复复用，未知费用保留预算不重发。最终以实际 support＋主体/期间/模态做确定性拼装和去重，不新增第二次 LLM 汇总来创造事实。

每 chunk 20 项不能偷偷变成公开 80 项；公共容量不足要公开覆盖缺口并按实际重要性选择。分批会增加重复上下文、调用、时延和恢复复杂度，故本轮应先验证最小中央 purpose 修复，尚无证据要求立即启用新协议。

**SOURCE STOP：只读审查及已保存证据增补完成；仅更新两份独审 scratch 报告，无供应商调用，无源码/测试/配置/PWF/Git/原件改动。**
