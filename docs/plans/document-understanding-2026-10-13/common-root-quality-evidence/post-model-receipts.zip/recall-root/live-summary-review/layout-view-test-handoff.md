# Fourth pre-push failure: transient native view test expectation

2026-10-14. SOURCE STOP. Only the body of `test_rich_layout_preserves_all_old_metadata_and_durable_evidence_identity` in `tests/unit/test_shared_reading_pdf_layout.py` was changed. No implementation, model, PWF, original or other test was edited; no supplier was called.

## Attribution

The old test removed only `reading_layout` before comparing rich metadata with the legacy parser. The designed 0.9 native-range feature also adds `native_source_view`, an immutable page view shared by original text units of that page. It is deliberately transient. `NarrativeUnit.to_evidence_span` already removes both transient fields. Source inspection and the corrected strong test confirmed **no durable evidence identity change or private page-view leak** in these paths. This is a stale test expectation, not a justification for deleting its metadata assertion or ignoring arbitrary new fields.

## Strength retained and added

- Exact old metadata values are still compared. Key sets must be exactly old keys plus the named transient fields; table rows are not allowed an unplanned `native_source_view`.
- Original unit IDs and complete old/new EvidenceSpan values remain equal.
- Text units on the same page must share the same `MappingProxyType` object; top-level and block records are immutable. Feature and real view SHA are checked.
- Layout drift and substituting a private transient-view canary cannot change durable Span identity or fields.
- An **unknown metadata field** remains durable and changes the span ID, demonstrating that the test has not silently removed all metadata from its contract.
- Actual typed selection, actual model-request construction and public NarrativeBundle serialization exclude the private view, source strings, reading layout and transient page-view hash. These are synthetic in-memory PDF/DTO checks, not supplier quality or a real-corpus acceptance.

## Evidence

The original failing pre-push log remains ROOT evidence. The targeted corrected test first passed; the final run of this one related test file is **36 PASS in 1.77 s**, process exit0. Ruff `--no-cache` exit0. `layout-view-final-pytest.json/log`, `layout-view-final-junit.xml` and `layout-view-final-ruff.json/log` record exact commands and frozen source/test SHA, size and mtime.

Final test SHA: `79a86379cbabd5a82fc0d1edfcce38d028e6f31d5b56b883a6c99bbe2482a3e7`.

No source edits, no actual-original parse/copy, no provider/model/network calls and no full-suite rerun. ROOT handles the three independent JSON decode failures and normal publication.
