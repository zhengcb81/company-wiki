# DU4 TABLE / STATE 最终补充：取得类辅助动词

2026-10-15；独立审查 `attribution_release_review`。

## 结论

**PASS_COMPONENT：上一版唯一非阻断 P3 辅助动词对象问题已关闭，约定审查范围内无剩余阻断项。** 本报告与 `final-handoff.md/json` 共同阅读；原报告、最初 REQUEST_CHANGES、两轮 FAIL 和全部原始输出保持原样，不能将旧报告中的 P3 或当时的 251 项 in-progress 当作当前状态。

独立读取实际最终 `patterns.py:115–119`：取得/获得/获取/拿到/获归入同一取得类辅助动词，可无已披露对象。该调整位于共同 qualification 语法，没有添加特定公司或整句分支。

## 定点实际复验

强制从 ROOT/src 导入，只复验既有两句，未扩新样本：

| 既有样本 | 实际结果 |
| --- | --- |
| 我们已与未获认证的供应商签署供货合同。 | qualification：actor=供应商、object_refs=[]、negative/current/actual、other；主句签署：actor=我们、object=供货合同、positive/current/actual、issuer。 |
| 母公司青梧尚未取得客户对其膜产品的认证。 | qualification：actor=母公司青梧、object=膜产品、negative/not_yet/actual、quoted_related_party。 |

逐字段断言通过；原膜产品正控未因允许空对象而丢失已有对象。实际完整返回、导入路径及八份源码/三份测试 SHA 见 `aux-final-probe-results.json`，不将控制台字体/编码显示当作来源字节变化。

## 执行边界

- 之前 27 组结果属于原 `final-candidate` 快照；没有声称这 27 组已对最后两行语法再次执行。
- ROOT 报告最终三包与 Git 边界 **251 PASS / 6.42 秒**，Ruff/mypy 八份源码 PASS；这些是 ROOT 证据，本审查未重复全套。
- 本次仅写独立审查目录；0 供应商/API、0 原件读取、0 真实 parse/AUTO；未改源、测试、PWF、配置、Git 或作者工作树。
- 组件通过不能替代 normalize→router→selector 生产接线、真实摘要语义与文档召回验收；未证明任意复杂自然语言都可正确解析。

最终指纹和证据清单见 `aux-final-handoff.json`。不新增小节点审批。
