# DU4-TABLE / DU4-STATE 独立只读接收审查

2026-10-15；审查者`attribution_release_review`。

## 接收结论

**两包均REQUEST_CHANGES_COMPONENT。** 发现TABLE四项P2共因、STATE一项P1和两项P2。均用有限纯内存输入复现，详见`probe.py table|state`及对应JSON；未声称这些问题已经在生产发生。ROOT可在同一整合大节点集中TDD修复，不增加逐项人工审批，也不要求作者进入共享目录施工。

作者提交已正常主机只读确认：TABLE `fa1681c0514df4b1896857ff56baa60be5729fc7`；STATE `284eea600764e0dfe98270c364c9c6cd2c095478`。探针分别独立Python进程显式导入对应作者src，JSON保存真实`__file__`，避免两个company_wiki模块互相污染。只写ROOT独立审查目录；没有改作者、ROOT源/测试/PWF/Git、配置或其他DU4包，没有网络/供应商、真实AUTO或原件重parse。

先读两份作者handoff/固定INTERFACES，再读交付模块与关键测试。作者纯组件树未用ROOT索引的缺失搜索结果推断端口不存在，也未初始化作者CodeGraph。ROOT复跑TABLE36PASS/0.89秒、STATE90PASS/3.25秒属于ROOT执行证据；独立审查没有重复整个测试包。

## TABLE

### T1 / P2：解释所需的header/label依赖没有同一scope检查

`bindings.py::build_columns`（约294起）和`_bind_one`（353起）只对value unit做parent/page检查，随后直接使用column path及row header refs。

独立输入：value `42`属于parent `p`，header `As of December 31, 2024 (RMB millions)`属于`other-parent`；实际返回**complete、measurement bound、period.end=2024-12-31、unit_refs来自other-parent**，没有跨parent诊断。偏移全合法，问题是解释依赖的来源归属没有一起验证。

修复责任是共同ref依赖解析：value、column header、row label、单位/限定词必须在同scope下可用；跨parent/page或冲突/不可用header不可继续把measurement标bound。按来源观察逐项降级/诊断，不借另一表的标签，也不重新签身份合同。测试应将现有“value跨parent/page”的负控扩到header/label，并保留同parent正常绑定。

### T2 / P2：同label中的期间角色被独立首匹配拼错

`_periods.py::parse_label/combine`分别取首个year与month/day；start有单独from规则，但end仍使用同一个首month/day。

独立输入header：`Six months from January 1, 2024 to June 30, 2024`。实际返回duration=6、**start=end=2024-01-01**，仍为bound/complete；真实披露的结束日是June30。不是缺覆盖而返回unknown，而是输出了错误的明确日期。

共同修复是按局部日期提及及from/to/ended/as-of关系绑定字段，不能从互不关联的首匹配合成日期。支持的简单范围可精确绑定；多个日期无法确定角色时保留raw refs并ambiguous/unspecified，不猜。测试包括完整range、跨年range、单ended/as-of正控、同label冲突和拆分header，不做未披露start或12个月推导。

### T3 / P2：单位层级优先覆盖会删除兼容的币种/数量级维度

`bindings.py:428`使用`cell_units or row_units or path_units`。独立输入row label `Revenue (RMB)`、column header `2024 (millions)`、value `42`，measurement被标bound，但unit_refs只剩row `(RMB)`，丢掉明确披露且兼容的`(millions)`。原column raw refs仍保留，因此并非原始文本丢失；问题是显式unit绑定不完整，消费者若按该对象使用会失去数量级。

作者handoff把该行为列为known limit，但层级更近不意味着所有单位维度互斥。建议在有限单位识别层区分货币、数量级、百分比、数量/每单等维度：同维度有真正覆盖关系才选紧范围，兼容维度应共同保留；不确定/冲突则保留refs并诊断，不换算数值。不能简单把所有unit_refs无脑合并，须保留“百分比行覆盖货币金额列”等负控。该问题直接影响用户要求的数字/单位正确性，建议在接生产projection前关闭。

### T4 / P2：预算前/预算外索引实际遍历不受WorkBudget约束

独立精确计数：

| 输入 | 实际工作 | 报告预算 |
|---|---:|---:|
| 零units/cells，header_rows含10000项，budget0 | 完整遍历10000项 | used=0，甚至status=unavailable而非预算partial |
| 1unit/1 unavailable cell，budget2已在验证耗尽，provenance10000条 | 完整遍历10000条 | used=2/partial |
| 1unit/1 merged_unknown cell，column_span5000，budget4已耗尽 | covered.update及下一列range总yield5001次 | used=4/partial |

代码位置为validate header_rows/provenance（145、202附近）、build_columns `covered.update(range(...))`（290）。只用了5000宽度，没有进行巨大range内存压力试验。

此外每列全扫cells构造header_cells、index_slots中的provenance/refs循环没有逐项计费，静态上是列数×cell数；本报告未把这部分伪装成独立性能测量。200units/64k原文cap不限制header_rows/provenance或声明的列跨度；哪怕调用cap较小，也不能让budget0后的扫描声明变真。

建议以同一个caller预算计费所有必要遍历/索引，避免未计费raw副本和宽度range扩张；用稀疏slot/header索引按真实观察列组织路径，保留合并格unknown，不为了性能把所有列都跳过。超限返回partial并保留已确定结果。现有测试多断言work_used等于计数器且不超上限，缺少“实际input遍历/转换在预算前是否发生”的计数反例。

## STATE

### S1 / P1：常见否定/计划披露被标为已发生的正面经营事实

全部独立合成输入，非真实公司陈述：

| 原文 | 实际输出 |
|---|---|
| 公司未签署供货合同。 | positive/current/actual，qualifier空；actor甚至含“未” |
| 公司计划签署供货合同。 | positive/current/actual，qualifier空 |
| 公司尚未建立联系。 | positive/contact_established/actual，qualifier空 |
| 公司计划商业化新产品。 | qualifier确有“计划”，仍positive/current/actual |
| The company has not signed a supply contract. | positive/current/actual，qualifier空 |

五例均status=complete。严重度P1针对组件核心正确性，**不是声称已发生生产投资事故**。

共同根因在patterns与`_clause_events/_resolve_fields`之间：部分predicate可从限定语后面开始裸匹配，未消费的否定/计划被留在actor region；另一些已捕获计划，却被construction默认actual/current覆盖。不能按每句话添特例或全句见“不”即负面。

建议在统一event绑定层为predicate建立有限局部qualifier作用域，保留真实限定语span，解析否定/计划/条件后再落阶段枚举；不确定作用域必须unknown/uncertain，不能默认完成。最低TDD按同predicate的positive/negative/planned/conditional对照，覆盖签署、联系、商业化、中英文、两个独立命题，以及负面词属于另一对象的负控。保持希望合作、接触、合同、出货等不同阶段，不把缺强词的predicate自动升级。

### S2 / P2：清理subject字串后未同步base，原文actor偏移错误

`relations.py::_bind_event`在约325–337先strip、再strip_connector，却仍把原`lower`交给`_np_candidates`。

独立baseline `本公司尚未量产X产品。`能正确切出actor `本公司`、issuer；加前导空白后`  本公司尚未量产X产品。`实际actor_ref只切出`本`、attribution unknown；`随后本公司已量产X产品。`实际actor切出`随后本`。predicate/object/qualifier仍来自该句，因此不能用“所有offset都落在字符串内”测试宣称角色绑定正确。

共同修复应沿匹配view坐标传递每次trim/connector移除的准确位移，或直接在原view上维护[start,end]窗口，不依赖改写后的region再猜base。扩充空白、connector、native换行及繁体原文对照，断言精确原文actor切片，不仅检查索引合法。原字串、ID、locator和角色不得改变。

探针最初还试过“量产设备”，该组合当前被noun-compound guard整体排除，baseline也无relation；因此**没有**把这些空输出冒充offset反例。改用同一识别语法能处理的X产品做正负对照后才确认偏移问题。该额外召回边界不作为另一阻断发现泛化。

### S3 / P2：零预算仍做完整验证、context复制和逐字转换

实际计数：budget0时，units.items已检查1001项；context list已复制10000项；一个5000字符target已调用script conversion5000次，再在第一次charge抛超限，work_used仍0/partial。

位置为`_validate`全units、list(context)、dict(units)（144–179），以及`detect_operating_relations`先`build_matching_view`再charge（550附近）。5000字符单unit在64k以内，不能用阅读cap掩盖这一真实可达路径。`_clause_events`还按全部pattern扫描/排序候选，regex长度/窗口工作没有跟同一预算绑定；这里仅作已读结构风险，不伪称独立bench结果。

建议先在同一预算下接触实际需要的target/context并构造有界匹配view，按字符/窗口/实际候选工作计费；不要先全量转换再一次charge，也不要创建第二个预算。保留已确定relations的partial语义；不为省工作把全部negative业务句删掉。单元测试需统计真实转换/遍历，而不是仅断言计数器0和budget.exhausted。

## 正确部分与真实材料边界

- 两包均纯内存、source-oriented，不新建router/任务库/投资结论或权限链，不读取配置/API。
- TABLE保留原value refs、native column、merged_unknown/empty/unavailable及有限geometry来源；明确拒绝按文本位置拆合并大格，这些方向正确。但header依赖也必须同样可信。
- STATE MatchingView的每字符原始索引、未知主体/双重否定退化与上下文parent限制方向正确；识别层是有限规则，不能声称通用语义蕴含或已达到跨市场召回。
- TABLE真实HK fixture是保存的局部packet，real_packet另有显式derived adapter字段；合成多表holdout不是第二真实公司。STATE真实CN IR fixture也只是保留观察，未重开PDF；本次新反例全为合成。不得把这些纯组件绿结果称为真实文档全链路通过。
- 所有原文refs在范围内只是必要条件，不证明单位、日期角色、否定/阶段或actor语义正确；这正是此次反例共同暴露的测试盲点。

## ROOT后续整合责任

同一大节点先集中关闭上述共因、保留最初RED与当前作者纯包绿证据；独立报告不要求每个小修复重新人工签收。测试helper namespace及retained fixture Git字节由ROOT按FORM已验证的统一机制处理，不能修改gold掩盖传输变更。

组件通过后，仍需唯一normalize/structure/adapter/shared-reading/router/selector接线；表格interpretation refs进入同一依赖闭包、业务关系状态不得洗问答角色，配置、预算、旧显式0.8/Ref字节恢复及缓存指纹升级保持所属owner负责。最后做真实HK/CN IR及另一家公司/格式holdout，并独立审摘要的对象、阶段、期间/单位。**没有上述生产接线/真实质量验收证据，本报告不能宣称DU4整体完成。** FORM已发布及CI状态与这两包接收独立，不用本次发现倒写FORM发布收据。
