# DU4-TABLE / DU4-STATE：ROOT共因修复最终独立复核

2026-10-15；`attribution_release_review`。

## 接收结论

**PASS_COMPONENT：本轮约定范围内未发现剩余阻断问题，原来源归属/日期/单位/预算和主要状态/角色反例已关闭。** 保留一项非阻断的有限语法残留，见下文；不宣称任意自然语言都能被本规则模块正确理解。

结论针对ROOT工作树整合后的冻结源码，未改作者树。原作者`handoff.md/json`中的REQUEST_CHANGES、STATE首轮及候选第二轮报告/原始JSON全部保留，没有用最终PASS覆盖最初FAIL。

本轮只读核对实际diff和当前源码，**只重跑既有第二轮两次纯探针**（`final-candidate-probe.py table|state`），不扩张新句子或重跑整包。27组逐字段结果断言通过，见`independent-final-checks.json`；实际完整输出为`table-final-candidate-results.json`和`state-final-candidate-results.json`，每份均记录强制ROOT/src的真实import路径。没有API/供应商、原件/真实parse、配置/密钥读取，也没有源/测试/PWF/Git/作者写入。

ROOT报告两包完整集中**164PASS/3.38秒**，Ruff/mypy八源通过；最终三包+Git边界251项当时正在集中运行。它们属于ROOT执行证据，本审查没有冒充独立重跑或提前宣布251已绿。

## 已关闭的共同责任

### TABLE

- **解释来源scope**：foreign parent/page header不能提供当前value的日期/单位；原foreign-header实测measurement ambiguous、period null、unit_refs空，保留跨parent诊断。
- **原生载体质量**：header presence、slot/provenance冲突参与路径可用性。原unavailable-header反例现在为partial/ambiguous、period null，不再以已确定日期输出；原value保留，不拒绝整表。
- **期间角色**：同年与跨年显式from/to都正确分离start/end；同label多year/day/duration冲突不取第一个，保留raw ref并降级。日历校验已读；没有推导未披露start或财政年=12个月。
- **单位维度**：币种、数量级、ratio/count按维度在已观察范围中合并/覆盖；row RMB不再删除header millions，原文子ref保持；不进行数值换算。原percent等范围规则保留。
- **实际预算与复杂度**：header_rows/provenance在索引前charge；稀疏列与gap区间不铺满空列；label及column path set缓存避免重复扫描。原计数10000/10000/5001现在分别为0/0/3，最后3次是有限range索引框架操作，不是5000宽度展开。

独立range wrapper已补真实range原本支持的len/getitem，分别计实际索引/迭代，不把原仅iter wrapper的TypeError当产品缺陷。

foreign row label已剔除并使全局partial；按既有“bound表示native column+header path”定义，合法column仍bound不单独构成阻断。没有新增“缺任意row label须整表拒绝”的门。

### STATE

- **限定语与阶段**：原未签署、计划签署、尚未联系、计划商业化、中英文否定均保留真实qualifier；正式副词/客户论元不清掉否定，双重否定保守unknown/uncertain；conditional结果不再被qualification family覆盖。
- **假设与控制动词**：原`would sign`变conditional/conditional；计划停止生产X的actor为公司、object为X产品、modality为planned，不再将公司计划当产品或将计划停产当已停。
- **关系从句归属**：原供应商未认证不再归到issuer，主句签约仍绑定我们/issuer并保留已，不借从属否定。embedded party不更新主句actor，主/从作用域分离。
- **精确原文坐标**：前导空格、最长connector、繁体/换行匹配view回到原Unicode坐标；既有X产品反例actor均精确为本公司，未改源字串/ID/locator或洗来源角色。
- **实际预算**：target/context按需验证，未复制全units/context；匹配view/正则/候选工作先计费。原budget0下1001个units、5000字符转换、10000 context扫描均变0。有限deque和ordered sweep避免反复全扫前events，最终冗余sort移除；未新建预算/队列或提高cap。

## 非阻断有限语法残留（如ROOT后续未另行收尾则保留）

既有`我们已与未获认证的供应商签署供货合同。`的主要归属已正确，但qualification relation的object_ref仍为单字`获`。这是原有限qualification语法将取得类aux切成对象，应该在无法确定真实对象时留空。未发现因此仍把供应商资格错归issuer或把签署否定；本报告将它作为P3非阻断的有限语法残留，**不谎称所有actor/object均已获得一般语义证明**。这不是新扩样，不要求再增加人工门；已通知ROOT可沿共同qualification valency收尾。

## 证据边界与后续生产责任

本报告证明冻结组件能正确处理这些已出现的共因反例和有限控制；不证明真实文档召回率、任意否定/复杂宾语均正确，也没有真实供应商或原件重放。作者真实HK/CN IR夹具是保存的局部观察，合成holdout不是第二家真实公司；预算计数不等于每个CPU指令或token消耗。

生产仍由ROOT将唯一normalize/structure/adapter/shared engine/router/selector接通；表格解释依赖、QA support/context、来源角色与cache版本保持所属层责任。旧显式0.8/Ref字节恢复、真实HK/CN IR和另一公司/格式holdout、正式摘要对象/阶段/期间/单位的独立语义验收尚不能由这些组件PASS替代。FORM已发布及远端CI另有自己的收据，本报告不倒写该状态。

最终源码/测试指纹和各轮报告/JSON的SHA见`final-handoff.json`；无新增小节点审批要求。
