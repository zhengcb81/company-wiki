# DU4 ROOT最终候选：第二轮有限独立复核

2026-10-15。**当前仍REQUEST_CHANGES：大部分原反例关闭，保留两组正确性根因待收尾。** ROOT正执行的244项不是本审查执行结果；本轮只读源码/新增集中测试，执行`final-candidate-probe.py table|state`两次有限纯内存探针，强制ROOT/src，无原件/API、全suite或源码写入。

## 原问题关闭与探针协议

TABLE原foreign header已降为ambiguous，不再借用另一parent期间/单位；原显式range、跨年range返回正确起止；同label多year退化ambiguous；row币种+header scale均保留。预算前header/provenance访问归零，merged宽度5000在已用尽budget4后仅3次range索引框架操作，不展开5000项。

原CountRange只实现iter，而真实range也支持len/getitem。第二轮探针补齐这两项并记录两种访问；没有将wrapper TypeError当产品缺陷，也未更改真实输入预算。TABLE稀疏索引不再铺满未观察列，标签/范围缓存和逐项计费方向正确。

STATE原五条和第一轮四条scope反例已纠正；前缀/繁体原切片、母公司归属、预算0的units/context/字符转换保持正确。计划暂停/停止的阶段也已改为planned。

## 剩余一：不可用header仍被用于明确期间

同parent、合法TextRef、header文本`As of December 31, 2024`，将该header cell的`presence`设为`unavailable`：实际输出**complete、measurement bound、period.end=2024-12-31**，仅有slot_unavailable诊断。

共同根因是header路径只检查ref范围/parent/page，未传播载体slot不可用/原生位置冲突。解释该值的native column provenance没有得到同样质量处理。至少不能将明确不可用header当成已确定期间；应保留局部诊断并对依赖的column/measurement降级，原value不丢、不拒绝整表。原表头的empty/merged_unknown/conflicted/provenance-conflict等同构状态应按同一规则判断，不加逐fixture特判。

**foreign row label校准**：本轮该ref已剔除且全局partial；若binding_status沿作者定义仅表示native column+header path已绑定，该measurement仍bound并不单独构成阻断。本报告不追加“每个缺失row label必须整表拒绝”的新门。它和上面不可用header仍输出明确日期的错误不同。

## 剩余二：模态与actor/object角色仍有共同作用域缺口

| 独立纯原文 | 实测问题 |
|---|---|
| The company would sign a supply contract. | qualifier有would，仍positive/current/actual，假设性签约变已发生 |
| 我们已与未获认证的供应商签署供货合同。 | 把供应商未获认证输出为issuer的负面认证（actor“我们已”、object“获”）；签署actor则变“的供应商” |
| 公司计划停止生产X产品。 | planned阶段正确，但object_ref是“公司计划”，不是产品；actor为空 |

这些都是同一event论元/算子作用域的正例变体，不要求通用NLP。有限规则无法解析时可返回unknown/uncertain或不输出该额外关系，但不能把已有modal强制actual，也不能把关系从句的第三方资格移给issuer，或把公司+计划当产品。

建议在同一事件组装层：未确定modal在resolve时保守处理；relative clause/宾语前置的角色未闭合时不沿前一subject继承确切issuer；production_stop的前置object也应经过现有actor/product角色判别，不能每个前缀都当object。保留真实refs，不按三句原文补黑名单。正控包括“已签署”、真正issuer未认证、无relative歧义主体、明确产品停产，集中TDD即可。

## 证据与后续

本轮完整输出已冻结为`table-review-round2-results.json`和`state-review-round2-results.json`，原作者`*-probe-results.json`及STATE首轮记录保持。TABLE/STATE生产接线、真实文档holdout、QA角色、0.8历史恢复和模型语义仍未由纯组件证明；ROOT后续按既有大节点负责，不新增人工小审查。
