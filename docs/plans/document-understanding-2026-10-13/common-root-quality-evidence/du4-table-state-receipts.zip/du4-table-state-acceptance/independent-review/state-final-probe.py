"""Finite independent DU4 component probes; explicit author imports only."""
from pathlib import Path
import builtins
import json
import sys

LANE=sys.argv[1]
AUTHOR=Path('C:/Users/郑曾波/Projects/company-wiki')
sys.path.insert(0,str(AUTHOR/'src'))
from company_wiki.document_understanding.layout_hints.contract import WorkBudget

BASE=Path(__file__).parent
def unit(text,parent='p',page=1):
    return dict(text=text,parent_id=parent,role='company_filing',kind='table_cell',locator={'page_number':page})
def ref(uid,text):
    return dict(unit_id=uid,char_start=0,char_end=len(text))
def cell(cid,row,col,text_refs=(),header_refs=(),presence='present',width=1):
    return dict(cell_id=cid,row=row,column=col,row_span=1,column_span=width,presence=presence,text_refs=list(text_refs),header_refs=list(header_refs))
class CountedList(list):
    visited=0
    def __iter__(self):
        for x in super().__iter__():
            self.visited+=1
            yield x
class CountedDict(dict):
    visited=0
    def items(self):
        for pair in super().items():
            self.visited+=1
            yield pair
out={'lane':LANE,'supplier_calls':0,'original_reads':0}

if LANE=='table':
    import company_wiki.document_understanding.table_measurements.bindings as m
    out['imported_from']=m.__file__
    def observation(units,cells,**extra):
        return dict(schema_version=m.SCHEMA_IN,scope=dict(parent_id='p',table_id='t',page=1),units=units,cells=cells,**extra)
    def table(header,parent='p',row_label=None):
        units={'h':unit(header,parent),'v':unit('42')}
        headers=[ref('h',header)]
        if row_label:
            units['r']=unit(row_label)
            headers.append(ref('r',row_label))
        return observation(units,[cell('h',0,1,[ref('h',header)]),cell('v',1,1,[ref('v','42')],headers)],header_rows=[0])
    def run(o,n=10000):return m.bind_operating_table(o,work_budget=WorkBudget(n))
    out['foreign_header']=run(table('As of December 31, 2024 (RMB millions)','other-parent'))
    out['explicit_period_range']=run(table('Six months from January 1, 2024 to June 30, 2024'))
    out['orthogonal_currency_scale']=run(table('2024 (millions)',row_label='Revenue (RMB)'))
    headers=CountedList(range(10000))
    result=run(observation({},[],header_rows=headers),0)
    out['zero_budget_header_rows']={'visited':headers.visited,'work_used':result['work_used'],'status':result['status']}
    provenance=CountedList(dict(kind='native_slot',cell_id='c') for _ in range(10000))
    result=run(observation({'u':unit('x')},[cell('c',1,0,presence='unavailable')],provenance=provenance),2)
    out['spent_budget_provenance']={'visited':provenance.visited,'work_used':result['work_used'],'status':result['status']}
    visits=[0]
    class CountRange:
        def __init__(self,*args):self.actual=builtins.range(*args)
        def __iter__(self):
            for value in self.actual:
                visits[0]+=1
                yield value
    m.range=CountRange
    try:
        result=run(observation({'u':unit('7')},[cell('c',1,0,[ref('u','7')],presence='merged_unknown',width=5000)]),4)
        out['spent_budget_merged_coverage']={'range_yields':visits[0],'work_used':result['work_used'],'status':result['status']}
    finally:del m.range

elif LANE=='state':
    import company_wiki.document_understanding.operating_states.relations as m
    import company_wiki.document_understanding.operating_states.text_view as tv
    out['imported_from']=m.__file__
    def observation(text,units=None,contexts=None):
        return dict(schema_version=m.OBSERVATION_SCHEMA,unit_id='u',units=units if units is not None else {'u':unit(text)},context_unit_ids=contexts or [])
    def run(text,n=10000,**kw):return m.detect_operating_relations(observation(text,**kw),work_budget=WorkBudget(n))
    def shown(text):
        result=run(text)
        for relation in result['relations']:
            relation['observed_slices']={key:[text[r['char_start']:r['char_end']] for r in relation[key]] for key in ['actor_refs','object_refs','predicate_refs','qualifier_refs']}
        return result
    cases=['公司未签署供货合同。','公司计划签署供货合同。','公司尚未建立联系。','公司计划商业化新产品。','The company has not signed a supply contract.','  本公司尚未量产设备。','随后本公司已量产设备。','本公司尚未量产设备。','  本公司尚未量产X产品。','随后本公司已量产X产品。','本公司尚未量产X产品。','公司尚未正式签署供货合同。','公司没有与客户签署供货合同。','公司计划逐步商业化新产品。','公司并非没有签署供货合同。','如果客户验证通过。','母公司未签署供货合同。','子公司已量产X产品。','  本公司尚未量產X產品。']
    out['semantic_cases']={text:shown(text) for text in cases}
    units=CountedDict({'u':unit('公司未量产设备。'),**{'x'+str(i):unit('x') for i in range(1000)}})
    result=run('',0,units=units)
    out['zero_budget_unit_validation']={'items_visited':units.visited,'work_used':result['work_used'],'status':result['status']}
    original=tv.matching_script_text
    calls=[0]
    def counted(text):
        calls[0]+=1
        return original(text)
    tv.matching_script_text=counted
    try:
        result=run('甲'*5000,0)
        out['zero_budget_matching_view']={'script_conversion_calls':calls[0],'work_used':result['work_used'],'status':result['status']}
    finally:tv.matching_script_text=original
    contexts=CountedList('missing'+str(i) for i in range(10000))
    result=m.detect_operating_relations(observation('公司未量产设备。',contexts=contexts),work_budget=WorkBudget(0))
    out['zero_budget_context_copy']={'visited':contexts.visited,'work_used':result['work_used'],'status':result['status']}
else:raise ValueError(LANE)

(BASE/(LANE+'-final-probe-results.json')).write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'lane':LANE,'imported_from':out['imported_from'],'summary':{t:[{**{k:r[k] for k in ['polarity','stage','modality','attribution']},'slices':r['observed_slices']} for r in v['relations']] for t,v in out.get('semantic_cases',{}).items()},'budget':{k:v for k,v in out.items() if k.startswith('zero_budget')}},ensure_ascii=False,indent=2))
