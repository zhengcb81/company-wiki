# ROOT STATE首轮共因修复：独立复核

结论：**原S2坐标和S3预算反例关闭，原S1五个最小例改正，但S1限定语作用域仍有阻断缺口。** 本报告对应ROOT第一次冻结STATE代码，TABLE仍在施工，未运行或改写TABLE结论。原作者树/原报告保持不变。

独立纯探针强制ROOT/src，保留于`state-final-probe.py`及`state-review-round1-results.json`。没有复跑105条整包测试，没有调用API/native/原件或修改源/测试/PWF/Git。ROOT105PASS/1.25秒是ROOT证据。

## 已关闭

- 原五条“未签署/计划签署/尚未联系/计划商业化/has not signed”均正确绑定否定或计划及qualifier原文。
- 前导空格/随后connector不再把actor切成“本”或“随后本”，原文`本公司`和issuer保持；繁体`量產X產品`也精确回到原字串。
- budget0下unreferenced units.items、5000字符script conversion、10000 context复制三个真实计数均为0；仅触碰target/context，未再复制整份units。去掉平方overlap/final冗余sort方向正确。
- 新母/子公司控制保留quoted_related_party，不洗成issuer。

## S1仍开放：谓词前有普通副词/论元后又丢限定语

| 新纯反例 | 当前实测 |
|---|---|
| 公司尚未正式签署供货合同。 | positive/current/actual、qualifier空 |
| 公司没有与客户签署供货合同。 | positive/current/actual、qualifier空；actor含“公司没有”和“客户” |
| 公司并非没有签署供货合同。 | negative/current/actual、只保留“没有”，未退化双重否定unknown/uncertain |
| 如果客户验证通过。 | stage=current但modality=conditional；actor_ref为“如果”，qualifier仅“通过” |

这不是索要无限NLP覆盖；前三个是原否定/计划缺陷的相同常用语法变体。新`PREDICATE_MODIFIERS`只接受紧挨谓词的限定词token串，遇到“正式”或“与客户”断开后，原动词regex仍输出actual/current。仅新增这两字面词不能关闭共因。

建议统一event层在有界、同assertion的predicate-local region内维护actor/限定语/论元片段及真实坐标；能闭合才决定actual/current。未消费但可能作用于该谓词的否定/计划、复杂双重否定不能默认完成；无法确定作用域应unknown/uncertain并保留原文，不做全篇见“不”即否定。条件的结果后缀不能覆盖先前conditional stage，条件连接词也不能充当actor。

TDD可复用以上四个变体，加正控“已正式签署”“已与客户签署”、负面词实际属于另一对象的控制，以及中英文/两个命题的独立scope对照。原105回归保持，集中验收即可，无新增人工小门。

附限界：“公司计划逐步商业化新产品”当前没有relation，不把召回未知伪装成positive错误；“量产设备”baseline本就被noun guard排除，因此未拿其空结果作为坐标bug。上下文名称分类的完整依赖、真实selector/QA角色接线及跨公司真实摘要质量仍由后续生产节点证明。
