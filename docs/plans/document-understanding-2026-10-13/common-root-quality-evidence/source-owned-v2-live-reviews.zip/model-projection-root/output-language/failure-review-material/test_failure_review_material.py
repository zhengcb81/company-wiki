"""Owned harness probes: native isolated AUTO state, no HTTP or original reads."""
from contextlib import closing
from dataclasses import replace
import gzip
import hashlib
import json
from pathlib import Path
import runpy
import socket
import sqlite3

import pytest

from company_wiki.automation.models import (
    Event, HandlerError, HandlerMetrics, HandlerOutcome, HandlerResult,
    JobStatus, canonical_json, make_job_key,
)
from company_wiki.automation.narrative_model import FailedFinalDiagnostic
from company_wiki.automation.narrative_run_store import ModelUsage
from unit.test_narrative_reading_generation_store import (
    NOW, _claim, _finish, _selected, _state,
)

ROOT = Path(__file__).resolve().parents[3]
HELPER = ROOT / "live/owned-runner/failure_review_material.py"


def fingerprint(path):
    return (hashlib.sha256(path.read_bytes()).hexdigest(), path.stat().st_size,
            path.stat().st_mtime_ns)


@pytest.fixture(autouse=True)
def zero_network_and_protected(monkeypatch, tmp_path):
    project = ROOT.parents[1]
    files = [*project.joinpath("src").rglob("*.py"), project / "config.yaml",
             project / "config/source_catalog.yaml"]
    before = {path: fingerprint(path) for path in files}
    original, sentinel = tmp_path / "original.txt", tmp_path / "existing.txt"
    original.write_bytes(b"original must never be opened by helper")
    sentinel.write_bytes(b"test directory before observation")
    protected = {path: fingerprint(path) for path in (original, sentinel)}

    def forbid_network(*args, **kwargs):
        raise AssertionError("network forbidden in pure native DB probes")

    monkeypatch.setattr(socket, "create_connection", forbid_network)
    yield
    assert before == {path: fingerprint(path) for path in files}
    assert protected == {path: fingerprint(path) for path in protected}


@pytest.fixture
def helper():
    return runpy.run_path(str(HELPER))


def failed_state(root, *, reserve=True, finish=True, select=True):
    auto, runs, jobs, generation, selected, base = _state(root)
    if select:
        _finish(auto, _claim(auto, jobs[0], generation), selected)
    work = _claim(auto, jobs[1], generation)
    if reserve:
        runs.reserve_model_attempt(run_id="run", job_id=jobs[1].job_id,
            attempt_id=work.attempt.attempt_id, lease_token=work.attempt.lease_token,
            runtime_generation=generation, request_sha256="f" * 64, model_id="fixture",
            prompt_version="prompt", pricing_version="price", input_tokens_bound=100,
            max_output_tokens=200, output_bytes_bound=500, now=NOW)
        runs.settle_model_usage(run_id="run", attempt_id=work.attempt.attempt_id,
            usage=ModelUsage(20, 5), response_sha256="e" * 64, error_code=None,
            settled_at=NOW)
    if finish:
        result = HandlerResult(HandlerOutcome.TERMINAL_FAILURE,
            {"failed_final": FailedFinalDiagnostic.from_observation(
                provider_body=None, content="invalid final response").to_dict()}, (), (),
            HandlerMetrics(25 if reserve else 0, 0.0, 1),
            HandlerError("SUMMARY_INVALID", "claim support rule"))
        _finish(auto, work, result)
    return auto, runs, jobs, generation, selected, base


def dump(path):
    with closing(sqlite3.connect(path.as_uri() + "?mode=ro", uri=True)) as connection:
        return tuple(connection.iterdump())


def preserve(helper, auto, path, run_id="run"):
    return helper["preserve_failure_review_material"](auto.db_path, run_id, path)


def test_exact_native_selection_and_final_generation_retained_without_db_writes(helper, tmp_path):
    auto, runs, jobs, _, selected, _ = failed_state(tmp_path)
    before, charge = dump(auto.db_path), runs.budget_snapshot("run")
    output = tmp_path / "review.json.gz"
    receipt = preserve(helper, auto, output)
    payload = json.loads(gzip.decompress(output.read_bytes()))
    assert set(receipt) == {"path", "sha256", "bytes"}
    assert receipt == {"path": str(output.resolve()),
        "sha256": hashlib.sha256(output.read_bytes()).hexdigest(), "bytes": output.stat().st_size}
    assert payload["schema_version"] == "native-failure-review/1"
    assert payload["run_id"] == "run"
    assert len(payload["items"]) == 1
    item = payload["items"][0]
    assert item["item_key"] == jobs[0].subject_id
    assert item["select_attempt_id"] == "attempt-job-select"
    assert item["select_job_id"] == "job-select"
    assert item["select_result"] == selected.to_dict()["result"]
    assert item["final_generation"] == runs.final_generations("run")[jobs[0].subject_id]
    assert item["failed_summary_attempt_ids"] == ["attempt-job-summarize"]
    assert "failed_final" not in json.dumps(payload)
    assert dump(auto.db_path) == before and runs.budget_snapshot("run") == charge


def test_repeat_verifies_reuses_exact_bytes_and_mtime(helper, tmp_path):
    auto, *_ = failed_state(tmp_path)
    output = tmp_path / "review.json.gz"
    first = preserve(helper, auto, output)
    before = fingerprint(output)
    assert preserve(helper, auto, output) == first
    assert fingerprint(output) == before


def test_existing_different_bytes_are_not_overwritten(helper, tmp_path):
    auto, *_ = failed_state(tmp_path)
    output = tmp_path / "review.json.gz"
    output.write_bytes(b"prior independent receipt")
    before = fingerprint(output)
    with pytest.raises(helper["FailureReviewMaterialConflict"]):
        preserve(helper, auto, output)
    assert fingerprint(output) == before


def test_missing_database_no_material_no_database_creation(helper, tmp_path):
    missing = tmp_path / "missing.db"
    output = tmp_path / "missing-parent/review.json.gz"
    assert helper["preserve_failure_review_material"](missing, "run", output) is None
    assert not missing.exists() and not output.parent.exists()


@pytest.mark.parametrize("kind", ["preselect", "unreserved", "unfinished", "unknown-run"])
def test_no_completed_native_model_failure_creates_no_material(helper, tmp_path, kind):
    if kind == "preselect":
        auto, *_ = _state(tmp_path)
    else:
        auto, *_ = failed_state(tmp_path, reserve=kind != "unreserved", finish=kind != "unfinished")
    output = tmp_path / "review.json.gz"
    assert preserve(helper, auto, output, "unknown" if kind == "unknown-run" else "run") is None
    assert not output.exists()


def add_unrelated_same_source_run(auto, runs, template, generation):
    document = template[0].subject_id
    digest = template[0].input_hash
    event = Event("other-event", "source.revision_registered", "source_revision", document,
                  digest, "{}", "other-policy", NOW, NOW)
    auto.put_event(event)
    jobs = []
    for job in template:
        copied = replace(job, job_id="other-" + job.job_id,
            job_key=make_job_key(job.job_type, job.subject_type, document, digest, "other-policy", "1.0.0"),
            policy_version="other-policy", created_from_event_id=event.event_id,
            status=JobStatus.READY)
        auto.put_job(copied)
        jobs.append(copied)
    runs.create_run(run_id="other-run", input_hash=digest, job_ids=tuple(j.job_id for j in jobs),
        model_id="fixture", prompt_version="prompt", pricing_version="price",
        input_micro_usd_per_million_tokens=1, output_micro_usd_per_million_tokens=1,
        max_tokens=10000, max_micro_usd=10000, max_output_bytes=10000,
        created_at=NOW, binding_json=runs.get_run("run").binding_json)
    other_selected = _selected(digest="b" * 64)
    _finish(auto, _claim(auto, jobs[0], generation), other_selected)
    return jobs, other_selected


def test_later_same_source_in_other_run_cannot_replace_current_selection(helper, tmp_path):
    auto, runs, jobs, generation, selected, _ = failed_state(tmp_path)
    _, unrelated = add_unrelated_same_source_run(auto, runs, jobs, generation)
    assert unrelated.result != selected.result
    output = tmp_path / "review.json.gz"
    preserve(helper, auto, output)
    item = json.loads(gzip.decompress(output.read_bytes()))["items"][0]
    assert item["select_result"] == selected.to_dict()["result"]
    assert item["final_generation"] == runs.final_generations("run")[jobs[0].subject_id]
    assert item["final_generation"] != runs.final_generations("other-run")[jobs[0].subject_id]


def test_successful_native_verify_bundle_skips_duplicate_failure_material(helper, tmp_path):
    auto, _, jobs, generation, selected, _ = failed_state(tmp_path)
    # This native VERIFY success is the existing Store's accepted bundle signal;
    # the helper must not open any published file or original to discover it.
    bundle = {"schema_version": "narrative-bundle/2.0", "source_ref": selected.to_dict()["result"]["source_ref"]}
    _finish(auto, _claim(auto, jobs[2], generation), HandlerResult(
        HandlerOutcome.SUCCEEDED, bundle, (), (), HandlerMetrics(0, 0.0, 0), None))
    output = tmp_path / "review.json.gz"
    assert preserve(helper, auto, output) is None
    assert not output.exists()


def test_unrelated_successful_bundle_does_not_hide_current_failure(helper, tmp_path):
    auto, runs, jobs, generation, selected, _ = failed_state(tmp_path)
    other, _ = add_unrelated_same_source_run(auto, runs, jobs, generation)
    _finish(auto, _claim(auto, other[2], generation), HandlerResult(HandlerOutcome.SUCCEEDED,
        {"schema_version": "narrative-bundle/3.0"}, (), (), HandlerMetrics(0, 0.0, 0), None))
    output = tmp_path / "review.json.gz"
    preserve(helper, auto, output)
    assert json.loads(gzip.decompress(output.read_bytes()))["items"][0]["select_result"] == selected.to_dict()["result"]


def test_changed_native_selection_observation_rejects_without_replacing_old_file(helper, tmp_path):
    auto, *_ = failed_state(tmp_path)
    output = tmp_path / "review.json.gz"
    preserve(helper, auto, output)
    before = fingerprint(output)
    # Change only the isolated test DB's persisted diagnostic, not source bytes,
    # to prove write-once compares the actual new observation, not just run_id.
    with closing(sqlite3.connect(auto.db_path)) as connection:
        row = connection.execute("SELECT result_json FROM attempts WHERE attempt_id='attempt-job-select'").fetchone()
        value = json.loads(row[0])
        value["result"]["source_metadata"]["title"] = "different native observation"
        connection.execute("UPDATE attempts SET result_json=? WHERE attempt_id='attempt-job-select'", (canonical_json(value),))
        connection.commit()
    with pytest.raises(helper["FailureReviewMaterialConflict"]):
        preserve(helper, auto, output)
    assert fingerprint(output) == before


def verify_failed_state(root, *, reserve=True):
    auto, runs, jobs, generation, selected, base = failed_state(root, reserve=reserve, finish=False)
    # The helper reads native task outcomes, not semantic model validation.
    # This distinct marker proves it retains the actual successful result.
    summary = {"schema_version": "owned-native-summary-fixture/1", "marker": "accepted-before-replay"}
    auto.finish_attempt(attempt_id="attempt-job-summarize", lease_token="lease-job-summarize",
        runtime_generation=generation, finished_at=NOW,
        result=HandlerResult(HandlerOutcome.SUCCEEDED, summary, (), (), HandlerMetrics(25, 0.0, 1), None))
    _finish(auto, _claim(auto, jobs[2], generation), HandlerResult(
        HandlerOutcome.TERMINAL_FAILURE, {}, (), (), HandlerMetrics(0, 0.0, 0),
        HandlerError("LOCATOR_REPLAY_FAILED", "selected evidence replay could not complete")))
    return auto, runs, jobs, generation, selected, base, summary


def test_paid_summary_success_then_verify_failure_retains_native_review(helper, tmp_path):
    auto, runs, jobs, _, selected, _, summary = verify_failed_state(tmp_path)
    before, charges = dump(auto.db_path), runs.budget_snapshot("run")
    path = tmp_path / "review.json.gz"
    assert preserve(helper, auto, path) is not None
    item = json.loads(gzip.decompress(path.read_bytes()))["items"][0]
    assert item["select_result"] == selected.to_dict()["result"]
    assert item["summary_result"] == summary
    assert item["failed_summary_attempt_ids"] == []
    assert item["failed_verification_attempt_ids"] == ["attempt-job-verify"]
    assert item["final_generation"] == runs.final_generations("run")[jobs[0].subject_id]
    first = fingerprint(path)
    preserve(helper, auto, path)
    assert fingerprint(path) == first
    assert dump(auto.db_path) == before and runs.budget_snapshot("run") == charges


def test_unpaid_verify_failure_does_not_copy_source_review(helper, tmp_path):
    auto, *_ = verify_failed_state(tmp_path, reserve=False)
    path = tmp_path / "review.json.gz"
    assert preserve(helper, auto, path) is None
    assert not path.exists()
