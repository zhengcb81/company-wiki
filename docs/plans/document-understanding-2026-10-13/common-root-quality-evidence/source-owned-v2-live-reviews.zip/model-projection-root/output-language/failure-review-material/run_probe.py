"""Run only owned pure probes, keeping RED/GREEN receipts and deleting Temp."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time

OWNED = Path(__file__).resolve().parent
PROJECT = OWNED.parents[4]
label = sys.argv[1]
started = time.perf_counter()
with tempfile.TemporaryDirectory(prefix="cw-native-failure-material-") as name:
    temp = Path(name)
    sentinel = temp / "existing.txt"
    sentinel.write_bytes(b"restore exact test directory")
    command = [sys.executable, "-B", "-X", "utf8", "-m", "pytest", "-q",
        "-p", "no:cacheprovider", str(OWNED / "test_failure_review_material.py"),
        "--basetemp", str(temp / "pytest"), "--junitxml", str(OWNED / (label + ".xml"))]
    env = dict(os.environ)
    env["PYTHONPATH"] = os.pathsep.join((str(PROJECT / "src"), str(PROJECT / "tests")))
    process = subprocess.run(command, cwd=PROJECT, env=env, capture_output=True)
    (OWNED / (label + ".stdout.log")).write_bytes(process.stdout)
    (OWNED / (label + ".stderr.log")).write_bytes(process.stderr)
    sentinel_unchanged = sentinel.read_bytes() == b"restore exact test directory"
receipt = {"exit_code": process.returncode, "seconds": round(time.perf_counter() - started, 3),
    "supplier_calls": 0, "network_calls": 0, "temp_removed": not temp.exists(),
    "sentinel_unchanged": sentinel_unchanged,
    "stdout_sha256": hashlib.sha256(process.stdout).hexdigest()}
(OWNED / (label + ".json")).write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf8")
print(json.dumps(receipt))
sys.exit(process.returncode)
