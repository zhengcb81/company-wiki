# Failure review helper — SOURCE STOP

Only new test harness material was written. Production source, existing tests,
PWF, Git, provider configuration, requests, prompts and the ROOT runner/observer
were not changed by this task. ROOT owns the append_native connection and the
actual invalid-loopback acceptance; that acceptance is not claimed here.

## Exact API

```python
preserve_failure_review_material(
    database: Path, run_id: str, output_path: Path,
) -> dict[str, object] | None
```

Helper: `.planning/shared-reading-production/live/owned-runner/failure_review_material.py`

Frozen SHA-256: `4d25d5335114c309520856766b11fe1391e3323b8aa06e17e203d3449375b42d`.

Return value contains only `path` (absolute), `sha256`, and `bytes`. No material
is printed. No eligible material returns `None` without creating a directory.
Different existing bytes raise `FailureReviewMaterialConflict`, without replacing
the old file. An identical observation reuses exact bytes and mtime. Atomic
exclusive linking publishes a complete flushed gzip; the staging file is removed.

Gzip JSON top-level keys:

- `schema_version`: `native-failure-review/1`;
- `run_id`;
- `items`: sorted by the native run item key.

Each item contains `item_key`, `select_job_id`, `select_attempt_id`,
`select_result`, `final_generation`, and `failed_summary_attempt_ids`.
`select_result` is the full native successful select attempt's result, including
its raw SourceRef/subject binding, evidence spans/native locators, reading context
and coverage. `final_generation` comes from the existing read-only
`NarrativeRunStore.final_generations(run_id)`; legacy absent freezes remain null,
never reconstructed from current code. Failed final response/usage stay in the
runner's existing native-failures/native-usage files and are not copied again.

Eligibility uses only that run's `narrative_run_jobs` membership, joins attempts
and jobs, and pairs by `subject_id`. The failed summarize attempt must be finished,
have a failure code, and own a native model reservation in that run. A successful
verify attempt containing the native bundle schema excludes that same item.
Another run's later selection or successful bundle cannot replace or hide this
run's material. The helper opens only the supplied isolated AUTO database in
read-only/query-only mode, then uses the Store's existing read-only generation API.
It does not open a source or published bundle, select/parse again, or send HTTP.

## Actual pure probe results

`final-green.xml`: **12 PASS, 3.51s**, process exit **0**, total runner 5.976s.
Ruff on the helper and two owned probe files: exit **0**, all checks passed.

Covered at one concentrated node: exact native selection and generation,
unchanged database/charges, repeated bytes/mtime, differing receipt refusal,
missing database, preselect/no reservation/unfinished/unknown run, later unrelated
same-source selection, successful bundle no duplicate, unrelated successful bundle
does not mask failure, and changed observation does not overwrite an earlier file.
Synthetic verification results in the pure probe exercise native Store mapping;
the real bundle/contract flow is ROOT's separate loopback responsibility.

All tests used independently generated AUTO databases and no original parsing.
All production `src/**/*.py` and both production configuration files retained
SHA/size/mtime per test. Temporary directories and pytest's relocated basetemp
were removed; original/sentinel fixture bytes remained unchanged. Zero network
or provider calls; socket connection creation was forbidden in the probe.

## Retained failures (not reclassified as production defects)

- First sandbox command exited 1 before pytest: denied writing its generated
  AppContainer Temp directory. Host rerun was explicitly approved; the uniquely
  named empty sandbox residual was later checked and was absent.
- `baseline-red`: collection exit 2 because scratch tests did not inherit the
  repository tests directory on PYTHONPATH. Fixed only the owned probe launcher.
- `missing-helper-red`: exit 1, 12 errors for the not-yet-created helper.
- `first-green`: exit 1, 11 PASS/1 FAIL. The success fixture supplied a native
  mappingproxy directly to HandlerResult JSON. Changed only the fixture to use
  the existing `to_dict()` wire representation; no production guard changed.

ROOT should call after native fee append/fsync, and catch helper failures as a
diagnostic index entry. Helper failure must not hide native usage or prevent
finally cleanup. A genuine model failure remains failed, regardless of whether
this optional review material can be preserved.
