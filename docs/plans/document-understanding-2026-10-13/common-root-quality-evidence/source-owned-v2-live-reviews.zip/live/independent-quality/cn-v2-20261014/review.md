# CN real MiMo v2 independent quality review

**Verdict: FAIL — unpublished candidate, not an accepted summary.**

Actual run `phaseC-090-7a8c5088f903`, attempt `fd51f0caf5f64e7db8e46ba5d19e611e`, execution `live-20261014T224232-993368`. Reviewed exact saved input/final, native failure/usage and full `native-failure-review/1` typed selection + generation. No original reopen, parse, API call, test run or source/test/PWF/Git write. Seventeen packet files were fingerprinted before/after; unchanged. Full claim/locator/packet matrices are in [review.json](review.json).

## 1. Actual execution and deterministic rejection

- One real configured MiMo `mimo-v2.6-flash` POST, thinking disabled, temperature1, max_completion_tokens8192. Input13,483/output2,044/reasoning0; 15,527 tokens /2,929 micro-USD budget proxy, not an invoice. Known usage remains charged; failed output quota settled0, no artifact. Mother550,156 tokens /367,316 micro-USD proxy; prior unknown7 retained.
- Exact native error: `SUMMARY_INVALID: model draft violates the summary contract (rule=GROUP_INCOMPLETE)`. It is not a header error, language error or observed truncation. Complete final7,871 bytes SHA `fb3554aa148f69228469a2cf709922fdf79af369fc346aae2ddf41546a1f5ab7` decodes unchanged as JSON with20claims, no duplicate keys, unknown aliases or text-length overflow (max160/280). Provider finish reason was not retained; it is unknown.
- All20claims declare context groups but omit members required by those actual groups. First c1 declares g11=[e10,e11],g5=[e95,e96], cites onlye11/e96, hence e10/e95 missing. This alone explains the recorded first refusal. Actual schema max IDs is96, not the earlier loopback example max2. Later decoder errors after the first refusal were not executed/certified.
- Selected and actually sent source support is10/10 under the retained canonical closed-group oracle. Actual96typed spans match all sent eN text/role/flags, and all64gN groups map to saved native groups. Native locator/generation audit is available this time; it is not the previous failed-packet retention gap.
- Temp cleanup and protected-file preservation passed in the retained receipt. No new0.8baseline POST followed this failure.

## 2. Candidate semantics and fixed gold

The prose is substantially better than the earlier missing-product candidate: Preciomo Udx and PRISMO PD5 now both appear. That does not make this result valid. Eighteen claim texts are supported by their direct/declared-group support; two have material citation/scope gaps. Six compound claims mix current facts with planned actions while exposing one scalar modality. All20 remain formally invalid from group closure. Chinese prose and original product names are preserved; no actual translation or obvious numerical/currency fabrication was found in this candidate.

Fixed10required/7critical gold, unchanged SHA `10d1dc12e251e57354599c58abd55d5ee3d010259a8bf04415a73fb55cb2a335`: candidate semantic coverage5full/5partial/0missing; critical4full/3partial. This stricter semantic count includes coherent structured state, with prose-only coverage separately retained below. It is not a formal summary pass and should not be compared arithmetically with an older review using different state treatment.

| Gold ID | Candidate coverage | Claim | Concrete observation |
|---|---|---|---|
| f-five-year-target-is-plan | partial; prose full | c2 | 未来五年/60%/70%和产品/市场口径文字正确，但structured actual未保留计划状态。 |
| f-current-coverage-30 | full; prose full | c2 | 50多种、超30%为当前前道设备产品覆盖；未写成市场份额或收入占比。 |
| f-cmp-acquisition-completed | full; prose full | c1 | 报告期内完成众硅控股权收购、CMP/干法+湿法覆盖正确；同claim另有未来协同混合状态，收购子命题自身为actual。 |
| f-microled-sample-verification | partial; prose partial | c10 | 产品/验证/性能/可靠性/重复订单保留；2023年底首次样机付运时点未保留。 |
| f-gan-power-stage | full; prose full | c11 | PRISMO PD5生产验证与重复订单保留，未宣称验证完成或量产；未与新型GaN设备混同。 |
| f-sic-8inch-stage | full; prose full | c12 | 8寸SiC头部客户生产验证/重复订单正确。 |
| f-inp-development-started | partial; prose nearly_full | c13 | 开发启动及H2客户反馈/开发/样机下一步在文字里；未来客户验证目的欠明确，且actual字段未区分后续计划。 |
| f-advanced-packaging-primo-matrix | partial; prose full | c14 | “即将发往…产线验证”文字正确，structured actual没有区分计划。 |
| f-tsv-300e-serving | full; prose full | c14 | TSV300E持续服务客户与重复订单正确；未额外声称量产规模。 |
| f-third-gen-tsv-rd | partial; prose full | c14 | 研发/已获订单与即将客户验证文字都保留，但后者未来状态被全条actual覆盖；不机械照抄gold总体actual标签。 |

## 3. Every claim and actual citation closure

Semantic review reads the actual declared closure as potential context while retaining its explicit-membership failure. It does not amend the model output or attach other input evidence to make it pass. Source actor is company_filing for these claims; c19 explicitly attributes the industry forecast to SEMI and should not be recast as an analyst question.

| Claim | Missing members of declared group | Prose / state | Finding apart from common closure failure |
|---|---|---|---|
| c1 | e10,e95 | supported / mixed_actual_planned | 收购完成与中微众硅12英寸CMP量产地位有e11/e96支持；双方“将在…协同”是未来，不能同记actual。 |
| c2 | e10 | supported / mixed_actual_planned | 50多种/超30%产品覆盖与未来五年60%/70%目标均原样保留；structured actual把未来目标并入当前。 |
| c3 | e14 | supported / coherent_actual | H1 2026研发投入约20.41亿元、同比约5.50亿元/36.86%、收入占比约30.51%逐项匹配e15；无币种/亿万换算。 |
| c4 | e17 | supported / coherent_actual | UD-RIE迭代、客户端验证/重复订单与XD-RIE Alpha完成测试/Beta验证均支持；多个产品进展被合在一条，虽未升级状态。 |
| c5 | e17 | supported / mixed_current_planned | e20支持当前实验室开发与预计2026年内付运；planned字段只适合下一动作，不适合整条当前+未来。 |
| c6 | e21 | supported / coherent_actual | 50多个客户产线量产、LUX-Cryo量产、Angnova实验室/客户端认证与重复订单均匹配；不同产品不同阶段压在一条。 |
| c7 | e21 | supported / coherent_actual | Twin-Star量产、Menova量产与Domingo实验室Alpha验证均支持，未把Domingo写成量产；三产品压在一条。 |
| c8 | e28 | partial / coherent_actual | e30“该系列设备”及e35“该系列产品”不自带CVD/HAR/ALD钨与Preforma Uniflash身份；实际需e29/e34，均在input却不在本claim直接或声明group闭包中。属于可定位的引用归属遗漏，不是input外编造。 |
| c9 | e28 | supported / coherent_actual | 减压成熟制程验证成功/先进制程量产验证，与常压完成开发/晶圆验证分开表述；e37逐项支持。 |
| c10 | e38 | supported / coherent_actual | Preciomo Udx验证、性能可靠性、重复订单和应用拓展有e40/e41支持；gold要求的2023年底首次样机付运时点遗漏。 |
| c11 | e38 | supported / coherent_actual | PD5客户生产验证/重复订单与新型GaN设备报告期内付运分别陈述；未把验证/订单写成量产，研发的性能/成本目的未写成已达成。 |
| c12 | e38 | supported / coherent_actual | 8寸SiC进入头部客户生产验证、重复订单及技术/商务接洽均有e45支持。 |
| c13 | e38 | supported / mixed_actual_planned | 红黄光样机当前验证与InP启动开发/下半年加快开发并尽早付运同时置actual；InP未来行动在文字里保留，但客户端生产验证目的未明确保留。 |
| c14 | e49 | supported / mixed_actual_planned | TSV300E持续服务/重复订单正确；Matrix即将发往验证、第三代TSV已获订单而验证尚待未来均文字保留，却全标actual。 |
| c15 | e51,e53 | supported / coherent_actual | 中微惠创/DAS与汇链/We-Linkin主体分别清楚，超80场景/超900微服务单位和近似限定保留。 |
| c16 | e56 | supported / mixed_actual_planned | 临港20万平H2开工计划、滴水湖10万平8月1日落成、广州7月/成都8月封顶及2027投产计划逐项支持；计划与已完成建设事件共用actual。日期属于原报告披露的后续更新，文字未明确伪装为H1已发生。 |
| c17 | e61 | supported / coherent_actual | e62支持交付及时率/物料成本描述；没有具体数值，信息量较低，在20条上限时其优先级应低于关键时点/后续动作。 |
| c18 | e84,e85,e86 | partial / coherent_actual_with_estimate_label | 1.16累计投入、43.46预计总投资/6.11本期/29.91累计均来自表；亿元/列义只在未显式引用的e84/e85，g1可提供但闭包未完整引用。文本“项目合计”未说明是整张源表的合计，容易被读作前述5项目小计；不据此做减法或断言数值编造。 |
| c19 | e1 | supported / coherent_forecast | e3确有SEMI预测1659亿美元/23.2%/2026；引用的主体是行业协会，issuer filing source_role映射company_statement合理，并非公司收入或analyst_question。 |
| c20 | e1 | supported / coherent_actual_source_statement | e2支持中国大陆占比与国产/国外门类、性能、量产能力差距缩小；这是被引用的公司行业叙述，未当成独立外部核验。 |

## 4. Shared causes and implementation advice

### A. Mechanical group ownership is assigned twice

The exact instruction already says declare every used group and explicitly repeat every member, while also allowing narrower propositions to declare[] and cite actual support. MiMo systematically emits content spans plus group aliases and omits headings/context, so another wording-only prompt patch is poorly supported. Most missing members are headings; c18 also misses real unit/header context. This is a deterministic protocol responsibility problem, not a reason to discard all group/context integrity.

Consider one source-owned citation compiler: accept a finite existing eN/gN reference grammar; reject unknown/foreign IDs; expand explicitly declared known gN membership from the pinned selection once; keep narrower[] claims tied only to their actual direct support. Canonical artifacts retain exact closure. The model should not redundantly reproduce program-owned headers/member arrays. Review entailment separately: expansion is not proof a statement is true. Freeze a new causal prompt/decoder generation and preserve old refs/boundaries. This recommendation does not authorize repairing or accepting this already-failed final.

### B. Structural closure lacks some semantic antecedents

c8 cites e30 “该系列设备” and e35 “该系列产品”. Their declared groups supply generic薄膜沉积标题e28 but not identity-bearinge29(CVD/HAR/ALD钨) or e34(Preforma Uniflash). Those exact identity passages exist in the sent input but were not cited. Adding headings would satisfy the mechanical rule while leaving those names unsupported by this claim. The shared closure/planning engine needs source-local referent dependency handling; do not whitelist these products or attach all nearby rows. Bound reference continuity and test same-section competing series, page-break continuation and an identity absent from the selection.

### C. A20-slot summary is packing more than20 distinct stage obligations

The actual output plan targets20claims and instructs one subject/product/stage/modality. The candidate uses exactly20 yet compresses current + future under actual(c1,c2,c13,c14,c16) and current + future under planned(c5); it also merges multiple product identities into c6/c7/c8/c13/c14. Textually future words survive, but downstream scalar modality can be wrong. The fix should plan coherent fact units and material next actions in the shared engine before generation. If the distinct material obligations exceed the configured single-call contract, use bounded existing AUTO batches and deduplicate only same-subject/same-stage propositions; do not blindly raise caps, strip future qualifiers or repeatedly pay the same request. Generic c17 is a lower-priority slot than the omitted Micro-LED first-shipment date.

## 5. Focused acceptance examples for the next root change

These are proposed fixtures, not tests run by this reviewer:

1. Preserve this immutable raw20claim failure and first GROUP_INCOMPLETE; separately prove the new finite reference compiler handles known gN/eN, narrower[], foreign/missing groups and mandatory unit/header context without another original read.
2. e30/e35 deictic text with generic heading only must not validate CVD/HAR/ALD or Uniflash identity; actuale29/e34 closure must supply their identities. A conflicting other-product antecedent must not be accepted.
3. c2 current30% versus future60%/70%, c13 InP development versus H2 future customer validation, c14 TSV300Ecurrent versus Matrix/third-generation TSVfuture, and c16 construction dates must remain separate coherent modalities.
4. Table currency/unit/column/global-total scope stays source-owned. e87累计1.16 and e92 total43.46/6.11/29.91 must not become five-listed-project sums or another currency.
5. Re-run actual configured supplier independently after shared changes, with fixed10/7gold and original-language review. Existing quote recall, JSON success and loopback cannot fill the real summary quality result.

## Unknowns and limits

No independent original replay was performed by this read-only reviewer; exact saved typed selection/locators and the owner’s retained source proof were used. Provider finish reason and any hypothetical later decoder/language-check result remain unknown. The source itself is selected_evidence_only/partial, not whole-document coverage. The current refusal is justified by the contract actually sent; the systematic remedy is to clean up responsibility and semantic fact planning, not to mark this paid candidate successful.
