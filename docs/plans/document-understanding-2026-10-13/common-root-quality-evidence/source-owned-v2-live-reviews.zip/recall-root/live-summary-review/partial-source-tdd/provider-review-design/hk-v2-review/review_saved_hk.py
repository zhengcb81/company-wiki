"""Read retained HK provider artifacts only; no original/parser/model access."""
from datetime import datetime, timezone
import gzip
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[7]
OWNED = Path(__file__).resolve().parent
RUN = ROOT / ".planning/shared-reading-production/live/owned-runner/receipts/live-20261014T224413-922d46"
RUN_ID = "phaseC-090-76236609f71c"
INPUT = RUN / "materials" / f"{RUN_ID}.input.json.gz"
FINAL = RUN / "materials" / f"{RUN_ID}.7e85d4a23b5d473eb59c8baeff651b62.response.json.gz"
GOLD = ROOT / "tools/document_understanding_benchmark/gold/hk-annual.json"

NOTES = {
    "c1": ("SUPPORTED", "2013 start, two brands and frequently refreshed lifestyle products supported by e1/e3; Chinese script differs from Traditional original but same language family."),
    "c2": ("SUPPORTED_APPROXIMATE", "e4 supports approximate counts/date exactly in meaning; not an exact 7504/4386/3118 assertion. e4 is English-only, output is Simplified Chinese."),
    "c3": ("SUPPORTED_WITH_EXCESS_CITATION", "503/2615 and 2024 date are in e26/e28. g3/e33-e35 are unrelated geographical count data and do not add support for operating-model totals."),
    "c4": ("SUPPORTED", "TOP TOY 2020 expansion, 2024 overseas start, year-end276 and mainland272 all in e6; e6 is English-only and output is Chinese."),
    "c5": ("SUPPORTED", "Mainland-only25 MINISO direct,26 distributor,38 TOP TOY direct and remainder partner model match e10; not worldwide direct count. English-only citation, Chinese output."),
    "c6": ("WRONG_YEAR_HIGH_CONFIDENCE", "522+1617+1787=3926, matching e5's2023 mainland total, not e5's2024 total4386. g2 has2023|2024 headers but only one numeric body column; asserting2024 is not supported."),
    "c7": ("WRONG_YEAR_HIGH_CONFIDENCE", "1333+172+552+231+199=2487, matching e5's2023 overseas total, not2024 total3118. g3 has two year headers but only one numeric column."),
    "c8": ("PERIOD_ALIGNMENT_UNSUPPORTED", "g4 shows three period/year headings2023|2023|2024, but body rows only two values. 13035/30-35%/37.6 are visible; assigning them to2024 cannot be established from the retained sent column structure."),
    "c9": ("PERIOD_ALIGNMENT_UNSUPPORTED", "g5 has the same three-header/two-value mismatch.10899 and25-30% occur, but the2024 binding is not established; do not invent missing2024 values."),
    "c10": ("PERIOD_ALIGNMENT_UNSUPPORTED", "g6 has three period/year headers and two body values.814/45-50%/121.3 occur without adequate2024 alignment. e49's1410.4 is multi-channel brand GMV, a different scope."),
    "c11": ("SUPPORTED", "e49 supports2020-12 launch and FY2024 multi-channel TOP TOY GMV RMB1410.4million; does not imply store-only GMV."),
    "c12": ("SUPPORTED", "e24 states42/64 Retail Partners in2023/2024; the quantity counts partners/operators, not TOP TOY stores. English-only citation, Chinese output."),
    "c13": ("SUPPORTED", "e25/e27 give three operating models and optional conversion between partner/distributor modes, without claiming all stores are direct."),
    "c14": ("MIXED_STATE_PRECISION_GAP", "e56 supports actual2024-09-23 agreement via wholly-owned subsidiary and pending29.4% acquisition; target821 outlets/date and RMB6270118134 are correct. planned modality also wraps the completed signing event."),
    "c15": ("AGREEMENT_VS_ISSUANCE_PRECISION_GAP", "e57 states entered subscription agreement for issuance, cash settlement, USD550million, expected2032-01-14 maturity and USD8.2822/share. Wording can imply issuance already completed; agreement completion is the proven actual state."),
    "c16": ("SUPPORTED_REFERENT_LIMIT", "e90/e91 support post-reporting2025-03 completion,29.4%, RMB6270118000. Target remains generic in cited text; do not infer a new target identity. Difference134 vs c14 is present in the source statements, not invented conversion."),
    "c17": ("SUPPORTED", "e59/e60 explicitly give FY2024 margin44.9%, overseas product/direct-operation mix causes and TOP TOY profitable-product mix; no invented percentage-point calculation."),
    "c18": ("SUPPORTED_SCOPE_CAUTION", "e61 supports total overseas direct stores505, doubled direct revenue and related expenses+72.2%.505 is company-wide wording, not automatically identical to MINISO-only503 in c3."),
    "c19": ("SUPPORTED", "e71/e72 support actor MINISO Guangzhou for Group,2022 agreement ending2025-06-30 and2024-11-29 renewal ending2026-12-31. English-only citations, Chinese output."),
    "c20": ("SUPPORTED", "e75 supports two distinct less-than30% concentration statements; no one-customer or one-supplier inference. English-only citation, Chinese output."),
}


def fp(path):
    raw = path.read_bytes()
    return {"sha256": hashlib.sha256(raw).hexdigest(), "bytes": len(raw), "mtime_ns": path.stat().st_mtime_ns}


def main():
    protected = [INPUT, FINAL, GOLD, RUN / "overall.json", RUN / "events.jsonl", RUN / f"{RUN_ID}.native-failures.json", RUN / f"{RUN_ID}.native-usage.json"]
    before = {str(p.relative_to(ROOT)): fp(p) for p in protected}
    input_bytes = gzip.decompress(INPUT.read_bytes())
    final_bytes = gzip.decompress(FINAL.read_bytes())
    request = json.loads(input_bytes)
    envelope = json.loads(request["messages"][1]["content"])
    final = json.loads(final_bytes)
    overall = json.loads((RUN / "overall.json").read_text("utf8"))
    events = [json.loads(line) for line in (RUN / "events.jsonl").read_text("utf8").splitlines()]
    pre = next(e for e in events if e["event"] == "pre_reservation_material")
    observation = next(e for e in events if e["event"] == "model_final_observed")
    assert hashlib.sha256(input_bytes).hexdigest() == pre["http_body_sha256"]
    assert hashlib.sha256(final_bytes).hexdigest() == observation["final_sha256"]
    assert envelope["schema_version"] == "narrative-model-request/3"
    assert overall["model_post_attempts"] == 1
    evidence = {row[0]: row[1] for row in envelope["evidence"]}
    groups = dict(envelope["evidence_groups"])
    claims = []
    for claim in final["draft"]["claims"]:
        verdict, note = NOTES[claim["claim_id"]]
        refs = claim["evidence_ids"]
        assert set(refs) <= evidence.keys()
        assert set(claim.get("evidence_group_ids", [])) <= groups.keys()
        missing = {g: sorted(set(groups[g]) - set(refs)) for g in claim.get("evidence_group_ids", []) if set(groups[g]) - set(refs)}
        if missing:
            verdict = "CONTENT_SUPPORTED_BUT_GROUP_DECLARATION_INVALID"
            note += " Actual raw declaration omits required group members; current decoder rejects this individual claim under summary claim evidence group coverage is incomplete. Canonical output was not retained."
        claims.append({**claim, "review_verdict": verdict, "review_note": note,
                       "group_members_missing_from_explicit_citations": missing,
                       "native_locator_mapping": "NOT_RETAINED_AFTER_VERIFY_FAILURE",
                       "source_excerpt_pointers": [f"materials/{INPUT.name}::messages[1].content.evidence[{alias}]" for alias in refs]})
    assert len(claims) == 20
    exact_occurrences = {value: [alias for alias, text in evidence.items() if value in text]
                         for value in ("7,504", "4,386", "3,118")}
    coverage = [
        {"gold_id": "f-store-total-2024", "quote_support": True, "coverage": "APPROXIMATE_ALTERNATIVE_FULL_EXACT_TARGET_NOT_SENT", "claims": ["c2"], "note": "Gold OR accepts over7500 but must_preserve requests7504. No sent alias contains7504; model must not calculate or invent it. Strict exact-field score is partial; no model-only omission finding."},
        {"gold_id": "f-store-mainland-overseas", "quote_support": True, "coverage": "PARTIAL_APPROXIMATION_ONLY", "claims": ["c2", "c3"], "note": "4386/3118 are in e5, while summary only gives nearly4400/over3100; c3's503+2615 is not an explicit summary3118 statement."},
        {"gold_id": "f-store-operating-model", "quote_support": True, "coverage": "FULL", "claims": ["c3", "c5", "c13"]},
        {"gold_id": "f-top-toy-total", "quote_support": True, "coverage": "FULL", "claims": ["c4"]},
        {"gold_id": "f-top-toy-mainland", "quote_support": True, "coverage": "FULL", "claims": ["c4"]},
        {"gold_id": "f-top-toy-overseas-commenced", "quote_support": True, "coverage": "FULL", "claims": ["c4"]},
        {"gold_id": "f-store-network-approximate", "quote_support": True, "coverage": "FULL", "claims": ["c2"]},
    ]
    result = {
        "status": "QUALITY_FAILURE_UNPUBLISHED_PROVIDER_DRAFT",
        "observed_at": datetime.now(timezone.utc).isoformat(),
        "scope": "actual HK v2 final+sent material; not a published Bundle/full RF/original truth certification",
        "execution": {"id": RUN.name, "run_id": RUN_ID, "actual_posts": 1, "provider": "deepseek", "model": request["model"],
                      "actual_input_schema": envelope["schema_version"], "actual_projection": pre["reading_model_projection"],
                      "valid_final_json": True, "source_header_omission_correct": True,
                      "failure_code": "LOCATOR_REPLAY_FAILED", "failure_layer": "source.narrative_verify",
                      "input_tokens": 13332, "output_tokens": 1755, "charged_tokens": 15087, "fee_proxy_micro_usd_not_invoice": 6785,
                      "protected_unchanged": overall["protected_unchanged"], "sentinel_unchanged": overall["sentinel_unchanged"], "temp_removed": overall["temporary_lake_removed"]},
        "request_sha256": pre["http_body_sha256"], "final_sha256": observation["final_sha256"], "final_bytes": len(final_bytes),
        "source_sha256": overall["source_ref"]["content_sha256"], "gold_sha256": before[str(GOLD.relative_to(ROOT))]["sha256"],
        "selected_sent_quote_support": pre["gold"], "native_failure": json.loads((RUN / f"{RUN_ID}.native-failures.json").read_text("utf8")),
        "claims": claims, "gold_semantic_coverage": coverage, "sent_exact_value_aliases": exact_occurrences,
        "table_scope_observations": {"city_values_sum": 3926, "overseas_region_values_sum": 2487,
                                     "comparative_2023_totals_pointer": "e5", "2024_mainland_total": 4386, "2024_overseas_total": 3118,
                                     "three_header_two_body_value_groups": ["g4", "g5", "g6"]},
        "english_only_citation_chinese_output_claims": ["c2", "c4", "c5", "c12", "c14", "c15", "c18", "c19", "c20"],
        "limitations": ["No actual native failing span/cause retained; cannot assert exact original replay failure cause.",
                        "No published Bundle or failure-review source snapshot found in execution directory.",
                        "Table raw input preserves values but inadequate native column mapping; original2024 figures not reconstructed.",
                        "Gold exact7504 field differs from its permitted approximate quote alternative; no silent target edit.",
                        "Chinese Simplified vs Traditional is not equated to wholesale foreign-language output.",
                        "This artifact does not certify full-source recall or RF financial/model quality."],
        "activity": {"new_api_calls": 0, "original_opens": 0, "original_parses": 0, "source_test_pwf_git_writes": 0},
        "protected_before": before,
    }
    after = {str(p.relative_to(ROOT)): fp(p) for p in protected}
    result["protected_after"] = after
    result["review_inputs_unchanged"] = before == after
    assert before == after
    result["canonical_decode_scope"] = {
        "raw_claim_count": 20,
        "invalid_declared_group_claims": [c["claim_id"] for c in claims if c["group_members_missing_from_explicit_citations"]],
        "rule": "narrative_model._validate_group_declarations: summary claim evidence group coverage is incomplete",
        "policy": "decoder can discard individual claims and retain a needs_review draft",
        "actual_canonical_claim_count": None,
        "reason_unknown": "Successful summarize result was not retained before verify failure cleanup; do not call all20 accepted."
    }
    out = OWNED / "review-resolved.json"
    if out.exists():
        raise RuntimeError("do not overwrite earlier independent review")
    out.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf8")
    print(json.dumps({"decision": result["status"], "claims": len(claims), "actual_posts": 1, "gold_quote_support": "7/7", "inputs_unchanged": before == after}))


if __name__ == "__main__":
    main()
