# HK DeepSeek v2 — independent actual-summary review

**Decision: QUALITY_FAILURE; no published Bundle.** This is the actual `live-20261014T224413-922d46`, not the earlier zero-POST HK failure. Review uses retained input/final/events/usage/failure artifacts and existing gold only. No original open/parse, API/model call, source/test/PWF/Git edit.

## Actual execution and source scope

- Run `phaseC-090-76236609f71c`, model attempt `7e85d4a23b5d473eb59c8baeff651b62`: **1 real POST** to configured `deepseek-flash`, thinking disabled, max_tokens8192, temperature1.0.
- Known13,332 input +1,755 output =15,087tokens;6,785µUSD budget proxy, not invoice. Full valid JSON final has20 raw claims and6,307bytes; exact final SHA `1324c5685770fbabf2269e105b8a43b64c709a84800563ee50a895fd49c80756`.
- Actual HTTP body55,551bytes, SHA `0fc9020b40f9c4ecf10cdf231466eaf2887124daa494e160a0280466445cde53`; schema3, `reading-model-input/2`, claims-only response. **Omitting source/hash/language echoes is correct.**
- Source SHA `07f4937e0558fc31189a56236313ad93c1cef4182adb10ebaf4f355acb9bf1cf`,2,230,253bytes; registered mixed English/Traditional Chinese. Gold SHA `10f9e3b98d1fc99d49c1edf2abba025f8ea3ea060916aac8430a6732fb78c5b7`.
- Actual selected/sent material:96 evidence rows,57 groups,22,455characters; partial coverage with unread/deferred content recorded. Canonical source quote oracle says **7/7** required supported. This is not a summary quality score.
- Actual document failed **LOCATOR_REPLAY_FAILED**, after model response/summarization. Native failing attempt `3310d15839724e04a736c873734759d7`, job `137aafcc06826c11`, error detail exactly `selected evidence replay could not complete`. No artifact Ref/Bundle published. Original/config/sentinel protected receipts pass and isolated lake was removed.
- Failure-review snapshot / canonical summary / complete generation / native locator map were **NOT_RETAINED in this execution**. ROOT has fixed future harness capture, without rewriting this old packet. Native error cause/failing spans cannot be fabricated from aliases or current code.

Artifacts are under `.planning/shared-reading-production/live/owned-runner/receipts/live-20261014T224413-922d46/`. Actual request/final live in `materials/`; `review-resolved.json` in this review directory holds all20 raw claim texts/citation pointers, seven gold observations and protected artifact hashes.

## Per-claim findings

Citation aliases below refer only to the **actual sent envelope**. The draft is not a published canonical summary. Content support and citation-protocol acceptance are different checks.

| Claim | Actual support and finding |
|---|---|
| c1 | e1/e3 support2013 start, two brands and refreshed lifestyle products. No subject/count/state error observed. Output is Simplified Chinese; source Chinese lane is Traditional. |
| c2 | e4 supports date and approximate over7,500 / nearly4,400 / over3,100. The summary correctly preserves approximation, but does not provide exact regional counts. e4 is English-only; output Chinese is a per-citation language change. |
| c3 | e26/e28 support overseas503 direct +2,615 partner/distributor at2024year-end. Extra geographical g3 is unrelated. **P2 citation-contract error:** it declares g3 but omits e31/e32; current decoder rejects this individual claim (`summary claim evidence group coverage is incomplete`). It must not be counted as retained merely because its numbers are right. |
| c4 | e6 supports TOP TOY network since2020, overseas expansion since2024, total276/mainland272 at2024year-end. No completed revenue/profit is invented. English-only cited paragraph, Chinese output. |
| c5 | e10 supports mainland MINISO25 direct/26 distributor and TOP TOY38 direct, remainder partner model. Mainland scope is preserved; not the worldwide TOP TOY40 direct count. English-only citation, Chinese output. |
| c6 | **P1 wrong-year assignment with strong internal evidence.**522+1,617+1,787=3,926, exactly the2023 mainland total in e5;2024 total in e5 is4,386. g2 body e23 has only one numeric column under2023/2024 headers. It does not support claiming these city counts as2024. |
| c7 | **P1 wrong-year assignment with strong internal evidence.**1,333+172+552+231+199=2,487, exactly2023 overseas total in e5;2024 total is3,118. g3 has two year headers but only one numeric body column. Same common defect as c6. |
| c8 | **P2 unsupported period/column binding.** g4 has three headings (six months2023 / twelve months2023 / fiscal2024) but body e41 has only two values per metric.13,035 /30–35% /37.6 are visible, yet their assignment to2024 is not established by the retained structure. Do not reconstruct missing2024 values or claim an exact original-page error without native mapping. |
| c9 | **P2 same period/column defect.** g5 has three headings and two values per metric.10,989 /25–30% occur, but2024 association is unproven. Currency RMB/million is copied consistently; year binding remains the issue. |
| c10 | **P2 same period/column defect.** g6 likewise has three headers and two numeric values per row.814 /45–50% /121.3 occur without adequate2024 alignment. e49's1,410.4 is multi-channel TOP TOY brand GMV, a different scope; do not substitute it for store-only GMV. |
| c11 | e49 supports2020-12 launch and FY2024 multi-channel RMB1,410.4million GMV. No million/亿 or store-vs-brand scope error observed. |
| c12 | e24 supports42/64 **Retail Partners** in2023/2024, not42/64 TOP TOY stores. Summary wording remains partner/operator count. English-only citation, Chinese output. |
| c13 | e25/e27 support direct/partner/distributor operating modes and possible partner↔distributor conversion. No all-direct-store inference. |
| c14 | Amount RMB6,270,118,134,29.4%, subsidiary actor, signed2024-09-23 and target821outlets at2024-09-30 match e56. **P2 mixed-state precision:** modality planned also wraps actual agreement signing and existing target stores. Separate signed agreement from pending acquisition completion; do not imply the acquisition completed in2024. English-only citation. |
| c15 | e57 supports subscription agreement **for issuance**, USD550million, cash settlement, expected2032-01-14 maturity and USD8.2822/share. **P2 wording/state precision:** actual agreement signing must not silently become completed securities issuance. No observed currency conversion error. English-only citation. |
| c16 | e90/e91 support post-period2025-03 completed29.4% acquisition and paid RMB6,270,118,000. Target is generic in its cited text; do not invent another identity. The134RMB difference from c14 exists in the source excerpts, so it is not a model-created currency error. |
| c17 | e59/e60 support FY2024 margin44.9% and the overseas product/direct-operation mix and TOP TOY product-mix causes. Useful financial-note business explanation, not a reason to drop the whole passage. |
| c18 | e61 supports overseas direct total505, doubled revenue, related expenses+72.2%. Retain company-wide wording:505 is not automatically the same brand scope as MINISO503 in c3. No invented contradiction is asserted here. English-only citation, Chinese output. |
| c19 | e71/e72 content supports actor, procurement agreement and renewal dates through2026-12-31. **P2 citation-contract error:** g17 declared but e70 omitted; current decoder rejects this individual raw claim. English-only citations, Chinese output. |
| c20 | e75 supports distinct less-than30% totals for five largest customers' revenue and five largest suppliers' purchases. No single-counterparty or equal30% inference. English-only citation, Chinese output. |

### Raw20 is not accepted20

`narrative_model._validate_group_declarations` requires explicit member coverage for a declared group. c3 lacks e31/e32; c19 lacks e70. `decode_model_draft` catches individual claim errors and can keep the remaining claims in a needs_review draft. This explains how summarize can succeed despite those two raw protocol errors. **The exact canonical retained claim count is unknown because its result was not captured.** Do not assert either20 or18 as an observed accepted count.

The first inspection script initially asserted all declared groups were complete and failed. That incorrect inspector assumption was removed; the actual omissions remain in the earlier `review.json` and `review-resolved.json`. This was a review-tool finding, not a repaired provider response.

## Fixed7gold /6critical

| Gold ID | Semantic coverage in raw final |
|---|---|
| f-store-total-2024 | **Approximate alternative correctly expressed by c2.** Gold OR permits “network of over7,500”, while must_preserve asks7504. No sent alias contains7,504/7504, so exact-target coverage is partial/not sent, not a model-only omission. Do not ask the model to invent or calculate7504. |
| f-store-mainland-overseas | **Partial:** c2 gives nearly4,400/over3,100; exact4,386 and3,118 are available in e5 but omitted from the summary. c3's503+2,615 is not an explicitly stated3,118 and no arithmetic is backfilled. |
| f-store-operating-model | Full content in c5/c13 independently of rejected c3: direct, Retail Partner and distributor modes preserved. |
| f-top-toy-total | Full in c4:276 stock at year-end, not additions. |
| f-top-toy-mainland | Full in c4:272 mainland, not worldwide or overseas. |
| f-top-toy-overseas-commenced | Full in c4:2024 expansion start, not realized revenue/profit. |
| f-store-network-approximate | Full in c2, approximation preserved. |

Strict exact-field accounting is **5 full +2 partial /7**, with one of those two limited by source/input scope. Critical exact-field accounting is4 full +2 partial /6. Under the explicit permitted approximate alternative, f-store-total is faithful; both views are reported without changing gold or its7/7 source quote result. Major quality failure also comes from **additional** c6/c7 assertions outside this small gold list; passing known gold cannot hide them.

## Language

The output is all Simplified Chinese, not English/Traditional bilingual. c2,c4,c5,c12,c14,c15,c18,c19,c20 cite only English substantive paragraphs and render them in Chinese. This is a **per-citation original-language fidelity gap** under the actual instruction “Keep the supplied source language / No translation”; a global mixed document label cannot prove those individual paraphrases preserve original language. Several other claims cite genuine Traditional-Chinese or bilingual rows, where Simplified vs Traditional is orthography within the same language family and is not equated to the previous MiniMax wholesale Spanish failure.

Do not use absence of a translation field or a program-supplied mixed header as proof of language fidelity. Short-text detector uncertainty remains diagnostic; this is direct independent comparison with actual cited prose, not a proposed universal single-claim confidence threshold.

## Exact responsibility and next evidence interface

### Publication failure

The exact error phrase is emitted by `NarrativeVerifyHandler._replay` after successful select/summarize dependencies. Path:

`automation/narrative_verify.py::_replay` → `automation/narrative_replay.py::replay_narrative_evidence` → `source_catalog/narrative_evidence.py::verify_pdf_evidence_spans_bytes` → pinned `parse_pdf_bytes` → shared source matcher → `_require_full_replay`.

Read-only source examination shows **no whole-document partial-coverage rejection** in this PDF path. The verifier does reparse original bytes for independent final proof; this review did not execute it. The generic wrappers erase the exact lower cause/failing span IDs.

A **proven static language-port gap** is present: PDF replay API does not accept/pass language and therefore uses parse_pdf_bytes default zh, while selection uses canonical source metadata mixed. `verify_native_range_span` requires rebuilt.language equal the selected span's language. This input records seven native_continuity groups. That gap is a concrete candidate consistent with this actual failure, but absent native snapshot/failed IDs prevent certifying it as the exact historical failing span. ROOT will use one bounded offline replay and the saved final, not another paid call.

Minimum future failed-verify capture: successful SelectResult + SummaryResult + actual frozen generation; job ID/type/outcome; actual source parser/language/table-page/native-range options; actual verified/failed IDs or bounded existing exception chain. Save from existing Store before Temp cleanup, without another parse or a second audit database. ROOT already assigned the harness extension; this review writes no helper/production code.

### Common quality roots

1. **Table carrier completeness and projection alignment:** source/sent g2/g3 bodies have fewer numerical columns than headers; g4–g6 have three period headers but two numeric values. A closed group is not automatically a complete typed row/period alignment. Source/projection should retain actual column identity, missing cells and scope, so the model cannot silently slide2023 data into2024. Use generic sparse/three-period tables in TDD, not store/company-specific repairs or larger caps.
2. **Model restraint:** incomplete period alignment must produce omitted/uncertain data rather than an asserted year. Correct headers mechanically included in a claim do not prove entailment. Preserve actual disclosed business causes and all relevant qualifiers.
3. **Duplicated citation declarations:** supported c3/c19 content is discarded because aliases and group membership are redundantly recited. ROOT's planned single citation-unit interface can simplify this; don't add another permission or repeated identity proof. Citation closure still belongs to the source; narrowing a claim must retain its real necessary support.
4. **Mixed-language handling:** choose the cited original lane per claim, not a global mixed-header shortcut. Keep existing finite observer as a diagnostic and test actual per-citation examples; no new manual approval chain.
5. **Coverage/priority:** source exact regional values and meaningful contract/revenue mechanics should not be displaced by unresolved comparison columns or routine financing. Do not require every selected row to become a claim or solve omissions by increasing20/96/48000.

SOURCE STOP for this independent review. `review_saved_hk.py` final execution exit0 verifies retained request/final SHA and unchanged input fingerprints; that exit means the **review tool ran**, not that the summary passed. Formal summary/native-locator/RF acceptance remains failed or not evaluated as stated.
