"""Finite read-only ROOT shared-budget review; no originals or APIs."""
from pathlib import Path
import sys
import json
from copy import deepcopy

ROOT=Path.cwd()
sys.dont_write_bytecode=True
sys.path.insert(0,str(ROOT/'src'))
from company_wiki.document_understanding.layout_bridge import bind_layout_context
from company_wiki.document_understanding.layout_hints.contract import WorkBudget
from company_wiki.document_understanding.profiles.observation import parse_observation
from company_wiki.document_understanding.profiles import route_document,get_profile
from company_wiki.document_understanding.profiles.registry import resolve_reading_profile,_bounded_observation

source={'source_id':'s','source_sha256':'a'*64}
structure={'source_ref':source,'sections':[],'semantic_units':[{'semantic_id':'x','completeness':'complete','member_unit_ids':[],'required_context_unit_ids':[]}],'coverage':{'complete':True,'limits':{'max_work_units':0}},'diagnostics':[]}
before=deepcopy(structure)
result=bind_layout_context(structure,{'source_ref':source,'groups':[]})
out={'standalone_zero_mutated_input':structure!=before,'standalone_before_completeness':before['semantic_units'][0]['completeness'],'standalone_after_completeness':structure['semantic_units'][0]['completeness'],'standalone_return_completeness':result['semantic_units'][0]['completeness']}

class CountList(list):
    def __iter__(self):
        for item in super().__iter__():
            self.visited+=1
            yield item
diagnostics=CountList({'code':'KNOWN','unit_ids':[]} for _ in range(1000))
diagnostics.visited=0
shared_structure={'source_ref':source,'sections':[],'semantic_units':[],'coverage':{'complete':True},'diagnostics':diagnostics}
b=WorkBudget(0)
shared=bind_layout_context(shared_structure,{'source_ref':source,'groups':[]},work_budget=b)
out['shared_zero_diagnostics']={'visited':diagnostics.visited,'budget_used':b.used,'returned_diagnostics':len(shared['diagnostics'])}

units=[{'unit_id':f'u{i}','ordinal':i,'locator':f'loc:{i}','text':text,'kind':'paragraph','role':'company_filing','language':'en','hints':{},'layout':{}} for i,text in enumerate(['one','two','three'])]
observation={'schema_version':'du-input/1','source_ref':source,'metadata':{},'coverage':{'native_scan':'complete','opaque_pages':[],'deferred_pages':[]},'units':units}
prepared=parse_observation(observation,{'max_probe_units':1,'max_probe_chars':1})
route=route_document(prepared)
resolved=_bounded_observation(prepared,route,None)
policy=resolve_reading_profile(get_profile(route['profile_id']),prepared,route)
out['implicit_policy_widens_prepared']={'input_probe_ids':[u.unit_id for u in prepared.probes],'input_chars':prepared.probed_chars,'resolved_probe_ids':[u.unit_id for u in resolved.probes],'resolved_chars':resolved.probed_chars,'policy_probe':policy['policy_probe']}
scoped=_bounded_observation(prepared,{**route,'unit_ids':['u2']},None)
out['implicit_subscope_reopens_unprobed_text']={'parent_probe_ids':[u.unit_id for u in prepared.probes],'child_probe_ids':[u.unit_id for u in scoped.probes],'child_chars':scoped.probed_chars}
out.update(api_calls=0,original_reads=0,source_test_git_writes=0)
(Path(__file__).parent/'probe-results.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(out,ensure_ascii=True,indent=2))
