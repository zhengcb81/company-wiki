# 统一准备/共享WorkBudget tranche 独立审查

2026-10-16，`attribution_release_review`。当前ROOT八份责任源、`test_prepared_source_budget.py`及原集成测试替身差异；不审作者目录。本报告不把尚未承诺的structure/strategy整链硬限作为门禁。当前`work.scope=layout_preparation_and_binding`、`full_pipeline_hard_bound=false`的范围标识诚实，保持。

## 结论

**REQUEST_CHANGES：3个已复现P2，共同责任为失败路径的借用/复制边界及prepared预算继承。** 没有发现P1或来源ID/角色被改写的证据。只运行自有小型内存探针，不重复1045项套件；该既有1045PASS/11SKIP由ROOT报告，不能替代这三个未被现测试覆盖的行为。

完整实测为`probe.py`和`probe-results.json`。0原件读取、0native parse/API、0源码/测试/PWF/Git/作者写；报告目录是唯一写入。

## R1 / P2：standalone零预算失败路径修改原输入

责任：`layout_bridge.py:194–239 bind_layout_context`。

新实现先构造共享semantic的浅result，再`budget.charge()`，之后才执行standalone deepcopy。coverage中合法`max_work_units=0`使charge直接抛出，catch又对`result.semantic_units`逐项写`completeness=partial`；此时仍是原输入对象。以前是先deepcopy后进入预算，未改输入。

实测一条semantic：调用前`complete`，调用后**原structure也变partial**；返回partial本身正确，原输入改变错误。现有`test_zero_binding_budget_has_no_deepcopy_or_exception_tail_scan`只覆盖显式shared实例，`test_standalone_layout_returns_independent_nested_view`只覆盖apply入口，均未保护这个standalone binding分支。既有bridge零限测试只断返回partial，没有断输入不变。

最小修复：standalone的独立结果必须在任何可能修改它的成功/失败路径上存在；可保持原独立物化契约并在charge前clone，或失败路径构建真正独立的semantic projection。shared路径不要为此恢复全文deepcopy。先RED同一实际standalone输入的before/after及返回partial，再修owner，不改旧limit=0语义。

## R2 / P2：shared零预算仍全量复制旧diagnostics

同一函数在首次charge之前无条件执行`list(structure.diagnostics)`。实测CountingList 1000条，`WorkBudget(0)`：实际**visited=1000、budget.used=0、返回diagnostics=1001**。这是本次binding工作范围内的实际复制，不是structure未承诺硬限的问题，也不是假设极端dict类型才出现。

最小修复：共享分支先建立常量级壳并检查预算，变长diagnostics/semantic容器的遍历和物化也沿唯一预算逐项进行；耗尽只产有界的新失败诊断，不为了返回全部旧诊断再扫描。原structure保留其原诊断以供所属层读取，不对借用list append。standalone维持独立完整投影，与R1共同处理而非在两处分散补丁。对coverage等复制也按其实际可变大小核边界，不能简单把全部深复制换成多个未计费浅复制。

## R3 / P2：prepared原probe限额在resolver缺省参数时被放宽

责任：`profiles/registry.py:220–242 _bounded_observation`；`profiles/observation.py:266–280`的prepared支持本身保留缺省限额，但registry提前以`Limits.from_mapping(None)`创建了默认值。

实际原文仅三个单位one/two/three，先`parse_observation(...max_probe_units=1,max_probe_chars=1)`。`route_document(prepared)`正确维持一个probe/一个字符；随后同一prepared调用`resolve_reading_profile(...limits=None)`，实际policy_probe成为**3单位/11字符/limited=False**。调用内部真正`_bounded_observation`也得到同样扩大。子scope只含u2、未显式传limits时，又变成5字符而非继承1字符限额。

这不是禁止child有自己的明确探测，也不是要求所有子scope只能沿父probe集合；错误是“省略limits”隐式重开默认预算，使route和policy不再消费同一受界观察，违背resolver现有docstring与本次复用设计。当前生产pipeline显式传相同limits通常不触发，但新的prepared公开组合接口和子scope能触发，属于真实行为遗漏。

最小修复：当输入为prepared且limits省略时，先继承`observation.probe_limits`再做原固定cap收紧；显式limits仍按原语义处理。scope内重新分配probes沿继承/显式限额，保留原序、actual form resolved值与parent隔离。不要通过重新_parse_units全量构建修复，也不删现负数/布尔limit类型检查。

先RED：prepared1/1→route→policy缺省仍1/1；scope=单u2但省略limits仍≤1字符并marked limited；显式更紧0仍无probes；显式旧Mapping/default和原child范围正控保持。

## 已核正确方向和不扩大审查范围

- 0.9生产选择入口在分parent前拥有实例，_understand逐parent传递同一预算；预算0有真正早退出，未调用分类/完整映射路径。旧默认/0.8入口仍走原分支。
- pipeline有薄deferred结果、source_unit_count且不为失败枚举全部ID；shared layout不再整棵deepcopy，hint缺失不再KeyError；shared binding先构造requirements再提交，不发布半依赖图。这些方向应保留。
- standalone apply保持原独立nested返回，现正控覆盖；prepared类型保留单位对象、source角色/ID/locator，不引入全局cache/新source registry/任务库。
- layout parse预先按unit/字符与排序成本charge；它内部耗尽返回已建Doc，后续coverage读取`budget.exhausted`，未见将其签成complete的证据。bridge对耗尽整体defer。是否进一步优化页内已付费但尚未物化条目属于后续效能设计，本报告不据此新增阻断。
- adapter基础O(N)物化、profiles分层扫描、structure/strategy/package算法仍有原工作；已有scope明确未称全链硬限，本报告不要求本节点完成这些重构。不得反过来用这一范围声明豁免R2的binding已承诺路径。
- `analysis_status=complete`不能被理解为真实文档完整、语义正确或正式摘要已完成；现有coverage/源状态与母PWF仍负责这些判断。
- 多parent合成仍deepcopy首part，当前范围不包含全选择图复制，列为已声明后续项即可；本次不因它要求增加审批门或重跑大PDF。

ROOT可在这一个集中节点修复R1/R2共同ownership边界与R3继承规则后，用上述小反例和已有相关测试一次验收。不需要再次跑全原件、修改生产配置或追加逐小点人工审查。最终源码指纹见`handoff.json`，当前结论仅针对本快照。
