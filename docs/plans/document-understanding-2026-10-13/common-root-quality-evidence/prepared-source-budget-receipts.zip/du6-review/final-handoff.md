# 统一准备/共享WorkBudget tranche：最终独立复核

2026-10-16，`attribution_release_review`。

**PASS_TRANCHE：首轮3个P2已关闭，在本轮声明的layout preparation/binding及prepared复用范围内未发现剩余阻断。** `full_pipeline_hard_bound=false`保持；不是structure/strategy/candidate整链硬限或DU4/v4正式语义验收完成。

## 同一反例的实际复验

只在内存改变原probe的输出文件名为`final-probe-results.json`，测试逻辑与样本不变，未扩样/重跑全套；原`handoff.md/json`与`probe-results.json`首RED完整保留。

|问题|首轮实际|最终实际|
|---|---|---|
|R1 standalone零预算借用原semantic|原输入complete→partial|原输入仍complete；独立返回partial。|
|R2 shared零预算先复制diagnostics|visited1000、used0、返回1001诊断|visited0、used0、只返回1条新耗尽诊断。|
|R3 缺省resolver隐式放宽prepared|prepared1unit/1char→policy3units/11chars|policy仍1unit/1char、limited=true。|
|R3 子scope继承限额|u2文本5chars|u2仅1char，继承已有cap。|

子scope可以在明确范围内独立探测，最后一行不是要求子probe只能属于父已选probe；修复的是缺省额度不能续开。最终逐字段断言与8源/2测试SHA在`final-handoff.json`。

## 源码复核

- standalone binding现在在可能失败/修改前创建独立clone；shared分支不因此恢复整文deepcopy。
- shared binding先charge，prior diagnostics按实际长度预留再物化；耗尽结果只补新有界诊断并保留prior_diagnostic_count，不扫描尾部。
- registry在输入为prepared且limits省略时继承其probe_limits，再沿原固定cap处理；公开Mapping/default和显式limits规则未被替换为新默认表。
- ROOT报告先留3FAIL/11PASS行为RED、修复后集中224PASS。此为ROOT执行证据，本审查仅独立执行上述同一纯probe及字段断言，不冒充重跑224项。

本次0原件、0native parse、0API；只写独审目录，未改源码/测试/PWF/Git/作者。首RED前源码SHA未及时捕获，原报告已诚实标注；最终SHA仅绑定本次冻结最终源，不倒写成首RED指纹。

现节点可继续正常提交/发布。原有真实端到端、旧0.8/已付费恢复及母PWF后续节点仍各自按计划执行，不新增小节点审批。
