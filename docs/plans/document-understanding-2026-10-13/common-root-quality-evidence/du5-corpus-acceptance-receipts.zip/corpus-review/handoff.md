# DU5-CORPUS 独立接收审查

2026-10-16；`attribution_release_review`。作者树 `company-wiki-du5-corpus`，HEAD `3558fd507c76411bae0ab423e53d34f267833c7d`，基线 `8c027011037dc8c8659235fb65f529028dcd15ca`；正常host只读Git status干净。沙箱Git无法切换目录的Permission denied已用正常host只读命令核验，不是作者仓损坏。

## 结论

**REQUEST_CHANGES_BENCHMARK：新增语料和诚实的生产FAIL有价值，尚有两类共同责任遗漏需要ROOT接收修复。** 不以9份native的8 FAIL/1 PARTIAL否定交付，也不要求其修生产算法；阻断项是金样负例仍惩罚合法精度表达，以及锚点完整性测试对未覆盖范围签发PASS。

本审查没有读取原件、重跑PDF/native/全套、调用网络/供应商或修改作者树。只执行ROOT独审目录的有限纯探针（一个小合成文本Temp已删除），并读取已保存收据、已提交Git blob。源码指纹见`handoff.json`。

## 需要修复

### C1 / P2：v2负例仍把正常四舍五入列为事实错误

位置：`gold/du5-cn-proya-q1.json:130–135`；`gold_corrections.json:102–116`；对应作者`tools/apply_review_corrections.py`。

已保存gold原数为`2,305,344,625.43元`。新`must_not_assert`又加入`营业收入23亿元`、`营业收入2,305,344,625.4元`。它们分别是原金额按亿元取零位小数、按元取一位小数的正常四舍五入，不能作为币种/数量级或数字捏造的通用负例。即便要求保留精度，省略精度与错误事实也应分开，不应把此两句本身列为永远不能断言。

纯探针在实际`check_basis_fact`上确认，两句均产生对应`must_not_assert_violated`（同次结果还有missing-required-token；本报告不声称其他检查全部通过）。Decimal计算分别得到23和2305344625.4。由于匹配跨claims搜索，即使摘要明确写“约”或同时给出精确原数，出现被禁短语仍会触发负例。

根因不是该公司，而是“审查发现真命题负例后，又以精度偏好替换成另一个可为真的负例”。建议将这两项作为正式版本更正删除/改为明确错误的期间、方向、数量级或币种命题；若存在精度要求，单列precision警告/要求并支持明确舍入。保留v1/v2旧值、版本记录、support anchors与importance/target_kind和原37 critical分母，不看候选改金样。增加正确带约数正控和真正错单位/错期间负控；无需逐fact人工审批。

### C2 / P2：锚点验证范围不闭合，单项例外扩大成整sample免检

位置：`tests/test_gold_anchor_integrity.py:153–164`，`gold_corrections.json.unverifiable`。

unverifiable先只取`sample_id`组成set，命中后直接continue整份record。可是`holdout-cn-glodon-q1`只登记`h-ifrs-not-audited`字形差异，`us-20f`只登记`f-not-a-discontinued-operation`的XBRL边界差异。其他可检查fact/anchor也被全部跳过。

有限反例直接调用该现有测试函数，仅替换本次内存输入：Glodon保留已登记例外，再加入独立`page 999 / absent`坏锚点。结果测试正常返回PASS、`verify_gold_anchors`实际调用**0次**。这不是对作者真实原文的错误指控，而是完整性保护本身可被确定性绕过；不能用245绿测试宣称所有旧锚点持续受保护。

同一责任层还有两个精确度缺口：

- `tests/anchor_verify.py:77–115`不消费`source_sha256`；持续real_data测试只读本地binding路径，未用现有`resolve_original`。实际小合成文件SHA与gold全0 SHA不同，quote相同仍`ok=True`。**freeze脚本:403–407当时确有SHA校验**，原native CLI也验SHA；本问题针对今后的独立锚点回归，不能倒推说此次原件身份错误。
- helper只区分document/page；page=None一律搜全文，`location_kind=line,line=999`仍可因为quote在另一行返回`ok=True`。纯内存反例正文第二行`Revenue 100`，声明line999，实际ok=True。当前DU5主要page/document锚点不因此自动无效，但卡上的“错页行”机制尚未覆盖行。

共同修法：沿唯一锚点校验owner，先复用现`resolve_original`确认本次真实字节（尽量只读一次并复用，不新增多重签收），按真实location_kind核对支持的page/line/locator；不支持的定位给unverified，不能退回全文却称定位正确。例外精确到sample/fact/set/anchor或明确声明整source不可独立读，保留可读其余项验证；输出checked/excepted/unresolved计数。用纯控制证明：例外仍可保留、其他错anchor会失败、错SHA不签发锚点PASS、错行不接受。仍不涉及修改旧gold原字节/分母。

## 已独立确认的正面证据

1. **9份现gold的真实工作区字节SHA、Git HEAD blob SHA和manifest全9/9一致**，support_set_digest重新计算9/9一致。当前`.gitattributes`通用benchmark JSON `text eol=lf`与这些LF JSON冻结一致，没有逐sample特判。已保存fresh-checkout收据是v1珀莱雅`a7b9...`的现场，不能冒充v2；本审查另以当前Git blob直接确认v2 `1eb273...`与manifest一致，未创建checkout/改Git。
2. 基线→HEAD的gold目录差异只有9个新增`du5-*`，旧20份gold未修改；3个旧错页保留proposed更正和旧字段，不在本卡静默应用。
3. 新集7公司、CN/HK/US、9载体/形态；100事实、193锚点，required-business critical合计37。纯财务珀莱雅0 required-critical是按声明目标冻结，不是测试后删除业务事实；其correctness_if_emitted事实仍保留。
4. 两份已保存native报告均9样本、critical **12/37=0.324324**、unavailable=0、not_evaluated-critical=0、8 FAIL/1 PARTIAL；所有claims空。新旧未混算，原FAIL保持。v2更正仅负例/modality不会把没有claim的native基线洗绿，两个收据确实同分母同结果。
5. coverage五轴将original/gold/readable/selected/summary_reviewed分开；name-only、乱码可选但不可读、无摘要都明示。HK季度与8-K/exhibit只增加真实载体覆盖，不能替代6-K/S-1/amended缺口。summary_reviewed=no没有冒充语义验收通过。
6. 污染记录明确Kingsoft/Microsoft不能称新公司泛化，后续样本参与修规则需转regression。中密等已知历史材料在why中公开；fresh是该基准内容未用于调规则的范围，不能扩张为公司历史上从未被任何项目阅读。未知历史不由本审查认证。
7. 保存native恢复收据两份均raw/config unchanged和sentinel restored，0网络/模型/付费。本审查未再次读取生产config或原件验证这些恢复主张，只检查已有证据。

## 非本卡新增的效率债与证据范围

现有native成功链每source仅调用一次`_parse`，两轮9份对应18次native观察；没有发现本卡新加第二parser。**一次parse不等于一次文件读取**：当前CLI成功路径会resolve SHA、before fingerprint、observer SHA、parse read、after fingerprint、resources size fingerprint，共6处完整读字节/哈希入口。最后为size重算hash尤无必要；这是未改动既有代码中的共同效率债，非本卡新增阻断项。此处为静态调用计数，不伪装成独立真实I/O测量。后续可复用已验证同一payload与stat尺寸，保留原件前后验真职责，不要再叠一个验真器。

锚点独立helper目前对PDF每次验证整份get_text；两个real_data测试会重复提取新9份，旧错页更正每项又全提取。可在该次只读验收调用内按已验证SHA共享提取页视图，不持久全文、不将生产parser输出当独立来源；不要求本次为效率重写parser。

本文没有确认193个真实原文语义/定位正确，只有作者冻结与阅读收据及有限机械检查；没有因schema、native可读或SHA一致就签发自由文本语义PASS。报告仅要求修C1/C2，不无限扩样，不新增小节点门禁。
