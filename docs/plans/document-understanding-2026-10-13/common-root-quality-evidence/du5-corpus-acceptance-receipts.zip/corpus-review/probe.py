"""Finite pure DU5 reception probes. Never reads originals or invokes parsers."""
from pathlib import Path
from decimal import Decimal, ROUND_HALF_UP
import copy
import hashlib
import json
import os
import sys
import tempfile

AUTHOR = Path('C:/Users/郑曾波/Projects/company-wiki-du5-corpus')
BASE = Path(__file__).parent
sys.dont_write_bytecode = True
sys.path.insert(0, str(AUTHOR))
from tools.document_understanding_benchmark.tests import anchor_verify as av
from tools.document_understanding_benchmark.tests import test_gold_anchor_integrity as integrity
from tools.document_understanding_benchmark.checkers import check_basis_fact
from tools.document_understanding_benchmark.contamination import support_set_digest

out = {'api_calls':0,'original_reads':0,'real_parse':0,'author_writes':0,'imported_from':av.__file__}
old_extract = av.extract_text_pages
av.extract_text_pages = lambda path: {None:'line one\nRevenue 100\nline three'}
try:
    fake = {'sample_id':'synthetic','source_sha256':'0'*64,'facts':[{'id':'f','any_support_sets':[[{'location_kind':'line','line':999,'exact_quote':'Revenue 100'}]]}]}
    out['wrong_line_accepted'] = av.verify_gold_anchors(fake,Path('never-read.txt'))
    # A missing path and arbitrary SHA are still accepted because extraction
    # is replaced; proves this helper never invokes source binding checks.
    out['sha_not_consulted'] = av.verify_gold_anchors({**fake,'source_sha256':'f'*64},Path('never-read.txt'))
finally:
    av.extract_text_pages = old_extract

# Scope a documented single-fact exception and inject a separate bad anchor.
# Call only the existing test function with pure stubs and an owned empty file.
with tempfile.TemporaryDirectory(prefix='owned-probe-',dir=BASE) as tmp:
    dummy=Path(tmp)/'owned-sentinel.txt'
    dummy.write_text('synthetic only',encoding='utf-8')
    sha_probe={'sample_id':'synthetic-sha','source_sha256':'0'*64,'facts':[{'id':'f','any_support_sets':[[{'location_kind':'document','exact_quote':'synthetic only'}]]}]}
    out['actual_synthetic_sha_mismatch_accepted']={'expected_sha':sha_probe['source_sha256'],'actual_sha':hashlib.sha256(dummy.read_bytes()).hexdigest(),'rows':av.verify_gold_anchors(sha_probe,dummy)}
    fake={'sample_id':'holdout-cn-glodon-q1','facts':[{'id':'h-ifrs-not-audited','any_support_sets':[[{'exact_quote':'glyph mismatch'}]]},{'id':'independent-unrelated-bad-anchor','any_support_sets':[[{'page':999,'exact_quote':'absent'}]]}]}
    seen=[]
    av.verify_gold_anchors=lambda record,path: seen.append(record['sample_id']) or [{'ok':False,'fact_id':'independent-unrelated-bad-anchor','set_index':0,'anchor_index':0,'where':'page 999','quote':'absent'}]
    old_load,old_bind=integrity.load_gold_dir,integrity._bindings
    old_env=os.environ.get('DU_BENCH_ALLOW_REAL_DATA')
    try:
        integrity.load_gold_dir=lambda:[fake]
        integrity._bindings=lambda:{fake['sample_id']:str(dummy)}
        os.environ['DU_BENCH_ALLOW_REAL_DATA']='1'
        integrity.test_all_gold_anchors_verify_or_are_corrected_with_evidence()
        out['fact_exception_skips_entire_sample']={'test_returned_pass':True,'verification_calls':len(seen),'unrelated_wrong_anchor':'page 999 / absent'}
    finally:
        av.verify_gold_anchors=__import__('importlib').reload(av).verify_gold_anchors
        integrity.load_gold_dir,integrity._bindings=old_load,old_bind
        if old_env is None: os.environ.pop('DU_BENCH_ALLOW_REAL_DATA',None)
        else:os.environ['DU_BENCH_ALLOW_REAL_DATA']=old_env
out['owned_temp_restored']=not Path(tmp).exists()

gold=json.loads((AUTHOR/'tools/document_understanding_benchmark/gold/du5-cn-proya-q1.json').read_text(encoding='utf-8'))
fact=next(f for f in gold['facts'] if f['id']=='q1-revenue-yoy-decline')
loc='loc:synthetic/page:1'
anchor=fact['any_support_sets'][0][0]
rounding=[]
for text in ['营业收入23亿元','营业收入2,305,344,625.4元']:
    observed={'sample_id':gold['sample_id'],'source_sha256':gold['source_sha256'],'selected_locators':[loc],'selected_evidence':[{'locator':loc,'page':1,'text':anchor['exact_quote'],'source_role':'company_filing'}],'claims':[{'text':text,'evidence_locators':[loc],'role':'company_filing','modality':'actual','quantities':[]}],'coverage':{'native_scan':'complete','complete':True},'semantic_units':[]}
    check=check_basis_fact(fact,observed)
    rounding.append({'claim':text,'check':check})
out['normal_rounding_marked_forbidden']={'source_amount':'2305344625.43','rounded_yi_zero_decimals':str((Decimal('2305344625.43')/Decimal(100000000)).quantize(Decimal('1'),rounding=ROUND_HALF_UP)),'rounded_yuan_one_decimal':str(Decimal('2305344625.43').quantize(Decimal('.1'),rounding=ROUND_HALF_UP)),'cases':rounding}

manifest=json.loads((AUTHOR/'tools/document_understanding_benchmark/du5_manifest.json').read_text(encoding='utf-8'))
frozen=[]
for row in manifest['samples']:
    data=(AUTHOR/'tools/document_understanding_benchmark'/row['gold_file']).read_bytes()
    raw=json.loads(data)
    frozen.append({'sample_id':row['sample_id'],'raw_sha_matches_manifest':hashlib.sha256(data).hexdigest()==row['gold_sha256'],'lf_sha_matches_manifest':hashlib.sha256(data.replace(b'\r\n',b'\n')).hexdigest()==row['gold_sha256'],'support_digest_matches':support_set_digest(raw)==row['support_set_digest'],'facts':len(raw['facts']),'anchors':sum(len(s) for f in raw['facts'] for s in f['any_support_sets']),'required_critical':sum(f['importance']=='critical' and f['target_kind']=='required_business' for f in raw['facts'])})
out['manifest_checks']=frozen
out['notes']='Synthetic anchors and recorded gold only; no independent original-source semantic review.'
(BASE/'probe-results.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'wrong_line':out['wrong_line_accepted'][0]['ok'],'sample_exception':out['fact_exception_skips_entire_sample'],'rounding':[r['check'] for r in rounding],'manifest':frozen,'temp_restored':out['owned_temp_restored']},ensure_ascii=True,indent=2))
