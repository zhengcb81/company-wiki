"""Pure repro of unselected fallback coupling; owns one disposable config."""
import json
import os
from pathlib import Path
import sys
import tempfile
import yaml

ROOT = Path(__file__).resolve().parents[5]
sys.path[:0] = [str(ROOT / 'scripts'), str(ROOT / 'src')]
from config import Config

os.environ['PYTHON_DOTENV_DISABLED'] = '1'
os.environ.pop('PYTEST_CURRENT_TEST', None)
os.environ['DEEPSEEK_API_KEY'] = 'scope-review-fixture-not-a-real-key'
rows = []
base = {'llm': {'provider': 'deepseek', 'model': 'configured-flash',
               'base_url': 'https://configured.example/v1', 'temperature': 1,
               'max_tokens': 8192}}
with tempfile.TemporaryDirectory(prefix='owned-', dir=Path(__file__).parent) as td:
    path = Path(td) / 'config.yaml'
    for name, value in [('absent', None), ('null', None), ('list', ['unused']),
                        ('str', 'unused'), ('bad_provider', {'provider': 'unused-invalid',
                                                           'usage_scope': 'unused-invalid'})]:
        raw = json.loads(json.dumps(base))
        if name != 'absent':
            raw['llm']['fallback'] = value
        path.write_text(yaml.safe_dump(raw), encoding='utf8')
        before = path.read_bytes()
        try:
            config = Config.load(path, validation_scope='llm')
            rows.append({'case': name, 'status': 'PASS', 'provider': config.llm.provider})
        except Exception as exc:
            rows.append({'case': name, 'status': 'ERROR',
                         'exception': type(exc).__name__, 'message': str(exc)})
        assert path.read_bytes() == before
Path(__file__).with_name('fallback-probe-rerun.json').write_text(
    json.dumps(rows, indent=2) + '\n', encoding='utf8')
print(json.dumps(rows))
