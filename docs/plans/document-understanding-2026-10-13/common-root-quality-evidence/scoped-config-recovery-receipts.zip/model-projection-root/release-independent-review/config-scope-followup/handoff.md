# Scoped configuration and pre-push follow-up — independent review

Date: 2026-10-15. Reviewer: `attribution_release_review`. Final reviewed `scripts/config.py` byte SHA-256: `78059cd84e89f5f976157b9b4e87b4f422a3c04cb519fc6ab607ec367e4dd7a6`.

## Final conclusion

**PASS for the scoped configuration and three pre-push fixture/adapter corrections.** Both independently reproduced scope defects are now closed by selecting the actual profile inside the authoritative builder. No new release blocker was found in this follow-up. ROOT still owns the real configured CLI/official QA E2E, full pre-push result, commit and exact-SHA remote CI; this report does not claim those have completed.

No production source, test, PWF, configuration or Git file was changed by the reviewer. All reviewer writes are in this report directory. No original financial document or actual secret was read. No provider calls were made.

## Findings, repair and confirmation

### CF-01 — unused fallback consumed in LLM-only scope — closed

The initial implementation returned early before search/schedule/paths parsing but still executed `fallback_raw.get(...)` first. With a fully valid selected DeepSeek profile, `llm.fallback: null`, a list or a string each raised `AttributeError`. The configured entry point did not catch this exception, so a real valid-primary request would traceback due to an unused component. `fallback-probe.json` and `initial-findings.json` retain that original failure.

The final builder receives the explicit requested provider in LLM scope, chooses primary/configured fallback/other known provider before construction, and does not parse an unselected fallback. Re-executing the same independently owned probe gives **all five cases PASS** in `fallback-probe-rerun.json`. ROOT did not hide the defect by catching `AttributeError` at the entry point.

### CF-02 — third-provider selection re-entered full builder — closed

The initial explicit OpenAI selection traced calls with `llm_only=true` followed by `llm_only=false`, rebuilding unused default search/schedule/downloader/paths. `provider-scope-probe.json` retains the observation. The final provider is already selected when `llm_for_provider` is reached; the independent final trace records **one LLM-only builder per load**, with no recursive full builder. See `selected-profile-after.json`.

### Selected profile and strict checks retained

The independent final probe also confirms:

- Selecting the configured MiMo fallback with no primary credential retains its exact configured model and endpoint, shared temperature/token settings and selected provider's narrative thinking policy.
- Explicitly selecting a disabled configured fallback still fails with `ValueError`.
- A missing selected MiMo environment key fails even when `PYTEST_CURRENT_TEST` is deliberately present. The previous pytest-based loose key validation is not used for LLM scope.
- Selecting a third known provider uses the same loader's provider defaults and shared generation settings, without inheriting the unused primary model or the unrelated configured fallback endpoint.
- The owned YAML bytes do not change, and projected model options contain no credential value.

The existing `NarrativeHTTPModel` remains responsible for finite URL, model name, token, temperature and request/response parameter validation before POST. This follow-up adds no model default table, provider retry, download allowance, budget bypass, source exemption or supplier call.

## Other reviewed corrections

- `narrative_summary_review_pilot.py` supplies the **measured source_id** in its evidence adapter. This gives the expanded common source-parent validator real input; it does not invent a second source identity.
- The native continuity test now checks exact context/view keys and that actual raw prose is not copied. Removing the broad substring test for `"text"` is appropriate because `context_evidence_ids` contains those letters but is an ID field. The production source behavior is not weakened.
- The selector binding test checks unavailable decoder rejection at the actual `validate_model_execution` boundary while allowing construction of a runtime that may only finish an existing publication. This matches the reviewed stage ownership; it does not permit a paid call with unavailable software.
- Default `validation_scope="all"` still follows the existing full-component building and validation path. Its previous pytest behavior remains unchanged; only the explicit LLM scope always requires the actual selected key. The new scope is finite (`all|llm`), with invalid scopes rejected.
- `Config` remains a compatibility dataclass containing inert default component objects in LLM scope. The unused **configuration payloads are not consumed or validated**, and those inert defaults perform no filesystem/network operation. This is not a second source/storage configuration mechanism.

## Evidence and limits

The reviewer read the current diffs and structural context, reproduced the two defects with isolated configurations, then re-ran their exact pure counterexamples and four selected-profile controls against the frozen repaired builder. Original failure receipts were retained. No full test suite or supplier/E2E run was repeated by the reviewer; ROOT's reported 74-case concentrated suite and its running E2E are separate evidence, not independently re-executed results here.

This review does not certify real supplier summary semantics, all possible malformed legacy YAML, all legacy `Config` consumers, generalized company E2E, or remote CI. It adds no small-step approval gate. ROOT can archive this report and proceed with the planned node-level acceptance and normal publish process.
