# AUDIT DU8 最终冻结实现独立终审

结论：**REQUEST_CHANGES（1项新P2接口组合问题）**。审查者未参与AUDIT实现/接收修复；不自修、不提交Git。此结论只对应下列已核验冻结版本，后续变更需针对性复核，不能沿用本报告签PASS。

## 冻结边界

- 接收树：`C:/Users/郑曾波/Projects/revenue-forecast-audit-du8-integration`。
- Git HEAD：`3ed248df06b2ba00e4f59d930647149ecc1f88af`，加ROOT未提交修复；源码/测试/文档共13份SHA均与`audit-root-repair.json`一致。
- `review_evidence.py`：`d0f6170487b9d904b72aa9c71cd53ffa3b9ce4bb14f5eb38d5f1edfb7e1fc64c`。
- `financial_measure_evidence.py`：`f2923990f1b61b3a9ad25d803ed60775530d8e8eb6bce795543c2dd998cdd668`。
- CodeGraph明确该接收树未初始化；已从交接指向的精确文件读结构，没有为只读终审另建大索引。外部Git沙箱拒绝访问后，正常宿主只读HEAD/status核对成功；没有Git写。

## 新发现：AUDIT-FINAL-01 / P2

**已解析的复合primary locator在显式null字段复用时丢失原reader语义。**

位置：`financial_measure_evidence.py::audit_measure_evidence`的`if pointer is None: pointer = reference['locator']`，随后调用`reader.json_value(..., pointer, exact=True)`。

原reader的`split_locator/locator_shape`接受`source.json#/value`，能从同一文件真实解析`/value`；但adapter把完整复合字符串再当JSON pointer传下去。结果：

| 同一源字节`{"value":0.3}`，声明0.3 | primary reference | 字段value=null | overall |
|---|---|---|---|
| locator=`/value` | OBSERVED/file_pointer/Decimal | MATCH | MATCH |
| locator=`source.json#/value` | OBSERVED/file_pointer/Decimal | UNRESOLVED，result_pointer_invalid | UNRESOLVED |

预期：文档明确null复用primary locator，两个既有合法primary形式应使用原reader的同一split结果，不能把解析成功再变失败。它是合法引用漏检，**不是假数字误PASS**。证明见`audit-final-pointer-composition.json`；仅两个小型实文件控例，owned Temp已删除。

建议：在所属边界复用既有`split_locator`或reader归一化port得到的实际pointer，保持null含义；非法非字符串/空字段不得借这个修复回退到便利值。不要新增第二pointer parser、放宽pointer预算或新增许可。请ROOT保留该RED，补复合locator/null阳性和原坏pointer阴性后修复。

## 已独立检查通过的范围

1. 12项有界组合控例实际运行，0失败：精确0.30000000000000004与声明0.3不匹配；0.3正例；超过2^53的整数保持精确；JSON escape pointer；同字段收紧token上限；valid+malformed+重复ID全部4项留分母、有效项继续；同目标不同field map的A/B/A冲突不复活；非字符串pointer不回退；重复JSON成员/非标准常量不升级；共享reader缓存后超时不MATCH且files_read仍1。
2. 代码与ROOT控例检查：ledger真实字节exact decode与对象逐类型/Decimal核对，map不能用另revision字节证明当前对象；完整artifact/locator/fields/SHA冲突比较；原malformed map digest不产生干净overall MATCH；被拒/缺失/容器/自由文字仍unknown，不数值正则造事实。
3. JSON exact/cache/time/pointer归原EvidenceReader，未另建reader、文件库或预算；同reader每artifact/hash/exact mode复用解析；比较后亦检查时间。当前缓存是一次reader快照，不假称每字段重新核验当前磁盘。
4. 逐row local_fields聚合取代全局反复扫描；重复ID membership为set。源码未把全部row MATCH升级为经济意义真值；semantic_source_truth/source_truth_verified恒false，economic_reasonableness未评价。
5. 旧`financial_measure_audit.py`完整AST（含既有CLI/main和数学逻辑）与author HEAD一致。原reader默认exact=False路径保留；当前真实legacy全套结果由ROOT负责，未把其历史40项通过说成本审查新跑。
6. 本包是可选报告诊断，未引入授权JSON/人工签收/新的发布或访问许可链。显式root/预算仍是本工具局部实读范围与资源事实，没有扩展成公司身份验证。

## 实际验证与清理

- `audit-final-probes.py/json`：12项独立控例，0失败；原ledger/map/source输入前后不变；旧math/CLI AST一致。
- `audit-final-pointer-composition.json`：上述P2对照，1阳性MATCH、1合法形式误UNRESOLVED。
- 0网络/供应商/真实公司资料/原件复制；所有自有Temp删除、sentinel不变；未写AUDIT源码/测试/Git或作者树，未进入RF/DU9工区。
- ROOT完整unittest已经在独立运行，本审查不重复整套；本报告不代签其结果。

下一步：ROOT修复AUDIT-FINAL-01后冻结新SHA，再做该组合与坏pointer/预算边界的小范围独立复核；不新增小节点审批流程。
