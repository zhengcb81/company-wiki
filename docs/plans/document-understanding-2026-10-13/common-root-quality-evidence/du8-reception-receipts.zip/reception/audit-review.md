# DU8 AUDIT independent review — original delivery findings

## Scope and decision

Read-only review of **3ed248df06b2ba00e4f59d930647149ecc1f88af** in the ROOT integration checkout. **Two P1 and three P2 common-root issues need ROOT disposition.** Original author PASS/review prose was not treated as evidence. ROOT has already begun repairs; reviewed source SHA inventory is frozen from the original Git blobs below, not attributed to later WIP.

No source/Git writes, network/supplier calls, author-tree access, DU8-RF or DU9 work. The only writes are this CWP review package and owned Temp synthetic files; temporary root was removed. CodeGraph ignored the requested external project and returned CWP symbols, so known target files were read directly. Sandbox external Git entry failed; approved normal-host read verified HEAD and initial status (only ROOT test untracked before probes).

## Reproduced findings

### AUDIT-I01 — P1: JSON floating decode loses source precision before exact-value comparison

- Location: `review_evidence.py:365 -> financial_measure_evidence.py:375/450`.
- Expected: The distinct byte literal 0.10000000000000001 must not MATCH a declared exact 0.1. Preserve decimal lexical precision or report not comparable.
- Actual: Existing reader json.loads produces float 0.1; adapter reports normalized 0.1, MATCH, declared_field_match=true.
- Shared root: Structured JSON decode uses binary float before the new exact financial comparison; precision is irreversibly lost in the shared reader port.
- Repair direction: Add a backwards-compatible precise structured-value port at existing EvidenceReader boundary, using one reader/budget/parser policy; adapter consumes it. Do not repair only this number or add a second numeric regex/parser.

### AUDIT-I02 — P1: Malformed and duplicate declared observations disappear from coverage denominator

- Location: `financial_measure_evidence.py:178-214`.
- Expected: Two declared entries must remain counted; malformed/duplicate-ID entries must be diagnosed and must prevent a clean full-set field match. Continue valid row diagnostics.
- Actual: [valid r, malformed string] is reported as observations_declared=1, matched=1, overall MATCH, no malformed-row diagnostic. [r=0.1,r=999] also reports 1/1 MATCH, only duplicate diagnostic. Old math reports INVALID.
- Shared root: _ledger_observations filters/skips bad rows, missing IDs and later duplicate IDs before computing denominator, and duplicate_observation_id does not downgrade clean overall. Malformed relation results have the same skip pattern (static, not independently probed).
- Repair direction: Retain raw entry coverage and explicit invalid/unresolved representation at the ledger owner. Do not silently select one conflicting declaration. Fold shape/duplicate diagnostics into clean-match eligibility while preserving valid rows.

### AUDIT-I03 — P2: Field dereferences bypass caller-tightened pointer limit

- Location: `financial_measure_evidence.py:739-769 vs review_evidence.py:481`.
- Expected: max_pointer_tokens=1 must apply both to primary locator and every field pointer.
- Actual: Primary /marker is admitted. fields.value=/nested/value is MATCH despite 2 tokens; same existing reader.inspect_reference rejects /nested/value with max_pointer_tokens.
- Shared root: Adapter invokes audit_contracts.resolve_json_pointer directly after primary-locator inspection, bypassing the reader limit port. Global 128-token parser hard cap still exists, so this is tightened-budget drift, not an unbounded pointer claim.
- Repair direction: Route primary and field resolution through one bounded structured reader port, preserving diagnostics and no second budget.

### AUDIT-I04 — P2: Cached evidence bypasses cumulative deadline and repeated assembly is quadratic

- Location: `review_evidence.py:300; financial_measure_evidence.py:627, 700-712, 797`.
- Expected: Shared reader cache should avoid charging/read duplication, while elapsed deadline still constrains further field work; expired time must remain visible.
- Actual: Fake clock 0 first call then 2s with max_seconds=1 on same reader yields another MATCH, elapsed_seconds=2, exhausted=null, files_read=1.
- Shared root: Existing cache returns before admit; adapter performs no elapsed check between rows/fields. It also decodes the same cached document once in inspect_reference and again in adapter for every observation; row.fields scans cumulative field_results on every row, O(N^2). The deadline hole is an existing reader-boundary issue amplified by the new repeated financial adapter.
- Repair direction: Keep byte-cache reuse and file/byte accounting, enforce elapsed time at shared structured resolution/loop boundaries, reuse decoded immutable observation once per artifact snapshot, build per-row field list locally then aggregate. No large benchmark was run; O(N^2) finding is direct loop analysis.

### AUDIT-I05 — P2: Malformed map ledger digest can still yield clean overall MATCH

- Location: `financial_measure_evidence.py:276, original baseline final clean-match eligibility`.
- Expected: A supplied invalid digest is a diagnostic and cannot certify exact map-to-ledger binding or clean overall.
- Actual: ledger_sha256="not-a-sha" emits map_ledger_sha_invalid but overall MATCH/declared_field_match true.
- Shared root: validate_map diagnoses malformed digest, but final downgrade set in original 3ed248df omits that diagnostic.
- Repair direction: Treat malformed supplied binding identity as unresolved clean-binding eligibility while retaining observable field checks; ROOT already appears to be fixing this in its WIP, so not represented as an unfixed final finding.

## Tests and preserved boundaries

- Independent small controls are executable in `audit-probes.py`; full numeric receipts are `audit-probes.json`. Genuine original files and real existing EvidenceReader/Budget were used; no fake reader replaced byte/hash/locator behavior.
- Four existing narrow compatibility/input-immutability tests actually ran: **4 PASS, 0 errors/failures/skip**. `audit-targeted-tests.txt` and `audit-compatibility.json` preserve results. No full suite rerun.
- Baseline versus current declared math function AST (after function rename only) and old CLI main AST are equal. Current source during these four tests was ROOT WIP; original review/probes are kept separate.
- Semantic truth remains false; economic reasonableness not_evaluated. Unsupported company/definition semantics and unstructured prose are not auto-certified. Field values are compared only after structural resolution, subject to the precision/budget defects above.
- The 1500-level nested JSON negative returned UNRESOLVED without crash. This is **not** a reported defect; do not invent a recursion failure.
- File/byte cache is reused once, as intended. Deadline/resource work and current-byte snapshot semantics must be distinguished; do not solve I04 by charging a cached byte payload as a fresh file.

## Work intentionally not duplicated

ROOT's ledger object/bytes identity, duplicate binding fields/SHA, A/B/A resurrection and non-string pointer fallback probes were not repeated. Root repair acceptance and provider/real-company runs are **NOT_RUN** by this review. No opinion here upgrades field MATCH into economic source truth.

## Frozen original source SHA-256

- `skills/revenue-forecast-audit/scripts/financial_measure_evidence.py`: `cfcb297730312d749b91da6c76fee8be1b200019cb205de5d9cefd2a34958176`
- `skills/revenue-forecast-audit/scripts/financial_measure_audit.py`: `fbd2e89305f77a9fdd9411752d564e6b70f2c8bf8445b4f934e402cfd73386f2`
- `skills/revenue-forecast-audit/scripts/review_evidence.py`: `dc12035dd1dbc84d6aad67713f8025732c8e610cf563a4a717d9397ee7b675ca`
- `skills/revenue-forecast-audit/scripts/audit_contracts.py`: `751c233fc08523ff2cf3ae9c4d95591637afd34b26f82c192317f33948f4615d`
- `skills/revenue-forecast-audit/scripts/numeric_audit.py`: `39cb4f8f561f14f406b5c79639f7395af915e1f9027b15a0e2ac8e0c40949aec`
- `tests/test_du8_financial_measure_evidence.py`: `f62a6e60c799c123dc604aba8238a2d5f7af030809d60e25816ec2557bdc1298`
- `tests/test_du8_measure_evidence_cli.py`: `6e1388cc1ecf1f532312ba8ff593ff8210ef5698d1bd5780e3da7413855c7755`
