# FF DU8 ROOT 最终独立复核

## 结论

最终冻结 5 个 SHA 全部匹配；矩阵核心 3 个运行源码 SHA 与原冻结一致。上一轮恢复观察器 P2（FF-ROOT-01）已关闭，本次审查范围内剩余 P1=0、P2=0。工程修复可接收；完整 41 链仍 C OPEN。

## P2 修复依据

观察状态按 request 名与 request/fixture 字节 SHA 分开；只接受有效的初见零，再见 GET 增长。初见正计数永久不能成为该 key 的零基线；不增长、回退、部分 JSON、当前 proxy state 不匹配和已完成 response 都不能产生证明。实际 calls 路径由 fixture_builder 的 group/proxy/calls 路径产生，与新观察器 current state 定位一致。

标记明确只证明观察期间该 case 新进入 GET 后终止 owned tree，未声称 kill 瞬间 provider 仍阻塞。精确 stalled 子孙清理由已有受控 marker 测试负责。未新增人工审查或权限门。

保留的旧观察器行为 RED 确实执行到旧实现返回正 marker 而断言失败（1 FAIL /0.53 秒），不是仅因为新关键字接口不存在而失败。新增测试覆盖正计数初见、零到增长、计数不增/回退、部分 JSON、proxy state 变化、response 完成与 fixture 变更。

## 完整矩阵不冒称完成

只读 ROOT 唯一完整运行收据：20 PASS /0 FAIL /4 PARTIAL /17 NOT_RUN，173.2744 秒，exit 1、oracle 非通过；209 个文件、1,151,019 字节保留，scratch/cache/sentinel 恢复成功。零 GET deadline 为 PARTIAL，未粉饰为完整通过。测试性能与覆盖完成仍待主线处理，不能用本工程接收替代 C 节点。

最终集中收据已读取匹配：251 PASS /0 FAIL /0 SKIP、9.19 秒、exit 0，Temp 与 sentinel 恢复成功（ff-root-focused.log/json）。这是普通集中工程小测试，不是真实完整 C 链；旧 244 PASS /17.72 秒收据保留在 ff-root-pre-review-focused.log/json。本复核没有启动进程、测试或 API，没有写源码或 Git，也没有改写原冻结报告。
