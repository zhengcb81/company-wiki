# DU8-FF-MATRIX-COMPLETION：独立只读验收

## 结论

**工程实现可接收；C 节点整体完成仍 OPEN，不能宣布 41 链闭环。** 未发现本次两个工具源码改动带来的 P1。发现三个 P2：旧 deadline 用例混合两种覆盖、恢复夹具把未观测洗成零泄漏、交接 Markdown 的真实字节损坏。前三次 C 的 21/26/14 PASS 均须保留，不能用 37 个快速测试替代。

- 作者工作树：`C:/Users/郑曾波/Projects/filing-fetch-du8-matrix`。
- exact HEAD：`6f381199f146109b4f517537a70da1c20c6e05bd`。
- 基线：`e8a85585b4c64a9596e576ff3b73e5c2ee29c334`。
- 审查范围：新增 `case_scheduling.py`、`cli_main.py` 差异、两个新测试文件、own PWF/收据/恢复夹具；另只读原 case authority、handler 和固定 ET supervisor。
- 未改作者源码或 Git；未访问生产资料、供应商、密钥、网络；未启动全仓或 41 条真实链；未进入 DU8-RF/DU9。

## P2-1：截止边界与在途超时混用同一成功条件

位置：`case_specs.py:490` 的 1 秒请求，`extended_cases.py:20–39`，`case_specs.py:203–210`。

固定 ET 的 `retrieval_runtime.py:95` 在创建临时工作环境和 `Popen` 前建立绝对 deadline；`145–152` 启动子进程后只等待原剩余额度。**冷启动耗尽 1 秒、尚未发 GET 即被 supervisor 中止，可以是正确边界行为。** 这并不能证明 `StallResponse` 已在途并被中断。handler 和独立 authority 却都要求 GET=1，混合“真实预算拒绝”和“在途请求中断”两个不同目标。

最小纯 fake 反例已保留：相同 `provider_unavailable/provider_deadline`、原件拒绝、cleanup=true、结果 receipt，只改 GET 数量，0→FAIL、1→PASS。该 probe 证明断言结构，不冒充生产/真实进程覆盖。

合理 ROOT 修法：

1. 保留 1 秒真实公开入口作为**含冷启动的绝对截止用例**；记录是否到达 GET，GET=0 与 GET=1 分别报告，不通过延长预算、无条件 `>=0` 或伪造计数使在途覆盖变绿。
2. 对“worker 已进入 GET 后的 stall 中断”增加独立受控覆盖：fake-clock 的剩余预算贯穿创建/启动/等待；小型真实受控 worker 用明确 entered-GET marker 证明进入请求，再检查原截止不重置、树被终止、usage 未知保留。若真实 1 秒窗口没进入 GET，则该子覆盖 PARTIAL/NOT_RUN，而非算为 PASS。
3. 同步 CaseSpec 的固定意义、handler、oracle/相关测试；不要只放宽 handler 留 authority 不一致。无需新增审批、权限或收据签收层。
4. 接受“正确 pre-GET deadline”时，要明确修改的是测试目标，不能声称旧 `call_hard_timeout` 的在途覆盖已完成。最终 report 仍应诚实显示所有必需子覆盖。

作者受高主机负载影响的证据有参考价值，但没有同输入隔离控制实验，不能把所有 C 失败因果归为纯外部；该测试合同问题与 hostload 可以同时存在。

## P2-2：恢复夹具可把未知、旧目录及准备阶段误算成恢复成功

位置：`fixtures/interruption_recovery_e2e.py:50–72,75–86,110–146,190–220`。

- `_python_children_of` 在非 Windows、WMIC 无法执行、异常时返回 `[]`；未检查 WMIC 非零 exit。后续 `==[]` 直接 PASS。独立 fake `FileNotFoundError` 复现了这一洗绿路径。无法观测应为 unknown/NOT_RUN。
- 通过“out 下任意 attempt 的 artifacts 非空”认定本次真实 case 已开始；未绑定当前子进程新建 UUID、未要求 case request/GET marker；固定旧目录会触发。保留 JSON 自己含两个 interrupted attempt，2.045 秒就 kill，不能证明进了本次在途 case。
- 检查没有要求 `interrupted_after_seconds` 非空，也没有排除旧 attempt 污染。`proc.kill()` 针对顶层进程；捕获异常后未确保 communicate/wait，后代退出证明完全依赖上述可能失败的观察器。
- 固定 sentinel 会覆盖同名既存内容，随后才建立 before 基线；不是严格测试目录原样恢复。
- interrupted scratch/cache 仍留存（JSON 明示两次 attempt 与 `pc/p00`）。新第二次 attempt 清理成功不能证明第一次的恢复/清理。`14/14` 只代表这些当前断言得到 true。

合理 ROOT 修法：fixture 只用新 TemporaryDirectory，在其中预置并保存 sentinel；绑定本次唯一 UUID 和当前 case 的进入标记；利用现有受控进程 owner/树退出能力而非 WMIC 全机字符串扫描；不可观测记 unknown；异常也 drain/reap owned 树；保存 before/after shape、归属、GET 标记和清理收据，然后只清理自身目录。不要启动另一套任务库、审批或全局扫描器。无需本代理重跑长链，由 ROOT 串行大节点验收。

## P2-3：三份计划/交接 Markdown 确实有非法 UTF-8

使用 `read_bytes().decode('utf-8', errors='strict')`，不是依据控制台显示。首个坏字节：

| 文件 | 偏移 | 局部十六进制 |
|---|---:|---|
| `task_plan.md` | 58 | `4320e5ae8ce68890e4bd3f2ae69caae8bebe` |
| `progress.md` | 33 | `bc9ae8af9d203120e2803f4120e590afe58a` |
| `handoff.md` | 27 | `504c4554494f4e20e2803fe4baa4e68ea5ef` |

`findings.md` 与 `handoff.json` 严格解码通过。需要 ROOT 根据有效 JSON、findings、真实收据重建损坏段落并用明确 UTF-8 保存；不应猜补已丢数字。保留原件 SHA/历史。`Status: complete` 要改为工程 A/B 已完成、C 尝试完成但验收未完成，不把 OPEN 写成整体完成。

## 可合流工程内容与真实收益

调度 owner 是纯函数，LPT 的 case 粒度完整、不拆 download→reuse 链；CLI 仍限制 workers 1/2，单 case 30 秒、batch 180 秒、proof reserve 10 秒不变。只替换分组、增加预测诊断与绝对截止具名原因；没有 provider 或权限变更。最终 report 仍由原 oracle 审核，旧 FAIL/PARTIAL/NOT_RUN 不会被新 scheduler 直接改成 PASS。

独立从保留 W07 原始 41/41 行重算：总 135.3325 秒；旧分组 `[75.5306,59.8019]`；新分组按同一实际表评分 `[74.0080,61.3245]`；改善 **1.5226 秒 / 2.02%**。这是对一份完整历史表的离线重评分，未证明新实跑也有相同比例。原报告 SHA：`7c5906237d03260e0598bca37e02036fa0202f05e7516696a3c488c583d17ddf`。

静态模型预测 `[52,52]` 仅指 run-count proxy 相等，**实际负载仍相差 12.6835 秒**，不能据此称“调度本身完全均衡”。不能用这 2% 的优化解释/解决两三倍的整体变慢。历史 v1 的 16–21 秒收益和 v2 的全局泛化结论均不接受；当前 JSON 明确撤回，但模块顶层仍留有 `rejected as overfit`，progress 也有未撤回的“完全均衡”措辞，可顺手清理。`_measured_case_costs` 命名和调用处 measured 注释建议改为 estimates/static，与真实 cost_source 一致。

非阻塞改进：`cost_of` 对 None 有 fallback，但非有限/负值未规范，会使排序与诊断失真。当前 runner 只使用正的固定模型，不是现行生产 bug；若对外开放该 hook，增加小型类型/有限/非负检查或明确约定即可，不增加人工 gate。不要把文档中“41 identical heavy entries 会全部进一组”的错误例子视为 LPT 正常事实。

## 独立测试、归因和清理

- 两个新文件完整 **37 PASS / 0 FAIL / 0 SKIP，3.07 秒**，普通 Python、禁网 socket guard、移除敏感环境变量、pytest 自动插件禁用。
- 两个纯 fake probes：截止 GET0/1 判定差异；WMIC 不可观察返回空列表。
- 使用独立 TemporaryDirectory；sentinel 字节未变；Temp 删除；作者所有 changed_paths SHA 前后一致；作者 git status 前后均干净。
- 作者 344 PASS 仅作为已有收据，未独立重复；全仓所谓 15 baseline failure 本次未重跑，不采信为已独立证明。C 三次失败未重跑；ROOT 将独占串行运行。作者已删 C restore/guard 证据的限制仍保留。
- 收据：`ff-new37.log`、`ff-review-probe.json`、`ff-cost-recalc.json`；可复现入口：`ff-review-probe.py`（只改 ROOT 收据，不改作者）。

## 建议 ROOT 大节点顺序

先接收两源码与 37 小测试的工程价值，修复上述测试合同和恢复夹具共因、重建损坏交接文本；集中相关短测试一次。然后单独串行运行固定 41-case 真实工程链，保留原始 request/response、GET entered/cleanup、restore/guard 及 timing 原件。若仍出现 PARTIAL/NOT_RUN，按实测拆分冷启动、seed、单 case 与清理成本，不重复重跑到偶然绿，不用静态均衡或 hostload 猜测替代证据。无须增加小节点审查。
