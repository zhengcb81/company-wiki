# FF DU8 ROOT 独立冻结审查

## 结论

工程部分可接收。冻结 5 份源码的实际 SHA 全部匹配 `ff-root-frozen.json`；未发现 P1、新增审批门或生产原文泄漏。恢复夹具仍有 1 项 P2 证据口径缺口，完整 41 链须采用 ROOT 唯一运行收据，当前未代为验收。

## P2：缺少 response 不等于请求仍在执行

`fixtures/interruption_recovery_e2e.py:55-80` 只验证无 response、当前 attempt 内 fixture/calls 和累计 GET>0。`Context.run_ff` 的有界子进程若抛 DeadlineExceeded，会在写 response 前退出；`run_case_group` 捕获后能继续执行下一项。观察器此时仍可能选中旧请求的 GET，误称该请求仍在途。该反例是静态可达控制流，未启动真实进程；不冒称当前链已实际触发。实际 chainA 两轮使用不同 calls 文件，不能据此宣称它已发生复用旧 GET。

影响仅为恢复夹具的归因与证明强度；共用 OS owner 的杀树/回收能力未被此反例否定。

### 最小修正

采用有状态观察：以 request+fixture 字节 SHA 为 key，先见当前请求 GET=0/日志尚未出现，再见新 GET 增长，且 response 仍未出现、当前 group proxy/state 与该 fixture state 一致。初见正 GET、计数不增/回退、fixture 变更、状态不一致保持 NOT_RUN；部分 JSON 不能误计为零。文案只宣称“观察期间本 case 新进入 GET 后终止 owned tree”，不宣称供应商在精确终止时刻仍阻塞。真正 stalled 子孙终止沿用已有受控 marker 测试。这足以解决本次反例，无需新增门禁。

## 已闭合检查

- 零 GET 的正确 deadline 为 PARTIAL，边界 PASS、在途 NOT_RUN；原 CaseSpec 的完整 PASS 必须一次 GET，固定 1 秒不放宽。
- 进程树复用既有 transport 的 `_spawn/_IOState/_cleanup`；异常清理保留 unknown；截止时间包含 spawn；未引入全机 PID 扫描。
- 原 3 份非法 UTF-8 文档的 hex、原 SHA、字节数均可还原匹配；重建文档严格 UTF-8 有效。原失败次数与 C OPEN 保留。
- 静态估算与实测分开；52/52 不是实测均衡；历史关键路径收益仅 1.5226 秒 / 2.02%。
- ROOT 集中测试收据为 244 PASS / 17.72 秒，exit 0、sentinel 完整、临时目录删除；本审查没有重跑。

## 范围

只读指定 ROOT 集成树及 CWP 接收收据，没有测试/子进程/API、源码或 Git 写入，没有读取密钥或生产原文。完整矩阵与后续夹具修复需引用各自最终收据与 SHA；不能用本审查宣告 41 PASS。
