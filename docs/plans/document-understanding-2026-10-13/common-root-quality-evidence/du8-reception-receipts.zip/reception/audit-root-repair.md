# AUDIT ROOT reception repair — frozen for independent review

Status: **FROZEN_READY_FOR_INDEPENDENT_REVIEW**, not self-accepted.
Target: revenue-forecast-audit-du8-integration, original complete author HEAD 3ed248df06b2ba00e4f59d930647149ecc1f88af plus ROOT WIP. No Git write/commit/install/sync or author/main checkout write.

## Shared-root repairs

- Existing EvidenceReader owns optional bounded exact JSON/field port and one per-artifact/hash/mode in-memory parsed cache; existing byte cache and one Budget remain authoritative. Old inspect/CLI defaults retain their policy.
- Preserve Decimal byte precision, reject ambiguous duplicate JSON members and nonstandard constants in exact mode, represent Decimal observed values losslessly as JSON strings. Ledger float 0.1 can match literal 0.1, never a different precise literal.
- Every malformed observation/result stays in denominator as INVALID; duplicate IDs retain all copies INVALID. Bad measure_kind type cannot crash or discard valid rows. Duplicate membership is a set.
- ROOT's complete binding conflict, A/B/A stickiness, ledger identity and invalid-pointer/digest repairs remain.
- Apply shared pointer/time limits across source parsing, fields, cached reuse and comparison; positive one-file budget still allows cached repeated observations. Per-row field lists no longer scan accumulated global results.

## Test expectation correction

Original BudgetTests test appended the same artifact/locator with a different field subset. Complete binding equality correctly treated that as a conflict and only read two files. Original RED is preserved in audit-cache-expected-red.txt. The test now duplicates the complete original binding; independent positive also proves two observations reuse one physical read and one source decode. No conflict assertion was relaxed.

## Actual tests

- Final ROOT narrow **24 PASS** (15 new shared-owner tests + 9 original ROOT binding tests), 0.348s.
- Narrow author core **62 PASS**, CLI **17 PASS**, unchanged-default reader **40 PASS**. Author-core run predates final input-kind/post-comparison-time tightening; final full suite must use frozen SHAs below.
- Ruff and git diff check PASS. No full suite rerun by this worker; ROOT owns one final concentration and a different agent owns independent final review. Expected count, if no other tests added, is 637 PASS / 2 SKIP, but actual results must govern.
- Original REDs remain. A mistyped unittest filter ran zero tests and is explicitly NOT_RUN; corrected invocation produced actual 1 FAIL / 1 ERROR before final fix.
- Temp/source/sentinel cleanup tests passed; no provider/network/original/config/Git writes.

## Final source SHA-256

- `skills/revenue-forecast-audit/scripts/review_evidence.py`: `d0f6170487b9d904b72aa9c71cd53ffa3b9ce4bb14f5eb38d5f1edfb7e1fc64c`
- `skills/revenue-forecast-audit/scripts/financial_measure_evidence.py`: `f2923990f1b61b3a9ad25d803ed60775530d8e8eb6bce795543c2dd998cdd668`
- `skills/revenue-forecast-audit/scripts/financial_measure_audit.py`: `fbd2e89305f77a9fdd9411752d564e6b70f2c8bf8445b4f934e402cfd73386f2`
- `tests/test_root_du8_measure_evidence.py`: `0c6bbdc228f802eed827cb9009cdbaef339e8e276bed68876ad2bd32785f8b60`
- `tests/test_root_du8_exact_reader.py`: `1d9d702f11349e7f99a89f5b2092863a5f7ca776b002763154d0095d2311187a`
- `tests/test_du8_financial_measure_evidence.py`: `962e510f2d9ef2b4c88ba938bc5777df31df5cb4e6807f8a294b01854f6bfbbc`
- `skills/revenue-forecast-audit/references/financial-measure-evidence.md`: `d03e6bbde3224c23321a28d46576ae29bffcde7fb198c94a0834f6d7bc23cf22`
- `docs/plans/du8-measures-2026-10-16/INTERFACES.md`: `f68d7b7bc0cdea120c5ff08ee8f90d46317deabd91034ba9407b3d6c0933751d`
- `docs/plans/du8-measures-2026-10-16/findings.md`: `5cea4b2aa292f2957c5be3fb7b33d171cde7a371850d6bd0a9a656367ecdd048`
- `docs/plans/du8-measures-2026-10-16/progress.md`: `cb443ba13cbc8e816b77b11ee9f11f7600faca9cf980c0f14f827e0fa1f32931`
- `docs/plans/du8-measures-2026-10-16/task_plan.md`: `ab05c5e1fb25173dad8973959efb115f3dbd3b51725e60b50cb56acc1b179cf9`
- `docs/plans/du8-measures-2026-10-16/handoff.md`: `16de3be26b360c8b31dc301c558c5c7cfa0b2aa8814cb491fe300d5144eb95ca`
- `docs/plans/du8-measures-2026-10-16/handoff.json`: `2744156a1ec1dd61913eb0f2e515cbc0794bf5a3350b819bf36e21c6b7d5e915`

## Final handoff

Run `python -B -m unittest discover -s tests -v` once from the integration root after independent review. Merge complete author history plus committed ROOT reception repairs, never only old first feat. Original author receipts remain historical. The ROOT reader scope extension is documented in reference/PWF/handoff; there is no new approval gate.
