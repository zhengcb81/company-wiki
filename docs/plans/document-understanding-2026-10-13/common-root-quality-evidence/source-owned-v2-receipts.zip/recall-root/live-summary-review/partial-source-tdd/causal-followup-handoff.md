# Source usability causal followup — SOURCE STOP

Date: 2026-10-14. Owner: `/root/table_admission_review`. No commit/push/PWF changes.

## Scope and demonstrated root cause

`NarrativeSelectHandler._verify_selected_material` does **not** dispatch solely on MIME. For nonempty material, it uses normalization's pure matcher iff every already-parsed unit has `cwp_document_normalization` as its parser name; otherwise it calls `source_catalog.narrative_replay.verify_replayed_pdf_spans`. The latter also handles TXT/JSON and HTML/XHTML transcripts despite its historical PDF name.

The former `source-usability/2` inventory only included that shared matcher for PDF. TXT/JSON changes could leave caches `same`. HTML MIME also covers two real parser owners: transcript HTML was incorrectly bound to the normalization matcher and could remain reusable when its actual matcher changed.

This was reproduced without parsing originals or contacting suppliers:

| Node | Actual result | Evidence |
|---|---:|---|
| `causal-followup-red` | 2 failed / 15 passed, exit 1 | TXT/JSON actual matcher code changes falsely stayed `same` |
| `causal-followup-same-mime-red` | 4 failed / 21 passed, exit 1 | Same TXT/JSON failures plus HTML/XHTML transcript wrongly depended on normalization matcher |
| `causal-followup-green` | 25 passed, exit 0 | Targeted repair |
| `causal-followup-final` | 84 passed / 3 deselected; Ruff exit 0; mypy exit 1 | Existing optional `module.__file__` typing issue exposed |
| `causal-followup-final-resolved` | **84 passed / 3 deselected (8.64s); Ruff exit 0; mypy exit 0** | Final unchanged-source node |

Original RED and failed typing receipts/logs remain intact. Each label has a JSON receipt and per-command stdout/stderr logs in this directory. The final command manifest is `causal-followup-final-commands.json`; final receipt is `causal-followup-final-resolved.json`.

## Implementation

Only these files were edited for this followup:

1. `src/company_wiki/document_understanding/decision_inventory.py`:
   - Add optional `source_parser_names=None` to the existing `build_decision_trace` internal API. Omitted/None/empty callers retain their prior calling behavior and deterministic carrier fallback.
   - Match the source owner's **actual parser-name branch**, including the mixed-parser case. No document-name, purpose, company, market or unit-kind guessing.
   - Freeze the finite actual matcher responsibility in an additive `source-matcher-used|…` component of the existing trace/dependency contract. `current_decision_trace` replays that component; no original scan, second manifest or task store.
   - Bind only select plus its responsible matcher source file. Normalized HTML ignores PDF/transcript matcher changes; PDF and transcripts ignore normalization replay changes. Source bytes are normalized from CRLF to LF; installation paths are not hashed.
   - `source-usability/3` forces one cache miss for old 0.9 decisions lacking the actual matcher proof, including ambiguous HTML. Source selection is recomputed from preserved originals; historical bundles are not rewritten.
   - Give a missing module source file a concrete `ValueError`; the previous `Path(None)` was already invalid and failed mypy.
2. `src/company_wiki/source_catalog/narrative_reading.py`: only the existing `build_decision_trace` call adds the unique actual parser-name tuple from its already-held parsed units. No other reading logic changed.
3. `tests/unit/test_narrative_source_usability_dependencies.py`: 38 tests, including real post-parse handler calls, parser-forgery rejection, same-MIME real `select_reading_evidence` calls, relevant/unrelated code changes, actual proof replay, mixed names, None/empty API compatibility, old-cache miss, path relocation and CRLF portability.

No model prompt/request/body, None/v1 frozen model request, generation/store/factory, routing, business policy, caps or production configuration was changed. Actual identity/source byte/citation responsibilities remain in their existing layers; this adds causal cache freshness rather than permission or manual approval.

## Final concentrated verification

Pytest files: this dedicated source-usability suite plus existing `test_reading_decision_inventory.py` and `test_shared_reading_cache_precheck.py`.

Three collected tests were deliberately excluded to keep this followup at zero parsing:

- `test_transient_script_matching_change_invalidates_actual_decision` (normalizes synthetic HTML).
- Both parameters of `test_optional_import_does_not_hide_dependency_internal_module_failure` (the source-selector parameter parses a transcript fixture).

They were not changed and their omission is not a pass claim. All 84 selected tests passed; supplier calls and original parses were **0**. No real end-to-end quality, recall or model summary certification is claimed by this engineering node.

Ruff checked the two source files and dedicated test. Mypy checked both source files using `--cache-dir=NUL`.

Final receipt records before/after SHA and mtime. `source_unchanged_during_node=true`, `sentinel_unchanged=true`, `temp_removed=true`; pytest's separately relocated basetemp cleanup also reports `removed=true`. Production `config.yaml` and `config/source_catalog.yaml` were unchanged. The four previous partial-source STOP files retained their exact SHA/mtime.

## Exact final SHA-256

| File | SHA-256 |
|---|---|
| `src/company_wiki/document_understanding/decision_inventory.py` | `6b43c2ef1f0c98dae2a897a533ac72c1632ed2767f87012d3e68267e6ed0d6d6` |
| `src/company_wiki/source_catalog/narrative_reading.py` | `517c50fe52645b08d189feec41db1be3b8cf235c9ec27cb97883a387599ac04a` |
| `tests/unit/test_narrative_source_usability_dependencies.py` | `cddc10463e63d245f76d6ed1af7571edbba937406c11af6cbe5da70f142bb9de` |

Previous STOP SHA retained:

- `narrative_select.py`: `dca261ce4676c55afb24091877101a96563d8693edbdc18332cd7f9640ae950e`.
- Normalization `replay.py`: `39594373d4a9b0b834ed5f2d838cd70baae76703fcd88299bedfbd045ee01b18`.
- Source-catalog `narrative_replay.py`: `bd28988c1be17f2d545e61b6efefbdc06c63036491a5d008386dab0c9518f644`.
- Partial admission test: `bd81a82bbcf787c315fdd9e45a113f4a56a1bf60f69b52936f974b934ec9f198`.

ROOT owns final integration, normal hooks, commit/push and PWF publication. This owner is now SOURCE STOP.
