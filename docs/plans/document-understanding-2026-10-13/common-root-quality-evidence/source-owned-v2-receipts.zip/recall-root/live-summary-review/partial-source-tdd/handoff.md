# Partial-source TDD 交接 — SOURCE STOP

2026-10-14；ROOT/table_admission_review。已完成分配窗口，**不再改 source/tests**；没有 commit/push、PWF/config/model/generation/业务策略/routing 写入，没有真实供应商调用、下载或生产原件解析。

## 改动与职责

1. `src/company_wiki/automation/narrative_select.py`：去除 normalized 宽严开关。非空、可靠、可与本轮原始解析材料匹配的片段允许继续；errors/opaque/deferred 仍使 coverage=False，必要时 status=partial。blocked、空 incomplete、全 opaque、媒体打开失败、不可靠所选材料仍在模型前失败。完整行政/无业务来源继续 0 模型 skip。
2. 已有 canonical SelectResult 的 shape/path/cap/group 校验只构造一次，随后进行源材料纯匹配，均在模型前。两项原 cap/path 错误分类一度被 matcher 掩盖，已修生产调用顺序，原测试未放宽。
3. `src/company_wiki/document_normalization/replay.py`：抽出 `verify_parsed_evidence_spans`；原 replay 和 selection 共用 source_locator/text/coordinates/quality/metadata/role/text-hash/parser 证明。没有改变 `_parse`、OCR 或 limits，没有新增 normalize/source-read。
4. `src/company_wiki/source_catalog/narrative_replay.py`：沿既有纯 matcher，普通片段先对照实际 unit 的 source/parser name/version。单独 RED 证明仅将普通 span parser_version 改9.9.9会错误通过选择；窄修后拒绝。native-range/QA 专用匹配保持，旧 IDs/bytes 没改。
5. 新专属 `tests/unit/test_narrative_partial_source_admission.py`：**24 项**，实际注册的 select→summarize→verify DAG（real handlers/executor＋offline counting model），partial PDF/HTML 正例、corrupt/all-opaque 两前置负例、局部页 extraction 失败、所选 source/text/locator/native-range/parser/normalized metadata 篡改、coverage 假完整、blocked/空 incomplete、行政 skip、坏 group、质量 flags。不能把直接 selector 回放当生产 DAG。

正例用本轮已解析 units 内存证明；计数精确为 **select 1 parse＋最后 verify 原件再回开 1 parse**，准入没有新增全源重解析/逐 span open。selected原始文本与引用不被修补，group验证沿原 typed contract，没有新 ranker、public flag、身份许可或签收。

## 留证和检验结果

| 标签 | 实际结果 | 解释 |
|---|---|---|
| `red` | 9FAIL/7PASS | 含新测试 DAG job_key 夹具错误；保留，不充作全部实现缺陷 |
| `red-fixture-fixed` | 7FAIL/9PASS | 仅修正确 frozen job_key 后，生产差异仍真实 RED |
| `red-complete` | **14FAIL/9PASS** | 最初完整23项 RED，source未修；包含 PDF 全份拒绝和未验真实引用 |
| `green-focused` | **23PASS /4.88s** | 初次实现后 focused绿色 |
| `final-node` | 343PASS/3FAIL /100.21s；Ruff/mypy0 | 两项原 cap/path分类回归＋一个既有 OCR preflight失败，全部保留 |
| `resolved-node` | **303PASS /37.80s**；Ruff0/mypy2source0 | 修调用顺序；集中验证相关格式、OCR、native、旧投影；只复核明确剩余OCR单例，没有重跑100秒全套 |
| `parser-red` | **1FAIL /2.24s** | 后续发现普通 PDF span parser版本绑定缺口，实证9.9.9错误SUCCEEDED |
| `parser-green` | **1PASS /1.03s** | ROOT分配窄辅助扩展后共享matcher修复 |
| `shared-replay-final` | **177PASS /9.07s**；Ruff0/mypy3source0 | 24项新测试＋受影响的 real handler/replay/native/旧投影边界，最终源码快照 |

所有实际命令和 exit 在各 `{label}.json`，stdout/stderr 独立保存，RED/FAIL未被覆盖。`shared-replay-final.json` SHA：`ff44356bf3446a44c4cfe670b743f2bd196e7ece9ddc351e2f5d25bd620aae07`。

最终 node：源码 SHA/mtime 前后相同；sentinel unchanged、Temp removed 均 true。测试媒体、配置夹具使用独立 tmp；正例的测试 original SHA/mtime 不变，最后删除仅本测试新增的 original/sentinel、恢复目录为空；pytest 自己的 Windows relocated basetemp cleanup 也留有 removed=true。没有恢复完整备份演练。

## 精确冻结文件

| 文件 | SHA-256 |
|---|---|
| `src/company_wiki/automation/narrative_select.py` | `dca261ce4676c55afb24091877101a96563d8693edbdc18332cd7f9640ae950e` |
| `src/company_wiki/document_normalization/replay.py` | `39594373d4a9b0b834ed5f2d838cd70baae76703fcd88299bedfbd045ee01b18` |
| `src/company_wiki/source_catalog/narrative_replay.py` | `bd28988c1be17f2d545e61b6efefbdc06c63036491a5d008386dab0c9518f644` |
| `tests/unit/test_narrative_partial_source_admission.py` | `bd81a82bbcf787c315fdd9e45a113f4a56a1bf60f69b52936f974b934ec9f198` |

ROOT需把上述 **三个 source** 纳入现 source-usability 因果 inventory/digest。该责任已通告ROOT，本分线没有改 generation/inventory、重签历史Ref或添加新manifest。None/v1模型模板/decoder未动，旧投影兼容测试11项包括固定None/v1请求语义及实际HTTP计划边界通过；相同pinned输入的旧body不被此线改写。

## 限制和后续责任

- 此处绿色是隔离工程与来源定位验收；**不是业务 gold/正式摘要质量验收**。partial、未读/推迟、selected_evidence_only 全程保存，不能据此把 critical miss 记为通过或宣称全文无某业务。ROOT按原大节点做真实来源/三供应商summary独审，不因工程绿默认切生产。
- `final-node` 的 `tests/document_normalization/test_isolated_ocr.py::test_native_stdin_probe_does_not_deadlock_liveness_monitor[preflight]` 曾在 warm 后1秒deadline报 OCR_WORKER_FAILED，`resolved-node` 单例随后通过。本线没有改其 source/test、没有放宽deadline或增加自动retry；这两条结果都保留。不能断言已根治其负载敏感性，ROOT若需要处理应独立归因。
- 初始测试 runner 的 shell JSON引号错误与沙箱Temp sentinel权限失败也未当产品故障；改用JSON命令文件，已核路径清理空测试Temp，再在明确授权的非沙箱跑独立测试。测试最终全部 cleanup，不通过改命令绕平台拒绝。

**SOURCE STOP：已交接，等ROOT统一集成/审查/commit/push/PWF；不再扩大改动范围或继续供应商试验。**
