# Language model-resource resolver repair — SOURCE STOP

## Root cause and corrected responsibility

The actual installed py3langid0.4.0 exports a relative MODEL_FILE and its own MODEL_DIR. LanguageIdentifier.from_model_file prefixes MODEL_DIR when the path is relative. The observer identity helper instead used the worker current directory. It could wrongly mark a genuinely usable library unavailable, or hash a same-named unrelated cwd file. This was a real root defect, and the earlier absolute-path fake tests missed it. The old76/206PASS receipts remain historical; they did not establish actual installed resource availability.

Only the already-owned observer and its dedicated test module changed. The helper now mirrors that actual relative/absolute resolver using module resource ports, without filenames/installation paths in public identity. Missing/invalid bases abstain; absolute resources retain compatibility. It does not load or reload a classifier, change language classification, modify installed code/weights, or add a permission gate.

Six new tests cover actual installed code/weight SHA and availability, relative cwd collision, arbitrary-name relocation/change/missing/restoration, missing/invalid bases, and absolute-path compatibility. Actual installed resource RED plus these controls: **5 FAIL /1 PASS /67 deselected,4.46s**. Final observer+summary-binding concentrated node: **82 PASS /3.21s**, exit0; Ruff two files exit0; Mypy one source exit0. A prior first run had1actual failure and5sandbox Temp setup errors; that original log is retained. An intermediate optional-Path typing failure was corrected with explicit missing-component handling; final82ran again on the current exact source bytes.

Actual installed library code normalized-LF SHA: `87dd47f1253b2adc6f82ed96f53e385a80bbde4f3627741cc516e7d0dd4a55d5` (12687B). Actual raw weights SHA: `f4f4a2c3465ca1f081541037f9cac23021d68151c2f709c55ae5eedfca522963` (4586720B). Distribution py3langid0.4.0 / NumPy2.4.6; module/model/distributions now all available. Identity call left classifier thread-local state unchanged. No installed resource was changed.

Final owned SHA:

- narrative_output_language.py: `ca835583905aff912ddb2e7006d7e7d822aa0fc2969d1c444aa9b95a38e52a6d`.
- test_narrative_output_language_observer.py: `91453d95b2d7c6dbac262a07c93747043e9e21617c7eaf220c9e3293b79c9be4`.

Exact commands, source/test/config/installed-resource SHA/mtime before/after and Temp recovery are in final-green-receipt.json; drift0. Owned RED and final test Temp were restored/removed; the first sandbox fallback's reported cleanup failure is separately retained and current existence recorded in handoff.json. No production E2E, supplier/model, parse, download, Git, PWF or installation was written/run here. ROOT owns production E2E and final commit/push. Component green does not certify real model output quality.

**SOURCE STOP**.
