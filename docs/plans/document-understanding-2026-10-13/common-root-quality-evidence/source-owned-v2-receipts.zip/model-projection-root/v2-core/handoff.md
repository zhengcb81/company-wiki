# Source-owned model boundary v2 — SOURCE STOP

## Owned scope and API

Only three repository files were changed: `automation/narrative_model.py`, new `tests/unit/test_narrative_source_owned_model_boundary.py`, and new frozen `tests/support/reading_boundary_legacy_snapshots.json.gz`. The fixture is a byte-for-byte copy of ROOT's existing six-case20,069byte before.gz, SHA `b8403d5c8b3b3c75c4d70ed9c02e89dd0ea83ad3ab7aa4ef2b5898149da789dd`; no gold was regenerated. No Git/source writes outside this slice, original/document parse, suppliers, models, downloads, installation or production configuration writes.

- Existing `READING_MODEL_PROJECTION_VERSION='reading-model-input/1'` remains unchanged; added `SOURCE_OWNED_READING_MODEL_PROJECTION_VERSION='reading-model-input/2'`.
- Frozen `ModelBoundary` has `reading_projection_version`, `prompt_version`, `request_schema`, `decoder_version`, `source_owned`.
- `resolve_model_boundary(version, *, projected=False)` is the single finite policy dispatcher. None/v1 retain old raw/official branches; v2 raw/official share prompt `reading-source-owned/2.0.0`, request schema `narrative-model-request/3`, decoder `reading-source-owned-decoder/2`. Unknown/false/list/string-null versions are refused, not silently lowered.
- `reading_model_boundary_identity(version, *, projected=False)` returns the exact eight frozen pathless keys: schema_version=`reading-model-boundary/1`, reading_projection_version, prompt_version, request_schema, decoder_version, instruction_sha256, response_schema_sha256, decoder_sha256. Prompt and claims-only base schema are actual consumed content digests; decoder SHA is this module's actual bytes normalized to LF. No path/mtime/original/config read enters that identity. Actual per-selection citation caps/body remain pinned separately by request/HTTP bytes.
- `decode_model_draft(response, *, selected, reading_projection_version=None)` has the new keyword; old callers continue None behavior.

## Responsibility change

V2 model response remains `{'draft': {'claims': [...]}}`; the output schema requests only claims, not source/subject ID/SHA/language/status. Input source/subject envelopes contain only language/title/document_kind; evidence aliases, original text, roles, quality flags, real group aliases and bounded semantic reading context remain unchanged. A real reading_context is required for v2.

Internal request identity still binds the full pinned subject for raw and official projections, canonical citation/group maps and selected metadata. Two different immutable sources can produce identical model HTTP bytes yet different inputSHA. Distinct official original parents remain separate; reused record labels never merge parent groups.

Decoder builds canonical header from pinned selection. Additional echoed identity/language/status values cannot replace it or block the request; one static `SOURCE_OWNED_MODEL_METADATA_ECHO_IGNORED` logging diagnostic observes the ignored echo, with no raw value. Quality status is still projected from evidence and claims. No header-value comparison/permission stage is introduced for v2.

Strict JSON, explicit translation rejection, original role, citation and group validation, unique claims, bounds and whole-claim recovery are shared with the existing decoder. A bad claim is discarded whole, not repaired by deleting unsupported citations; retained claims get existing partial-quality projection. None/v1 still use historical model-header identity validation.

## TDD and concentrated evidence

1. Initial RED:29FAIL +6PASS in8.77s. All six ROOT-frozen legacy request fields and actual HTTP bytes passed before implementation; v2 tests failed because its boundary did not yet exist. Logs/XML preserved.
2. First GREEN:34PASS +1FAIL in6.47s. The failing new assertion incorrectly required the word question; the existing validator correctly refused with `non-company evidence cannot support a company statement`. Only the new test message assertion was corrected; production role behavior was preserved. Log preserved.
3. First concentrated run:141PASS,14ERROR,0assertion failures in16.21s. All14 were sandbox-default pytest Temp numbered-dir creation errors; logs preserved. No old tests or code were altered to address that environment failure.
4. Same concentrated suite in a uniquely owned TemporaryDirectory, scoped TEMP/TMP and cache directory: **155PASS in11.07s**, whole guarded subprocess19.204709s, exit0. Owned Temp/cache restored; model source, original frozen/copy fixture and production config SHA/size/mtime drift0.
5. Ruff: two owned Python files PASS. Mypy: model module PASS, no issues (follow-imports=silent). Its55,719,952byte cache was removed from the verified explicit owned directory after completion; no other actor's cache/Temp was cleaned.

The seven-file concentrated package covers the new42boundary tests plus113related existing tests: raw/official request/decoder, reading transport/projection, alias groups, role separation, frozen HTTP controls and group contract. The added causal tests prove actual instruction/schema changes affect identity, LF/CRLF/path changes do not create false decoder drift, source changes do, old prompt versions do not mix with v2, and strict duplicate-key/nonfinite/non-UTF8 JSON remains invalid.

## Integration and remaining scope

ROOT owns generation/batch/factory/summarize/verify/runtime wiring and actual language detection. This slice has **no claim-language classifier implementation**: a program-generated language header alone cannot prove a model claim's text remains in the original language. No real model was called; no claims of supplier output quality, full source recall, material summary completeness, production default switch or RF analyst forecast acceptance.

ROOT should pass the same frozen version to request and decoder, bind this v2 identity only in v2 generations, and keep legacy manifest bytes untouched. Runtime/header binding and real-budget replay must be tested at ROOT's integration node. The earlier VRSK route/IR operating-denial/parser-duration diagnoses remain separate, unresolved source tasks; this slice did not modify routing/business policy.

Artifacts in this owned directory: `red.log/xml`, `green-first.log/xml`, `concentrated.log/xml` (environment errors), `concentrated-owned-temp.log/xml`, `concentrated-owned-temp-receipt.json`, `ruff.log`, `mypy.log`, `run_concentrated.py`, `handoff.json`.

Reproducible concentrated command: `python -X utf8 -B .planning/shared-reading-production/model-projection-root/v2-core/run_concentrated.py`. It uses isolated owned Temp and restores it; no provider or production file writes. Current source is frozen for ROOT reception; do not amend this slice concurrently with ROOT's final integration.

**SOURCE STOP.** No commit/push/installation/PWF edits performed by this lane.
