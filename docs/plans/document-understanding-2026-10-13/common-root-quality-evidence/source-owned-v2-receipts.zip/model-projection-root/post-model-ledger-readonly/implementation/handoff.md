# Failed summary output quota — SOURCE STOP

## Scope and implementation

Only `src/company_wiki/automation/store.py`, `src/company_wiki/automation/narrative_run_store.py`, and new `tests/unit/test_narrative_output_failure_finalization.py` were changed. No existing test, production config, shared PWF, Git state, or historical reservation was changed.

`AutomationStore.finish_attempt` first validates the current active lease and outcome. For a failed `source.narrative_summarize` result containing neither artifacts nor effects, it asks the native RunStore accounting helper to settle that exact attempt's output to zero, inside the same existing SQLite transaction as the finished attempt and job state. Public `settle_output` and this path now share the same settlement implementation and conflict/idempotence rules. No second Store or transaction is introduced.

Native usage status, token and cost charges, response hash, and transport error remain unchanged. Known, unknown, and still-reserved costs are retained. Successful/pending results, other job types, lost/crashed workers, stale leases, and failed results carrying an artifact do not receive this credit. A failed result carrying effects retains the existing rejection. A positive prior output settlement conflicts and rolls the finish transaction back. There is no historical backfill, public schema change, fee refund, or retry POST.

## Actual TDD and verification

- RED: 25 new tests executed, **12 failed / 13 passed**, exit **1**, pytest 17.71 s. These expose the real reservation defect; failure stdout, stderr, JUnit, and exit code are preserved under `red/`.
- GREEN: the new 25 tests and existing atomic Store, native RunStore, run ownership, model caller, and failed-final public CLI tests executed together: **100 passed**, exit **0**, pytest 76.30 s; no skips or errors. Evidence is under `concentrated-green/`.
- Ruff on all three changed files: exit **0**, no cache.
- mypy on both changed source files: exit **0**, cache directory `NUL`.

The real public CLI test performs one synthetic local loopback HTTP POST and triggers strict summary identity failure after a complete transport response. Native known usage remains 92 tokens, the response SHA remains exact, and the native transport error remains null. The output reservation settles to zero with no accepted artifact. Resuming that failed run makes **zero additional POSTs** and leaves the entire AUTO database dump unchanged.

Additional tests prove exact rollback after SQL settlement followed by a fault, successful same-lease retry, committed finalization after a lost COMMIT acknowledgement without repeated credit, unchanged lost-predecessor quota, independent document slots, and active-lease fencing. They forbid a second native RunStore write transaction during finalization.

## Restoration and publication

Supplier calls: **0**. Local HTTP is confined to the loopback fixture. Isolated Temp roots were removed; pre-existing sentinels and immutable fixture originals were preserved. Canonical production configuration SHA, size, and mtime were checked unchanged. No commit or push was performed.

Exact frozen source/test hashes, actual node exits/JUnit counts, restoration receipts, and static command evidence are in [`source-stop.json`](source-stop.json). Files are SOURCE STOP; ROOT owns further integration, PWF updates, commit, and normal push.

| File | SHA-256 |
| --- | --- |
| `src/company_wiki/automation/store.py` | `4646402295499f74bbcd2084aefcd6cbb95d1c4213d499e7dea66fb0a600fcd4` |
| `src/company_wiki/automation/narrative_run_store.py` | `83ea08d532e1ea9121b435294a6fd150450909c18d7c4a7f1041ac0a81962ddb` |
| `tests/unit/test_narrative_output_failure_finalization.py` | `5ab2696a77a100bce3414f87e0c0a378b417b4631087bff9808153f3c0fd114d` |
