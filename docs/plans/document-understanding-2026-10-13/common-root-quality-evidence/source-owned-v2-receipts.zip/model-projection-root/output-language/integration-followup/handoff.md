# Historical reading generation integration — SOURCE STOP

## Scope

Only `tests/integration/test_reading_projection_generation_e2e.py` was changed. No production source, shared support, observer/tests, config, shared PWF or Git was changed by this worker. ROOT owns the production prompt-map fix, schema-aware shared provider helpers and final release.

The obsolete default-constant patch is replaced by the actual explicit `generation_manifest(..., reading_model_projection=None or "reading-model-input/1")` interface in isolated controller/worker bootstrap. Both projection constants remain intact. None/v1 each exercise two scenarios, for **four actual integrations**. A local transparent recorder observes the shared helper's real reply; it does not supply another protocol. Schema 3 uses the final shared claims-only response, while None/v1 preserve their full legacy header response.

## Final actual result

`final-frozen-green/`: **4 passed**, exit **0**, pytest **133.42 s** (runner elapsed 144.86 s), no errors/skips. Ruff on the owned test exits **0**, no cache (tool chunk `3eb127`). No optional large suite was run.

All of the following completed through the ordinary production CLI and real child worker factory:

1. None and v1 pause before model reservation: zero POST, zero native reservation. Resume with current `/2` defaults sends exactly one local POST, with byte-identical recorded legacy system instruction and user JSON. Old frozen bindings remain exact and have no newly inserted job-prompt map.
2. None and v1 have already-paid output awaiting activation: restore it without a second POST. Existing attempt/request/response hashes, usage and charge remain unchanged. The old public exact reference reads successfully.
3. Each historical paid scenario then creates a current `/2` generation: exactly one new POST, actual schema-3 claims-only reply, a different model request hash and artifact pin, and the actual per-job prompt `reading-source-owned/2.0.0` bound in the raw run.
4. Same-run resume and a new run against another AUTO database both reuse the current exact artifact without another POST. Cross-database native reservations/tokens/money are zero. Origin current and historical native accounting stays exact.
5. The new public bundle retains the full original reading context. Its new visible pin does not invalidate the older exact reference, which still returns the exact earlier bundle.

Total **6 local synthetic loopback POSTs**, **0 supplier calls**: two pre-model-recovery tests each use one POST; two historical-paid-to-current tests each use two. Fixture pricing is a proxy, not a supplier invoice: each actual paid synthetic call records 92 tokens / 111 proxy micro-USD. Actual native/public facts for ten phases were saved before assertions in `final-frozen-green/process-proof.json`, including run prompt, optional job prompt map, manifest prompt versions and native reservations.

## Frozen source and restoration

Before/after fingerprints cover **440 files**: the complete `src/company_wiki` Python and JSON/YAML policy closure, all top-level Python scripts, both actual shared helper files and the owned integration test. SHA-256, byte length and nanosecond mtime match for every file; source drift is empty. This includes actual inventory, reading, replay, select, model, observer identity, runtime, factory and batch owners rather than the former seven-file subset.

Canonical configuration SHA/size/mtime, immutable company fixture originals/sidecars, and pre-existing sentinels were checked unchanged. The independent fixture lakes, runner Temp and relocated pytest basetemp were removed. Execution used the authorized real host loopback (`require_escalated`), avoiding the separately proven restricted-sandbox TCP denial. No network/supplier retry or test relaxation was introduced.

Owned test SHA-256: **`e7caf712ed177d36cc889bd30c2d506f01db2f89d67155c780fd3c7d334b92b8`**, 15,599 bytes. Exact fingerprint and all actual node exits/JUnit counts are in `source-stop.json`.

## Failures preserved and common cause resolved by ROOT

`baseline-red/` retains the real original **2 failures / exit 1**, proving that setting the former `/1` constant to None no longer constructed a historical None generation. `fixture-explicit-generations/` retains **2 passed / 2 failed / exit 1**: historical restore passed, but the subsequent current raw `/2` run failed before POST with a binding conflict. These intermediate nodes were marked NO_CERT while other causal owners were still writing; no cache tail was falsely signed off.

Read-only investigation identified the raw schema-1 prompt-map gap: native admission correctly fell back to run prompt `1.7.0` when its immutable per-job map was absent, but the current `/2` request actually used `reading-source-owned/2.0.0`. ROOT separately proved and fixed that common cause with TDD, preserving old None/v1 missing-map identity. This final frozen integration now observes both historical absent maps and current actual maps and passes the previously failing tail. Native validation was not weakened.

SOURCE STOP. ROOT may perform its centralized normal-hook validation, commit, push and PWF update. No commit or push by this worker.
