# Actual output prose language observer — SOURCE STOP

## Delivered interface

Two new files only: `src/company_wiki/automation/narrative_output_language.py` and `tests/unit/test_narrative_output_language_observer.py`. ROOT owns dependency declaration/install, decoder composition, causal version binding, shared PWF, commit and push. The previously delivered Store files remain STOP.

`observe_summary_language(claims: Sequence[SummaryClaim], *, evidence_spans: Sequence[EvidenceSpan]) -> LanguageObservation` returns the frozen fields `state`, `output_family`, `source_families`, `prose_claims`. States are `compatible`, `different`, `uncertain`, `unavailable`. Inputs are canonical typed claims after citation binding. No header or self-reported model language is used.

It observes each claim's actual prose against only its own cited raw spans. Source families come from substantive cited text and its aggregate. Output requires whole-claim, substantive complete-sentence, and aggregate agreement. A different claim's foreign citation cannot supply this claim's language evidence. Nonobservable local citations and cross-claim borrowing remain uncertain.

An identifier is lazily created per thread and PID. It uses the complete py3langid 0.4.0 model, with **140 unique labels / 142 class entries** (the shipped entries duplicate `sr` and `uz`). No `set_languages`, shared module-level client, network or model call. `zh`, `wuu`, and `yue` map to one Chinese writing family. The uncalibrated posterior is not an acceptance threshold.

Bounds are 20 claims, 5,600 claim characters, 96 supplied spans, and 48,000 characters across **unique actually cited** spans. Bounds return unavailable before loading the classifier. Unreferenced text is not classified and contributes neither language evidence nor cited character count. Numeric labels, short Items, model names and short proper names abstain. Different requires sufficiently substantive output (at least two substantive claims or one long complete prose claim), actual source comparability, and agreement on a family absent from the cited source families. Missing or failed classifier is unavailable; neither abstention state becomes default English or permission to publish.

Exact original prose in a claim's own citation is compatible. Exact retained quotations use straight double, curly, guillemet and CJK quotation delimiters; only the cited exact substring is removed from surrounding generated-prose observation. Nothing is erased from stored claims or originals. Semicolon product/operating lists stay in their grammatical sentence: splitting one saved Spanish sentence into an English product list would falsely imply a second language.

## Actual verification and failures retained

All stdout, stderr, JUnit and actual exits are saved in the named directories:

| Node | Actual result | Interpretation |
| --- | --- | --- |
| `red` | exit 1, 52 setup errors | The new target module did not yet exist; explicit initial RED. |
| `green-first` | exit 1, 51 failed / 1 passed | New test fixture incorrectly used coordinate names `page/block`; full-model count confused entries with unique labels. These were corrected in the owned new test only. |
| `green-fixtures-corrected` | exit 1, 1 failed / 51 passed | Real 20-claim MiniMax case abstained because a semicolon product list was treated as a separate English sentence. Exact diagnostic in `real-case-disagreement.json`. |
| `green-sentence-boundary` | exit 0, 52 passed | Complete-sentence boundary fixed that shared cause without keyword exceptions or probability thresholds. |
| `red-local-citation` | exit 1, 2 failed | Exposed global language borrowing from another claim and unsupported short-Item citations. |
| `concentrated-green` | exit 0, **119 passed**, pytest **8.80 s** | New observer 60 plus existing aliases 9, model requests 8, source-owned boundary 42. No existing test changed. |

Ruff (both new files, no cache) and mypy (new source, cache `NUL`) both exit 0. mypy ignores only the actual untyped third-party import, not the observer's body. Receipts are in `source-stop.json`.

The self-contained test includes the saved **20 Spanish claims and 43 actual cited English spans**, rather than depending on ignored scratch. It detects `different/es/(en,)/20` without repairing the invalid original JSON or examining its correct English header. It also covers generic en/es/fr/zh prose, foreign names and operating brands, Chinese `wuu/yue`, mixed English/Chinese sources with a third output language, actual retained original quotations, verbatim bilingual prose, short labels/model/numeric abstention, mixed output, disagreement with aggregate, per-claim citation scope, missing/failed library, all language labels, and thread/PID isolation. Genuine correct Chinese long prose with posterior about 0.705 is compatible; a second control replaces scores with 0.000001 while retaining real labels, proving scores alone do not decide.

## Limits and restoration

This observer establishes finite text-language observations, **not** translation fidelity, fact correctness, reference entailment or every sentence's semantic validity. It is intentionally uncertain for mixed/contradictory or insufficient text. The floors are information bounds for substantive prose, not a population accuracy claim. ROOT chooses decoder composition and preflight; this module adds no identity receipt, approval, retry, output schema or persistent task state.

Zero supplier calls and zero network calls. Independent Temp and relocated pytest basetemp were removed, sentinel retained, canonical production config SHA/size/mtime unchanged. Saved samples still match their original probe SHA `51e51ba4f9748d3548cca72baaff507cbed5123718b56acf57dafa43eacd4592`. No original/config/shared PWF/Git writes or installation by this worker. `build_tests.py` records initial fixture extraction only; the authoritative full 60-test file is the frozen repository test and should not be regenerated from that historical script.

Frozen SHA-256:

- Source: `31536acd569650b7ee184007d69c3c406ee0619019da4bb1c2df4673f5cc6b88`.
- New test: `f78ebf61c4257776c507b485b7d07d958722a8804e1c286aa31e4a9929afedd0`.

SOURCE STOP; ROOT may now compose and perform final integration/publish. No commit/push by this worker.
