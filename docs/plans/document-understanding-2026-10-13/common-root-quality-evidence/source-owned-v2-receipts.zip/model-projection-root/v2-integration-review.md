# V2 A/B integration — independent read-only review

## Scope and method

This report preserves the initial review of ROOT's actual generation/batch compression and resume, summarize, verify/runtime, frozen worker descriptor, source-usability inventory, and the output-finalization/partial-source authors' delivered source and handoffs. At that initial window the language observer was separate and not frozen; the subsequent received repairs and final read-only comparison are recorded below. Default0.8 remains unchanged. No source/tests/PWF/config/Git writes, paid/model/download/PDF parse or optional broad suite.

Two small pure counterexample groups ran successfully in0.029937s compute (one ordinary Python startup). Only the requested review JSON/Markdown were written. An in-memory source-byte substitution tested dependency hashing; it did not change source files. A synthetic typed span plus a pure matcher spy established the actual non-normalized call branch; it is not a real parser or a source-integrity certification.12 relevant sourceSHA/size/mtime before/after stayed equal. No Temp files were created.

## Historical finding1 — P2: transcript matcher causal dependency (repair received)

`automation/narrative_select.py::_verify_selected_material` chooses the normalized verifier only when the actual parser is `cwp_document_normalization`. Every other parser, including the existing raw TXT/JSON transcript producer, uses `source_catalog.narrative_replay.verify_replayed_pdf_spans`. Its synthetic transcript branch called the matcher once in this independent probe.

At the initial review, `document_understanding/decision_inventory.py::_source_usability_version` added that matcher module only for MIME application/pdf; text/plain and application/json include only narrative_select. In-memory changes to the actual matcher module produced these actual results:

| Carrier | Dependency changed? | Actual responsibility |
|---|---:|---|
| application/pdf |Yes |Correctly bound |
| text/plain |**No** |Raw transcript selection calls this matcher; missing dependency |
| application/json |**No** |Raw transcript JSON selection calls it; official JSON is a separate typed path |
| text/html |No |Correct: normalized verifier owns the proof |

This can leave a transcript decision digest saying SAME after a real used verifier implementation changes. It does not prove corrupt bytes are currently accepted—the final public reader still reopens/replays—but the cache/software causal contract is incomplete. The current PDF/HTML55test package cannot cover this actual TXT call path.

Suggested root repair: reflect the actual source proof mechanism in the existing inventory rather than infer relevance from the helper's PDF-shaped name. Include the shared matcher for raw transcript TXT/JSON, preserving the normalized HTML irrelevant-module control. If application/json contains both official projection and transcript carriers, use the existing typed source/parser responsibility to distinguish them; do not introduce a second registry or blanket unrelated hash. A generic renamed/shared matcher can be an internal followup, but callers should not fork its logic.

Concentrated RED: build an actual raw transcript reading dependency, change only its used matcher code, expect CHANGED; relocation/CRLF remains SAME, changing normalized replay code remains SAME for TXT. Preserve official JSON parent/source semantics separately. No new identity or approval gate.

## Historical finding2 — P2: old None-resume bootstrap (explicit historical API now inspected)

`tests/integration/test_reading_projection_generation_e2e.py::test_old_missing_projection_pauses_before_model_and_resumes_exact_legacy_bytes` at the initial review patched only `narrative_model.READING_MODEL_PROJECTION_VERSION=None` in controller/child bootstrap. Current `_bind_reading_projection` chooses `SOURCE_OWNED_READING_MODEL_PROJECTION_VERSION=/2` for selector0.9 when the argument is omitted. The independent pure probe patching the exact old constant observed reading-model-input/2 and reading-source-owned/2.0.0, while the old test expects du-production-reading/1.

This is a fixture no longer reproducing the historical branch, not evidence that legacy bytes should be changed. Preserve the old scenario using the existing explicit `generation_manifest(..., reading_model_projection=None)` and the matching official entry when applicable. Both coordinator and actual worker must see the resulting frozen descriptor. Do not merely set the v2 constant to None: that would also turn version equality in the renderer dispatcher into a false source-owned branch. ROOT already added None/v1/v2 cases elsewhere; this existing old bootstrap needs the same explicit correct interface.

No test source was changed by this review. Legacy six frozen request/HTTP snapshots and all core behaviors remain accepted as previously delivered.

## Reviewed integration paths with no new concrete defect found

- `_bind_reading_projection` puts actual v2 prompt/request schema and the exact eight-key instruction/schema/decoder identity into the existing generation; legacy omission/v1 don't receive new identity fields. `_freeze_generations/_thaw_generations` retain it in deduplicated settings and verify exact causal SHA. Model core stays SOURCE STOP.
- Summarize resolves the per-subject callback **once**, passes the same version to `from_selection` and `decode_model_draft`, and records the actual response prompt. Verify and Runtime use that same configured callback. The frozen worker snapshot derives generation values/selector/projection/model options from one decoded binding; actual HTTP options are compared with frozen effective behavior before use. These are software compatibility checks, not permission to process a document.
- V2 worker descriptor checks actual boundary content/hash and active prompt/schema, without source rereads or a second model identity. Completed-history exemptions and public replay remain distinct from creating new paid work; no new broad cache machinery was added.
- Selection's partial usability predicate keeps incomplete coverage visible and uses the **already parsed** actual material proof before model work. Original shape/path/cap/group constructor executes once before material matching; selected corrupt/low-quality content is rejected, administrative complete empty input skips. The source author retained normalizer/PDF/native/QA protections and proved one select parse plus final verify reopen. No new permissive shadow or borrowed context was found.
- Store output release occurs within the same fenced SQLite finish transaction, only for an explicitly reported failed summary with no artifact/effect. It shares the public settlement helper and conflict/idempotence rule, preserves all known/unknown/reserved token/cost/response receipts, and does not refund a crashed/lost/stale predecessor. The delivered25new/100related tests cover rollback, lost-COMMIT acknowledgement, exact run attempt ownership and one loopback response/zero resumePOST. Source hashes match the author handoff below; no broad suite was repeated by this reviewer.

Store author frozen SHA: store.py `4646402295499f74bbcd2084aefcd6cbb95d1c4213d499e7dea66fb0a600fcd4`, narrative_run_store.py `83ea08d532e1ea9121b435294a6fd150450909c18d7c4a7f1041ac0a81962ddb`. Partial-source's177test final handoff remains `.planning/shared-reading-production/recall-root/live-summary-review/partial-source-tdd/handoff.md`; its proof source modules are included in this review snapshot. Author tests are evidence from authors, not independent reruns.

## Initial limits and next node (historical)

At the initial review, these two findings required correction before ROOT's concentrated integration node. The final reception section below supersedes their open status. Do not add a small-node permission or a whole-matrix/paid retest solely for these pure boundaries. Final source hashes may change under ROOT repair; the initial frozen counterexamples must remain as RED observations and the same groups may be checked once after its SOURCE STOP.

At that initial window, the original-language observer and its summarize+observer causal binding were pending ROOT's separate integration. They are now received as software integration, as described below. A canonical header language is insufficient to prove each claim's actual text language; no language/model-summary/business-recall/RF analyst acceptance is claimed here. The VRSK falsecall/IR operating-denial/HKIPO duration problems stay in the separate root-cause report, unresolved by this model-boundary node.

**Read-only review delivered. Source, tests and configuration remain STOP.** Detailed pure probes and exact12source snapshots are in `v2-integration-review.json`.

## Supplemental language review and ROOT-authorized causal repair — SOURCE STOP

The language wiring was then inspected after ROOT's source window: v2 only, canonical typed claims and their own cited original spans; `different` goes through the existing post-model failure/metrics/failed-final path, with no artifact/effect; `uncertain/unavailable` remain consumable quality metadata and static diagnostics. None/v1 do not call the new observer. Generation binds the actual summary wrapper/observer code separately from the unchanged core's eight-key decoder descriptor; factory checks this software descriptor. These are existing responsibility/causality checks, with no new manual permission.

A concrete dependency omission was independently reproduced: actual py3langid distribution0.4.0 metadata remained available while its MODEL_FILE pointed at an uncreated path. The real observer returned **unavailable**, but the old summary-validation descriptor was identical. No installed file was changed. Initial synthetic span parser_version=`1` failed the existing semver contract before any observation; only that harness field was corrected to1.0.0, and the failure remains explicitly recorded in JSON rather than counted as a product defect.

ROOT then explicitly assigned only `narrative_output_language.py`'s new identity helper plus dedicated causal tests in the existing observer test module. The original classification/abstention logic was left unchanged.

`language_observer_identity() -> dict[str, Any]` now returns a detached pathless `narrative-language-observer/1`:

- py3langid actual distribution/version/status;
- its actual `py3langid.langid` Python code SHA and normalized-LF byte count;
- actual MODEL_FILE binary weight SHA/byte count, preserving raw binary line endings;
- actual NumPy distribution/version/status;
- missing library/module/model/distribution as explicit unavailable components. Restoring a missing model changes identity without requiring a version bump.

Only these static software resources use a locked16entry stat-key digest memo. Document strings/text/evidence and classifier instances never enter it. Weight bytes are streamed; the memo holds only digests/counts. A changing file is not pinned from partial read bytes.100successive identity calls opened unchanged fake weights exactly once. Location and codeLF/CRLF changes with the same normalized code/raw weight bytes do not invalidate content; code/model/version/missing-component changes do. Installed package/library/model files were never modified. ROOT owns consuming the nested `language_observer` field in summary_validation, preserving the readable detector_distribution and core8key contract.

TDD: **7new tests RED**,60other cases deselected, exit1/3.88s (identity API missing). Final existing observer + ROOT binding node: **76PASS /4.81s**, whole guarded window10.834452s, exit0. Ruff two owned files PASS; Mypy one source PASS with cache_dir=NUL. Actual command, XML/logs and source/configSHA/size/mtime before/after are in `lang-identity-green-receipt.json`; drift0. Green TemporaryDirectory and the explicitly verified own RED Temp were removed. Config sentinels and production configuration remained unchanged. No new paid/model/download/PDF parse/Git/PWF/install write.

The old None-resume test now visibly uses the real explicit historical generation API and retains missing/v1 assertions; ROOT owns its actual new E2E result. The initial transcript matcher finding is now closed by its own actual parser-owner binding repair and dedicated 84-PASS TDD receipt, rather than inferred from language tests; see final reception below. Supplier/model quality, business recall, full RF forecasts and the other type-matrix root causes remain outside this concentrated acceptance.

**Supplement SOURCE STOP.** Exact owned source/testSHA and final review receipt are in the adjacent JSON. No further code changes by this lane; ROOT owns final integration and normal commit/push.


## Final read-only reception — SOURCE STOP

The historical RED evidence above is retained. No source/tests/configuration/PWF/Git were changed in this final comparison, and no new tests, native parses, model/supplier calls, downloads or Temp files were started.

### Received engineering repairs

1. **Transcript matcher dependency: resolved and received.** `causal-followup-handoff.md` and the final-resolved receipt match the current inventory/source-selector/test SHA exactly. `select_reading_evidence` passes the actual already-parsed unit parser names to the existing inventory. The finite source-matcher-used component follows the real normalized-versus-narrative verifier branch, including mixed parsers and same HTML/XHTML MIME. `current_decision_trace` replays that existing proof; it does not reread sources or create a second registry. Used verifier code changes invalidate the decision, unrelated matcher changes do not; relocation/CRLF controls remain. `source-usability/3` invalidates old insufficient decisions without rewriting historical bundles. Dedicated 38 new tests plus the existing inventory/cache node: **84 PASS / 3 deselected, 8.64s pytest, exit0**; Ruff and Mypy exit0. The three parse-requiring exclusions are not claimed as passed. Earlier 2/4-failure RED and intermediate typing failure remain recorded by the owner.

2. **Raw schema1 per-job prompt: resolved and received.** The actual new raw run still has the historical container prompt1.7.0, while its v2 model job must use reading-source-owned/2.0.0. `_frozen_binding` now adds job_prompt_versions when generation prompts differ from the container even for schema1; resume checks the exact per-job mapping. Existing equal legacy prompts retain the old wire, and official schema2 retains its mapping. The saved real RED is **1 FAIL / 5 PASS, 3.55s**; the final concentrated batch/generation/resume node is **87 PASS / 25.33s pytest, exit0**. The earlier None-bootstrap fixture now uses the explicit historical generation API in both processes; its source correction is inspected, but that full process/loopback E2E is not independently rerun here.

3. **Language software/model causal identity: connected and received.** Actual `reading_summary_validation_identity` consumes the complete nested `language_observer_identity()` dict while retaining readable detector_distribution. The decoder's original eight-key descriptor is unchanged. Actual detector Python code, binary weights and py3langid/NumPy distributions remain in their responsible helper, with bounded static digest memo and explicit unavailable components. This is software freshness, not document permission. The existing v2-only output-language failure/quality paths and legacy branch remain as reviewed. ROOT's saved final nine-file concentrated node is **206 PASS / 6.90s pytest, exit0** (guarded command11.081118s), with Temp/sentinel/config unchanged and 0 supplier calls. Author/ROOT tests are reviewed evidence, not a second independent execution by this reviewer.

### Exact current source acceptance

| File | SHA-256 |
|---|---|
| decision_inventory.py | `6b43c2ef1f0c98dae2a897a533ac72c1632ed2767f87012d3e68267e6ed0d6d6` |
| source_catalog/narrative_reading.py | `517c50fe52645b08d189feec41db1be3b8cf235c9ec27cb97883a387599ac04a` |
| narrative_batch.py | `9e51d0b6ef2a4f8c6f614828570894e9ed29033093ed6393eaaa820802d17e41` |
| narrative_summarize.py | `25fccd7460f84425ac15c121eb051b0aeb2129e54d12e34e339ac4e1bb8422a7` |
| narrative_output_language.py | `058764d05f548994b8c07b0dc6350ecb22260b6051c93f6935c7258ce3a545ca` |

All current inspected source/test/config SHA/size/mtime are in the adjacent JSON final_reception snapshot; initial snapshots remain historical. This final read-only window checks they stay unchanged rather than falsely claiming the whole development tree has never changed.

### Still not certified by this node

- Actual configured supplier v2 model end-to-end output quality, source-language prose and broad business recall remain **NOT_EVALUATED** here. Component/loopback tests cannot certify a real model response or a full RF forecast/analyst conclusion. ROOT's paid run has its own receipt and acceptance.
- The old None/v1 cross-process resume/outbox E2E after its corrected explicit fixture remains ROOT's responsibility; this read-only comparison inspects the correction and frozen contracts, not a new execution.
- Type matrix's VRSK actual10-Q falsecall, IR critical operating-denial omission and HKIPO80s parse cutoff remain their separately recorded root-cause scope; no repair is inferred from these model-boundary tests.
- Real S-1/F-1/8-K/6-K/amended and a genuine administrative-policy sample were missing in the purposive type matrix. HKIPO actual original exists but completed parsing was not certified within that window. Those types are not silently treated as covered.
- The 20-document matrix is purposive architecture coverage, not representative recall or holdout certification. Default selector0.8 is unchanged by this component acceptance.

**Final read-only reception STOP.** This lane updates only this Markdown and its existing JSON. ROOT owns subsequent paid E2E, overall PWF/main publication and normal hooks/commit/push.
