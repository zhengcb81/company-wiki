"""One release-node probe: genuine official QA publication -> RF public CLI."""
from __future__ import annotations

import json
from pathlib import Path
import runpy
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[3]
sys.path[:0] = [str(ROOT / "tests"), str(ROOT / "src"), str(ROOT / "scripts")]
hermetic_runtime = runpy.run_path(str(ROOT / "tests/conftest.py"))["hermetic_runtime"]
from integration import test_shared_reading_production_e2e as production
from support import official_json_batch_fixture as fixtures
from company_wiki.narrative_subject import NarrativeSubject, NarrativeSubjectRef

official_json_loopback_model = production.official_json_loopback_model


def test_real_qa_public_bundle_crosses_rf_without_losing_attribution(
    tmp_path, official_json_loopback_model, monkeypatch,
):
    original_read = fixtures.invoke_read
    observed = []

    def read_then_rf(state, reference, *, issuer=None):
        bundle, replay = original_read(state, reference, issuer=issuer)
        subject = NarrativeSubject.from_dict(reference["subject_binding"])
        discovery_request = {
            "schema_version": "narrative-reference-request/3",
            "subject_ref": NarrativeSubjectRef.from_subject(subject).to_dict(),
            "generation_sha256": reference["generation_sha256"],
        }
        discovery = subprocess.run(
            [sys.executable, "-B", "-X", "utf8", "-m",
             "company_wiki.source_catalog.narrative_transport_cli",
             "--config", str(state.config_path), "--operation", "reference"],
            input=json.dumps(discovery_request).encode(), env=fixtures.subprocess_env(),
            cwd=state.root, capture_output=True, timeout=30)
        assert discovery.returncode == 0, discovery.stderr.decode("utf8", errors="replace")
        compact_ref = json.loads(discovery.stdout)
        for field in ("artifact_version_id", "artifact_sha256", "byte_size", "generation_sha256"):
            assert compact_ref[field] == reference[field]
        request = {
            "schema_version": "narrative-read-request/3",
            "narrative_ref": compact_ref,
            "as_of_date": "2026-10-08",
            "expected_issuer": {k: v for k, v in issuer.items() if v is not None},
        }
        rf = ROOT.parent / "revenue-forecast/scripts/narrative_source_preparation.py"
        command = [sys.executable, "-B", "-X", "utf8", str(rf),
                   "--company-wiki-catalog-config", str(state.config_path),
                   "--operation", "read", "--timeout-seconds", "45"]
        process = subprocess.run(command, input=json.dumps(request).encode(),
                                 env=fixtures.subprocess_env(), cwd=state.root,
                                 capture_output=True, timeout=60)
        assert process.returncode == 0, process.stderr.decode("utf8", errors="replace")
        value = json.loads(process.stdout)
        for field in ("reading_context", "evidence_spans", "summary"):
            assert value[field] == bundle[field], field
        assert value["narrative_ref"] == compact_ref
        assert value["read_receipt"]["replay_status"] == "verified"
        assert bundle["reading_context"]["schema_version"] == "du-production-reading/2"
        claims = bundle["summary"]["draft"]["claims"]
        assert any(claim.get("context_evidence_ids") for claim in claims)
        roles = {span["span_id"]: span["structured_value"]["source_role"]
                 for span in bundle["evidence_spans"]}
        for claim in claims:
            assert {roles[sid] for sid in claim["evidence_ids"]} == {"management"}
            assert {roles[sid] for sid in claim.get("context_evidence_ids", ())} <= {"investor_question"}
        observed.append({"command": command, "exit_code": process.returncode,
                         "claims": len(claims), "attributed_claims": sum(bool(c.get("context_evidence_ids")) for c in claims),
                         "full_context_preserved": True, "replay_verified": True})
        return bundle, replay

    monkeypatch.setattr(fixtures, "invoke_read", read_then_rf)
    production.test_official_projection_shared_reading_publishes_the_final_generation_target(
        tmp_path, official_json_loopback_model, monkeypatch)
    assert len(observed) == 1
    receipt = Path(__file__).parent / "qa-rf-public-observation.json"
    receipt.write_text(json.dumps({"status": "PASS", "observations": observed,
                                  "local_model_POSTs": len(official_json_loopback_model.requests),
                                  "external_POSTs": 0}, ensure_ascii=False, indent=2) + "\n", encoding="utf8")
