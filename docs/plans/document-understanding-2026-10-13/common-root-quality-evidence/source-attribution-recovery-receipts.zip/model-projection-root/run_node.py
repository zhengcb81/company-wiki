from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import tempfile
import time
from company_wiki._bounded_process import ChildFailed, ChildTimeout, TransportError, run_bounded
ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).parent
label, *tests = sys.argv[1:]
missing = [case for case in tests if not (ROOT / case.split('::', 1)[0]).exists()]
if missing:
    raise ValueError(f'Unknown test paths; inventory before running: {missing}')
folder = OUT / label
folder.mkdir(exist_ok=False)
protected = {p: (hashlib.sha256(p.read_bytes()).hexdigest(), p.stat().st_size, p.stat().st_mtime_ns) for p in (ROOT/'config.yaml', ROOT/'config/source_catalog.yaml')}
start = time.perf_counter()
code = 99
with tempfile.TemporaryDirectory(prefix='.cw-', dir=ROOT) as name:
    lake = Path(name)
    sentinel = lake/'existing.txt'
    sentinel.write_bytes(b'original test contents')
    try:
        environment = dict(os.environ, TEMP=str(lake), TMP=str(lake))
        command = [sys.executable, '-B', '-X', 'utf8', '-m', 'pytest', '-q', '-p', 'no:cacheprovider', '--basetemp', str(lake/'p'), '--junitxml', str(folder/'junit.xml'), *tests]
        try:
            result = run_bounded(command, cwd=str(ROOT), env=environment, timeout_seconds=240,
                                 stdout_cap_bytes=1024*1024, stderr_cap_bytes=128*1024)
            code, stdout, stderr = int(result['returncode']), result['stdout'], result['stderr']
        except ChildFailed as error:
            code, stdout, stderr = error.returncode, error.stdout, error.stderr
        except TransportError as error:
            # Existing process owner kills/reaps the entire child tree before
            # TemporaryDirectory cleanup, including Windows worker children.
            code, stdout, stderr = (124 if isinstance(error, ChildTimeout) else 125), b'', type(error).__name__.encode()
        (folder/'stdout.log').write_bytes(stdout)
        (folder/'stderr.log').write_bytes(stderr)
        print(stdout.decode('utf8', errors='replace')[-12000:], flush=True)
    finally:
        assert sentinel.read_bytes() == b'original test contents'
        assert all((hashlib.sha256(p.read_bytes()).hexdigest(), p.stat().st_size, p.stat().st_mtime_ns) == saved for p, saved in protected.items())
assert not lake.exists()
receipt = {'exit_code':code, 'seconds':time.perf_counter()-start, 'tests':tests, 'temp_removed':True, 'sentinel_unchanged':True, 'production_config_unchanged':True, 'supplier_calls':0}
(folder/'receipt.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
print(json.dumps(receipt), flush=True)
raise SystemExit(code)
