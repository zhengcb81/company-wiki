# Citation-unit model /3 — SOURCE STOP

Implemented only the two assigned model sources, one new unit test and one new
pre-change v2 byte fixture. ROOT owns runtime generation/summarize/factory/batch,
PWF, integrated E2E, provider quality, Git and publication. No API calls, original
opens/parses, configuration edits or supplier-specific code were introduced.

## Exact interface

- `CITATION_UNIT_READING_MODEL_PROJECTION_VERSION = 'reading-model-input/3'`.
- `resolve_model_boundary(version).source_owned`: False for None/v1, True for
  explicit v2 and new v3. `ModelBoundary` retains its original five dataclass
  fields; its finite `uses_citation_units` property describes the new policy.
- New prompt `reading-citation-units/3.0.0`, request schema
  `narrative-model-request/4`, decoder `reading-citation-unit-decoder/3`.
- Request retains unique `evidence_columns`/`evidence` original prose. Adds
  `citation_unit_columns=['id','evidence_ids']` and `citation_units` rows mapping
  content-bound `u_<20 hex>` identifiers to existing e aliases. No gN membership
  table remains. `reading_strategy.groups[].id` uses the same unit IDs.
- Response is flat `{'claims': [...]}`. Each model claim has exactly the five
  meaningful fields claim_id, text, citation_unit_ids, claim_type, modality.
  Legacy e/group output fields are rejected, rather than silently reconciled.
  Program-owned identity/language/quality are restored into the existing canonical
  draft; public claims keep their original six fields and canonical span IDs.

`narrative_model_citations.compile_citation_units(evidence_spans, groups)` compiles
one immutable transient binding from the current pinned material. It uses native
groups plus only genuinely ungrouped spans as standalone units. Identical member
groups share a unit; overlapping groups remain separate. Alias membership is bound
to full canonical span IDs, independent of e/group enumeration or native labels.
Collision is a typed failure, never a rebind. Decoder expands only explicitly
referenced units, unique canonical members in selection order, with no recursive
neighbor inference. Multiple claims share one compilation per decode.

Empty, unknown, malformed, foreign, duplicate or dual-namespace references reject
the entire claim. Valid neighboring claims can recover with needs_review. Existing
role/path/claim ID/modality/JSON/translation/20-claim/280-character and configured
token/byte limits remain. This is exact reference compilation, not entailment,
financial truth or a permission decision. Source role mixtures remain checked after
expansion. Table references do not borrow other rows or invent numbers/units/stages.

Instruction explicitly follows the language of cited original prose; English prose
requires English. Reading-policy/instruction language cannot decide output language.
Actual language observation remains ROOT's source-owned wrapper responsibility.

## TDD and concentrated verification

1. Before source edits, `freeze_v2.py` used explicit /2 to preserve four independent
   raw/official/identical-parent-label/English renderer and actual HTTP bodies.
   `tests/support/reading_citation_v2_snapshots.json.gz`: 14,161 bytes,
   SHA `010a09825ca73c3b0ffea5f7208be7dddee76917eba3fa5f74f52d73a8b5f8a4`.
   Actual producer model source SHA was
   `49959956e73125b3e7a53e48cb22ca28f4b7c56a376bfdd9a4d4d6706dbdd453`.
   File was created exclusively; no future implementation generated the old gold.
2. Actual `model-red.xml`: **28 FAIL / 4 PASS**, exit **1**, 2.08s. All four old /2
   byte cases passed; /3 was unavailable. No source edits preceded this RED.
3. First new boundary node: **32 PASS**, exit **0**, 1.16s.
4. After adding once-only compilation, actual implementation fingerprints, collision,
   legacy decoder refusal and cross-parent tests, the concentrated node ran the new
   37 tests plus six existing raw/official/model/strategy suites:
   **169 PASS**, exit **0**, 3.67s; `model-concentrated.xml` and full stdout/stderr
   are saved alongside this handoff. No old test was edited by this lane.
5. Ruff on the two sources/new test: exit **0**. Mypy on both sources with cache NUL:
   exit **0**, no issues in two source files.

Native original fixture prose is in memory; none was parsed or opened. Test socket
creation/connect is forbidden. Both production configuration files and the two owned
model source SHA/size/mtime values are checked before/after each new test. No global
whole-src guard was used, respecting the independent observer writer. Pytest's
existing isolated basetemp cleanup applies; this lane created no production output.

## Frozen source/test hashes

| File | SHA-256 | Bytes |
|---|---|---:|
| automation/narrative_model.py | edde8a8e2453d73e7e95781e9fce9a936fb166d19bea153f94bc74a71644cb7d | 50,584 |
| automation/narrative_model_citations.py | 8b3488b91458528ff3631ac19c856c75c3c980f99ebd468d75e06aba7daab2b0 | 3,898 |
| tests/unit/test_narrative_citation_unit_model_boundary.py | 5eb5acf6e89167c0a52c28c0f8fa20abead8fecaf3f45d678ae104c940657d39 | 17,921 |

## Causality and remaining compatibility boundary

New /3 descriptor hashes actual LF-normalized model **and citation compiler** bytes,
plus its actual instruction/schema/prompt policy. A compiler-only change therefore
changes generation even when request text is otherwise identical. New input hash and
actual HTTP output budget behavior are tested. ROOT's existing generation/factory
binding consumes the descriptor; there is no new registry, state store or user flag.

None/v1 frozen request bytes and existing behavior are green. Explicit /2 request
and HTTP bytes are byte-exact; its incomplete group still fails as before. **This
does not prove true pre-upgrade v2 unfinished-manifest recovery.** Its existing
`decoder_sha256` hashes the whole old model file, so adding /3 changes today's
whole-file descriptor even though v2 renderer/decoder behavior is preserved. No old
SHA was hardcoded, forged or ignored here. ROOT will test an actual saved 5a v2
manifest separately, distinguish historical availability from newly created v2
manifests, and decide the smallest truthful compatibility solution. Old artifacts
and failed attempts were not re-signed or rewritten by this lane.

ROOT runtime/factory/replay/cache/usage integration and actual language/provider
quality are **NOT_RUN by this lane**, pending its one concentrated integration node.
Neither this model green node nor reference validity certifies semantic correctness.
