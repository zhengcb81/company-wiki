"""Freeze only old/current code in a unique short Temp; never originals/config."""
import hashlib
import io
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile
import tempfile

OWNED = Path(__file__).resolve().parent
PROJECT = OWNED.parents[5]
root = Path(tempfile.mkdtemp(prefix="cwo-"))
(root / "owned-marker.txt").write_bytes(b"old-code-resume isolated code only")
copied = []
for tree in ("src", "scripts"):
    for source in (PROJECT / tree).rglob("*"):
        if not source.is_file() or source.is_symlink() or "__pycache__" in source.parts or source.suffix == ".pyc":
            continue
        destination = root / "n" / source.relative_to(PROJECT)
        destination.parent.mkdir(parents=True, exist_ok=True)
        data = source.read_bytes()
        destination.write_bytes(data)
        copied.append({"path": str(source.relative_to(PROJECT)), "sha256": hashlib.sha256(data).hexdigest(), "bytes": len(data)})
export = subprocess.run(["git", "archive", "--format=tar", "5a8e895e", "src", "scripts"],
    cwd=PROJECT, capture_output=True, check=True)
with tarfile.open(fileobj=io.BytesIO(export.stdout)) as archive:
    for member in archive.getmembers():
        path = Path(member.name)
        if (path.is_absolute() or ".." in path.parts or path.parts[0] not in {"src", "scripts"}
                or not (member.isfile() or member.isdir())):
            raise ValueError("unexpected archive member")
    archive.extractall(root / "o", filter="data")
model = Path("src/company_wiki/automation/narrative_model.py")
factory = Path("src/company_wiki/automation/narrative_worker_factory.py")
receipt = {"temp_root": str(root), "old_commit": "5a8e895e",
    "copied_current_files": copied, "current_bytes": sum(item["bytes"] for item in copied),
    "old_archive_bytes": len(export.stdout),
    "old_model_sha256": hashlib.sha256((root / "o" / model).read_bytes()).hexdigest(),
    "current_model_sha256": hashlib.sha256((root / "n" / model).read_bytes()).hexdigest(),
    "old_factory_sha256": hashlib.sha256((root / "o" / factory).read_bytes()).hexdigest(),
    "current_factory_sha256": hashlib.sha256((root / "n" / factory).read_bytes()).hexdigest(),
    "configuration_copied": False, "originals_copied": False, "supplier_calls": 0}
destination = OWNED / (sys.argv[1] if len(sys.argv) > 1 else "preparation.json")
assert destination.parent == OWNED and not destination.exists()
destination.write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + "\n", encoding="utf8")
print(json.dumps({key: value for key, value in receipt.items() if key != "copied_current_files"}))
