"""One genuine old-code paid outbox, then the pinned upgraded implementation.

No Git mutation, production documents, credentials or supplier calls. The code
snapshots prepared earlier and the synthetic lake are removed in finally.
"""
from dataclasses import asdict
import hashlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
from threading import Thread
import time

OWNED = Path(__file__).resolve().parent
ROOT = OWNED.parents[5]
sys.path.insert(0, str(ROOT / 'tests'))
from integration.test_narrative_generation_reuse import setup_source, request_path  # noqa: E402
from support.narrative_model_request_fixture import response_draft  # noqa: E402
from support.narrative_batch_fixtures import KEY, KEY_ENV  # noqa: E402
from company_wiki.automation.narrative_run_store import NarrativeRunStore  # noqa: E402
from company_wiki.automation.narrative_batch import _thaw_generations  # noqa: E402

preparation = json.loads((OWNED / sys.argv[1]).read_text(encoding='utf8'))
code_root = Path(preparation['temp_root']).resolve()
assert code_root.parent == Path(tempfile.gettempdir()).resolve()
assert code_root.name.startswith('cwo-')
assert (code_root / 'owned-marker.txt').read_bytes() == b'old-code-resume isolated code only'
output = OWNED / sys.argv[2]
assert output.parent == OWNED
output.mkdir(exist_ok=False)
requests = []
errors = []


class Provider(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def do_POST(self):
        try:
            assert self.path == '/v1/chat/completions'
            raw = self.rfile.read(int(self.headers['Content-Length']))
            assert KEY.encode() not in raw
            envelope = json.loads(raw)
            payload = json.loads(envelope['messages'][1]['content'])
            requests.append(raw)
            draft = response_draft(payload)
            body = json.dumps({'model': 'stub-model', 'choices': [{'message': {
                'content': json.dumps(draft, ensure_ascii=False)}, 'finish_reason': 'stop'}],
                'usage': {'prompt_tokens': 73, 'completion_tokens': 19}}, ensure_ascii=False).encode()
            self.send_response(200)
        except Exception as exc:
            errors.append(type(exc).__name__)
            body = b'{"error":"isolated fixture failure"}'
            self.send_response(500)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)


def invoke(code, lake, config, llm, request, *, hold):
    launcher = lake / ('old-hold.py' if hold else 'new-resume.py')
    prefix = '''from company_wiki.source_catalog.narrative_artifact_store import NarrativeArtifactStore
from company_wiki.source_catalog.lock import CatalogOperationLockedError
def held(*args, **kwargs):
    raise CatalogOperationLockedError("isolated old paid activation pending")
NarrativeArtifactStore.activate = held
''' if hold else ''
    launcher.write_text(prefix + 'from narrative_batch_configured import main\n'
                        'if __name__ == "__main__": raise SystemExit(main())\n', encoding='utf8')
    environment = dict(os.environ, PYTHONPATH=os.pathsep.join([str(code / 'src'), str(code / 'scripts')]),
        PYTHONDONTWRITEBYTECODE='1', PYTHON_DOTENV_DISABLED='1', DEEPSEEK_API_KEY=KEY)
    environment[KEY_ENV] = KEY
    result = subprocess.run([sys.executable, '-B', '-X', 'utf8', str(launcher),
        '--llm-config', str(llm), '--allow-local-model-http', '--project-root', str(lake),
        '--catalog-config', str(config), '--automation-db', str(lake / 'AUTO.sqlite'),
        '--work-dir', str(lake / 'work-old-paid'), '--request', str(request)],
        cwd=code, env=environment, capture_output=True, text=True, encoding='utf8', timeout=90)
    assert KEY not in result.stdout + result.stderr
    label = 'old-paid' if hold else 'new-resume'
    (output / (label + '.stdout.json')).write_text(result.stdout, encoding='utf8')
    (output / (label + '.stderr.log')).write_text(result.stderr, encoding='utf8')
    return result.returncode, json.loads(result.stdout)


report = {'schema_version': 'genuine-old-code-paid-outbox-replay/1', 'old_commit': preparation['old_commit'],
    'old_code': preparation['old_model_sha256'], 'new_code': preparation['current_model_sha256'],
    'external_POSTs': 0, 'status': 'NOT_RUN'}
started = time.perf_counter()
server = ThreadingHTTPServer(('127.0.0.1', 0), Provider)
thread = Thread(target=server.serve_forever, daemon=True)
thread.start()
try:
    endpoint = f'http://127.0.0.1:{server.server_port}/v1/chat/completions'
    with setup_source(endpoint) as (lake, catalog, config, llm, imported, kind):
        # The legacy global Config validator requires an unused search key and
        # wiki path. Satisfy its real contract in this synthetic lake, with no
        # PYTEST_CURRENT_TEST bypass. No search tool is invoked.
        llm.write_text(llm.read_text(encoding='utf8')
            + '\nsearch:\n  api_key: synthetic-unused-search-key\npaths:\n  wiki_root: '
            + json.dumps(str(lake)) + '\n', encoding='utf8')
        sentinel = lake / 'existing-sentinel.txt'
        sentinel.write_bytes(b'original')
        protected = {path: (hashlib.sha256(path.read_bytes()).hexdigest(), path.stat().st_mtime_ns)
                     for path in [config, llm, sentinel, *(lake / 'companies').rglob('*')] if path.is_file()}
        try:
            request = request_path(lake, imported, endpoint, 'genuine-old-paid', selector_version='0.9.0')
            old_exit, old = invoke(code_root / 'o', lake, config, llm, request, hold=True)
            report.update(old_exit=old_exit, old_status=old['status'], old_documents=old.get('documents'),
                          old_error=old.get('error'))
            assert old_exit == 2 and old['documents'][0]['status'] == 'activation_pending', old
            assert len(requests) == 1 and not errors
            runs = NarrativeRunStore(lake / 'AUTO.sqlite')
            before = runs.get_run('genuine-old-paid')
            before_usage = [asdict(row) for row in runs.reservations_for_run('genuine-old-paid')]
            old_manifests = _thaw_generations(json.loads(before.binding_json))
            assert {row['reading_model_projection'] for row in old_manifests.values()} == {'reading-model-input/2'}
            native_decoder = next(iter(old_manifests.values()))['reading_model_boundary']['decoder_sha256']
            old_bytes = (code_root / 'o/src/company_wiki/automation/narrative_model.py').read_bytes()
            assert native_decoder == hashlib.sha256(old_bytes.replace(b'\r\n', b'\n').replace(b'\r', b'\n')).hexdigest()
            report.update(old_actual_manifests=old_manifests, old_usage=before_usage,
                old_request_body_sha256=hashlib.sha256(requests[0]).hexdigest())
            (output / 'old-paid.http.json').write_bytes(requests[0])
            new_exit, new = invoke(code_root / 'n', lake, config, llm, request, hold=False)
            after = runs.get_run('genuine-old-paid')
            after_usage = [asdict(row) for row in runs.reservations_for_run('genuine-old-paid')]
            changes = {key: {'before': before_usage[0][key], 'after': after_usage[0][key]}
                       for key in before_usage[0] if before_usage[0][key] != after_usage[0][key]}
            # Publication legitimately settles the previously reserved output
            # slot. It must not change any paid request/usage/fee field.
            accounting_unchanged = (len(before_usage) == len(after_usage) == 1
                and not (set(changes) - {'output_bytes', 'output_sha256', 'output_settled_at'}))
            pin = new.get('documents', [{}])[0].get('artifact_ref') or {}
            output_settled = (after_usage[0]['output_bytes'] == pin.get('byte_size')
                and after_usage[0]['output_sha256'] == pin.get('content_sha256')
                and after_usage[0]['output_settled_at'] is not None)
            report.update(new_exit=new_exit, new_status=new['status'], new_documents=new['documents'],
                total_loopback_POSTs=len(requests), restored_without_POST=len(requests) == 1,
                binding_unchanged=after.binding_json == before.binding_json,
                reservation_full_row_unchanged=before_usage == after_usage,
                reservation_changes=changes, new_usage=after_usage,
                paid_accounting_unchanged=accounting_unchanged,
                output_settled_to_exact_published_artifact=output_settled,
                fixture_errors=errors)
            report['status'] = ('PASS' if new_exit == 0 and new['status'] == 'completed'
                and len(requests) == 1 and accounting_unchanged and output_settled
                and before.binding_json == after.binding_json else 'RECOVERY_FAILED')
        finally:
            report['lake_protected_unchanged'] = all(path.exists() and
                (hashlib.sha256(path.read_bytes()).hexdigest(), path.stat().st_mtime_ns) == saved
                for path, saved in protected.items())
    report['lake_removed'] = not lake.exists()
except Exception as exc:
    report['status'] = 'PROBE_FAILED'
    report['error'] = {'type': type(exc).__name__, 'message': str(exc)}
finally:
    server.shutdown()
    server.server_close()
    thread.join(timeout=5)
    # Only the exact marked code snapshot tree created by prepare.py.
    assert code_root.parent == Path(tempfile.gettempdir()).resolve()
    assert (code_root / 'owned-marker.txt').read_bytes() == b'old-code-resume isolated code only'
    shutil.rmtree(code_root)
    report.update(code_temp_removed=not code_root.exists(), seconds=time.perf_counter() - started)
    (output / 'overall.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf8')
print(json.dumps({key: value for key, value in report.items() if key not in {'old_actual_manifests', 'old_usage', 'new_usage'}}, ensure_ascii=False), flush=True)
raise SystemExit(0 if report['status'] == 'PASS' else 1)
