"""Independent pure release counterexamples; no IO except this owned receipt."""
from copy import deepcopy
from hashlib import sha256
import json
from pathlib import Path
import random
import socket
import sys

ROOT = Path(__file__).resolve().parents[4]
sys.path[:0] = [str(ROOT / 'src'), str(ROOT / 'tests')]
from company_wiki.automation import narrative_generation as gen
from company_wiki.automation import narrative_model as model
from company_wiki.automation import narrative_worker_factory as factory
from company_wiki.automation.narrative_contracts import NarrativeContractError
from company_wiki.automation.narrative_model_citations import compile_citation_units
from company_wiki.automation.models import canonical_json
from unit.test_narrative_citation_attribution_contract import selected_qa
from unit.test_narrative_frozen_software_responsibility import manifests

def deny_network(*args, **kwargs):
    raise AssertionError('independent pure probes cannot use network')
socket.create_connection = deny_network
socket.socket.connect = deny_network

checks = []
def check(name, condition):
    assert condition, name
    checks.append(name)

selected = selected_qa()
req = model.NarrativeModelRequest.from_selection(selected, reading_projection_version='reading-model-input/3')
data = json.loads(req.data_json)
qa = [r for r in data['citation_units'] if r[1] == ['e1', 'e2']]
raw = {'claims': [{'claim_id': 'mixed', 'text': 'The company disclosed product progress.',
                  'citation_unit_ids': [r[0] for r in qa], 'claim_type': 'company_statement',
                  'modality': 'actual'}]}
reply = model.NarrativeModelResponse('offline', 'fixture', req.prompt_version, canonical_json(raw).encode())
try:
    model.decode_model_draft(reply, selected=selected, reading_projection_version='reading-model-input/3')
except NarrativeContractError as exc:
    check('combining_question_and_answer_views_cannot_wash_question_role', 'non-company evidence' in str(exc))
else:
    raise AssertionError('mixed question support incorrectly authorized a company statement')

# Exhaust all nonempty factual-support subsets for a same-parent group. A unit
# must retain the full context, while precise support never expands implicitly.
spans = selected.evidence_spans[:2]
ids = tuple(s.span_id for s in spans)
for mask in range(1, 1 << len(ids)):
    support = tuple(ref for index, ref in enumerate(ids) if mask & (1 << index))
    compiled = compile_citation_units(spans, (ids,), support_views=((support,),))
    alias = compiled.units[0][0]
    actual_support, context = compiled.resolve_attribution([alias])
    check(f'subset_{mask}_full_closure_preserved', compiled.resolve([alias]) == ids)
    check(f'subset_{mask}_support_is_exact', actual_support == support)
    check(f'subset_{mask}_context_is_complement', context == tuple(ref for ref in ids if ref not in support))

current = manifests('reading-model-input/3')
recorded = deepcopy(current)
recorded['reading_model_boundary']['decoder_sha256'] = 'a' * 64
recorded['summary_validation']['observer_sha256'] = 'b' * 64
check('historical_decoder_and_observer_are_observations_only', gen.with_frozen_model_identity(current, recorded) == recorded)
for field, value in [('model', {'temperature': 0.13}), ('profile', 'P1'),
                     ('source_metadata', {'language': 'mixed'}), ('source_ref', {'content_sha256': 'c' * 64})]:
    changed = deepcopy(current)
    changed[field] = value
    check(f'resume_does_not_hide_{field}_change', gen.generation_sha256(gen.with_frozen_model_identity(changed, recorded)) != gen.generation_sha256(recorded))
for field in ('selector', 'adapter'):
    changed = deepcopy(current)
    changed['execution_versions'][field] = 'real-future-component/99'
    check(f'resume_does_not_hide_execution_{field}', gen.generation_sha256(gen.with_frozen_model_identity(changed, recorded)) != gen.generation_sha256(recorded))
for field, bad in [('reading_model_projection', 'uninstalled/99'), ('reading_model_boundary', {'decoder_sha256': 'a' * 64}),
                   ('summary_validation', {'observer_sha256': 'b' * 64})]:
    changed = deepcopy(current)
    changed[field] = bad
    try:
        factory._validate_model_software(changed)
    except model.ModelResponseError:
        check(f'pending_model_stage_rejects_{field}_drift', True)
    else:
        raise AssertionError(f'pending model stage accepted {field} drift')

paths = [ROOT / name for name in (
    'src/company_wiki/automation/narrative_model.py',
    'src/company_wiki/automation/narrative_model_citations.py',
    'src/company_wiki/automation/narrative_generation.py',
    'src/company_wiki/automation/narrative_worker_factory.py',
    'src/company_wiki/automation/narrative_output_language.py')]
receipt = {'schema_version': 'independent-attribution-release-probes/1', 'status': 'PASS',
    'check_count': len(checks), 'checks': checks, 'external_calls': 0, 'original_reads': 0,
    'source_sha256': {str(p.relative_to(ROOT)): sha256(p.read_bytes()).hexdigest() for p in paths}}
Path(__file__).with_name('probe.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'status': receipt['status'], 'check_count': len(checks)}))
