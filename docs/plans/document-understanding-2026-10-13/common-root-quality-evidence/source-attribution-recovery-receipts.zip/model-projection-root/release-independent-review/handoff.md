# Citation attribution / historical recovery — independent release review

Date: 2026-10-15. Reviewer: `attribution_release_review`. Reviewed base HEAD: `4f065af218eb9422953678a7c483c11d9d3c25a3` plus the frozen uncommitted implementation identified by `probe.json` source fingerprints.

## Conclusion

**PASS for this engineering boundary; no new blocking defect found.** This is permission to continue the ROOT release acceptance sequence, not evidence that real supplier summaries are semantically correct, that selector 0.9 should become the production default, or that the mother plan is complete.

The review covered current production and test diffs for citation-unit/3, reading context/2, support versus required context, claim-local language observations, PDF language forwarding and stage-scoped historical recovery. CodeGraph supplied structural context before source inspection. No source, test, shared PWF, production configuration, Git or DU4 author file was changed by this reviewer.

## What was checked

1. `narrative_model_citations.py` compiles only the pinned selected spans. Every unit remains within one original source parent, aliases bind both the complete member set and the factual-support subset, overlapping groups do not recursively pull in neighbors, and only truly ungrouped spans obtain standalone units. Resolving multiple explicit units deduplicates canonical spans in original order.
2. Native `QaDraft.as_wire()` owns answer and question arrays. `build_dependency_packages` forwards them; `_context` derives the full complementary context; `_reading_context` checks complete, unique, same-parent partitions. This is not an LLM-authored role reassignment.
3. The /3 decoder rejects old eN/gN citation fields and program-owned context overrides. Canonical role validation and language observation read factual `evidence_ids`; quality projection still considers required context. The independent counterexample selecting both question and answer views as a company statement was rejected because the factual-support union includes the question role.
4. /3 uses a finite flat claims protocol and preserves strict JSON, byte, claim count and text bounds. Program-owned source/subject identity is restored from the pinned selection. Source-owned metadata echoes do not replace it. The causal descriptor covers both decoder and unit compiler bytes.
5. The claim-local language change gives a substantive local language mismatch precedence over unrelated claims, while short prose and missing classification remain explicit abstentions. A Chinese question context cannot authorize translating an English answer. These observations are not semantic entailment checks.
6. PDF verification now forwards the selected source's actual language to native replay. Synthetic EN/mixed/legacy-ZH path and bytes cases pass, while wrong language, original bytes, source identity and parser versions still fail. No real PDF was read in this review.
7. Resume comparisons retain historical model/observer fingerprints instead of describing them as current. Model, profile, source and other execution changes remain in the comparison. The current worker checks the actual pending summarize job's renderer, prompt/schema, decoder and summary validator before reservation or generate; unavailable software produces no model call or fake failed-final artifact. Already finished sibling model software is not executed merely to publish an outbox.
8. Read the existing genuine-old-code lifecycle receipt from `group-citation-design/v3/old-code-resume/execution-fourth/overall.json`: old source commit `5a8e895e`, one synthetic loopback POST before upgrade, zero added POSTs on recovery, completed publication, unchanged frozen binding and all paid-accounting fields. Only the expected output settlement fields changed. This is corroborating inspection of ROOT's saved execution, not a second independently executed old-code E2E. The original three earlier failed/incorrect-oracle attempts remain distinct historical evidence.

## Independent execution

| Run | Result | Evidence |
|---|---|---|
| Same 66 focused cases inside sandbox | 63 passed, 3 fixture setup errors | `junit.xml` |
| Identical 66 focused cases on normal host | **66 passed, 4.66 s** | `host-junit.xml` |
| Frozen v2 request/HTTP bytes, /3 boundary, runtime binding | **44 passed, 4.29 s** | `compat-junit.xml` |
| Additional pure counterexamples | **20 checks passed** | `probe.py`, `probe.json` |

The sandbox errors occurred before the three `tmp_path` test bodies: automatic basetemp relocation selected an AppContainer Temp where pytest could not create numbered directories. Normal host relocation used its normal short Temp and all 66 passed unchanged. Both successful host runs report `CW-BASETEMP-CLEANUP removed=true`. The exact first sandbox temporary path was subsequently inspected and was absent. No tests, assertions or production code were changed to obtain these results. The sandbox issue is an execution-environment limitation, not a verified source-code regression.

The 66 and 44 successful sets are disjoint: **110 independently rerun unit cases**, plus 20 direct pure checks. They overlap ROOT's previously recorded acceptance sets and must not be added to ROOT totals as unique new coverage.

All executions used immutable/synthetic fixtures and no supplier calls. The additional probe forbids socket connections, reads no original document, and writes only this reviewer-owned directory. The synthetic PDF test writes only pytest Temp. No actual provider fees were incurred.

## Evidence boundaries and remaining main work

- This node proves reference, role, version and stage ownership mechanics. It does **not** prove the truth of generated business claims, numeric/period/currency attribution, complete topic recall, or analyst-quality forecasting.
- No independent real supplier request, real original PDF reread, cross-repository FF→ET→CWP→RF execution, concurrent worker run, pre-push suite or remote CI was executed by this reviewer. ROOT owns those node-level receipts.
- Source-table value/column/period binding, operating-state semantics and actual form/speaker signals remain real source-quality work in DU4. A citation-complete unit can still contain the wrong factual row for the proposition. The source prompt explicitly states this limitation; it must remain visible in PWF and quality acceptance.
- The saved old-source replay proves an already summarized /2 job can finish publication without a second POST. It does not authorize executing an unavailable pending old decoder, resending a failed paid request, changing previous fee observations, or treating missing historical selection/generation as recovered evidence.
- Keep selector 0.8 as the default until the planned real quality and generalized E2E acceptance passes. Publishing this engineering implementation and switching the default are separate conclusions.

## Handoff

ROOT should retain this report, its JSON manifest, both successful JUnits, the first sandbox-error JUnit, and pure probe in the node receipt archive. Continue the previously planned cross-repository acceptance, normal hooks, commits/push and exact-SHA CI. No additional small-node review gate is requested by this report.
