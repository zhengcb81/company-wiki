# HK real source continuation — completed, source STOP

## True matcher result

Actual command: `python -B .../partial-source-tdd/hk_offline_resume_replay.py .../partial-source-tdd/hk-offline-resume-20261014`; process exit **0**.

- The saved actual typed selection is reused; no new initial parse, selection or `_understand` call.
- Normal `replay_narrative_evidence` uses canonical `mixed` and performs exactly **one** independent parse.
- **96 verified, 0 failed**; every actual span ID is retained in `matcher.json` and `overall.json`.
- Independent verify elapsed 2.852 seconds; process wall time 4.276 seconds.
- This continuation reads the original once, verifies its SHA and byte length, then reuses those immutable bytes. It does not re-read the original for a duplicate disk hash.
- Source stat, historical packet, first failed diagnostic packet, all production Python sources and production config remain unchanged. Sentinel unchanged, Temp removed.
- 0 provider calls, 0 attempted network connections, no generation/job state reconstruction.

The original initial-observation packet remains untouched: one initial parse/select (19.165 seconds), exact equality of 96 sent eN texts/roles/flags and all gN members, then diagnostic `Rect` JSON failure before any independent parse. It is not rewritten to success. Together these two packets contain one initial parse and one independent replay. The old actual paid run still records its original `LOCATOR_REPLAY_FAILED`; no exact historical failed span is invented.

## Diagnostic repair and output

Only owned scratch changed. The shared scratch `plain` serializer now accepts exactly native `pymupdf/fitz.Rect` and `IRect` objects with four finite numeric coordinates. It does not blindly serialize unrelated native objects. `rect_serialization_probe.py` ran exit 0 with six pure checks: actual Rect/IRect, int/float preservation, nested None/empty/whitespace, strict JSON roundtrip, nonfinite rejection and unrelated Point rejection. Zero documents/models were accessed by this fixture.

The continuation records matcher outcome **before** serializing the rich observation; observer capture errors and later serialization errors cannot prevent normal verification or erase its result. The actual run has `diagnostic_errors=[]`.

`table-observation.json.gz`: **112,030 bytes uncompressed**, SHA-256 `d0c3ff11603b84b30b8a1881f9d1d7db8b8c8e3c04727fe13d4085abf989e5bb`. Five target table extractions are observed through the normal verifier's existing calls; no extra `find_tables`, `get_text` or `extract` is made.

Capture is bounded at **64 logical rows / 256 cells**. Actual 64 rows / 228 cells are retained, `truncated=true`; page 20 table 1 has only its first two raw header rows. This is observer truncation, not proof that source data is absent. Actual returned units for all five target tables are retained separately. No extra parse is run to recover the truncated tail.

Initial rich structure pipeline is **NOT_RETAINED** because the first process ended before saving it. The normal verification parser uses `native_ranges=True`, not selector 0.9 rich-layout collection; absent rich structure is explicitly unknown and is never reconstructed or represented as the original pipeline.

## Source-column observations relevant to the independent quality design

These facts come from the fresh retained raw slots/boxes and exact old/new material match, not from external facts:

| Group | Actual source table | Observed common shape |
|---|---|---|
| g2 | page 14, table 0 | Header rows distinguish 2023 and 2024. Raw row 4 is a merged left cell containing all labels plus 2023 values 522 / 1,617 / 1,787. Actual 2024 right-column values occur later at rows 6–8: 587 / 1,822 / 1,977; total 4,386 is row 11. Sent group e19..e23 stops at row 4. |
| g3 | page 17, table 0 | Same merged-left shape. Row 4 contains 2023 values 1,333 / 172 / 552 / 231 / 199. Actual 2024 right values are rows 6–10: 1,611 / 350 / 637 / 295 / 225; total 3,118 is row 13. Sent e31..e35 stops at row 4. |
| g4 | page 18, table 0 | Three headers are six-month 2023, twelve-month 2023 and FY2024. Row 4 left giant cell contains two old-period values (e.g. 6,895 / 13,035). Actual latest right-column GMV is 14,008 at row 6, spending 38.1 at row 9, and same-store growth is `Down high-single digit` at row 12. Sent e37..e41 stops at row 4. |
| g5 | page 19, table 0 | Same three-period headers and merged old-period left cell. The old 6,452 / 10,989 values are left; actual latest right total GMV 14,001 is row 6 and same-store growth `up mid-single digit` is row 13. Sent e43..e47 stops at row 4. |
| g6 | page 20, table 1 | Raw capture reached the observer row bound after the first two header rows. Latest numeric raw-cell rows are not certified from this bounded subpacket. Existing actual returned units and saved typed source remain available; no new parse is authorized by this gap. |

The current failure in summary quality therefore is not only an absent check on a model header. Upstream native table recognition merges labels and old-period values into a large left cell; source selection admits the labelled merged row while newer numeric-only rows fall outside the sent operating group. The model then assigns old-period numbers to the latest heading. Exact source replay and group membership alone cannot prove period/value ownership. The independent quality lane's source-owned cell/period binding design must cover the merged-cell shape and numeric-only operating siblings, retaining unknown when no original binding exists.

These observations do not authorize replacing model numbers by hand, guessing label alignment, widening caps or claiming all actual summaries/RF forecasts passed. The source replay fix is proven; period semantics and summary quality remain separate work.

## Correction to earlier independent-review prose

The earlier HK review note accidentally wrote `10,899` in its c9 explanation. Retained actual c9 and sent e47 both say **10,989**. This is a reviewer prose typo, not a provider digit-transposition hallucination. The real c9 finding remains wrong/unsupported year assignment; it is now strengthened by the freshly observed latest 14,001 column. Old input/final/review artifacts are preserved, and this explicit addendum supersedes only that mistaken numeral in the review commentary.
