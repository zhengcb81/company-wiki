"""One finite static node, with all caches confined to a removed short Temp."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).parent / ('model-projection-root/' + sys.argv[1])
OUT.mkdir(exist_ok=False)
changed = subprocess.run(['git', 'diff', '--name-only', '--', '*.py'], cwd=ROOT,
                         capture_output=True, text=True, encoding='utf8', check=True).stdout.splitlines()
added = ['src/company_wiki/automation/narrative_model_citations.py',
    'tests/unit/test_narrative_citation_attribution_contract.py',
    'tests/unit/test_narrative_citation_unit_model_boundary.py',
    'tests/unit/test_narrative_citation_unit_runtime_binding.py',
    'tests/unit/test_narrative_frozen_software_responsibility.py',
    'tests/unit/test_narrative_output_language_claim_scope.py',
    'tests/unit/test_narrative_pdf_language_replay.py']
paths = list(dict.fromkeys(changed + added))
sources = [path for path in paths if path.startswith('src/')]
protected = {path: hashlib.sha256((ROOT / path).read_bytes()).hexdigest() for path in paths}
results = []
with tempfile.TemporaryDirectory(prefix='.cw-s-', dir=ROOT) as temporary:
    cache = Path(temporary)
    for label, command in [('ruff', [sys.executable, '-B', '-m', 'ruff', 'check', *paths]),
        ('mypy', [sys.executable, '-B', '-m', 'mypy', '--cache-dir', str(cache / 'm'), *sources])]:
        started = time.perf_counter()
        process = subprocess.run(command, cwd=ROOT, env=dict(os.environ, TEMP=str(cache), TMP=str(cache)),
                                 capture_output=True, encoding='utf8', timeout=120)
        (OUT / (label + '.stdout.log')).write_text(process.stdout, encoding='utf8')
        (OUT / (label + '.stderr.log')).write_text(process.stderr, encoding='utf8')
        results.append({'label': label, 'exit': process.returncode, 'seconds': time.perf_counter()-started,
                        'files': paths if label == 'ruff' else sources})
        print(label, process.returncode, process.stdout[-4500:], process.stderr[-1000:], flush=True)
assert not cache.exists()
assert protected == {path: hashlib.sha256((ROOT / path).read_bytes()).hexdigest() for path in paths}
receipt = {'results': results, 'source_unchanged': True, 'cache_temp_removed': True, 'external_calls': 0}
(OUT / 'receipt.json').write_text(json.dumps(receipt, indent=2), encoding='utf8')
raise SystemExit(0 if all(row['exit'] == 0 for row in results) else 1)
