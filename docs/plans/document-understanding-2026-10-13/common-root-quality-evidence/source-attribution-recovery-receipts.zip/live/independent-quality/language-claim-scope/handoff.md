# 逐claim原语言责任修复 — SOURCE STOP

Owner `/root/provider_quality_review`。仅修改授权的observer源、新test以及3条明确授权的旧聚合合同预期；没有Git/PWF/provider/原件操作。

## 根因与修复

旧函数已分别识别每claim的原文语言，但整批scalar在看到不同claim有中文原lane后，将另一个English-only→中文的强差异变成uncertain。不是检测库分类错，也不是需要再加概率阈值。

现在复用同一次有限分析和已有本地classifier cache，保留各claim自己的output/source families。沿既有long prose floor与一致性证据认定的**强局部different**，不会被别claim的compatible/uncertain稀释。各自忠实的中/英原lane可以compatible，aggregate output_family=None，不虚造单一语言。短文/未知source/品牌与原文外语quote等仍按既有规则诊断。

没有第二classifier、20次全source分析、全局正文cache、公司/语言例外、人工门禁或新审批。

## TDD及集中检查

- 新13例先RED：6FAIL/7PASS；[真实日志](red/stdout.log)、[收据](red/receipt.json)保留。
- 修复后86PASS：73旧（其中3条已明确授权升级聚合预期，其余70未放松）＋13新；[集中收据](green/receipt.json)。
- Ruff3文件PASS，mypy1源PASS；[静态收据](static/receipt.json)。
- 自有源/config在节点内SHA/mtime保持，独立Temp与mypy cache已移除；其他合法src施工不被静止检查阻挡。
- 新fixture中的HK c4/e6、c13/e25/e27来自实际保存材料，alias-only观察不认证source/locator/canonical状态。RED前核对纠正了一条原先手写的e6近义文字，使用实际字串后才运行RED；没有为凑绿调整gold或断言。

### 3条旧合同的明确变化

1. EN+ES输出均引EN：原whole-batch uncertain改为different，output_family仍None。
2. ES→EN＋ES→ES：原uncertain改different，后者不得给前者翻译许可。
3. short-source→ES＋EN-source→ES：short自身仍无证明；另一条独立strong different使aggregate different。

这些原测试未删除；名称、注释与state预期一起升级。不是宣称“旧73断言原样都绿”。

## 真实旧HK材料的零付费postfix观察

另存 [postfix-observation.json](postfix-observation.json)，不覆盖先前uncertain证据：

- all20raw与排c3/c19的provisional18都变different，source families=en,zh /output=zh。
- 短c2/c20单条仍uncertain。
- 4次纯观察0.547s，原packet与owned源不变，0原件/parse/API。

旧packet未保留native成功SummaryResult，因此18仍不是实际canonical认定；本观察不冒充正式摘要或RF质量PASS。

## 交接边界

文件/hash见 [source-stop.json](source-stop.json) 与 [handoff.json](handoff.json)。SOURCE STOP之后本agent不再改源码/测试。

ROOT在model/PDF线也STOP后做一次受影响runtime/binding/cache/E2E集中节点，再正常提交推送/PWF。None/v1调用旁路未修改，旧/2与新/3实际validator fingerprint随真实代码变化由既有generation端口绑定；本agent没有私自切默认或重签旧run。

表格期间设计另见 `../hk-period-root-design/handoff.json`：已交25条待实施用例与原生格槽/期间/单位绑定端口，**表语义仍未实施**。单citation-unit与本语言修复不能用来宣布HK错年已经解决。
