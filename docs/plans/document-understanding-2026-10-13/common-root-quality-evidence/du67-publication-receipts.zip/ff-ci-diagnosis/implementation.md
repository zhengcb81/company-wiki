# FF CI 跨平台测试修复交接

2026-10-16，ROOT授权实施；基线FF `ca23c926a808cf38d56e5dbf6cd9fe9185e2af69`，仅在 `filing-fetch-du67-integration` 修改指定两文件。

## 先RED，再修复

现有CI已包含 `tests/test_root_w07_matrix_boundaries.py`。在其中新增 `test_unexpected_cleanup_accepts_absent_stdin_on_any_platform`，参数 `lifetime/partial_io_start` 分别调用两条实际异常回收测试。回归仍运行真实 `public run_bounded` 并实际启动/回收子进程；只在其清理完成后，把已关闭的Windows bootstrap stdin隐藏为None，模拟POSIX input=None的合法形状。先断言进程退出、stdout/stderr真实存在且关闭，才隐藏stdin；没有改全局os.name或生产实现。

Windows修复前两参数均 **RED：None.closed**，直接击中两条实际测试。不是仅新增一条独立复制断言。

两个原测试的修改仅是：明确stdout/stderr必须存在，对实际存在的流检查closed。进程poll已退出、无线程遗留的断言保留。生产transport/runtime/cli/oracle、case30/batch180/cleanup期限均未修改。

## 验证结果

| 节点 | 结果 | 收据 |
|---|---|---|
| 原Linux诊断 | 2 FAIL None.closed | wsl-two-tests.json/stdout |
| Windows新回归先RED | 2 FAIL None.closed，0.69s | windows-portability-red.json/stdout |
| Windows两完整相关文件 | **32 PASS /1.61s** | windows-portability-green.json/stdout |
| Ubuntu Python3.12原两测试＋新两参数 | **4 PASS /2.11s** | linux-portability-green.json/stdout |
| Ruff两文件、git diff --check | PASS | frozen handoff |

两个平台的实际argv、Python版本、源文件SHA前后对照、自建临时目录恢复结果均在JSON。两个平台生产源码和被测文件运行前后SHA一致，Windows Temp与Linux/tmp本次目录均已删除。无网络/API/密钥/原件写入，无Git写。

## ROOT接收

- 可review补丁：`portability-fix.diff`。
- 精确冻结SHA：`handoff.json`。
- owned仅 `tests/test_w07_matrix_efficiency.py` 与 `tests/test_root_w07_matrix_boundaries.py`。
- 本节点未重跑全752套件、未确认远端最新失败清单；由ROOT执行最终集中预推送和精确远端CI，不能仅由4项Linux通过宣称远端全绿。
- 原诊断证据和失败收据保留；初始只读交接保存为 `diagnosis-handoff.json`。
