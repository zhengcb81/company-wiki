# 来源层持有身份、模型只生成 claims：只读架构提案

日期：2026-10-14；独审：ROOT/table_admission_review。状态：**设计提案，不是已实施或已验收**。没有 source/test/config/PWF/Git 写入、供应商调用或原文解析。当前 MiMo `SUMMARY_INVALID` 的具体规则尚未保存，本提案不宣称它由 header echo 引起；ROOT 在真实诊断明确后决定施工。

## 1. 责任边界与推荐变化

采用下一内部阅读投影版本，例如 `reading-model-input/2`：模型返回摘要 claims；程序从同一个 pinned `NarrativeSelectResult` 构造 canonical source/subject identity 与 language。不是关闭原文验真，而是移除模型复述既有 64-hex SHA 和内部 ID 的无用步骤。

```text
来源/解析层：原始字节、SHA、身份、期间、source locator、真实 role
    ↓ 一次 pinned SelectResult；原文、选择及引用映射冻结
模型边界：选择文字＋语义阅读策略＋eN/gN＋角色＋原文语言要求
    ↓ 模型仅生成 claims；不负责回填来源身份和 SHA
程序：相同 pinned 选择构造 canonical identity；解析引用与类型
    ↓ 有限质量观察＋原文回开/既有真实独审
canonical summary/bundle：继续既有公众 DTO；无第二份身份状态
```

| 层 | 负责 | 不承担 |
|---|---|---|
| 来源/存储 | 原件、路径/类型/实际 SHA、来源身份与期间，锁与限额 | 摘要模型复述 ID 作为原件验证 |
| 解析/选择 | 原文单位和 locator、引用 alias、group membership、speaker role、阅读 coverage | group 已闭合就保证所有摘要语义正确 |
| 模型 | 原语言业务 claims、实际支持 eN/gN、claim_type/modality、当前与下一步的正确表述 | 再生成 source/subject ID、SHA、canonical language 或质量签收 |
| 模型 adapter/decoder | UTF-8/JSON、真实 request/response 绑定、usage、有限 claims 类型/引用与质量观察，构造既有 canonical draft | 自动翻译、捏造引文、修复 JSON、重复采集原文、逐材料人工许可 |
| 真实独审/下游 | 语义支持、数字/币种/单位、主体/阶段/否定、重要业务覆盖、RF 模型合理性 | 通过相同 header 证明事实正确 |

当前实现已在 outer summary 中从程序构造 identity，inner draft 却仍要求模型复制一遍。相关位置：`narrative_model.py::_RESPONSE_SCHEMA/from_selection/decode_model_draft`，`narrative_summarize.py::_completed_result`，`narrative_contracts.py::NarrativeSummaryResult.validate_against`。移除的是 **inner model response 的必填 echo**，不改变 canonical 对象对来源事实的绑定。

## 2. v2 模型合同与程序组装

优先只移除模型 draft 的必填 `source_id/source_sha256` 或 `subject_id/subject_sha256` 和 `language`，保留现有 claim 形状，避免同时扩大到无关的 claim-ID 改造。响应仍用既有 `{"draft":{"claims":[...]}}` 容器，claims 包含 eN/gN、text、claim_type、modality；现有 claim_id 可继续使用，`status/needs_review` 仍由程序投影，不作为模型放行依据。

新 prompt 明确：**在实际所引用的原文语言中写 claims，保持源主体/角色/阶段；不生成身份/hash/语言标签，不翻译，不提出原文未提出的问题；每项只引用自己的真实支持。** 输入保留阅读必须的 title/document_kind、原文语言要求、实际角色和文字，以及语义策略/覆盖；可省模型无用的内部 URI/SHA，但 canonical selection/manifest 保持全部绑定。原文引用内容不因省去 metadata 被改写或擦除。

程序在解码阶段使用该 job 已 pinned 的选择，只构造一次 canonical header：

- raw：`selected.source_ref.source_id/content_sha256`＋`selected.source_metadata.language`。
- official JSON：`selected.subject.item_key/subject_sha256`＋实际选中文本语言；不能用一个 parent raw SHA 冒充整个 subject 的 SHA。
- 原有 parent/row roles、source IDs、subject binding、selection-generation 与 transcript lineage 留在源层/公众导出中。相同标签的不同 immutable parent 不能混成 group。
- eN/gN 映射来自这份选择，映射结果仍是原 canonical span/group IDs；不从响应里的名字/hash推断其他公司，不读当前目录或配置重建身份。

程序生成 header 与 canonical parser 的一致性检验可以保留为构造器不变量，但不再对模型缺 header、短 SHA、错误 SHA 格式进行身份许可检查。模型 response 的 adapter/model/prompt 和实际请求/付费 reservation 绑定是另一回事，仍检查一次，以防真正接错 job/renderer。

## 3. 显式矛盾：诊断与实质合同分开

ROOT 已明确同意：v2 **未消费的 metadata echo 只作诊断，不再因这些字段不同而阻断**。

| 返回情况 | v2 处理 |
|---|---|
| 无 source/subject/hash/language 字段 | 正常；程序自己构造。不是缺少授权或缺身份。 |
| 多回传一致 header | 不消费、不持久化到 canonical；不算事实质量加分。 |
| 多回传相矛盾的 source/subject/hash/language | 固定、有限的 `MODEL_HEADER_CONTRADICTION` 质量诊断；绝不覆盖 pinned 值；不因为未使用 echo 单独拒绝或要求人工签收。诊断可沿现 job detail/失败观察记录，不新增公众 DTO/flag。 |
| 文本为另一语言，即使 header 标签正确 | 检查实际文字，属于摘要质量问题；不得按 header 放行或把 canonical language 当检测结果。 |
| 明示 `translate=true` 或实际内容被翻译 | 沿现原语言任务约束诊断/处理；不为它自动翻译回去或加另一 LLM 修复。 |
| 引用选择外 eN/gN、实际角色错误 | 沿现 claim 支持/角色合同处理；不能用正确 header 抵消。 |
| JSON 多括号、重复键、非法数或错误响应形状 | 真正 transport/decoder 失败；保持原始字节/SHA/usage 与规则诊断，不能修补为合法 JSON。 |

缺 header 与“显式内容证据矛盾”必须是两个独立测试。metadata 诊断不等于它证明内容来自另一公司；同样，忽略未消费 header 不等于正文的错误主体可以自签合格。

## 4. 原语言的实际文字约束：已发现同脚本盲区

实际保存的 MiniMax-M3 运行：`live/owned-runner/receipts/live-20261014T201117-d9fb13/overall.json`，输入材料 `materials/phaseC-090-9d2a57aa6f13.input.json.gz`。

- 最终内容完整 **8,160 B**，SHA `00606400efd7377c96283cbfc613b7f827540ddd7da61f8b9fe2018ef38735df`，`clipped=false`；末尾多闭合 brace，当前失败为 `MODEL_RESPONSE_INVALID/FINAL_JSON`。本独审未修 JSON、未发布摘要。
- 正文多数 claims 是西班牙语，但 header 仍为 `language=en`。这直接反证“header 对齐 ⇒ 原语言正确”。
- c20 是 `analyst_question/question`，引用 e53。实际 e53 为英文公司财报风险陈述，default role `company_filing`，并非分析师问题；即使修复了 JSON，仍不能将 c20 作为原文问题签收。本观察没有改变本次真实最先失败规则。
- 当前 `source_catalog/narrative_language.py::_script_counts` 将全部 `LATIN` 字母计为 en。`detect_narrative_text_language` 实际区分汉字/拉丁脚本，**不能区分英文和西班牙语**。
- 一次零模型、零源 parse 的内存反例：从上述保存 final 提取第一项 text，调用现 helper（`python -B`，不写 bytecode），实际输出 **en**；该 text 是西班牙语。命令 exit 0。本例仅观察文本，未拼成可接受 JSON。

因此新 v2 不能调用这个脚本计数器然后称英文验收通过。建议语言责任这样拆：

1. source language 保持所属源层的观测/登记；模型响应不改写它。源样本脚本观测和语义语言不能混用名字，也不需要为每次输出重新解析原件。
2. 输出检查仅使用 **claim prose 与已引用的实际 pinned 原文**。输入指令明确指定原语言；中文段落含英文品牌/化学式/单位不等于翻译，英文原文里的其他语言专名也不等于输出语言变更。
3. 为输出实际文字增加有限、离线的语言观察能力，能够区分同为拉丁脚本的 en/es/fr 等；优先合并到现语言责任模块，而非建立另一个身份或审查系统。具体检测器及阈值应先用泛化反例选择，不在本只读提案拍定依赖或数字。
4. 对有足够正文且高置信的实际语言不匹配，按实质翻译/语言质量问题处理该 claim；整份都不合规时不产出 accepted summary。短产品名、数字、少字样本应记 `unclassified`，不能默认 en 或靠未知结果阻断所有摘要。检测不确定须公开为诊断，语义独审承担剩余风险；不是人工许可门。
5. mixed 不是任意语言通行证：按实际 cited prose 的原语言保留各 claim，不能把整份中文原文改成西班牙语后借 mixed 标签通过。仅脚本正确也不证明语义未被翻译。

不得用少数西语关键词黑名单、公司名、gold 专词或简单禁止重音字符实现此约束。语言检测只观察语言，不能证明数字、引用或公司业务事实正确；现独立事实审查继续负责这些问题。检测器若不可用应明确观察缺口，不称已经通过，不自动发起第二模型校验请求。

另一实际运行的 DS 新 HK 是 **0 POST、PARSER_INCOMPLETE**，属于源解析前置问题，不应计为供应商失败。MiMo disabled 的 `SUMMARY_INVALID` 仍需其具体诊断；本提案不把三类失败归成同一问题。

## 5. 必须原样保存 None/v1 冻结行为

版本选择应从每个 job frozen generation 读取，不能依当前默认或返回 shape 猜测：

| 冻结值 | 行为 |
|---|---|
| manifest 未包含 `reading_model_projection`；内存 renderer 参数 None | legacy 原 renderer/schema/decoder；保持原 prompt_version、instruction、data_json、input_sha256 和相同 frozen options 下的完整 HTTP body bytes。 |
| `reading-model-input/1` | v1 原 renderer/schema/decoder及 prompt，不把其响应当 v2；保持旧 hash/generation。 |
| 新 v2 | 新 source-owned schema/renderer/decoder 整套使用；从 frozen manifest 启用，而非新公众 flag。 |
| 字段显式 null、错误类型、未知值 | 沿既有软件可用性诊断；不能退回 legacy 或 v2 猜测。历史已完成 bundle 仍可按原合同回读，不因执行器未知而删除。 |

不能编辑全局 `_INSTRUCTION`、`_PROJECTION_INSTRUCTION`、现 v1 `_READING_INSTRUCTION` 再说只是 v2。新版本必须留旧渲染分支，并以一个有限版本派发同时选择 **模板、响应 schema、decoder**；不是分别维护默认值、不是根据缺 source header 自动改用 v2。同一核心 claim/citation/role/group校验可共用，去掉 header echo 的仅是新解码入口。

generation 必须绑定真实使用的新 prompt/schema/decoder，而不只改一个标签：使用现 generation 端口，v2 的 `reading_model_projection` 与实际 per-job prompt 版本、模板/响应 schema 的因果指纹、decoder 实现版本/因果指纹共同进入新 generation；沿现组件机制绑定，不另造第二份签收 manifest。HTTP exact request bytes 继续归预算 reservation 哈希。新模板或 decoder 改变，generation/reuse 身份必须变；旧冻结 manifest 不补新字段重新签名。

当前消费 prompt 身份的地方不止 model decoder，施工必须一起对齐同一 frozen 决定：

- `narrative_generation.py` generation 的 `execution_versions.prompt`。
- `narrative_batch.py::_job_prompt_versions`、冻结 binding、artifact reuse 的 prompt 比对。
- `narrative_worker_factory.py::_reading_projection_values/create_runtime`；run-level coordinator prompt 与 per-job model prompt 区分，不能用全局改号逼所有旧 run 失效。
- `narrative_summarize.py` 创建 request/解码，以及 `narrative_verify.py::_validate_dependency_identity` 的 active_prompt 比对。目前 latter 只按 subject kind 取全局 prompt；新实现应验证该 job 的真实 frozen 边界。
- `BudgetedNarrativeCaller` 将 request.prompt_version 传给 reservation，须与现 per-job prompt 绑定一致。

decoder 推荐接收该 job 的 frozen boundary 或所发出的实际 request identity；不从 response 自报版本派发，亦不从当前配置重选。原 raw/official-JSON 公众 draft/result/bundle schema不增版本，不加新的公开 flag，不增任务库、审批文件或逐材料签收。

## 6. 可证伪 TDD 反例（设计，除上述语言 helper 观察外尚未执行）

使用独立 Temp、虚构公司/产品名称、固定 pinned 文本与不同 SHA，0 网络/模型。先保留下面应失败的测试，再施工；不改变 gold、cap 或旧测试要求来换绿。一次集中工程节点＋既有真实大节点即可，不加每小步审查。

| 反例 | 必须验到的可观察结果 |
|---|---|
| v2 仅 claims；没有 source/subject/hash/language | 成功构造既有 canonical raw draft；字段全部来自 pinned selection，不要求 echo。 |
| 正确 claims＋额外错 URI/短 SHA/别的 language | canonical identity 不变；仅 metadata contradiction 诊断；不会因未消费 header 被拒或生成授权要求。 |
| official-JSON 两不同 parent 的同名业务 rows | canonical subject SHA 为 pinned subject；各 claim 引各自原 span/role；不把 parent SHA 填成 subject SHA，不合并同名 group。 |
| en 标签＋西班牙语有效 JSON（虚构名称） | 实际语言观察识别 mismatch；不因 header=en/拉丁脚本而认证原语言，不自动翻回英文。 |
| 英文原文/英文 paraphrase；中文原文含 English 品牌与型号 | 正常；不能以品牌、重音专名或短 token 比例误判为翻译。短数字/产品名 observation 可 unknown。 |
| mixed 原文分中英片段＋整段第三语言摘要 | mixed 不能免除实际语言约束；检查引用的 prose，不给第三语言摘要自签。 |
| 全部身份 header 正确＋e99/g99 不在本次选择 | 真正引用失败，保留规则/returned bytes/known usage；不能从另一选择中找同名 alias补救。 |
| 声明 g1，却未引用全部真实 members | 沿现 closure 合同处理；不悄悄自动补引用。窄命题声明 [] 并有自身 support 时仍可保留，部分上下文按现质量诊断，不要求所有 claim 灌满 group。 |
| `analyst_question/question` 引公司财报风险陈述 | 真实角色失败；不把作者自行提出的研究问题变成源问题。真正 analyst 原文 question 保留为 question，不能转 management 事实。 |
| 当前验证＋重复订单；下一代预计交付 | 当前两个动词可是一项 actual；未来阶段不能因为同产品而伪并为 actual。若 decoder 只保证 enum，必须如实说明阶段语义由独审验，不能假称 enum 等于语义验真。 |
| 明示 translate=true，或虚构支持/日期/货币 | 以实际内容/合同诊断，与未消费 header 不同；错误不能借程序绑定 SHA 被洗成来源事实。程序只保证机械部分，语义反例必须进入独审检查点。 |
| None/v1 固定选择与固定 model options 的快照 | prompt_version/instruction/data_json/input_sha256/完整 request body bytes 均与施工前冻结 golden 相同；missing 与显式 manifest-null 不被混为一种。旧 artifact 回读恢复 0 POST。 |
| v2 schema/模板/decoder 改变；current default 改变 | 新因果 generation 变化；旧 run 仍用 frozen None/v1，新返回不能由旧 decoder 解码。prompt 元数据与实际 renderer一致，job/reuse/verify/caller消费同一决定。 |
| 错 prompt/job 的 response；多 brace/重复键 JSON | transport/decode 失败留证而非 header诊断；不修 JSON、不去供应商盲重试，已消费费用恰好记一次，失败后 Temp/sentinel 恢复。 |

真实节点继续用现三家供应商原语言样本与独立质量审查：公开 quote recall 与正式 summary quality 的不同分数，实际数字/阶段/身份语义/引文范围逐项检查。去除 header 后不能降低这类验收，也不把每份材料变成新的人工许可；没有必要为这个接口新增付费回归循环。

## 7. ROOT 可按此顺序施工

先拿现失败规则和实际 returned bytes 明确每项原因，保持 paid session 冻结；再冻结 None/v1 byte snapshots，写 v2 的 source-owned/同脚本翻译/官方 JSON/引用角色及 generation 反例；之后集中实现唯一边界派发和程序 header 构造，贯通 generation、caller、verify、reuse；最后在现大节点验工程与真实质量。这里没有新合约签收或审批阶段。

**SOURCE STOP：只读设计完成；本提案不将未知 SUMMARY_INVALID 猜成某个根因，不改 source/test/PWF/config/Git/原件，不重解析、不 POST。**
