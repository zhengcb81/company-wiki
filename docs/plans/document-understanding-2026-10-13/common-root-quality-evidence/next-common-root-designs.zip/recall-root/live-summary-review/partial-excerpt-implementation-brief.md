# 统一可用片段准则：施工前只读实施细则

日期：2026-10-14；ROOT/table_admission_review。状态：**源码冻结中，仅设计，未写测试、未实施、未执行新回放**。仅本文件写入；source/test/config/PWF/Git/原件不改，0 supplier POST、0 download、0 原文 parse。ROOT 解除 source freeze 后再施工。

## 1. 已确认的生产根因

CodeGraph 找到实际方法：`src/company_wiki/automation/narrative_select.py:535::_require_usable_selection`。真实生产注册与调用链为：

```text
narrative_batch / worker spec
 → narrative_worker_factory.create_runtime
 → NarrativeRuntimeDependencies + register_narrative_handlers
 → HandlerExecutor / WorkerRuntime
 → source.narrative_select = NarrativeSelectHandler.__call__/_execute
     → source reader.open_version + 原件/metadata 责任层检查
     → _select_pdf / _select_normalized / _select_transcript
     → parser/normalizer → frozen selector
     → _require_usable_selection → canonical SelectResult
 → source.narrative_summarize = NarrativeSummarizeHandler
     → 成功且匹配的 select dependency → model caller
 → source.narrative_verify = NarrativeVerifyHandler
     → 同源再次打开 → locator replay → canonical bundle → outbox effect
```

仓内没有名为 `ProductionHandler` 的类；此处所需覆盖的是上述实际 `NarrativeSelectHandler` 等生产 handler，而不是只调用 selector 或 benchmark 函数。

当前准入表达式：

```python
if (not normalized and (parsed.errors or parsed.opaque_pages)) or package.status == "blocked":
    # PARSER_INCOMPLETE, terminal
```

- raw PDF 即使有闭合、可验真的业务 spans，只要其他页 opaque 或存在任意 parser error，就整体拒绝。
- normalized HTML/PPTX/DOCX 调用时 `normalized=True`，反而不按这些全局诊断拒绝；后续主要检查非空和完整空 skip。
- 独立 selector replay 没有经过这个 gate。所以 quote recall 通过不能证明真实生产任务能启动模型；两种验收应各自明确。
- `DocumentStructure.coverage_complete` 在 errors/opaque/deferred 存在时是 False；0.9 selector 自身有 unread、deferred、withheld、graph/工作预算覆盖记录。它已经能表达部分内容，不必新增公众 flag、身份许可或签收链。

真实 producer 诊断包含 PDF `page_text:<page>:<exception>`、`page_table:<page>:<exception>`；HTML 的 `no_html_root` 可有实际可读 fragment，代码明确允许 parse anyway 并标记 coverage；`no_visible_text_blocks` 没有内容。PPTX package_open/slide/媒体诊断也不是同一严重性。这说明“有 errors”不能等于“所有已提取文字无效”，也不能把所有 errors 一律忽略。

## 2. 统一规则：可用性、覆盖率和业务完整性是三件事

**接受条件：源/媒体有效；非空 selected evidence 真实且可回开；涉及的上下文闭合；覆盖不足如实记录。** MIME 不作为宽严切换开关。

| 问题 | 所属责任 | 结果 |
|---|---|---|
| 选中片段能否被绑定至已验真的原件、稳定 locator、实际文本及 parser | 源/解析/选择层 | 不可靠的材料不能进入模型；不是模型复制 hash 来证明 |
| 整份原文/结构/候选业务是否已处理完整 | parser/selector coverage | errors、opaque、deferred、预算不足、withheld 保持显式；不得因有 spans 改 complete=True |
| 已选片段是否覆盖所有重要业务、摘要是否正确 | 既有独立真实质量节点 | partial 不是豁免关键遗漏，不能以可运行等同质量合格 |

两个允许结果：

1. 有闭合且可验证的非空材料：允许仅这些材料产生来源型摘要。来源存在未读/错误/推迟时结果仍 `partial`、`coverage_complete=False`，摘要 scope 仍 `selected_evidence_only`。`summary completed` 只表示这些片段处理完成。
2. 没有业务材料且已完整处理、确定属于行政/纯财务等无业务价值：允许既有 `skipped_no_narrative`、0 模型；不能从空+incomplete 推导无价值。

以下始终在模型前拒绝，真实 POST=0：

- 全 opaque、零可信正文、空 incomplete、package blocked。
- 文件/容器根本无法可靠打开、结构致命破损、媒体不支持；不能靠注入一个 synthetic span 装成可用。
- 原件字节 SHA、请求与 source/subject/期间绑定、打开的路径/类型、来源状态出现真实错误；沿现责任层报具体错误。
- 选中 evidence 引用别的源、locator/文本无法对应已经解析的原件、selected group 缺必需局部上下文或依赖不可验证。
- 未可靠的 OCR、unstable locator 等涉及将送入模型的材料；不能借其他页 valid 将这个坏 span 一并送出。

**0 POST 是前置材料错误的验收要求。** 模型返回未知引用/错角色才被发现时，实际已经调用一次，须记录已消费 usage、没有 accepted artifact、0 额外盲重试；不能把这种后置失败写成 0 POST。

## 3. 最小统一实现方式

不直接删除 `parsed.errors/opaque_pages` 判断后收工；也不增加 `allow_partial`、人工许可或 carrier whitelist。

### 3.1 一个统一的可用性判断

把 `_require_usable_selection` 收敛为内容/依赖准则，移除 `normalized` 作为宽严开关。三个 raw carrier 路径共用；official JSON 既有 branch 的相同“blocked/空 incomplete/可用非空/完整空 skip”逻辑一起复用核心判据，源 parent 验真仍归它自己的 source port。

判断需使用 **已打开的源与已解析结构**：

- 源 guard 已完成自己的字节/身份检查；不再从模型或另一个目录刷新相同身份。
- package/source 和 chosen spans 对应同一实际 parsed result；span 合同、parent binding、parser identity、原文 locator、实际支持及闭包在源层验证一次。
- 重用既有 PDF replay 的匹配规则 `source_catalog/narrative_replay.py::verify_replayed_pdf_spans`，对本轮已解析 units 做纯内存匹配；支持 native-range 的现映射，不能按 span ID 强行对齐会因 selector 注释改变的 parser span。
- normalized carrier 对本轮 normalized units/source-owned DOM/slide/paragraph locator 使用对应已有 round-trip 规则；transcript 继续 `material.verify` 和精确 byte/line bindings；official JSON 继续源 port 的 verified fields/parent bindings。
- 这里复用匹配/来源绑定，不再为了准入重新全源 parse，不写临时整份 MD，不每条 citation 打开一次 PDF。最终 verify 原件回开继续防原件或读取状态在任务期间变化，职责与前置内存匹配不同。

如果 selector 将不可靠 unit/group 选入，不能只在 gate 末尾删几条 span 然后留原 group。应在既有候选/context graph 入口把该 **whole required package** 标为 withheld/deferred，重用现上下文图和原因记录；其他独立闭合材料可继续。已形成 selection 若仍含坏成员，先如实拒绝而不是偷偷修引用，不引入第二 ranker。

### 3.2 诊断按真实影响范围处理

全局 fatal media/source 错误始终失败；局部失败仅使对应页/单元/依赖不可用，同时把 source coverage 保持 partial。只有诊断明确定位、且 surviving excerpt 真正不依赖该缺口，才能继续。

应在 parser/normalizer 自己的责任模块区分 fatal 与局部覆盖损失，准入消费同一语义。复用现结构/诊断端口，不建立新的权限字段或 opaque 许可记录；不依赖“错误字符串含 warning 就放行”、文件扩展名、公司名、页码特判。不能确定错误是否破坏当前引用时保留明确失败原因并修 producer 诊断，而非默默全放或增加人工签收。

HTML `no_html_root` 有真实、可回开的 fragment，不等于坏文件不可读；但随机非 HTML 文本、没有正文、结构根本无法定位的材料不应被 synthetic unit 掩盖。PDF 的 page_table failure 可与该页可读 prose 共存；不能整页盲清，也不能把缺 header/footnote 的 table claim 当 closed evidence。

### 3.3 覆盖口径必须贯通

保持现 `SelectionValue`、reading_context.unread/deferred/layout/native-scan 的事实：

- `page_count/pages_read` 为原 parser 观测，不用“selected page 数”替换，也不把 opaque 页计作已读业务。
- 原页 scan coverage、结构解释 coverage、候选/预算选择 coverage、正式摘要事实覆盖分别记录；`unassigned` 不是“原件没读”，`selected` 不是“整份读全”。
- 有 error/opaque/deferred/withheld/关键依赖不完整时，selection coverage 不能 True；status 与 scope 一致。既有 counts、采样 lists 的 limited 标记和 group relation 保留。
- 空 incomplete 不能标 skip；partial 不能生成“公司没有此业务/没有风险/全文未提到某事实”的结论。
- 金标准重要项缺失仍报告 FAIL，源片段准入通过不能覆盖它；当前因几页没读仍找到关键 quote 时，也只为这些 quotes 签收，不称整个文件完整。

### 3.4 冻结与兼容

不改 None/v1 的旧 prompt、response schema、decoder、data body。相同 pinned SelectResult 与 frozen model options 下，旧 HTTP request bytes/input SHA 完全保持。新的 source selection 行为由现 selection-generation 因果代码依赖绑定进入新 generation；旧完成 artifact 原样回读，旧冻结请求不重新按当前默认渲染/补字段。

准入变化不应被伪装为旧 model renderer 的无字节变化升级。需要更新现 source-causal dependency 覆盖 handler 的相关准入/过滤变化，使新请求身份与实际执行对应；不新增公众版本/flag、另一 manifest 或任务库。不能把原已拒绝的 frozen job 默默重解释为新的许可请求。

## 4. 先写 RED 的测试表

以下是**设计用例，尚未写入/执行**。写到隔离测试目录，固定 Temp/sentinel，0真实模型/网络；用 counting fake model 观察是否调用，不能只 monkeypatch `_require_usable_selection` 或直接测 selector。

| 编号/用例 | 真实生产路径与预期 |
|---|---|
| R1 PDF：一页实际业务正文＋一页图像 opaque；选中文本闭合可回开 | 生产 select→summarize→verify 成功处理片段，fake model恰好1调用；coverage=False/status partial；replay 数=实际 spans，原文不变。当前 blanket gate 应 RED。 |
| R2 PDF：另页 `page_text`/`page_table` 局部异常，已读页 prose 自足 | closed excerpt 可用；具体错页保留 unread/diagnostic，不能 complete；实际 handler/model/verify 走通。异常注入 parser 单页 operation，不伪造整份 package。 |
| R3 等价 HTML fragment 有 `no_html_root`、稳定 DOM/text evidence | 与 R1/R2 采用同一语义；不能仅因 normalized=True无条件放；source/locator验真、partial coverage均断言。 |
| R4 PPTX/DOCX：一个独立可读段落＋另 slide/part 不可读 | 自足片段允许；fatal container与局部损失区分。仅校验真实单位与类型，不将外链下载作为修复。 |
| R5 全 image PDF/全 opaque、空 HTML、空 DOC、transcript body/start 缺失 | terminal PARSER_INCOMPLETE/所属具体原因；fake model=0，真实POST=0，无 bundle/effect，无 skip。保持现空媒体测试。 |
| R6 corrupt/encrypted-unavailable/bomb/unsupported media | 原 parser/来源责任层拒绝，0调用；不会因 fake selector返回正文误放。仅测试仓内已支持的 fatal 类型，不扩张新安全功能。 |
| R7 package blocked，即使塞入 valid span | 仍拒绝0调用。`partial`标签不能抹掉 blocked。 |
| R8 source SHA/source-ref/实际打开类型/路径或 metadata 不符 | 沿 source guard 具体错误，parser/model按触发点0调用；不让错误变成 partial，测试不改生产 config。 |
| R9 所选 span 从另一源来，或 locator/raw_text/native range 被篡改 | 前置 parsed-material 匹配失败，fake model=0；不等付费后才发现。真实 bytes 和独立 selector span 需分别留存对照。 |
| R10 table/QA/project chronology 依赖缺 header/unit/期间/footnote/提问角色 | 不完整 whole group withheld/deferred，不偷删某条引用或借邻近标题补成闭包；其他独立完整 group可用。若当前 selection仍包含坏 group则拒绝0调用。 |
| R11 所选 unit low-OCR-confidence/locator_unstable 与独立可靠 unit 同在 | 坏 required package 不入模型；可靠片段不因别处坏unit整体丢弃。剩余为空时0调用，非空时partial；coverage不谎报。 |
| R12 完整纯财务/行政文档，无业务候选 | 仍 skipped_no_narrative、coverage=True、0调用。只在扫描/处理真的完整时允许，不用 empty候选做业务不存在证明。 |
| R13 spans有内容但 selector伪标 complete；实际opaque/deferred/withheld已存在 | 不能以 package标签自签完整；来源/结构 coverage向结果、prompt、bundle全程保真。关键gold缺失仍FAIL。 |
| R14 partial片段闭合且 quote gold已覆盖，但正式summary漏关键/错币种 | 工程可运行与质量FAIL并存；测试报告两种结果，不用partial或replay成功冲销质量缺陷。 |
| R15 model返回选择外citation/伪分析师question | 此时fake/实际调用已发生一次；按后置真实规则拒/标质量、留usage/response诊断，0额外重试，不能伪记0POST。 |
| R16 None/v1 pinned旧SelectResult，source新默认改变 | 旧 instruction/data_json/input_sha/body及恢复缓存0POST不变；新 source准入generation另绑定因果变化，不能旧job偷偷重选重发。 |

测试分层：

- 单元：格式无关可用性判据、fatal/local诊断及 coverage 不变量，不写照搬实现的 trivial test。
- 集成：实际 `NarrativeSelectHandler`＋真实小型内存媒体/normalize/selector，source reader隔离，纯内存 round-trip matcher计数，negative样例 model spy=0。
- 端到端：通过 `register_narrative_handlers`/真实 executor/DAG，至少 PDF positive partial 和两个 negative cases贯穿 select、summarize、verify、outbox/reuse；fake model合法响应，记录过程。不能仅测 `select_reading_evidence` 就签生产通过。

命令集中在一个工程节点；保留实际 RED/GREEN命令退出值和 source SHA。最终与 existing真实三供应商质量节点合并验，不新建逐页许可或全盘测试循环。测试结束关闭handle/process，删仅由测试新增的资料并还原初始 Temp/sentinel/config；原件SHA/size/mtime留证。不要完整恢复备份做演练。

## 5. ROOT 解除源码冻结后的施工顺序

1. 冻结现 renderer None/v1 byte snapshots，并先写 R1/R2/R5/R9/R10/R13 的 production-handler RED；保留现破损/空媒体拒绝测试。
2. 统一判据及局部/fatal责任语义；复用已解析材料的匹配与已有 context graph，收敛 normalized开关。不得同时重构预算、模型provider、身份库或consumer代码。
3. 贯通 selection/unread/deferred/summary scope与bundle coverage，绑定 source代码因果generation；模型模板独立冻结。
4. 集中工程测试＋隔离 E2E 留证；再跑现真实节点的相关partial源验证实际准入与质量，不能用 benchmark quote recall替代。成功进展由ROOT按正常commit/push与PWF记账。

**SOURCE STOP：仅完成本实施细则，等待ROOT解除源码freeze；未改select实现或测试，没有额外权限门。**
