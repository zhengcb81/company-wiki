# Implementation brief — settle failed summary output in the owned finish transaction

Status: **READ ONLY / source and tests remain STOP**. No implementation or new
test execution is authorized by this brief. Start TDD only after ROOT explicitly
opens the write window. This file is the sole new write in this task.

## Confirmed defect and unchanged accounting

The prior `report.md` and `observation.json` prove that known complete transport
followed by a strict failed summary retains its 2,097,152-byte output slot, even
after `finish_attempt` and current coordinator reconciliation. Existing output
settlement can release that slot without changing usage. It is quota, not a new
2 MiB file or another supplier charge. Provider tokens/costs, including reserved
or unknown conservative charges, must not be refunded or relabelled.

## Minimal interface and ownership

CodeGraph confirms the relevant implementation boundaries:

- `AutomationStore.finish_attempt` owns the active lease/runtime/latest-attempt
  fence and one `BEGIN IMMEDIATE` transaction. `_update_finished_attempt` and
  `_transition_finished_job` commit result/status there; any exception rolls all
  transaction writes back.
- The Store already calls the narrative budget owner's
  `_freeze_select_generation_in_transaction(connection, job, result)` inside this
  transaction. Follow that composition pattern.
- `NarrativeRunStore.settle_output` owns final-output invariants and idempotence.
  `_budget` owns the max-per-summary-job slot; that calculation stays unchanged.
- `Worker._execute_and_finish` already supplies the classified HandlerResult to
  `finish_attempt`. Its interface and retry behavior need no new hook or callback.

Expected source scope: **two files only**, `store.py` and
`narrative_run_store.py`. Expected new test file:
`tests/unit/test_narrative_output_failure_finalization.py`. ROOT assigns ownership
before work; do not modify caller, summarize, batch, schemas, CLI, config or other
agents' files. No migration, new store, public field or permission mechanism.

Proposed private interfaces, with names finalized in TDD:

1. `_settle_output_in_transaction(connection, *, run_id, attempt_id,
   output_bytes, output_sha256, settled_at) -> ReservationRecord`:
   extract the existing settlement SQL/invariants, including existing zero/hash
   pairing, positive-output conflict, over-bound blocking and idempotence.
   Existing public `settle_output` delegates under its own transaction and retains
   its argument checks and public behavior.
2. `_settle_failed_summary_output_in_transaction(connection, attempt, job,
   result, *, finished_at) -> None`: one narrow lifecycle rule owned by the
   native budget module. Resolve the exact attempt reservation; no reservation is
   a no-op for legacy/unmetered handlers. A mismatched job must not credit a
   different reservation. For a summary's returned non-success result with no
   artifacts/effects, settle that attempt's output to `(0, None)` through helper 1.
3. In `finish_attempt`, invoke helper 2 after the existing result/lease checks,
   finished-attempt write and finished-job transition, before returning, on the
   **same connection**. Any settlement failure rolls back result/status/output
   together. Usage already settled before this transaction remains intact.

Do not instantiate `NarrativeRunStore(...).settle_output(...)` from inside the
Store transaction: its second connection/`BEGIN IMMEDIATE` would introduce lock
contention and lose atomicity. Do not duplicate the settlement SQL in Store.

## Exact scope of the rule

- Both terminal and retryable **explicitly returned failed attempts** have no
  accepted artifact. A later retry reserves its own slot normally; its provider
  call remains independently charged.
- A successful summary keeps its bound until verified artifact publication.
  Other job types, pending verification/outbox and other attempts are unchanged.
- A reaped/crashed/unreported worker is not a returned failed-result proof. Its
  existing conservative uncertainty and output bound remain; do not infer zero
  from job status, `finished_at`, a missing artifact or missing usage alone.
- Do not modify `usage_status`, token/cost fields, original response SHA, native
  transport error, run block state or attempt error. A `failed_final` observation
  belongs to bounded control data, counted by physical storage guards, not an
  accepted final artifact's slot.
- Existing zero settlement is idempotent. Existing positive settlement must not
  be overwritten; retain the current conflict and transaction rollback behavior.
- Historical backfill and coordinator reconciliation are outside this first
  patch. Original saved receipts remain historical. Do not resend any model call.

## TDD acceptance matrix (planned, not yet executed)

All tests own one independent Temp AUTO DB; original/sentinel/config SHA, size
and mtime remain intact; restore Temp. No supplier, model or original download.

| Case | Expected observation |
|---|---|
| Known complete response → strict terminal summary failure | **Primary RED** today: output bound becomes 0 atomically with dead letter; exact native usage/response SHA/error retained |
| Explicit retryable summary failure | Current failed attempt's output 0 and retry-wait; retry admission gets its ordinary new slot; both provider charges remain |
| Explicit failed result with reserved / unknown usage | Only local output 0; conservative tokens/cost/status remain; later existing reserved→unknown reconciliation still works |
| Successful summary / pending verify or outbox | Original bound and later actual artifact settlement unchanged |
| Other job type / summary with no reservation | No unrelated budget write; legacy behavior unchanged |
| Wrong lease / generation / expired / not latest / already finished | Existing fence rejects before any output/result/status change |
| Runtime paused or generation changed | Existing active fence refuses finish; output remains conservatively held |
| Crash/reaper with no returned HandlerResult | Old hold and lost-worker accounting unchanged; preserve current ownership tests |
| Failure carrying effects | Existing invalid-effect guard rejects first; no output credit |
| Failure carrying an artifact but no effects | This narrow no-artifact rule does not credit it; existing handling remains |
| Diagnostic-only failed result | Diagnostic retained and bounded; it is neither an accepted artifact nor final-output bytes |
| Already zero / already positive output | Zero repeat unchanged; positive conflict rolls back and preserves original pin |
| Fault after settlement SQL, before commit | Whole finish transaction rolls back output/result/status; preexisting known money unchanged; valid retry can finish once |
| Lost acknowledgement after commit | Read confirms failed attempt and output0 already committed; stale repeat still follows existing fence, no second refund or resend |

Observe real persisted rows and `budget_snapshot`, not fake callbacks or only
helper call counts. For the atomicity case, execute the real helper update then
inject an exception before commit. Prove the public settlement API did not open
a nested connection. Keep failed RED output/exit evidence.

After GREEN, one focused node includes the new matrix plus existing
`test_automation_store_atomic.py`, `test_narrative_run_store.py`,
`test_narrative_run_ownership.py`, `test_narrative_model_caller.py`, and the
existing local failed-final CLI chain. Ruff/mypy cover changed sources. ROOT may
add a narrow invalid-summary public CLI assertion if needed to demonstrate the
actual lifecycle connection; no full-suite or paid rerun is needed per small step.
Then SOURCE STOP with exact hashes, receipt and remaining scope for ROOT's normal
commit/push node. This does not create another review gate.
