# Read-only root-cause followup — provisional structural design

No source, test, configuration, original, gold, PWF, author-tree or Git writes. No network, models or suppliers. Actual probe is paused while ROOT's pre-push node runs; this document distinguishes code facts from unobserved actual-source decisions.

## 1. One source-derived observation, one routing owner

Verified existing HTML bytes name `dei:DocumentType=10-Q`; previous formal result was root `earnings_call` with no child route. The two `SPEAKER_TURNS` source texts were not retained. The exact false predicate remains NOT_EVALUATED until the compact observer runs.

Structural causes worth testing together:

- The HTML parser retains visible inline-XBRL strings but exposes no typed document-form fact. `NormalizedDocument.metadata` carries encoding/backend/table counts; `DocumentStructure` does not carry form metadata. `narrative_reading._understand` calls `understand_units` without the supported `metadata` argument. Caller SourceMetadata or actual DEI fact therefore does not reach the route observation.
- `profiles.signals._detect_qa_and_call` treats any two accepted initial `Pascal Words:` strings plus a `quarter/earnings/call` word as transcript structure. A growing NON_SPEAKER_LABELS list does not make a source turn association.
- `_detect_sec` only samples own structural lines and probes. In a native SEC cover whose words are separate table cells, `FORM` and `10-Q` can be real adjacent title members but neither is an entire `FORM 10-Q` unit. A references-only negative guard is sound; omission of actual typed form information is a different problem.
- One existing router already owns primary-vs-child decisions; preserve that owner. Do not add a downstream second classifier, filename forcing or a fresh identity check.

Proposed implementation contract: source owner extracts bounded own-document facts during its already-open HTML normalization. A fact records value, field/name, same-parent source ID, actual DOM/byte context and own-vs-attachment scope. Keep provider-declared metadata distinct from source-observed DEI/cover facts. Carry these through the established observation adapter. Router arbitrates strong own-form evidence first, genuine call/release attachments only within their explicit native scope; a conflicting provider label is diagnostic. Speaker structure uses actual attribution/turn sequence, not generic label morphology alone. Whole text, geometry or original bytes do not become durable route metadata.

Suggested RED interfaces (public API tests, not whitelists):

1. HTML split `FORM`/`10-Q` own cover with `Registrant:`/`Telephone:` plus a quarter paragraph routes quarterly, preserves original cells/locators and no invented speaker.
2. Visible own DEI10-Q with sparse cover and ordinary colon labels routes quarterly. Hidden unrelated `dei:DocumentType`/quoted prior10-K cannot overwrite a real visible own form; explicit contradictory own form stays diagnostic rather than silently guessed.
3. True operator/CFO/analyst sequential turns route call; a real release/call attachment under an8-K retains outer8-K scope and separate child reading.
4. Real Q&A body under a policy-shaped filename stays Q&A, while an actual readable administrative policy can skip business extraction. No manifest label used as oracle.

## 2. One source-bound QA closure, then one global budget

IR actual previous result: all6native pages readable,302units,38selected spans/2094chars,258candidates,220omitted. Core VC-negation/controller qualifiers were absent despite a non-full final budget. Exact target-unit admission/withholding/rank is still NOT_EVALUATED.

Do not attribute omission to `CONTINUATION_LIMIT` merely because it appears: `structure.sections` records that diagnostic and still appends the body and its section membership. The actual observer must distinguish source extraction, role-shadow suppression, source turn association, package truncation/required dependencies, anchor admission and final budget.

Existing sound responsibilities: parser owns original QA roles/association and cross-page continuation; adapter projects the explicit same-parent group; structure owns answer/question membership; candidate stage excludes text-layer shadows; planner charges unique real closure. Keep all of these, replacing duplicate or excessively broad dependencies only with actual native association evidence. Do not select an investor premise as a company statement or omit an answer's denial/actor/modality to make a smaller package.

Suggested RED interfaces, refined after actual trace:

5. A native record spans two pages/table cells. Question premise `signed supply` followed by answer `we do not manufacture that product; our shareholder only hopes to cooperate` forms one source-bound closed QA; negation and correct actor/modality remain, even under a small final cap if the complete source-native fact fits. Change parent/turn/next-question association and the pieces must never be merged.
6. Duplicate `qa_text_shadow` and structured answer are not both selected. Shadow exclusion cannot leave the structured answer dependent on the discarded duplicate. A genuine missing continuation remains partial; changing company/VC names does not change behavior.
7. Many unrelated answer fragments in one container cannot force one useful answer to depend on an entire unrelated section. If the actual turn itself exceeds a bound, publish explicit deferred source ranges; do not certify its truncated prefix. Budget compares exact native closures, not paragraph count guessed from gold.

Role observation remains a separate oracle contract issue: management_answer vs management can represent nomenclature; third_party/regulator may instead describe origin/attributed actor. Keep old scores and distinguish these axes before defining one global compatibility adapter. Do not substitute unknown or loosen source roles to pass tests.

## 3. Bound native parse work at its current owner

HKIPO source exists and matched SHA/size, but80s was consumed before any DU/selection receipt. There is no retained per-page/phase progress. It is not yet known whether native DICT, fine projection, table discovery or table extraction dominates.

Code fact: `_parse_pdf_document` first scans every page into `page_blocks`/native views; it then selects table pages and emits all pages. `_emit_pdf_tables` calls `find_tables()` without a per-call cooperative cap. The15s PdfLayoutCollector bound applies to fine geometry work, not the entire parser or native table call. The current code already uses one native TextPage for DICT/WORDS; do not falsely claim duplicate native decoding as the cause.

Proposed measurement and implementation: once the publish window ends, record compact phase/page timers around the current parser entry and expensive existing methods, with a bounded actual page sample only to locate cost. Do not retry the whole HKIPO blind. After evidence identifies cost, use one document parse budget (time/work/page/cell) with bounded progress and explicit deferred page/phase ranges. Native stop must yield honest partial evidence at original coordinates. Use the existing processing/cache/lease boundary for recovery; no second parser, durable wholeMD, copied PDF, extra approval JSON or unbounded checkpoint log. C-extension table calls require an interruptible execution boundary when enforcing a hard timeout; checking only immediately after a call is not a hard bound.

8. A deterministic parser fixture with one slow/dense table and valuable late ordinary business text: text/table work and geometry counts remain separate, one deadline yields partial/deferred evidence and a bounded receipt; recovery processes only actual deferred work with the same source hash/parser configuration; raw IDs/coordinates remain stable. Keep a native normal-page control and failure/opaque/OCR distinctions. No wall-clock speed threshold as a flaky CI assertion.

## Unified delivery order and acceptance

First prove actual route and QA trace using one short replay each; parser cost stays unproven until bounded measurement. Then write focused failing generic tests at these three existing owners. Implement typed source facts/QA native closure/parser budget through the shared observation and decision inventory, rather than three consumer patches. Preserve model projection and current original integrity behavior. One concentrated engineering node plus original six-document/type subset replay suffices; no small-step human approvals or full-matrix repetition. Missing whole-source gold and analyst forecast quality remain NOT_EVALUATED.
