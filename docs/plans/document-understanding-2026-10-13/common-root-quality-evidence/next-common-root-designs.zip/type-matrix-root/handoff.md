# Phase C real document-type matrix — SOURCE STOP

## Counts and scope

- 20 purposive architecture samples; 20 original files exist and match declared SHA/size. This is not representative recall, an unseen holdout or supplier/model quality acceptance.
- Reused exactly three current portfolio6 formal receipts; no new parse/selection for CN H1, HK annual or MSFT10-K.
- 16 additional sources completed current formal0.9 native/normalize→selection. HK IPO exceeded80s inside the native parser before DU/selector.
- 18 new parse attempts in total: the initial CN IPO attempt was cut by the whole-batch remaining21.94s, then ROOT explicitly authorized only CN/HK IPO supplement. CN IPO completed54.10s; HK IPO timed out80.08s. Original cutoff and NOT_RUN receipts remain.
- Initial execution window 180.075s; supplemental IPO window 134.670s. All samples use96spans/48000chars, not increased.

## Actual matrix

| Sample | Manifest declaration | Actual DU family/form | Selected | Status | Focused quote observation |
|---|---|---|---:|---|---|
| cn-h1 | semi_annual_report | interim / unknown | 96 | REUSED_CURRENT_PORTFOLIO6 | 10/10 |
| cn-annual | annual_report | annual / unknown | 96 | partial | NOT_EVALUATED |
| cn-ipo | prospectus | prospectus / unknown | 96 | partial | NOT_EVALUATED |
| hk-release | results_release | presentation / unknown | 5 | partial | NOT_EVALUATED |
| hk-deck | presentation | earnings_call / unknown | 26 | partial | NOT_EVALUATED |
| us-release | results_release | results_release / unknown | 55 | selected | NOT_EVALUATED |
| cn-q-business | quarterly_report | quarterly / unknown | 12 | partial | 2/7 |
| cn-q-sparse | quarterly_report | quarterly / unknown | 6 | partial | NOT_EVALUATED |
| cn-convertible | convertible_bond_prospectus | offering / unknown | 96 | partial | NOT_EVALUATED |
| cn-equity | equity_offering_prospectus | offering / unknown | 96 | partial | 2/10 |
| cn-ipo-confirmation | administrative_confirmation | administrative / unknown | 0 | needs_review | NOT_EVALUATED |
| cn-ir | investor_relations | investor_qa / unknown | 38 | partial | 0/6 (3 role-unsupported) |
| cn-ir-policy | ir_policy | investor_qa / unknown | 95 | partial | NOT_EVALUATED |
| hk-annual | annual_report | prospectus / unknown | 96 | REUSED_CURRENT_PORTFOLIO6 | 7/7 |
| hk-interim | semi_annual_report | prospectus / unknown | 96 | partial | NOT_EVALUATED |
| hk-ipo | prospectus | NOT_EVALUATED /  | — | PARSE_STARTED | NOT_EVALUATED |
| us-10k | annual_report | annual / 10-K | 96 | REUSED_CURRENT_PORTFOLIO6 | 8/8 |
| us-10q | quarterly_report | earnings_call / unknown | 26 | selected | NOT_EVALUATED |
| us-20f | annual_report | annual / 20-F | 63 | partial | 3/15 (5 role-unsupported) |
| us-txt | investor_call_transcript | earnings_call / unknown | 96 | partial | 0/7 (7 role-unsupported) |

The same current `closed_group_support` observer was used for every matching SHA gold. Ten samples have pre-existing development focused-fact gold. Raw presence is32/70 defined targets, including15 unsupported role targets; this is an observation table, not a corpus recall percentage. No roles, target sets, gold text, importance, numerator or denominator were rewritten. Whole-source/exhaustive recall is NOT_EVALUATED for all20 samples.

## Source integrity, geometry and coverage

Each newly completed selection has canonical source-ID/coordinates/raw/parser membership or actual `verify_native_range_span` proof against its once-parsed source. Failed canonical spans=0; no input spans were invented to fill gold. Original bytes/mtime/SHA match before/after. Selected bytes, native units, page counts, parsed/deferred table counts, timings, observed geometry/native-view counts and actual versions are in individual receipts. Selected-only evidence and real group refs are gzip-compressed; no originals, whole-page copies, whole Markdown or full DU snapshots are written.

OCR was not configured or run. Opaque/deferred pages remain explicit. The scanned IPO confirmation is0spans/needs_review/opaque, not a certified no-business skip. There is no readable genuine administrative policy example: the file declared ir_policy is actually investor event Q&A. Native parsing coverage and selection coverage are separately recorded; partial does not mean quality passed.

## Evidence-backed issues and limits

### A. Actual declaration conflict, not a reason to hard-skip

`cn-ir-policy` bytes contain investor-relation activity categories, real stock/inventory questions and management answers. These appear at page1/table0 with real span/locator in `minimal-route-evidence.json`. Its investor_qa reading is plausible and the filename/declaration is wrong. ROOT must not tune the router to force administrative just because a path says policy. A new genuine readable policy specimen is needed before administrative skip can be accepted.

### B. VRSK10-Q root route conflict

The original HTML contains `<ix:nonNumeric name="dei:DocumentType" ...>10-Q</...` at raw byte104100. Actual current DU root is earnings_call, triggered by SPEAKER_TURNS; child_routes=0. Saved selected material includes actual revenue/contract-assets source paragraphs. The unselected speaker-trigger text was not retained, so its exact false predicate is NOT_EVALUATED; do not invent it or reparse the whole file. The current root/child routing conflict is recorded as a concrete investigation target.

HK release→presentation, deck→earnings_call and interim→prospectus conflicts are preserved. The classifier source-short proof for its cover/speaker cues is not retained, so those cannot be confidently called misroutes from expected_family alone. Selected examples and reason IDs are retained, each minimal case≤2KiB. An actual attachment could legitimately have another child family.

The scanned confirmation also has legacy outer `document_kind=prospectus` while actual DU family is administrative. This demonstrates that the public kind and new reading classification can diverge. Reconcile the meaning at one owner rather than add another downstream classifier or identity gate.

### C. Actual IR closure miss, independent of role aliases

`cn-ir` native input is complete but its selected38spans do not contain the key VC-negation/controller-contact statements. Candidate258 / omitted220, with CONTINUATION_LIMIT and FINE_CELL_CONTEXT_PARTIAL diagnostics, despite no final budget_full diagnostic. This warrants common QA continuation/closure investigation. Parsed packages were discarded, so exact admission/closure/rank cause remains NOT_EVALUATED; do not present an inferred unit-level cause as a trace.

Gold management_answer vs current source_role management is an evaluator-convention mismatch. Third_party/regulator gold roles may refer to source origin/attributed actor while spans carry speaker/document voice. This is not enough to prove production actor misassignment. The TXT selection contains management speakers Amy Hood/Jonathan Neilson/Satya Nadella, and IR contains separate investor_question/management roles. Original scores remain unchanged and unsupported scopes remain explicit; never substitute unknown or erase role to force support.

### D. Long IPO native parser limit

CN IPO429pages/14796units completed the supplement (parse33.662s, select18.134s), with explicit partial coverage. HK IPO did not finish native parsing within80s; no DU/selection/geometry quality is certified. Preserve timeout evidence and address native stage cost before repeating. Increasing a budget, claiming a route from title, or changing gold cannot close this missing coverage.

## General one-engine + strategy TDD proposals

1. **One primary/child classification owner.** Preserve real declaration metadata and source-derived formal cover/DEI signals; actual native unit kinds and turn structure must distinguish officer tables from transcript turns. Primary formal filing and genuine release/call attachments have separate scopes. Generic fixtures: executive names in a10-Q cover do not create a call; a real two-speaker turn/Q&A does; mismatched filename cannot force administrative. Do not use market/company/path keyword lists. Keep actual source actor/raw and typed provenance.

2. **One QA closure owner.** Use source-contiguous cross-page/table-cell membership for question, answer, qualifiers and speaker before a package becomes eligible. Test a question on one page and a negating answer/controller subject on the next, overlapping continuation pieces, limit/deferred recovery and small final selections. Log actual decision reasons once; do not patch VC/company-specific vocabulary or the downstream model.

3. **Separate role dimensions in the test contract.** Document source-origin versus speaking/attributed actor semantics using the actual published producer field. Apply a global documented compatibility interpretation only after generic positive/negative tests (company answer, investor premise, quoted regulator, third-party digest). Keep old reports and limits. No unknown substitution, actor rewriting or new permission file.

4. **Bound native IPO work at the parser owner.** Measure page/layout/table work and expose bounded partial-source progress/locators using the existing source pipeline/cache. Test dense long financial tables, valuable late business sections, original byte proofs, stop/recovery and no duplicated durable whole-document artifacts. Do not create a second parser/queue, case-specific page lists or run expensive full scans repeatedly.

These are engineering proposals from observed boundaries, not completed implementation or independent analyst acceptance. ROOT decides the next TDD window and broader actual replay after repairs.

## Missing real dimensions

S-1, F-1,8-K,6-K,amended filing: no matched real specimen in this manifest. HK IPO exists but remains unparsed within the bounded window. Readable genuine administrative policy remains missing because its declared specimen is a different document. No synthetic capability certification was substituted.

## Frozen windows, downstream update and recovery

Both the original run and IPO supplement finally guards passed for the whole source/config/gold snapshot. Subsequent finishing detected only `automation/narrative_summarize.py` changing, confirmed by ROOT as its other agent's downstream summary diagnostic fix. This matrix never invokes summarize. Parser/DU/selection/oracle causal sources remain unchanged; no all-tree-constant claim or broad rerun is justified. `post-run-window-drift.json` preserves the exact old/new SHA/mtime.

Protected production SourceCatalog/global configuration and all original/gold SHA/size/mtime checks pass. All owned `matrix-*` Temp directories are removed. Source/test/config/PWF/Git writes=0; source parser/selection runs are pure, provider/model/download/production-DB writes=0. Initial introspection import of nonexistent parse_text was a harness error before any parse, preserved in inventory; correct native/normalize/TXT APIs were inspected before execution.

## Files and reproducible commands

- `inventory.json`:20 paths/existence/SHA/size and inspected API signatures; manifest patterns are never gold.
- `execution-final.json` / `protected-after.json`: first180s window, old failure/NOT_RUN and guards.
- `pending-ipo/`: explicit two-source supplement; no overwrite of first-window receipts.
- `*.receipt.json` / `*.selected.json.gz`: actual current route/versions/coverage/time/selected-only canonical material.
- `minimal-route-evidence.json`, `role-compatibility-evidence.json`, `summary.json`, `post-run-window-drift.json`: limited independent findings and exact limits.

```powershell
python -X utf8 -B .planning/shared-reading-production/type-matrix-root/run_matrix.py
python -X utf8 -B .planning/shared-reading-production/type-matrix-root/run_matrix.py --pending-ipo
python -X utf8 -B .planning/shared-reading-production/type-matrix-root/finish_matrix.py
```

First two commands refuse existing receipt labels to prevent blind replay/overwriting. ROOT can copy only the harness into a new owned empty receipt directory for a separately justified future window; source originals remain at their immutable locations. Current selected-derived storage is about1.1MiB, below4MiB, with no raw copies.

**SOURCE STOP.** Default switch/full source quality and supplier summaries remain open.
