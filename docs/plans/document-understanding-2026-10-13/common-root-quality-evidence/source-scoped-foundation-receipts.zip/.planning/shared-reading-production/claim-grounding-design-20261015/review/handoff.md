# 正式业务摘要：从全局选引用改为 source-scoped 草稿

2026-10-15，独立只读设计调查；`attribution_release_review`。

## 一、建议与不能承诺的边界

建议下一版本同时做三件事，不能只改prompt：

1. **唯一共享阅读引擎形成有证据的叙述任务和覆盖计划**：让“该系列”的定义、阶段、否定/限定条件随原生依赖进入同一scope；业务方向的内容分配使用已有policy/priority，不在模型层再写一套公司/产品选择器。
2. **一次API请求内的source-scoped草稿**：原文只出现一份，按原生章节/共同上下文组织，把短任务key和原文放在一起；响应内容放在相应task下，程序恢复其支持链，模型不再自由在96段原文、64个长hash和64条strategy之间挑引用。保留20条和现有8192 token/模型配置，不能变成每unit一次API。
3. **分清确定性来源链和语义保证**：局部basis、角色、对象/数值/期间等已有类型约束能确定性检查的就检查；自由改写是否忠实仍需真实样本语义验收。不要以合法引用、数字都出现在某处、合法quote或嵌套JSON当通用语义证明。

**一次请求内的task scope不是模型可见性的硬隔离。** 模型仍看得到其他task，完全可以把A的句子放进B的槽。因此“程序选scope+局部草稿”是减少不必要工作、固定出处责任的架构改进，不是自动证明任意paraphrase正确。新方法必须用本次六条错引及换公司/文档的真实输出证明质量；不能只让结构测试变绿。也不能为了易通过，把用户要的有效摘要默默替换为整段原文摘抄。

## 二、真实请求的具体负担

调查对象：`live-20261015T184634-4e0b40` 的实际cn-h1 input/response/bundle和逐claim审查，没有读取PDF或调用API。

| 实际观察 | 数量 |
|---|---:|
| 原文记录 | 96 |
| 不同citation units | 64 |
| strategy group行 | 64 |
| unit member refs / support refs | 135 / 135 |
| 原文字符 | 7,769 |
| model data UTF-8字节 | 55,329 |
| 完整JSON body按紧凑等价序列化字节 | 62,496 |

同一原文已经只发送一份；不能误称当前在重复发送整份全文。重复引用主要是共享标题：MOCVD标题被10个unit引用，薄膜研发标题9个，ICP标题6个等。模型当前做的是：

```text
读eN原文表 → 找u_hash对应哪些eN → 找strategy里的u_hash → 合成20条 → 再输出u_hash
```

长hash缩短只能省若干字节/抄写负担，不能单独解决语义归属。本次20条decoder都按真实unit正确展开，六条依然错引；错误没有发生在程序hash映射，而发生在模型把命题与合法unit关联时。

六个真实反例：

- c1的研发数字在e15，却选了e14/e16。
- c10从e29/e31借产品定义/特殊器件进展，实际只选e28/e30；e30开头“该系列”本身还有语义依赖。
- c11概括Uniflash定义与交付，实际选了e28/e33的ALD氮化钛。
- c12 Micro-LED+GaN选了红黄LED的e47；c13 SiC+红黄LED选了InP的e48；c14 InP选了红黄LED开发的e46。
- gold critical的PD5完全漏写，同段Matrix也被压掉。EPI、气体净化、数字平台等已在输入中仍未覆盖。

详细原文/真实support/context/locator见既有独立审查，不修改付费证据。

## 三、共同责任层：已有对象及其缺口

### 已有、可以复用

- `NarrativeSelectResult`：同一source/subject、96个原始span、selection/reading_context/reading_dependencies；不需要第二份来源注册表。
- `reading_context` context/2：原始group及source-owned `citation_views`；QA支持/上下文分离已存在。
- `CitationUnits`：完整成员、事实support、group映射、去重顺序、same-parent约束；保留为程序侧闭包编译器，不再强迫模型抄它的长hash。
- 共享 `pipeline/strategy_binding/orchestration/summary_input`：唯一profile/业务facet/章节优先级/依赖，不另起模型侧业务排序器。
- `narrative_reading`：native-continuity原文、候选/最终选择、完整成员/上下文。其 `_context` 当前压成kind/section_role/group成员，**丢掉了多项决定草稿分配的意图**；不能在模型层靠猜文本重新推回全部意图。
- `SummaryClaim`/`validate_summary_claim`：来源已知、角色、context same-parent、质量投影。它不提供通用entailment验证。
- 现有generation/selection材料hash、AUTO/费用、response hash和旧版本解析/恢复：继续同一体系。

### 当前没有的能力，需明确新增

- 来源拥有的**摘要任务计划**，包含scope内哪些对象/业务方向需要被保留、是否因20条预算而defer。
- 指代/对象限定的语义依赖，不只是“本段有标题”；“该系列”不能只带“薄膜研发”标题便称语义已闭合。
- task-local model renderer/decoder及稳定映射；当前只有全局flat claims+任选unit列表。
- 逐claim source-basis记录及局部可检查约束；不能说现有quote/citation验证已具备。
- 源输入覆盖、摘要覆盖与语义质量的分离观察；当前固定target20不等于重要业务都保留。

## 四、拟议接口：先冻结责任，再TDD

以下是ROOT可实现的拟议接口，不是现成端口。新增内容均为源处理/摘要表达，不涉及研究结论或第二任务库。

### 4.1 `SummaryTaskPlan`：共享引擎拥有，模型编译器只呈现

建议内部versioned数据：

```text
build_summary_task_plan(selected source material, reading intent, max_claims=20)
  -> SummaryTaskPlan
     source/subject + selected material digest
     tasks: ordered SourceSummaryTask
     coverage: required/recommended/deferred source obligations
     limits: existing chars/tokens/claim limits

SourceSummaryTask
  task_key: transient short local key (e.g. t07)
  source_scope: immutable source parent and known group/view references
  support_members: exact canonical span IDs
  context_members: exact source-required context, disjoint from support
  role/modality_constraints: only actually observed source constraints, unknown allowed
  purpose: existing policy/facet/section intent, never source fact
  coverage_keys: source-owned scope/object/topic references
  origin: native member IDs/locators and dependency reasons
```

- 这个plan是现有selection的有界派生view，不是新的canonical group库。不能在summary模块新增公司名、产品名单、日期白名单或行业特殊分支。
- 先确定source原生scope，再编译模型展示key；短key不作为持久身份，完整members/support/material/策略hash仍在程序映射与请求身份中。重排任务可以改变这次request字节，但不会改原文span ID。
- QA answer/question是同一exchange的不同视图：原文只保存一份，输出scope的事实support不能因问题视图/展示顺序改变。required context不能授权事实或翻译。
- 对非QA，不可把原本只是排序用途的anchor直接当事实support；事实支持边界必须由来源语义责任层声明。未知就保守保留，不把标题/邻居变成凭空事实。
- 支持跨多个有原生关系的fragment才能完整表述的事项，例如产品定义+“该系列”客户进展，必须由这个plan保留关系。不能到decoder看到模型写了产品名后才自动搜邻居补引用。
- 不把所有未知完整性都变成阻断：该任务可以标`needs_context/deferred`，独立闭合的其他业务事项继续产出；诊断不成为许可链。

### 4.2 coverage allocation与native依赖

使用现有共享策略的business facets、section priorities、native结构/父范围和实际已读材料形成覆盖义务。不能在renderer里重新排名，更不能从gold读生产必选事项。

- “业务方向/明确产品代际/阶段差异”是覆盖单位，不是每个动词一个claim。允许同一业务对象的自然复合句，只要阶段归属清楚且支持充分。
- 主营产品、明确新产品/新业务、经营项目、行业/出海等按该文档现有profile处理。重复描述一个方向不能挤掉另一个已读且重要方向。
- 当重要事项多于20条可用空间，计划要明确本次输出范围/压缩分配与deferred；不能偷偷发送64条文本草稿再截成20条，不能声称已穷尽全文。
- 原始selected96项继续保留且只一份；任务计划不允许未经记录丢弃其中的素材。未用于最终摘要的事项仍可检索/回开。
- “该系列/该设备/this platform”依赖只沿已验证的同原生窗口/章节/父范围、显式对象定义/接续关系建立。需要有界成员和停止条件；跨产品相同关键词不能建边，不递归拉入整章。
- 表格任务交给同一typed结构/DU4-TABLE接口：原始row、header、period、unit与真实ref；不得把“拟达到目标”混成进展，也不得用same numeric literal判等价。DU4作者目录继续独立，ROOT只在已交付接口处接入。

当前真实输入中native_continuity的section_role大多unknown，不能假定它们已具有高质量产品标签。先复用已观测标题/依赖，逐步补同一共享引擎的source关系；无确定对象标签时保留unknown，不把global facet提示当事实。

### 4.3 新的model boundary：一次请求的task-scoped草稿

建议显式新版本，例如 `reading-model-input/4`、独立prompt/request/decoder版本。**不要就地改/3。**

输入展示应满足：

1. 全部原文正文按原生scope呈现，每个source fragment只出现一次。
2. 公共标题/QA交换等共享context只一份；真正重叠是图，不能为了树状展示强行复制或删除。允许有限back-reference到已展示的fragment，禁止三个全局表之间反复抄长hash。
3. 在task本地放短key、原文范围/源角色、明确阅读意图；标题可以直接用已有原文标题，不生成假公司/产品标签。
4. 典型结构是“章节的原文context + 局部tasks的原文body”，再为少数真正共享body保留同scope引用。代码可编译成稳定有限JSON，不引入任意模板执行。
5. 新response以task为容器，claim不再带可自由替换的全局`citation_unit_ids`。例如：

```json
{
  "drafts_by_task": {
    "t07": {
      "claims": [{
        "claim_id": "c7",
        "text": "original-language supported business summary",
        "basis_parts": ["b1"],
        "claim_type": "company_statement",
        "modality": "planned"
      }]
    }
  }
}
```

task key及b1是这次plan的本地有限标记；程序知道它指向哪个完整source span/支持分区。模型不输出source SHA、path、canonical IDs、自己定义的context或需要精确数数的原文绝对字符偏移。basis_parts只允许当前task内已经提供的原生part，不允许引用其他task。

输出总claims仍≤20、每条≤280字符，model/max_output/thinking等遵守现有配置。若一个scope需要跨几个part才支持，basis要完整包含，程序按照共享引擎的依赖恢复context；不能把任意多个task的内容合并后用单个task名蒙混过去。

对无法产出/未分配的scope保留有限diagnostic（例如not-selected/needs-context），不要求为64个task各写一段解释，防止结构化汇报本身挤占token。全局预算仍由既有HTTP caller判断，不新增一个LLM预算账。

### 4.4 Decoder、source basis与真值界限

拟议纯函数：

```text
compile_grounding_view(selected, source_task_plan) -> frozen renderer view + local map
decode_scoped_drafts(response, selected, frozen view)
  -> canonical draft + bounded grounding/coverage observations
```

- task key、part key、duplicates、source parent、QA视图、必需依赖、role/modality枚举、原语言等确定性检查由程序完成。禁止模型覆盖绑定。整条不合法命题按现有recover-whole-claim方式处理，不删一半引用后悄悄保留。
- 如果需要持久source_basis，存**span/range refs和source-owned约束观察**，不要再复制原文。可用现有SummaryClaim的有限additive可选字段风格；旧wire省略，严格消费方（包括RF）同步兼容测试。若本节点选择不改公共合同，至少保留可复查的raw response/request映射于既有受界diagnostic/产物机制，不能另建无界日志库。
- 精确引用/完整source basis只证明出处。数字/单位/期间的typed关系（已有或DU4 source binder返回）能做局部矛盾检查；不能以“数字都在本task出现”证明对象、币种、期间、因果关系、否定均正确。
- 原文摘录可以作为basis，合法quote也不证明自由paraphrase被它蕴含。不能引入一个默认返回True的“entailment validator”，也不能把未知改成通过。
- 建议质量观察分列：`scope_binding`、`source_basis`、`typed_consistency`、`coverage`、`semantic_review`。未做语义审查就写未验证，不把`needs_review=false`或合法引用冒充语义签收。这些是质量信息，不是新的人工许可。
- 自由paraphrase对同task内容仍可能张冠李戴，不能通过JSON schema彻底杜绝。本次及holdout真实语义审查依然是验收标准；如果选择抽取型basis辅助显示，必须明确它是支撑材料而非用来降低用户摘要要求。

## 五、兼容/因果/恢复不变量

1. None、v1、v2、v3 的instructions/schema/request/data/input hash/HTTP body及旧响应解码金样保持。新增v4独立分支，不改变既有v3 helper行为来省工作。
2. 新model view/compiler/覆盖分配及source dependency版本进入当前generation causal identity；每个请求的短key映射和确切HTTP字节进入既有reservation hash。不能只改展示而不记录它对模型输入的影响。
3. 旧已付费generation继续stage-scoped恢复和outbox，无重POST。旧pending renderer不可执行仍在实际summarize前拒绝，不伪装当前decoder等于旧代码。
4. SourceRef、原件、locator、QA角色和原语言仍由原责任层验真；model boundary不读磁盘、不parse、不搜索供应商，不跨仓写文件。
5. source task plan只能消费当前selected材料及其已冻结依赖。post-model不能调用其他原文来给已付费claim补出处。
6. maxclaims20、maxtext280、实际token/费用/响应字节/时间/空间上限不变；不增加N次API、无自动修JSON重发。调试观察只存小型受界refs/计数，不落全MD。
7. profile默认/生产selector切换与新boundary合入分开。一次新样本机械绿不能直接把0.9改成默认。

## 六、ROOT实施文件与合理分阶段

### A：先用既有真实反例冻结测试

测试夹具只保留必要selected原文、实际units、真实paid claims及精确source SHA/locator，旧原始gzip留证不改。建立“形状合法但语义错”的负控，避免测试只验证decoder会展开合法ID。

### B：共享source task plan和新model协议

- `document_understanding/narrative_continuity.py`及已有source strategy/binder：有证据的指代/对象/阶段依赖和源覆盖意图，唯一责任。
- `source_catalog/narrative_reading.py`：把最终选中材料的任务/覆盖意图带到边界；版本化、partial诚实，不在模型层反推原文。
- 可新增 `document_understanding/summary_tasks.py` 一类纯模块，复用已有policy/结构；不是第二ranker或source库。
- `automation/narrative_model_citations.py`：继续原有闭包编译；新展示编译器可分新文件，旧3函数语义不变。
- `automation/narrative_model.py`：有限v4 boundary、task-scoped renderer/decoder、schema及旧分支冻结；不把所有不同renderer塞成不可读条件链。
- `narrative_generation.py`、`narrative_worker_factory.py`、`narrative_summarize.py`：注册新因果边界、当前runtime版本选择、沿既有caller与语言观察。源阶段不额外调用模型。
- 若持久basis/coverage字段：`narrative_contracts.py`、`source_catalog/narrative_evidence.py`及RF唯一消费合同同步处理，旧可选字段省略金样不变；FF无需新增下载入口。

### C：集中真实验收后再泛化

固定同一配置/预算重跑原cn-h1，独立逐claim语义审查；至少覆盖新范围的另一家公司/不同格式，检查不是针对中微名字修好。已有HK/US真实问题也要适配到同一协议/约束验证。合并正常hooks/CI与PWF更新，但CI工程绿不取代语义节点。

这里不建议为了“确定性”立即对64个unit分别调用64次模型；也不建议改为每个产品写一个provider或skill。相同共享引擎+阅读策略仍是唯一核心。

## 七、TDD反例矩阵

### 结构/引用/请求预算（可确定性单元测试）

1. 原文96项在新request恰好一份；共享标题/QA重叠不复制raw；无unit因展示树化而消失。
2. 同source两个产品、相同验证/订单词：不同task各有独立原生support；短key重排不能改canonical ID；未知/跨task/duplicate key/part拒绝。
3. question和answer展示在同一exchange、两个role view；只选问题不能产生公司actual，中文问题不能授权英文回答翻译。
4. 该系列定义+后续进展的有界原生依赖保留；另一个无关产品/隔页附件/独立公司声明阻断自动接续。无证据指代为unknown/deferred，不拿固定前一段补齐。
5. 一条自然复合句允许保留，前提是同scope/所需part和阶段全部支持；不按逗号/每个动词强制拆分。
6. table同一数字出现在投资额/产能、两行同数、两个年份同数、万元与亿元、货币不同、目标与进展不同：只有对应typed关系才能判一致，literal相同不代表通过。
7. 总claims21、文本281、输出字节/unknownsource/invalidJSON/path/metadata覆盖保持拒绝；20条预算不能内部先造64文本再截断隐藏。
8. None/v1/v2/v3全部请求/HTTP/hash/旧响应金样原样；v4 hash含新编译/计划/映射，旧付费恢复不多POST，pending unknown decoder仍拒绝。
9. 改变policy、source、parser/真正依赖必失效；仅可视key不同不重写旧generation。源原文不变，配置/Temp/费用账不写穿。
10. 只有一次model.generate/HTTP POST；失败无自动修JSON或按task补发；实际配置的模型/thinking/token字段不变。

### 语义/覆盖回归（不能冒充纯schema证明）

11. 固化c1：正确数字+错误任务出处仍属语义FAIL，不能因为20.41等出现在别的task就通过。
12. 固化c10：钨系列定义、存储/逻辑/特殊器件进展需要真实支持part；不能只带研发标题。
13. 固化c11：ALD TiN子产品quote不能证明Uniflash完整系统交付；同一术语出现也不能洗产品范围。
14. 固化c12/c13/c14：Micro-LED/GaN、SiC/红黄LED、InP三种不同scope和阶段不能互借。
15. 错误文本放入**正确嵌套task key**，合法basis_parts也仍不能声称semantic PASS；此为“嵌套scope不是通用隔离”的必备负控。
16. 相同数字/相同客户验证词但对象相反、否定遗漏、报告期与发布日期不同、旧代与新代：按实际原文语义验收。
17. source selected已有PD5/Matrix/EPI/气体净化/数字平台/行业更新，明确覆盖/范围诊断；不允许20条主要重复同一方向却声称业务覆盖完整。
18. 当前事实+未来目标允许自然表达，结构字段不得反转含义；不是每个动词都拆句，更不能把保留阶段文字的WARN统称幻觉。
19. 合成同构公司名/型号与第二真实公司验证；生产代码不能读取gold或识别中微产品名，换别名/顺序仍成立。
20. 真实新输出若仍错引/遗漏，保存失败和费用继续共因修复；不能静默改证据、放宽gold或把旧0.8测试适配失败当新0.9质量失败的替罪羊。

## 八、未知风险与实际下一步

- 新展示是否改善MiMo/DeepSeek/MiniMax的引用正确率，尚未测量。不能把设计建议当真实成功。
- task分配可能提前丢重要事项；必须沿共享策略记录allocation/deferred并看真实PD5/第二曲线反例，不另加固定公司清单。
- 共享source是图；强行每unit完整内嵌会重复原文，强行独占一份会丢依赖。需要对真实overlap分型（标题/QA/表头/重叠body）并保留原生refs。
- 原生“该系列”依赖本身可能跨多产品或读序不确定，不能承诺通用指代消解；保守unknown而非凭相邻猜测。
- 新basis公共字段会影响严格RF consumer，需要独立契约测试；并不要求任何消费者访问CWP物理目录。
- 只靠输出schema无法证明一般paraphrase语义；不应再新造一个可伪造的“semantic accepted”布尔值/人工签收合同。

建议ROOT下一具体动作：把真实六条错引、PD5/Matrix遗漏及两个产品同构例组成集中RED；冻结共享任务plan和新boundary接口；实施一次请求内的局部草稿与源依赖/覆盖共因，再做真实集中语义节点。报告本身不新增审批或小节点审查。
