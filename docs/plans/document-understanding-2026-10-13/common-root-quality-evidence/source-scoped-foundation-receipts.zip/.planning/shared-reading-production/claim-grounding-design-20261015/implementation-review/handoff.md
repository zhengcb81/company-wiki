# 来源摘要任务 view 与逐claim锚点观察 — 独立实施审查

2026-10-15；审查者 `attribution_release_review`。

## 结论

**本来源view/回归观察子节点通过，未发现需要阻断其独立发布的剩余问题。** 来源task只是既有选中材料的有界引用view，没有实现生产v4、修好模型错引或完成母计划语义验收。真实cn-h1的6条P1错引及PD5等遗漏仍开放。

本次阅读当前源码/测试/有限gzip夹具，最初独立执行两份新测试 **28 passed / 2.98秒**；ROOT按审查反馈关闭标签和非字符串role问题、补充语义边界负控并增加纯scoped compiler后，独立集中执行三份新测试 **44 passed / 2.88秒**（16来源task、16逐claim观察、12模型view），正常主机Temp自动清理成功，收据为`final-junit.xml`。这44条包含前28条，不应相加。之后ROOT将显示编码改为无损defaults并增加3条测试，报告 **47 passed / 4.30秒、Ruff六文件及mypy三责任源通过**；审查者只读复核该最终差异及收据，未重复运行。独立44条证据对应compact之前快照，不能冒充最终47条的独立重跑。没有读PDF、生产配置或密钥，没有网络/API、真实parse，也没有改源/测试/PWF/Git/DU4。

## 范围

- `src/company_wiki/document_understanding/summary_tasks.py`
- `tools/document_understanding_benchmark/closed_group_support.py` 的新增 `score_claim_facts` 与共用matcher调用
- `src/company_wiki/automation/narrative_model_scoped.py` 的纯本地模型view编译与basis解析
- 三份新unit测试及 `tests/fixtures/narrative_claim_grounding`

CodeGraph先提供结构入口，随后读取当前文件；源码指纹与报告manifest见 `handoff.json`。

## 审查结果

### 来源职责正确

`build_summary_task_plan`不读配置/文件/网络，不调用模型、不parse文本、不新增公司/产品规则或第二ranker。它读取既有group/views、原始EvidenceSpan及metadata，将topics/selection reasons当观察到的阅读意图，不声称它们是新事实。`max_claims`由既有调用者传入，只记录，不截掉任务/原文来凑20条。

task保存canonical引用而非原文副本。key仅局部地址，plan binding包含确切顺序、source、group、support/context、类型和观察metadata；重排改变本plan hash而不改变原始span ID。coverage只记录当前source task是否输出，明确 `semantic_status=not_evaluated`，不引入许可或投资结论。

### QA、父来源和重叠正确

QA两个source-owned citation views分别保留answer/question支持以及完整exchange上下文；support/context完整、分离、已知，跨original parent被拒绝。shared标题形成重叠task，但不递归吸入邻组；只有不属于任一组的span成为standalone。未从任务的显示key推断source身份、发言人或事实角色。

本helper是来源内部view，消费既有production context，而不是替代完整source ingress/字节/角色验证。它检查本view所需的引用/partition不变量，不重做整套SHA、许可或配置审核。

### 发现并关闭的有限不变性缺口

初次纯探针将不合法producer group的`kind`置为list：builder原来会保存这个可变对象，调用者随后append会改变已建plan的`binding_sha256`。它并非当前typed context的有效值，不能夸大为生产来源漏洞，但与不可变causal plan承诺不符。

ROOT已在`register`要求kind/section_role为immutable字符串，并新增两反例。审查者在最终源码上分别以list输入两字段，均得到 `ValueError`，证据 `label-postfix.json`。有效字符串context的外部赋值不改变已经构造的plan。

关于role的一次推断也明确纠正：`EvidenceSpan`会把list冻结成tuple，`source_role=['management']`实际可被规范为unknown，**并未观察到list必然TypeError**；不得把先前推断写成已复现bug。该探针保留为 `source-role-probe.json`。ROOT另外用合法JSON的dict role复现了去重前`TypeError`，并将非字符串role先投影为unknown、再去重；最终独立44条测试包含dict与None反例，已通过。此处理沿用既有unknown语义，没有把未知角色洗成management，也没有增加权限或重复身份门。

### 本地模型view维持来源归属

纯`compile_scoped_model_view`只消费同一typed selection并调用唯一source task builder，没有第二次selection/DU、IO或模型调用。模型中的短task/part key只是一种局部显示，程序侧binding保留原span、source和完整task映射；`MappingProxyType`及不可变source对象避免调用者改变内部映射，模型dict是可丢弃副本。

原文按canonical span身份定义一次，重叠task使用shared引用；相同文本但不同真实locator仍是不同span，不能按文本去重身份。每个task保持原有成员顺序，跨task part、未知/重复part及context-only part不能成为basis。`resolve_basis`分别返回模型实际选择的`basis_ids`以及该task既有的完整`support_ids`/`context_ids`，保留原scope限定和QA上下文，不补邻居、不递归扩大闭包。

合法task和basis仍不证明模型文字、业务阶段或数值含义正确；组件没有claim.text参数，`semantic_status`明确为`not_evaluated`，错误文字加合法basis的负控已通过。该纯组件尚未接生产v4、正式prompt/decoder、DAG或缓存恢复。

最终defaults编码已只读复核：fragment按真实选中role/flags计算默认值，task按真实kind/section/topics计算默认值，具体非默认值保留；`support_parts=all_parts`只对应本task全部parts，QA非全部support/context例外显式保留。原始reason codes只留program binding，模型仍收到observed topics；这不删原文、不改变角色归属或support/context。新增roundtrip测试沿真实task映射展开核对，而非只断言长度。

ROOT实际字节收据`../model-view-profile.json`保留初版verbose **47,813B**、旧material/group lookup **30,758B**与最终compact **30,590B**。最终只少**168B**，不能宣称明显token/费用/延迟或质量改善；旧完整data为55,329B，包含额外策略，不能拿它直接与新材料view比较得出收益。审查者读取收据和最终编码，没有独立重复字节测量。局部key能减少全局alias查找操作，但实际模型是否更可靠仍待真实摘要验证，full v4 HTTP与tokens明确`NOT_RUN`。

### 逐claim观察没有借用全selected输入

`score_claim_facts`先为每条claim过滤其真实factual `evidence_ids`，context-only引用不会补事实；只保留其实际完整引用的native group，沿原来的 `_supports` 唯一quote/range/role/page matcher判断。

`selected_source_support_present`与` supported`分列，其他claim/同批未引用文本只影响前者，不使本claim通过。AND anchors可在多个真正被本claim引用的units中分别找到，这个关联由独立审查者明确提供，不是程序自行把无关语句推成一项事实。native连续quote仍需要已有闭合窗口与原生连续性。

真实fixture的源/response SHA、生成prompt/data字节相同及20条原draft不变被测试固定；六条旧错引保持` supported=false`且全输入存在真实支持，没有静默补引用或把paid失败改写为通过。

### 重要界限已钉住

本工具**不读取/判断claim.text的通用蕴含关系**。审查者故意提供原文“尚未量产”、claim.text“已经量产”，并给原文quote作为人工anchor：观察器会返回该anchor在claim support中存在。这个True只表示“指定锚点存在”，不表示相反的claim正确。

这符合函数docstring、scope=`reviewed_anchors_in_claim_support`及fixture manifest的明确限定。ROOT已增加相应显式负控，防止以后把这种手工锚点观察包装为一般语义proof或生产自动放行。今后真实新response必须有对应的独立语义审查/事实锚点映射，不能把上一response按claim_id写的人工mapping直接当新语义评估。

## 复杂度和数据保持

- task构造与已选span及group/view实际成员引用规模相关；排序检查只作用于有限成员，不复制原文、不做两遍DU/全文查找；最多两source视图/组沿既有context界限。
- quote观察先建一次全selected locations，再按最多20条canonical claim构造局部locations；没有供应商调用或原文重parse。既有quote/range窗口及2048字符quote界限继续使用，没有新匹配器/全页拼接。
- 新fixture约123KB压缩，保存选中证据/实际请求/response与明确重构说明，不含PDF原件或API凭据，不冒充保留了未保存的完整原始typed selection。
- 此子节点没有注册v4/runtime默认、改变模型、输出上限、费用、预算、缓存恢复或旧None–v3 wire；未来v4接线需要自己的集中契约和真实语义验收，但不以“未来未做”阻断本节点发布。

## 验收边界与后续

本节点证明：source view忠实携带既有范围，回归工具能识别人工审查确认的六条错引，并诚实区分selected中有与本claim有。它不证明依赖组已语义闭合、覆盖优先级已经规划、生产v4已接线、任意数字/对象/阶段/否定已验证，或真实新摘要会更好。

ROOT可按正常hooks提交该子节点、保留本报告/指纹并更新PWF；继续同一共因计划的source依赖/覆盖、一次请求内局部草稿及真实跨公司审查。没有新增小节点审批建议。
