# Independent review: reading_plan/2

Reviewed production `narrative_budget.py`, `_admitted` / `_candidates` in `narrative_reading.py`, additive field transport in `narrative_finalize.py`, actual-carrier scope and versions in `decision_inventory.py`, and the author's value-coverage tests. This lane made no production/source/oracle/PWF changes and did not parse an original or call a model.

## What is sound

- The value band is supplied by source-owned fact eligibility or the shared engine's qualified operating table. Reading family/role alone becomes `description`; the budget never reads raw payloads or adds company/product vocabulary.
- The new policy uses the existing shared closure/heap implementation. Unique original span/character cost, missing references, cycles, context-only members and complete groups remain explicit.
- Novelty precedes reading priority only within value bands; average visits use exact rational arithmetic, preventing multi-label cardinality from becoming a penalty. Empty topics do not manufacture novelty.
- /1 retains its original strict-priority branch; legacy/semantic ignore the additive value field. The source diff has no replacement engine or classifier. The author additionally reports 1,400 released-HEAD differential cases; this reviewer did not repeat those runs.
- PDF/HTML dependency scope follows actual observation MIME carrier, not filename/company/market. Missing/conflicting carrier proof cannot recover a complete current inventory.

## Independent probes and findings

Scratch executable: `test_value_review.py` (9 tests, outside normal unit collection).

`initial.log`: **6 PASS / 2 FAIL / 4.43s / exit 1**. `signature-prefix.log`: **1 FAIL / 4.15s / exit 1**. No failing oracle was relaxed.

Six passing probes cover 80 deterministic small DAGs against an independent naive closed-set specification (value/novelty/priority/mean visits/unique cost), shared transitive context cycles, missing-reference isolation, no payload access/context promotion, distinct IDs sharing the same payload, and zero work stopping before Fraction ranking.

### Required fix 1: pure Chinese numbers are admitted as descriptions

`_admitted` uses `any(character.isalpha())`. Unicode Chinese numerals such as `一`, `二〇二六`, `壹佰` are alphabetic and therefore pass a business scope without a fact. They are not promoted to meaningful facts, but can consume remaining selection slots or create meaningless summaries. The isolated control fails on `一`. Retain the qualified operating-table numeric exception; do not add company-specific filters.

### Required fix 2: PDF projection version is omitted from cache dependencies

`_versions(pdf_frontend=True)` includes the frontend feature identity but omits the independently owned pure geometry projector's actual `layout_snapshots.FEATURE_VERSION = "du3-geometry/1"`. Updating that component independently could alter binding/frame/alignment behavior without invalidating old PDF decisions. HTML should remain independent of it. The control fails because no current PDF version entry equals the public component's identity.

### Required fix 3: realistic descriptive signature prefix stops before late facts

The producer's `_group_signatures` generates CoverageSignature for descriptive candidates as well as facts. The author's large value-band fixture uses `signature=None` for every description and therefore omits this real path.

Independent case: 19,997 high-priority descriptions, each carrying the same immutable, valid 50-token signature; 3 late low-priority meaningful facts; unchanged 96 spans / 48K chars / 2M work. Result is **zero selected spans** and `work_budget_exhausted` before ranking.

Signature validation costs roughly 1M; interning reserves three traversals per signature per item (roughly another 3M), even when the same immutable signature object is reused. This is excessive repeated preprocessing of low-value material, rather than a missing charge. /2 should avoid unnecessary description repetition intern/comparison, or safely bound/reuse validation/hash work for immutable identical metadata. /1 must retain released behavior. Do not raise the cap or remove the failing late-fact assertion.

## Work-accounting assessment

Indexing, graph expansion, topic membership, heap operations, signature hashing/comparisons and shared-context revisions reserve work before operating and return explicit partial stops. Fraction uses a denominator of at most 64 labels; visit increments are charged, its numerator is bounded by admitted input work, and construction occurs only after topic/heap work reservation. No unbounded Fraction loop was found. The real observed efficiency failure is the signature prefix above, not gcd arithmetic.

Accounting is an algorithmic operation estimate, not a hard CPU-time guarantee: sort/tuple comparisons and Python/C integer arithmetic are represented by bounded-size charges. This does not justify increasing the 2M cap.

## Acceptance status

Core value/closure ranking is supported by the independent probes, but complete acceptance is **pending the three fixes and unchanged 9-probe replay**. ROOT has assigned them to the production owner. This review does not sign the reviewer's own PDF frontend code or claim whole-corpus quality based on the ROOT US 8/8 replay.
