# PDF native layout frontend handoff

Status: source stopped; ROOT may run the shared A/B/C acceptance and commit. No commit, production configuration change, original write, model call or download was made by this lane.

## Owned changes

- `src/company_wiki/source_catalog/narrative_pdf_layout.py`: new bounded native frontend, `PDF_READING_LAYOUT_FEATURE_VERSION = "pdf-reading-layout/1"` (add this identity to decision inventory/cache dependencies).
- `narrative_evidence.py`: PDF state/read/emit/facades only. Opt-in `selector_version="0.9.0"`, optional `layout_limits`, shared `layout_max_seconds=15`.
- `narrative_document.py`: additive `DocumentStructure.layout_coverage` / `layout_diagnostics`; `NarrativeUnit.to_evidence_span` strips only the new transient `reading_layout` namespace.
- `automation/narrative_select.py`: PDF protocol and `_parse_pdf` only. Only the current default PDF parser receives opt-in parameters; a legacy custom parser still receives its original keywords.
- `tests/unit/test_shared_reading_pdf_layout.py`: 36 behavior tests.

The geometry package, adapter, structure/meaning/reading strategies, planner, active external lanes, shared PWF, production config and original files were not edited.

## Interface

New unit metadata is solely `reading_layout = {feature_version, layout, hints, upstream_hints}`. Old bbox/fonts/coarse feature version and every old metadata value remain identical.

- `layout`: shared projector output and actual cropbox/cropbox_position. Native dict and its word boxes remain in unrotated `dict` coordinates, with actual page rotation recorded. Rotation need not imply `frame_converted=true`.
- `upstream_hints.words`: actual same-TextPage `extractWORDS` boxes, native indices, exact unit character ranges, source/page/frame.
- `upstream_hints.cells`: actual existing `find_tables().tables[].rows[].cells`, actual table/row/column identities, exact unit character ranges. QA fragments retain actual parent cell offsets (`native_cell_char_start/end`, `partial_cell`); they use the real whole-cell box rather than an invented fragment box.
- `upstream_hints.font_runs`: measured native span style with exact intersecting unit character ranges.
- `upstream_hints.spans`: actual span boxes and native block/line/span indices, intersecting character ranges, partial-span flag, actual source/page/frame; no repeated span raw text.

One `TextPage(flags=TEXTFLAGS_DICT)` supplies dict and WORDS. The already-run table discovery/extract results supply cells. WORDS block indices count text blocks, while DICT includes image blocks: the explicit ordering mapping fixes the demonstrated common image offset defect and preserves old dict block locators.

New metadata is transient and never becomes `EvidenceSpan.structured_value`. Under identical topics/reasons, old/new EvidenceSpan objects and SHA identities are identical even when fine boxes drift. Native records are released after projection/summary. No full-page JSON/MD, original copy or second geometry store is produced.

## Resource/failure behavior

Defaults are global per document: 64 captured pages, 10,000 projected units, 200,000 native/committed fine elements, 1,000,000 work units, 15-second shared deadline. Limits can only tighten. Work exhaustion cannot restart on a smaller later charge. Missing crop frame, native provenance/characters, fine geometry, optional capability or projection failure is diagnostic/partial; original text units and table rows survive. Deferred unit examples and diagnostic unit IDs are bounded to 128 with counts/limited flags.

Fine geometry coverage is separate from ordinary text coverage. Real native word boxes spanning several source sentence units cannot be split into invented subword boxes. A measured style span alone is not claimed as a fine word/cell box.

Known scope limits: geometry capture currently follows scan order under the 64-page cap. Late prospectus pages may be deferred in a whole-document run; this must not be described as whole-document fine completeness. Native library calls themselves are synchronous; deadline checks surround analysis but cannot preempt an in-progress native call. The four-page probe below validates the native frontend and source identity, not whole-document recall/summary quality. ROOT owns policy/priority and any later staged page allocation.

## TDD and acceptance evidence

Decisive RED retained:

- `pdf-layout-a-red.log`: original 19 failures, exit 1 (new interface absent).
- `pdf-layout-fragment-red.log`: missing parent-cell fragment provenance, exit 1.
- `pdf-layout-native-image-red.log`: genuine PyMuPDF image block displacement, exit 1.
- `pdf-layout-capability-red.log`: legacy page capability failure and work-budget restart, exit 1.

Final A: `python -m pytest tests/unit/test_shared_reading_pdf_layout.py -q` → **36 passed / 4.41s / exit 0**, `pdf-layout-a-green.log`.

B concentrated command (old PDF parsing/replay/handler/version/transport and shared geometry contracts):

```text
python -m pytest tests/unit/test_shared_reading_pdf_layout.py tests/unit/test_narrative_pdf_bytes.py tests/unit/test_narrative_evidence.py tests/unit/test_narrative_select_handler.py tests/unit/test_narrative_selector_binding.py tests/unit/test_narrative_selection_architecture.py tests/unit/test_narrative_reading_transport.py tests/unit/document_normalization_layout_snapshots/test_a_snapshot_contract.py tests/unit/document_normalization_layout_snapshots/test_a_unit_binding.py tests/unit/document_normalization_layout_snapshots/test_b_projection_and_consumer.py -q
```

→ **263 passed / 45.09s / exit 0**, `pdf-layout-ab-normal-temp.log`. This B run preceded the final two A controls (normal paths unchanged; both controls and final source were included in A36). Initial sandbox B was 237 PASS / 25 setup ERROR because pytest could not create its default sandbox TEMP directory; original assertions/fixtures were not relaxed. Exact command ran with normal host TEMP and all tests passed.

`ruff check` on the four owned source files/new test → exit 0. `mypy` on all four owned source files → exit 0. Scoped `git diff --check` → exit 0.

C: `python .planning/shared-reading-production/tests-agent/pdf-layout-real-probe.py` → **exit 0**, final `pdf-layout-real-final.json` (25,856 bytes) and `pdf-layout-c-final.log`. Read existing original PDFs once per document handle, old/new bounded single-page parses; no original copy. SHA/mtime/size and every unit/raw/locator/metadata/durable span verified unchanged.

| Actual sample | Page | Source units | Real words / cells | Remaining fine-only gaps |
|---|---:|---:|---:|---:|
| AMEC annual | 41 | 26 | 29 / 0 | 6 units |
| Jinhe convertible prospectus | 223 | 47 | 90 / 42 | 2 units |
| Hengfeng offering prospectus | 61 | 44 | 60 / 29 | 6 units |
| MINISO annual | 12 | 49 (24 table rows) | 268 / 28 | 1 unit |

All remaining diagnostics are `NO_FINE_GEOMETRY` (plus informational work count), never silently declared complete. Image/block mapping repair eliminated the actual AMEC character alignment/source errors; inline numeric prose produced zero guessed cells. Maximum observed work count was 1,637, below 1,000,000. All model calls/downloads/original copies = 0.
