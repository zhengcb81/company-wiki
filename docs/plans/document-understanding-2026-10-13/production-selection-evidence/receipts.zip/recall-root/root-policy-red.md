# 根因①：实际 SEC form 在 ROOT 策略接线处丢失（RED）

2026-10-14。生产文件未改，等待 ROOT 发布前一工程节点后进入实现。

独立待搬迁测试：`test_reading_root_policy_binding.py`。正式位置应为 `tests/unit/document_understanding_selection/test_reading_root_policy_binding.py`，测试语义保持不变。

可运行命令：

```powershell
python -m pytest -q -o 'pythonpath=src tests' .planning/shared-reading-production/recall-root/test_reading_root_policy_binding.py --tb=short
```

结果：**14 FAIL / 1 PASS，4.50 秒**。第一次未提供 tests import root，只得到 fixtures collection error，不属于产品 RED；上面实际可运行命令收集 15 个测试并复现以下真实断言失败。

## 实证

- 既有公开原文 fragment fixture 的 `FORM 10-K`、`FORM 10-Q`、`FORM 20-F` 均由单次现有 signal pass 正确识别为对应 profile/family。Candidate 已带 typed `form_type`；公开 root route 没有该字段。
- metadata form 为 `unknown` 时，即使将实际 form 放入 route，`resolve_reading_profile` 仍返回 `family_policy.id=None` 和 fallback。
- 20-F 的正文配错声明 10-K 时，route profile 正确为 `sec_20f`，resolver 却实际绑定 `sec_10k`。这证明问题并非“unknown 字符串”一个局部特例，而是 resolver 用弱元数据重新决定已由原文路由完成的身份。
- pipeline 的实际原文 unit profiles 受同一机制影响。测试禁止修改输入 metadata，并验证整条绑定，而非只验证新增 wire 字段。
- 无可辨 form 的普通正文仍保持 generic / unresolved policy（PASS）。改显示诊断文案也不应改变实际表单，并断言原有 root detect 只调用一次。

## 共同根因及建议实现

1. `profiles.route_document` 将实际 `winner.form_type` additive 透传到 root route。使用现有 typed 值，不能从 subtype、profile ID、显示中文诊断或公司名反推。
2. resolver 消费该路由实际 form；只有旧 wire 未提供该字段时才使用 metadata 兼容路径。`None/unknown` 不是已知 SEC 表单，不应该在 applies.forms 中作为真实限制。
3. 检查 policy score 的 metadata_equals 也使用这个 scoped actual form，不能过滤用正确实际值、评分又用错元数据。来源 observation 原 metadata 保留作原声明，不能就地改写。
4. pipeline 已把 root route 传到 resolver；优先修共用接口，不新增公司/市场分支、不增加另一轮 detect/parse、不新增审批。
5. 发布前一工程节点后搬正式测试，按 RED→实现→跨市场原 profile/child/inventory 集中测试验收。若旧 wire shape helper 严格集合拒绝 additive form，按真实新 seam 窄幅更新兼容断言，不删老字段要求。

不因此宣称 MSFT 的 1/8 recall 已修复；实际策略接通后需原 golden 重新跑，还可能有候选/排序的其他共同根因。

## 实施及验收交接

ROOT 前一工程节点 `d3c57b31/fc2a4513` 正常发布后，scratch 测试已按相同核心语义搬到正式位置 `tests/unit/document_understanding_selection/test_reading_root_policy_binding.py`。加入实际 unit scope/依赖资格、旧 wire 和显式未知实际 form 的验证后，正式 RED 为 **19 FAIL / 2 PASS，4.01s**；原始 14 项失败仍全部复现。

实现文件：

- `profiles/__init__.py`：root route additive `form_type` 直接来自已有 `winner.form_type`。
- `profiles/registry.py`：原 bounded observation 的内部非改源 view 消费 route 实际 form，同时用于 applies 匹配与 policy score；只有 route 未提供新字段时保留旧 wire 的 metadata 兼容。现有来源 observation 原声明不改。
- `strategy_binding.py`：resolved profile 的真实 family/regime/form 进入 unit profiles 和 used profiles。
- `decision_inventory.py`：root form 采用真实 resolved scope，旧 wire fallback 仍兼容；inventory version 由 1.1.0 升为 1.2.0，旧错误 scope 不会被冒充新同一决定。
- strict wire helper：旧必需字段保留，只验证 additive actual form 的类型。

执行证据：

- 首轮实现后根因①正式 21 测 **21 PASS / 1.87s**。
- profiles + root + owned child/inventory/form + cache precheck 集中 **439 PASS / 11 SKIP / 9.67s**。独立 `%TEMP%/cw-form-70ab388e`，哨兵未变、结束后目录已全部清理；skip 是原真实样本条件，未删或改跳过规则。
- owned `strategy_binding.py` 原 HEAD 存在 nullable index 推断错误及 mypy 1.19 INTERNAL AssertionError，先由 `git show HEAD` 独立临时 baseline 实证复现。仅补列表/tuple/nullable 类型边界和独立 section 变量，未改路径匹配算法；registry 的旧 coverage inference 也补明确 Mapping 注解。
- 上述类型整理后相关 **55 PASS / 2.94s**；owned 四个生产模块 **mypy 无问题**；六个 owned 代码/测试文件 **Ruff PASS**。
- 新增两项真实适用范围测试验证 20-F 未适用指令变更不会干扰 10-K、其适用 forms 改为允许 10-K 则必须失效；最终新测试 **23 PASS / 2.51s**。
- `git diff --check` PASS（仅工作树 CRLF 提示）；没有生产配置/原件/费用/模型调用、没有 commit。ROOT 负责统一 PWF 与并线发布。

此交接仍未宣称真实 recall 已通过。另一路正在修业务意义识别；需要 ROOT 用统一真实 golden 大节点评价最终召回率和正式摘要质量。

### 最后窄幅接线：实际准入算法的版本依赖

ROOT 要求把经营作者的真实常量 `READING_BUSINESS_POLICY_VERSION='reading-business-policy/2'` 纳入 decision inventory。先新增测试得到 **1 FAIL**（trace 缺 `business_policy`）；再在 `_versions()` 中直接导入作者当前常量，使用 `versions.business_policy` 留证。延迟到函数调用再导入，避免给 source_catalog 包初始化新增半初始化 inventory 依赖；没有拷贝版本字符串、没有改业务策略。

新增四项测试：实际原文 pipeline 的 trace 含真实常量；变更常量必须使旧依赖失效；分别从 inventory、business policy、source selector 三个冷进程入口导入后读取版本成功。冷进程使用实际仓库 `src`、禁写 bytecode、无 provider/模型调用，验证真实导入链。

受影响范围（inventory/form/cache）首次执行 **66 PASS / 2 setup ERROR / 9.79s**，两项错误均为 sandbox Temp 无法建立 pytest numbered dir。只复跑这两项和四项新增版本/冷启动测试，独立非 sandbox TEMP 得 **6 PASS / 4.01s**，哨兵未变、目录已清理。没有产品断言失败。新增改动文件为 owned `decision_inventory.py` 与 `test_reading_decision_inventory.py`；Ruff 和 inventory mypy 均 PASS。ROOT 统一大节点仍负责最后集中验收。
