# 阅读价值、主题覆盖与历史回放交接

2026-10-14，formal_reading_transport → ROOT。源码 STOP；不 commit，不改 PWF，不替 ROOT 签收真实质量。

## 共同根因与实现

恢复真实 SEC scope 后，范围本身被当成价值：符号、页码和无信息标题获得候选资格；strict priority 又让低优先级新经营机制被重复高优先级描述挤掉；topic visits 的加总让标签较多的同一事实反而受罚。本批没有针对公司、原句、期间或特定主题加例外。

- `narrative_reading._admitted/_candidates`：普通 prose 的标点和纯数字不作 anchor，实际结构标为 heading 但没有经营事实的标题只可随原闭包保留。实际已合格 operating_table 的数字 cell/row 可作 anchor，header、unit、period 等完整上下文仍由既有图携带。source 生成简单 typed `value_band`，已有经营关系或实际经营表为 `meaningful_fact`，仅有业务 scope 的定性正文为 `description`。真实 fact topics 保留，不给每条 fact 再贴 scope/unknown 标签。
- `BudgetItem.value_band` additive 枚举，默认 description；`narrative_finalize` 只透传这个 source-owned 字段。planner 不打开或推断 text payload，不新增文本 classifier。
- 唯一既有 heap/closure/work/cost 引擎：新 `READING_BUDGET_POLICY=reading_plan/2`，小策略参数决定 rank 为 value→未覆盖实际主题→policy priority→保守重复提示→精确 Fraction 平均 topic visits→score→新增完整闭包成本→原始顺序。空 topic 不获得永久 novelty。无固定 slots、主题配额或容量扩大。
- `REPLAY_READING_BUDGET_POLICY=reading_plan/1` 保留原 rank；索引、闭包、共享原文 unique cost、终停留证仍是同一个实现。只把旧测试的版本出口断言指向显式 replay constant，没有改行为断言。legacy 与 semantic 完全不读 value_band。
- inventory 从实际当前 budget 常量取得版本，缓存依赖不再硬写 /1。

## PDF 暂态接线与缓存依赖

geometry 作者确认 `native_cell_char_start/end` 与 `partial_cell` 指向真实父 cell，不能把一个 cell 的片段当成不同细列。adapter 已窄幅保留这三项，22 项 priority/bridge 测试包含一次既有共享 engine 输入的决定性断言；原 unit metadata、source ID、坐标和正文不改。

PDF frontend `pdf-reading-layout/1` 仅在 observation 的实际 MIME 为 application/pdf 时进入 trace。使用小 carrier causal component 保存实际载体与 scope 证据；current inventory 从 frozen component 恢复，缺少或矛盾时 partial，不能从文件名/市场猜。改变 PDF frontend 常量会使 PDF 失效，HTML trace 不受影响。没有增加许可或人工审查。

## TDD 和集中结果

- 新 `test_reading_value_coverage.py` 初始 29 FAIL。fixture 的 metadata 参数及互斥 paragraph/table coordinates 已纠正，这些构造错误没有算作产品根因。
- value/admission 实现后 30 PASS；PDF scoped dependency 与 partial-cell transport 再加四个决定性 RED，修后 value 33 + priority/bridge 22 共 **55 PASS / 4.43s**。
- 集中 721 collected：**702 PASS / 11 SKIP / 8 FAIL / 71.91s**。所有 selection、profiles、root、structure、正式 transport 全绿。8 个失败全部是 ROOT-owned `test_shared_reading_cache_precheck._trace` 模拟 fixture 没有 MIME，新的 carrier 规则使 trace partial，其原 complete hash/import 断言无法进入目标分支。已交 ROOT 添加真实模拟载体并定点重跑，没有删除、弱化或跳过断言；不能将这个节点直接记全绿。
- 独立 TEMP `cw-v2-1d6c3def` 的哨兵 SHA 不变，结束后目录完全清理。
- 原 policy 104 项均通过：reading plan 21、coverage 16（集中节点中），n6 legacy 9 / 2.05s，w04 novelty/dispatch/semantic 58 / 20.35s。
- `reading-v2-parity.py` 从已发布 HEAD `804dfbb7fb8de38ae3be647827bf342b98ab6353` 只读载入原引擎，1000 个 /1 seeded graph、200 legacy 和 200 semantic graph 的 selected IDs 与所有 diagnostic 字段完全一致。变化 reading value 也不影响历史政策。无 provider POST。
- 最终五个本批生产模块 mypy PASS；八个修改代码/测试文件 Ruff PASS；diff check PASS。仅补旧 stage tuple 的显式 string 长度及 gutter 兼容 duck-type cast，类型修整不改运行语义。

## 真实联合验收状态

ROOT 同源、同 gold、同 48,000 chars / 96 spans 回放：US value 结果 **8/8、90 spans / 47,999 chars，parse/select 各一次、0 POST**，见 `us-10k-value-replay.json.gz`。此前不同阶段失败矩阵都保留，不能删除失败证据或把局部 8/8 当成整个项目完成。

ROOT 仍须统一独审、接真实 geometry coverage 和 pipeline 版本，验收其他市场及正式模型摘要/恢复。此 agent 不重新 parse 真原件、没有模型付费、不修改默认 0.8、不提高容量、不改外包目录。

## 独审遗漏修复与最后定点节点

独审又提供两个内容边界和一个真实大输入反例，已按 ROOT 授权继续修复，最后源码再次 STOP：

1. 中文数字 `一 / 二〇二六 / 壹佰`、完整 Roman 序号和孤立 `(a)` 都不构成描述 anchor。使用普通编号语法，保留带数字、Roman 前缀及中文数字偏旁的真实完整词句。没有公司名单或全文特殊语句。
2. PDF 的 MIME 只证明载体，不能证明前端实际执行。ROOT 实际接出 `observation.metadata.native_layout_frontend_version`；adapter 只保留这个明确 source-owned 字段。inventory 的 `pdf-frontend-used` scoped component 保存实际版本证明，current 从 frozen 证明恢复；无证明、冲突或缺组件时 partial。真实 PDF 同时依赖公共 `layout_snapshots.FEATURE_VERSION`；HTML 不受两项 PDF 版本影响。内部 import 故障不掩盖，纯组件缺失不会假 complete。
3. 第 9 独审反例：19,997 个 description 带同一 immutable 50-token signature、末三项真实 meaningful_fact，在旧 /2 初始化验证/intern 中约消耗四百万 work，导致空 selected。正式新反例确实 RED。/2 仅在单次 planner call 内按同一 frozen 对象共享 schema validation 和 intern 结果，每个 reference lookup 仍计费；不同 signature 和实际 overlap 比较照常完整计费。items 持有所有对象，没有 ID 复用/跨调用缓存，也没有合并不同原文 IDs。/1 不使用这个优化，保留原历史工作计费/终停。

最后定点：value 49 + coverage 16 + scale 9，**74 PASS / 14.82s**；value/PDF proof + inventory 集中 **65 PASS / 7.82s**（签名修复前，后者不改 inventory）。新增 PDF/编号负例的原 RED 为 **13 FAIL / 12 PASS**；第一次收尾出现两个 metadata 接线 FAIL 与两个 sandbox TEMP setup ERROR，修 source-owned metadata 白名单后产品 FAIL 已全部消除，两个 cache Temp 项由 ROOT 非 sandbox 集中验收。ROOT 同时确认加真实 carrier fixture 后 cache/coverage 31 PASS。

最终五模块 mypy PASS、八文件 Ruff PASS、diff check PASS。1400 graph 历史 parity 再次通过（当时已发布 HEAD d6e91356876292c7dd3c9a18de0d8855d507df61；第一次原实现对照 804dfbb7 的记录继续保留）。没有重复 721 全 suite。

## 港股只读逐层诊断

按 ROOT 新任务，仅增加一次真实 HK parse+select 的诊断观察，不改任何生产代码、gold/cap。详情 `hk-diagnostic/findings.md` / `native-p12.json.gz`。6502 native units、p12 25 units 都在，但错误 prospectus 路由使该页实际业务 scope unknown；store/network 关系未被通用经营意义识别，视觉表也没有 native cells/完整 operating_table 包，该页 BudgetItem 为零。ROOT 随后负责 source-provenance router 和 0.9 table-scan 信号修复；本 agent 不动这些 owner 文件，不能用预算特判掩盖上游问题。
