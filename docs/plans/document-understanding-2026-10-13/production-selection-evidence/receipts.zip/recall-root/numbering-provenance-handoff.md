# 标准编号、标题层级来源与暂态几何桥接交接

2026-10-14，formal_reading_transport → ROOT。源码 STOP，不 commit；ROOT 负责 PWF、联合回放与发布。

## 根因和边界

真实 US 原文归一化得到 5,215 units。文档正文的 PART / Item 标题是 html_paragraph，没有原生 hN；DOM locator 不能证明标题级别来自原生 HTML。唯一完整 Business 标题在 TOC 表格里，不能升为正文。实际正文重复 PART I / Item 1 后的产品名称也不能用来猜业务身份。

旧预算观测有 136 候选，87 入选、47,880 字符，全部 priority 2 / unknown role。因此本批先修实际声明策略与真实编号的解释、结构层级来源及不同原文父边界，不靠单句抢占预算。narrative_budget.py、narrative_reading.py、经营意义算法和外包目录均未改。

## 已完成实现

- strategy_binding：仅在实际 form 已确定、配置声明标准 Item 编号时解释完整裸编号；具体相异标题不能被编号覆盖。歧义编号保留 unknown 并诊断；Part 祖先、附件范围、Item 1A / 10 / 11 / 01 严格区分。STRATEGY_BINDING_VERSION 为 reading-strategy-binding/2。
- structure.sections / contract：heading_level_source 区分 native / numbering / layout。实际 hN 和旧缺来源的 DOM wire 保持旧含义；推断编号可恢复 Item→Notes 的相对层级。换实际 source_id 清除旧父标题，不能跨原文继承。
- observation_adapter：只从暂态 reading_layout 命名空间读取小白名单；原 unit 的 source、text、locator、legacy metadata 和 bbox 不改。OBSERVATION_ADAPTER_VERSION 为 du-observation-adapter/2。
- layout_bridge：fine words / cells / font_runs / spans 经既有 upstream_hints 进入唯一共享 engine；额外 layout 只带 frame、rotation、cropbox 等小字段。保留有效数组完整性，不做静默 prefix 截断。旧 coarse 字段不能覆盖新 typed granularity。消费 fine geometry 的共享引擎另由 geometry owner 完成。
- decision_inventory：记录实际策略解释器和观测 adapter 版本，已有 business_policy 实际版本依赖保留；版本变化使旧决定失效，不增加人工许可。

## TDD 与验收

新文件 tests/unit/document_understanding_selection/test_reading_priority_coverage.py 共 21 项：裸编号、重复标题、相异标题、编号歧义、精确 Part 层级、未知实际 form、真实 hN 对照、旧 wire 兼容、source 父边界、TOC 负例和 public projector→既有共享 engine 桥接。

真实产品 RED 为 9 FAIL / 7 PASS；编号修复后又以两项反例锁定层级来源错误。PDF 桥接反例实际暴露旧 bbox 和 coarse geometry 覆盖新字段。fixture 缺少必需 source_ref 及 MappingProxy 写法问题没有算作产品 RED。

最后集中节点：**531 PASS / 11 SKIP / 23.94 秒，542 collected**。范围为完整 document_understanding_profiles、document_understanding_root、document_understanding_structure，及 owned priority/form/child/inventory 和预算 plan/coverage/scale 测试。原 skip 条件未改。独立 TEMP cw-out-3c14c310 哨兵不变，测试后目录完全清理。

Ruff 七个本批代码/测试文件 PASS；mypy 六个本批生产模块 PASS；git diff --check PASS。无生产配置、原文、模型、provider 或网络写操作。

## 联合质量仍未通过

ROOT 保存的旧真实联合结果为 7/8，编号修复后的 us-10k-heading-replay.json.gz 为 **2/8**；同一 source、gold 和 48,000 chars / 96 spans 上限。新入选 96 spans 仅约 13,013 chars，说明候选价值、标题/上下文准入或严格优先级与主题覆盖仍存在共同缺陷。

本批局部工程测试通过不构成真实覆盖率签收。保留两份失败证据、零 POST、默认 selector 仍为 0.8。ROOT 统一审查候选价值与覆盖逻辑后，再用全部原 gold 评价；不得针对唯一 billing 句加例外或提高容量。
