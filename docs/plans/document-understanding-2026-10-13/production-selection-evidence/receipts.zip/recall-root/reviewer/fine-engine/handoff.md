# Native fine geometry engine handoff

Status: **source STOP**. No commit, POST, shared PWF, owner original, config, parser, adapter, bridge, external DU3, or benchmark change by this lane.

## Owned source and interface

- `src/company_wiki/document_understanding/layout_hints/__init__.py`: consumes fine views once inside the existing derive engine, projects table cells and column lanes back to original IDs, rejects a single text-column claim for original units spanning multiple lanes. `LAYOUT_HINTS_VERSION` is **1.2.0**, automatically included by existing decision inventory; wire schema remains `du2-layout-hints/1`.
- `layout_hints/contract.py`: additive frame input and tightening-only `max_fine_elements=200000`; same existing `WorkBudget` and no task/source store. Caller fields cannot forge the engine's `_fine_origin`/`_fine_font_coverage` markers.
- `layout_hints/fine_geometry.py` (new): strictly checks actual unit character intervals, supplied text, alignment, finite native box, source frame, native table/row/column provenance. Every fine record and character operation charges existing work. Valid words drive existing lane detection; valid cells drive existing table analysis; complete font ranges drive existing heading analysis. Spans are validated/charged, without allocating new source units or leaking their text.
- `layout_hints/geometry.py`: caches internal row/cell identity and groups actual native rows by table/row even when wrapped boxes or adjacent tables interleave in spatial order. This prevents the observed 13-row false split and repeated identity scans.
- `layout_hints/tables.py`: actual native table boundaries enter the existing RegionDraft/context/continuation engine. No second ranker and no fabricated merged-cell spans.
- `layout_hints/headings.py`: actual complete font ranges use character-weighted body-font evidence; legacy inputs retain their original block-median behavior.

Actual rotated `dict` geometry with `frame_converted=False` is valid and accepted when each rotated element explicitly declares the matching source frame. Missing/unknown frames remain partial. A partial native cell keeps its actual parent box and column; NFC/trim can change native versus normalized character extent, so differences produce partial diagnostics without moving original coordinates. Coarse aggregate boxes and strings do not become fabricated fine cells.

## Tests and evidence

- New `tests/unit/document_understanding_layout_hints/test_production_fine_geometry.py`: **26** cases. Real per-word boxes, multi-cell/multi-row original units, repeated text with different original identities, native table boundaries, wrapped cells, malformed ranges/text/frame, caps/work limit, full/partial/mixed fonts, conflicting native column claims across original units, parent-cell fragments and forbidden forged internal markers.
- Existing `test_a_contract_and_shapes.py`: only the version oracle imports `LAYOUT_HINTS_VERSION`; source/geometry/schema assertions remain unchanged.
- Initial focused RED: **14 fail / 1 pass**, 2.84s, exit 1, tool output only. Later meaningful REDs exposed wrapped/interleaved tables (13 rows rather than 6), cross-unit conflicting cell provenance, forged private view markers, and differing native/NFC character lengths. No fabricated persistent RED log.
- Concentrated offline integration node: **143 pass**, 6 real-data opt-in cases deselected, pytest 16.28s, runner 18.957s, exit 0. Includes all old offline layout tests, 26 new fine cases, actual tiny PDF extraction tests, adapter/priority tests, and inventory tests. `stdout.log`, `stderr.log`, `junit.xml`, and `result.json` beside this handoff are the actual retained evidence.
- Ruff for whole layout package and the two owned test files: exit 0. New `fine_geometry.py` mypy with imported modules silent: exit 0.
- Full layout package mypy is **not green**: HEAD `804dfbb7fb8de38ae3be647827bf342b98ab6353` has 27 diagnostics; current package has 26 and no added diagnostics. Existing optional-box/inference problems are outside this functional change. Actual baseline/current logs and `typing-baseline.json` retained here. No suppression or weaker oracle was added.

## Isolation and limits

The concentrated runner creates one independent Temp tree, protects its sentinel, saves only diagnostic logs/XML, and deletes the tree in `finally`. Both production config hashes/mtime remained exact, and scratch removal is recorded. Real owner-original opt-in was removed from the child environment; tiny PDFs were created only as test fixtures. These results do not claim complete real-document recall, a paid provider run, or a complete RF research workflow. ROOT owns the final integrated original replay and independent review.

`validate_fine_geometry.py` and `validate_fine_type_baseline.py` in the parent reviewer directory are reproducible diagnostic scripts, not production entry points. No further source mutation by this lane after handoff.
