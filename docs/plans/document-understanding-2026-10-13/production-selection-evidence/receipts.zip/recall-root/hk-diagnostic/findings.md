# 港股年报真实 p12 逐层只读诊断

2026-10-14。仅一次 native parse 与 production 0.9 select，understand / candidates / planner 各一次，零模型/provider POST。原件 SHA-256、大小、mtime 与 gold 字节均未变；没有修改源码、gold 或 48K/96 上限。

证据：`native-p12.json.gz`；脚本：上一层 `hk-diagnostic.py`。

## 实际结果

6,502 native units；物理 p12 共 25 个 units 全部仍在原生结构中。parse 6.93 秒，select 13.29 秒。157 候选，96 片段 / 13,786 字符；p12 入选零片段。预算剩很多字符，目标页却没有进入预算器，不能通过给该页抢 slot 修复。

## 真正的断线位置

1. **路由**：原件明确声明 annual_report，实际 route 却为 prospectus / hkex / low。COVER_HEADING 已找到港股年报真实信号；SECTION_VOCABULARY 的募投/全球发售历史内容仍让 prospectus 竞争胜出，且留下 DECLARED_KIND_CONFLICT。不能把正文提到历史上市当作当前原件身份。
2. **策略 scope**：p12 全部为 prospectus、unknown section_role、priority 2。真实双语 `Business Review and Outlook / 業務回顧及展望` 与 `Store Network / 門店網絡` 原文存在，实际经营章节却没有绑定正确阅读策略。
3. **布局/载体**：p12 每个 unit 已有实际 words/font_runs/spans；数字和双语文本仍可定位。该页没有 native table row/cell，全部为 pdf_text_block，cells=0。视觉门店表是分散原生文本块：日期、年度列、模式/区域值矩阵、Total 分开。不得凭空制造 cell bbox；后续应由唯一共享结构层消费真实 word/span 关系恢复完整经营表依赖。
4. **经营意义准入**：英文实际 store network 总量、门店扩张与海外进入的完整 prose，以及繁体中文同义描述，均得到 fact_eligible=False。由于实际 scope unknown，这些语段全部被 source admission 拒绝。用户要求的是通用经营渠道/网点/服务消费者关系，当前词汇与关系模型偏技术制造，不能添加该公司名或 gold 原句白名单。
5. **完整依赖**：初始视觉矩阵在 paragraph_event/background 包中，header/year blocks 和矩阵部分是成员，Total 原始块却在另一个 background 包中。所有实际 anchor 拒绝，未形成可入选的 operating_table；即使只把某一个数字放行，仍不足以保证真实年度、存量/增量、区域/经营模式关系同闭合群组保存。

## 已排除的解释

- 原文不是丢失或下载失败：25 个 p12 units、真实原文及 locator 均保留。
- 不是字符预算不足：仅使用 13,786 / 48,000 字符。
- 不是目标 p12 候选输掉预算：该页零 BudgetItem，无预算拒绝诊断。
- 不是需要增加一个 provider、翻译或 LLM 公司特殊规则：故障在实际单次路由、scope、结构依赖与通用经营关系准入。

## 下一大节点建议

ROOT 统一安排强原件标题与弱正文术语的路由证据等级、跨市场业务章节解释、通用渠道/门店/网点关系，以及无 native cells 时的真实细 geometry 结构组。每项使用不同公司/传统中文/英文/非年报历史 IPO 内容等通用反例，保持所有 raw/text/IDs/physical pages，禁止跨 group 拼 AND quote，最后同一冻结 7-fact gold 回放。当前 HK 仍 0/7，不能签收质量。
