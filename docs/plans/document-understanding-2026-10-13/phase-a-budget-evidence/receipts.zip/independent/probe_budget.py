"""Independent public-API probes; no network, model, or source writes."""
from __future__ import annotations

from dataclasses import replace
from itertools import permutations
import json
import hashlib
from pathlib import Path
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / "src"))
import company_wiki.source_catalog.narrative_budget as budget
from company_wiki.source_catalog.narrative_semantic_coverage import CoverageSignature, coverage_signature

OUT = Path(__file__).parent
RESULTS = []


def item(uid, *, group=None, deps=(), context=False, priority=2, topics=(), chars=1,
         order=0, signature=None, score=1):
    return budget.BudgetItem(uid, group, ("page", 1), f"p1:{uid}", (order,),
        ("specific_business_event",), score, False, uid,
        evidence_chars=chars, coverage_signature=signature,
        reading_priority=priority, reading_topics=topics,
        required_item_ids=deps, is_context_only=context)


def select(items, **kwargs):
    return tuple(x.item_id for x in budget.select_budget_items(
        tuple(items), policy=budget.READING_BUDGET_POLICY, **kwargs))


def diagnose(items, **kwargs):
    return [(x.bundle_key, x.item_ids, x.reason) for x in budget.budget_diagnostics(
        tuple(items), policy=budget.READING_BUDGET_POLICY, **kwargs)]


def record(name, observed, expected=None):
    result = {"name": name, "observed": observed}
    if expected is not None:
        result.update(expected=expected, passed=observed == expected)
    RESULTS.append(result)


# An independent project must still fit even if both depend on one header.
shared = (item("header", context=True, chars=5, order=0),
          item("project_a", deps=("header",), chars=4, order=1),
          item("project_b", deps=("header",), chars=4, order=2))
record("shared_header_marginal_span_cost", select(shared, limit=3),
       ("header", "project_a", "project_b"))
record("shared_header_marginal_character_cost", select(shared, limit=3, max_chars=13),
       ("header", "project_a", "project_b"))
record("independent_projects_not_merged", select(shared, limit=2),
       ("header", "project_a"))

# Required context is itself atomic, and dependencies traverse to a fixed point.
transitive = (item("a", deps=("b",), order=0),
              item("b", group="context", context=True, deps=("d",), order=1),
              item("c", group="context", context=True, order=2),
              item("d", context=True, order=3))
record("transitive_atomic_closure", select(transitive, limit=4), ("a", "b", "c", "d"))
record("transitive_atomic_does_not_split", select(transitive, limit=3), ())
cycle = (item("a", deps=("b",), order=0), item("b", context=True, deps=("a",), order=1))
record("dependency_cycle_closed", select(cycle, limit=2), ("a", "b"))
missing = (item("a", deps=("absent",), order=0), item("b", order=1))
record("missing_dependency_excludes_only_dependent_anchor", select(missing, limit=2), ("b",))

# Determinism uses a public output comparison, not a copy of planner ranking.
permuted = (item("header", context=True, order=0),
            item("a", deps=("header",), topics=("plans",), order=1),
            item("b", deps=("header",), topics=("mechanisms",), order=2),
            item("c", priority=3, order=3))
selections = {select(p, limit=3) for p in permutations(permuted)}
diagnostics = {tuple(diagnose(p, limit=3)) for p in permutations(permuted)}
record("permutation_normal_budget", {"selections": len(selections), "diagnostics": len(diagnostics)},
       {"selections": 1, "diagnostics": 1})
tiny_diagnostics = {tuple(diagnose(p, limit=3, max_work_units=0)) for p in permutations(permuted)}
record("permutation_exhausted_diagnostic", {"distinct": len(tiny_diagnostics), "outputs": sorted(tiny_diagnostics)})
record("permutation_exhausted_diagnostic_stable", len(tiny_diagnostics), 1)

# Count true calls during one public operation. Distinct factual signatures force
# false comparisons, so any() cannot hide the inner-loop cost by short circuit.
large = tuple(item(f"g{g:02}m{m:02}", group=f"g{g:02}", order=g*10+m,
              signature=coverage_signature(f"The product has customer orders {g+1} for this project."))
              for g in range(20) for m in range(10))
call_count = 0
original_repeats = budget.softly_repeats


def counted_repeats(current, previous):
    global call_count
    call_count += 1
    return original_repeats(current, previous)


budget.softly_repeats = counted_repeats
try:
    chosen = select(large, limit=200, max_work_units=22_000)
finally:
    budget.softly_repeats = original_repeats
record("actual_signature_work_vs_declared_cap", {"selected_count": len(chosen),
    "actual_softly_repeats_calls": call_count, "max_work_units": 22_000,
    "actual_comparisons_exceed_cap": call_count > 22_000})
record("actual_signature_comparison_cap_enforced", call_count <= 22_000, True)

# New reading metadata cannot alter the old replay policies.
old_items = tuple(item(f"old{i}", order=i, score=10-i) for i in range(4))
mutated = tuple(replace(x, reading_priority=1 if i % 2 else 99,
                       reading_topics=("arbitrary",), required_item_ids=("absent",),
                       is_context_only=True) for i, x in enumerate(old_items))
for policy in (budget.LEGACY_BUDGET_POLICY, budget.SEMANTIC_BUDGET_POLICY):
    a = tuple(x.item_id for x in budget.select_budget_items(old_items, limit=2, policy=policy))
    b = tuple(x.item_id for x in budget.select_budget_items(mutated, limit=2, policy=policy))
    record(f"old_policy_ignores_new_metadata:{policy}", a == b, True)

for field, bad in (("evidence_chars", -1), ("evidence_chars", True),
                   ("reading_priority", 0), ("reading_priority", True),
                   ("is_context_only", 1), ("reading_topics", ["topic"]),
                   ("reading_topics", ("",)), ("required_item_ids", (None,))):
    try:
        select((replace(item("boundary"), **{field: bad}),), limit=1)
        observed = "accepted"
    except Exception as exc:
        observed = type(exc).__name__
    record(f"field_validation:{field}:{bad!r}", observed, "ValueError")

valid_sig = coverage_signature("The product has customer orders 20 for this project.")
bad_signatures = {
    "wrong_object": object(),
    "token_count_513": replace(valid_sig, tokens=("token",) * 513),
    "token_list": replace(valid_sig, tokens=["token"]),
    "token_generator": replace(valid_sig, tokens=iter(("token",))),
    "token_not_string": replace(valid_sig, tokens=(1,)),
    "empty_token": replace(valid_sig, tokens=("",)),
    "protected_count_513": replace(valid_sig, protected_sentences=("fact",) * 513),
    "protected_not_string": replace(valid_sig, protected_sentences=(object(),)),
    "stage_count_513": replace(valid_sig, stage_signals=(("order", "placed", True, "realized"),) * 513),
    "stage_wrong_shape": replace(valid_sig, stage_signals=(("order",),)),
    "stage_bool_is_int": replace(valid_sig, stage_signals=(("order", "placed", 1, "realized"),)),
    "complete_not_bool": replace(valid_sig, complete=1),
}
for name, bad in bad_signatures.items():
    try:
        select((item("signature", signature=bad),), limit=1)
        observed = "accepted"
    except Exception as exc:
        observed = type(exc).__name__
    record(f"signature_validation:{name}", observed, "ValueError")

# Inclusive numeric character budgets and positive priorities beyond 1..3.
char_items = (item("value", chars=5, priority=4),)
record("character_cap_exact", select(char_items, limit=1, max_chars=5), ("value",))
record("character_cap_one_under", select(char_items, limit=1, max_chars=4), ())
record("zero_character_cap", select((item("zero", chars=0),), limit=1, max_chars=0), ("zero",))

# Count actual closure scans without reproducing ranking/selection logic. Every
# group requires every other value, so after the first choice added is always 0.
scan_items = tuple(item(f"v{i:02}", deps=tuple(f"v{j:02}" for j in range(20) if j != i),
                        order=i) for i in range(20))
scan_count = 0
scan_events = 0


def closure_scan_trace(frame, event, arg):
    global scan_count, scan_events
    if (event == "line" and frame.f_code.co_name == "_reading_plan"
        and frame.f_code.co_filename == budget.__file__):
        import linecache
        if "added = set(closures[key]) - selected_ids" in linecache.getline(frame.f_code.co_filename, frame.f_lineno):
            scan_events += 1
            scan_count += len(frame.f_locals["closures"][frame.f_locals["key"]])
    return closure_scan_trace


sys.settrace(closure_scan_trace)
try:
    scan_selected = select(scan_items, limit=20, max_work_units=40_000)
finally:
    sys.settrace(None)
record("closure_difference_actual_scan", {"selected_count": len(scan_selected),
    "offer_scan_events": scan_events, "actual_closure_member_scans": scan_count,
    "note": "every scan after first selected group has no newly added IDs"})

# A dependency that is already emitted must not receive an exclusion receipt.
dependency_anchor = (item("a", deps=("b",), priority=1, order=0), item("b", order=1))
contradictory_drops = []
for cap in range(200):
    emitted = set(select(dependency_anchor, limit=2, max_work_units=cap))
    for key, uids, reason in diagnose(dependency_anchor, limit=2, max_work_units=cap):
        if uids and set(uids) <= emitted:
            contradictory_drops.append({"cap": cap, "emitted": sorted(emitted),
                "dropped_bundle": key, "dropped_item_ids": uids, "reason": reason})
record("included_dependencies_have_no_exclusion_diagnostic", contradictory_drops, [])

# Already emitted non-context dependencies contribute actual semantic coverage.
# Compare the available third slot against two otherwise equal value candidates.
dependency_topics = (item("a", deps=("b",), priority=1, topics=("a-topic",), order=0),
    item("b", topics=("shared-topic",), order=1),
    item("duplicate", topics=("shared-topic",), order=2),
    item("novel", topics=("new-topic",), order=3))
record("emitted_value_dependency_topics_count_as_covered", select(dependency_topics, limit=3),
       ("a", "b", "novel"))

duplicate_sig = coverage_signature("The product has customer orders 20 and equipment shipment plans for customer validation at the company project.")
novel_sig = coverage_signature("The product has customer orders 21 and equipment shipment plans for customer validation at the company project.")
dependency_signatures = (item("a", deps=("b",), priority=1, order=0),
    item("b", signature=duplicate_sig, order=1),
    item("duplicate", signature=duplicate_sig, order=2),
    item("novel", signature=novel_sig, order=3))
record("emitted_value_dependency_signatures_count_as_covered", select(dependency_signatures, limit=3),
       ("a", "b", "novel"))

receipt = OUT / "probe_receipt.json"
document = {"source_path": budget.__file__,
    "source_sha256": hashlib.sha256(Path(budget.__file__).read_bytes()).hexdigest(),
    "checks_with_expected": sum("expected" in result for result in RESULTS),
    "failed_checks": sum(result.get("passed") is False for result in RESULTS),
    "results": RESULTS}
receipt.write_text(json.dumps(document, ensure_ascii=False, indent=2), encoding="utf-8")
print(json.dumps(document, ensure_ascii=False, indent=2))
