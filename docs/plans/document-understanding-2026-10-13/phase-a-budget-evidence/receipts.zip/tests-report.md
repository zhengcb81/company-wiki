# Phase A reading-budget TDD receipt

Owner: phase_a_tdd. Scope: the new `tests/unit/document_understanding_selection/` package and this receipt plus `tests-red.*` outputs. No source edits, production config edits, Git operations, network calls, or model calls.

Read `AGENTS.md` and `docs/plans/document-understanding-2026-10-13/completion_implementation.md`; CodeGraph located the public selector before the concrete source was read. Existing signature: `select_budget_items(items, *, limit, policy=LEGACY_BUDGET_POLICY)`; BudgetItem originally had no reading metadata. ROOT clarified that historical defaults stay unchanged until Phase C; this package always requests `reading_plan/1` explicitly. The additive contract also includes `max_chars=None` and bounded `max_work_units` on selection/diagnostics.

## Initial RED

- Command: `python -B -m pytest tests/unit/document_understanding_selection -q -p no:cacheprovider --basetemp <owned TemporaryDirectory>/pytest --junitxml .planning/shared-reading-phase-a/tests-red.junit.xml`
- Actual pytest exit code: **1**. Pytest: **19 failed, 2 passed, 21 collected**, 1.62 seconds; subprocess elapsed: 8.795 seconds.
- All 19 failures are explicit test-body assertions that `reading_priority`, `reading_topics`, `required_item_ids`, and `is_context_only` are absent. No collection errors, skips, or xfails.
- Both historical policy replay cases pass: legacy and semantic return `extension`, then `risk` for their frozen reserved-reason fixture.
- Preserved raw stdout: `tests-red.stdout.txt`; JUnit: `tests-red.junit.xml`; config/sentinel snapshots and actual command: `tests-red.receipt.json`.

## Counterexamples frozen

- Per-item ReadingPlan priority changes the winner; changing only lower-ranked unrelated metadata leaves the winner unchanged.
- Old integration-center/extension reserved reasons and 4–9-month wording cannot override a higher reading priority. Independent 2–7- and 12–18-month project facts compete without special treatment.
- Two projects share one header/footnote closure: four unique original spans and their exact character sum. A three-span cap still admits one complete project rather than merging all shared packages into one oversized group.
- Transitive dependencies and existing group members remain complete or deferred; both span and character limits apply.
- The all-candidates-fit path still checks missing dependencies and the complete original character cost.
- Context-only material cannot independently consume budget as a value anchor; a question remains source text when required by its management answer.
- Identical text at different locators keeps separate IDs and costs twice as many original characters.
- One hundred repeated-topic paragraphs leave places for independent operating-table and prose facts at the same reading priority.
- Selection remains stable under input permutations, does not open files, and reports work-budget exhaustion without a partial dependency package.

All fixtures construct real `BudgetItem` objects and call the existing public selector. No test reimplements ranking, closure, or an oracle selector.

## Isolation and harness observations

Production `config/source_catalog.yaml` remained byte-, mtime-, and size-identical: SHA-256 `3d159a4edc8e0e4d09b83afa95601c5ec885a18f7bd5d163579f3ff446e3f968`, mtime_ns `1790542565101886700`, 866 bytes. The module guard separately checked both an immutable original fixture and a preexisting sentinel. Network blocking uses the existing `tests/conftest.py`; model calls: **0**.

Test fixtures and the actual pytest run used `TemporaryDirectory` inside the owned new test package and restored all its scratch in `finally`. The harness-created empty `cw-pytest-basetemp` parent was checked within that scope and removed. An earlier runner attempt failed before invoking pytest because the Windows sandbox OS temporary directory denied sentinel creation and cleanup; it produced no test or source mutation. The successful run's receipt was fully saved before the console tail hit a GBK display error; the saved UTF-8 stdout and JUnit are authoritative.

The current RED demonstrates the missing additive interface. ROOT must run these unchanged assertions after implementing the planner to exercise and verify the behavior itself. Production ReadingPlan integration, candidate admission, HTTP/model serialization, generation/cache, and real-document summary quality remain outside this package's test claim.
