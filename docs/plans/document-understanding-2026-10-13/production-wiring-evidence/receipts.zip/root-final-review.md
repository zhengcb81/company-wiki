# ROOT 正式阅读接线：A/B 节点独立只读审查

日期：2026-10-14。审查者：`formal_reading_transport` 子 agent。

## 结论及适用范围

本次对 ROOT 负责的正式选择身份、缓存查找、批次恢复和来源桥接代码进行只读审查，**未发现新增的 A/B 必须阻断问题**。这只是代码路径结论，不能替代 ROOT 正在执行的集中测试，也不是共享阅读策略的真实质量验收。真实 MSFT golden 已暴露的新策略漏读尚未关闭；A/C 全部验收未完成；默认 selector 仍为 `0.8.0`，`0.9.0` 仅显式启用。

本 agent 自己修改的 planner、formal transport、decision inventory、pipeline、child route 不在独立结论范围内。下文读取这些组件的调用边界，只用于理解 ROOT 接线，未对自身实现再次签收。

本次未编辑生产代码、测试、PWF、配置或原件；未调用模型、供应商或网络；未重跑大 suite。唯一输出为本报告。

## 固定审查对象

| 文件 | 本轮读取字节 SHA-256 |
|---|---|
| `automation/narrative_selection_generation.py` | `53b6e4d1ca3ebd83f0ae738e0d590dcce264c55089935c68b95da6a1961ef919` |
| `automation/narrative_generation.py` | `b85699536f8ddfaff3c9a116b953c103afc89959fffa8631a71c3b59a30a6736` |
| `automation/narrative_batch.py` | `5a40322e99d38ff9257c757a693f2d53051f6814bc2179ddb464da3d2916c6a0` |
| `source_catalog/narrative_reading.py` | `1a75941b0aec6056cc785851c4ac7fd5e1624ca68efbd8888f4e4c87c7294a44` |

相邻边界只读：`narrative_run_store.py`、`narrative_projection.py`、`narrative_worker_factory.py`、`narrative_transport.py`、select/summarize/verify handlers。测试证据只读：`test_shared_reading_cache_precheck.py`、`test_narrative_reading_generation_store.py`；本报告不声称本次执行它们已绿。

## 检查结果

1. **实际摘要材料的身份。** `reading_material_sha256` 绑定 subject、source metadata、selection、全部 EvidenceSpan、完整 reading context、电话会 lineage/字节绑定，而非只绑定策略名称。Store 在选取结果提交的同一事务内冻结 select hash、evidence hash、material hash 和策略版本。完整 dependency trace 才能参加当前策略复用；合法 partial trace 仍可产生摘要，但不能声称是当前策略缓存命中。

2. **恢复不重签。** 新 run 的基础 generation 先冻结；已有 run 解码既有 binding 和 job membership。最终 selection generation 从该 run 的 Store 行取得，而非调用当前 selector 重建。worker 的 0.9 generation resolver 在 select 提交后读取最终身份；旧 selector 使用既有 base digest。v5 的 preparation 只读旧 run/binding，新增列由 AutomationStore 单独迁移，未看到更换原任务、重新签发费用或覆盖旧 usage 的路径。

3. **缓存与费用。** 新 run 的 0.9 缓存候选要求 exact base、完整当前 dependency 比较和公开 reader 实读校验；坏的匹配 artifact 会成为错误，不被降格为可以重新付费的 cache miss。同 run pin 使用冻结 manifest，不拿当前 registry 重签。generation mutex、持久 recovery pointer 与未知费用 reservation 保留恢复路径；网络响应不明仍按未知费用留账，因此这里没有宣称供应商网络请求具备绝对 exactly-once。显式 `refresh` 会创建新工作，这是请求语义。

4. **原文篡改。** 0.9 删去 coordinator 的重复预读，但未删 owner 的验真：新选择由 select owner 打开原件并验 SHA；缓存由 NarrativeTransportReader 检查原件字节、来源事实、定位 replay；正式 verify 在发布前再次 replay。`verified_reuse_keys` 仅是同一次操作的内存证明，`_frozen_binding` 不持久化，下一次恢复为空并重新实读。未发现仅凭旧元数据即可将篡改原件作为有效缓存输出的路径。

5. **全形状复用。** `verify_reading_bundle_generation` 比对策略版本、全部 evidence hash、material hash；material 包含实际 groups、constraints、unread/deferred diagnostics 等 context。`select_result_sha256` 保留 Store 审计意义，bundle 未保存的 selector-only 字段没有伪造重建。改变 title、选择覆盖状态、locators、groups 或 sent policy 均会改变 material，不能只凭相同 span 文本通过正式复用。

6. **问答与多 parent 源桥。** ROOT bridge 对每个实际 source parent 分开理解，统一将 root/child 的 used profile、unit profile、child profile key 和 package ID 加同一 parent namespace；canonical span key 含实际 source ID、coordinates、raw text，避免两份父原文坐标相同而互相覆盖。QA package 的显式空 anchor 不退回 question；required member/context 全部参与闭包和最终 group refs。缺失或预算截断会留 deferred / partial，未看到桥接层主动删掉完整包中的 question 的路径。这里不能证明真实 parser/策略已读到全部重要问答，MSFT 的已知漏读仍须真实端到端修复验证。

7. **旧 0.8 行为。** selector 默认常量仍为 0.8，公开选择入口只有显式 0.9 分支进入新桥。旧缓存继续按原 generation 查找，旧 worker resolver 不要求新增 selection 列；旧 generation 未被加入 reading 字段。未看到新正式身份规则无条件作用到旧 selector 的路径。

## P2 性能残项：未知语言原件仍可能重复读取

`narrative_batch._current_sources` 对 `metadata.language in {None, 'unknown'}` 先 `open_version` 并检测语言，随后 0.9 的实际 select 或 cache public reader 会再打开原件。`_run_owned` 去掉 coordinator 固定预读、`verified_reuse_keys` 去掉同操作 final receipt 重读，已经减少常见重复，但**每操作只实读一次目前仅对已知语言的复用准备成立**；新摘要本来还需要最终 verify。

这是具体性能残项，不是新增付费、原文安全或 A/B 阻断。后续可让所属来源 owner 在本次操作中返回真实语言与已验证 buffer 的临时 proof，或持久化 scan 已检测的语言；不要把 buffer 放进 binding，也不要为省读取消实际 SHA/replay。本轮未改实现、未另开审查门。

## 节点交接

ROOT 集中 suite 结果负责 A/B 的执行验收；若集中测试红，应以其反例为准。本报告没有新增要求逐小步骤人工许可。Phase C 仍须：真实原文质量 golden，正式摘要原语言结果，恢复/缓存真实端到端，至少跨市场及文档类型的覆盖。只有关闭真实漏读并通过对应大节点后，才可考虑变更默认 selector。
