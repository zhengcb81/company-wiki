import copy,json,sys,time
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,'src')
from company_wiki.document_understanding import understand_units
from company_wiki.document_understanding.observation_adapter import build_observation
from company_wiki.source_catalog.narrative_document import DocumentStructure
from company_wiki.source_catalog.narrative_evidence import _make_unit,select_narrative_evidence
from company_wiki.source_contract import EvidenceCoordinates,source_id_for_sha256
sha='a'*64
sid=source_id_for_sha256(sha)
N=20000
start=time.perf_counter()
us=tuple(_make_unit(source_id=sid,parser_version='0.1.0',coordinates=EvidenceCoordinates(page_number=1+i//25,paragraph_index=i%25),raw_text=f'Our product {i} service expanded to a new operating region during the reporting period.',unit_kind='pdf_text_block',source_role='company_filing',language='en',metadata={}) for i in range(N))
p=understand_units(us[:1],source_id=sid,source_sha256=sha,title='Annual report',language='en')
p['observation']=build_observation(us,source_id=sid,source_sha256=sha,title='Annual report',language='en')
template=p['reading_plan']['unit_profiles'][us[0].unit_id]
p['reading_plan']['unit_profiles']={u.unit_id:{**template,'section_role':'business','priority':1 if i>=N-3 else 3} for i,u in enumerate(us)}
ps=[{'package_id':str(i),'kind':'paragraph_event','section_ids':[],'section_role':'business','member_unit_ids':[u.unit_id],'anchor_unit_ids':[u.unit_id],'required_context_unit_ids':[],'completeness':'complete','priority':2,'first_ordinal':i,'truncated':False,'diagnostics':[]} for i,u in enumerate(us)]
p['packages']['packages']=ps
p['packages']['package_count']=N
p['structure']['coverage'].update(complete=True,deferred_unit_ids=[],unassigned_unit_ids=[])
p['diagnostics']=[]
doc=DocumentStructure(sid,sha,'en',us,page_count=800,pages_read=800)
ready=time.perf_counter()
with patch('company_wiki.source_catalog.narrative_reading.understand_units',lambda *_args,**_kw:p):
 r=select_narrative_evidence(doc,title='Annual report',max_selected=96,selector_version='0.9.0')
end=time.perf_counter()
selected={s.raw_text for s in r.evidence_spans}
rc=r.reading_context
result={'schema_version':'reading-large-input-probe/1','synthetic':True,'port':'coherent supplied ReadingPlan; real canonical units/candidate/finalizer/budget','unit_count':N,'selection_limit':96,'selected_count':len(selected),'candidate_count':r.candidate_count,'omitted_candidate_count':r.omitted_candidate_count,'status':r.status,'coverage_complete':r.coverage_complete,'late_critical_units_preserved':all(u.raw_text in selected for u in us[-3:]),'late_critical_ids':[u.unit_id for u in us[-3:]],'build_seconds':round(ready-start,4),'selection_seconds':round(end-ready,4),'reading_context_bytes':len(json.dumps(rc,ensure_ascii=False).encode()),'deferred_rows':len(rc['deferred']),'deferred_count':rc.get('deferred_count'),'unread':rc['unread'],'source_code_sha256':__import__('hashlib').sha256(Path('src/company_wiki/source_catalog/narrative_reading.py').read_bytes()).hexdigest(),'provider_calls':0,'model_calls':0,'production_writes':0}
Path('.planning/shared-reading-production/tests-agent/large-input-probe.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(result,ensure_ascii=False))
