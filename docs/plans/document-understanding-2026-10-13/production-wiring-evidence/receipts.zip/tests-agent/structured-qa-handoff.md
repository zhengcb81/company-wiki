# Official JSON Q&A shared-root repair

## Scope and ownership

- `observation_adapter.py`: project authoritative native roles and source-owned record association; retain actual unit parent attribution in hints.
- `structure/qa.py`: explicit record index, independent of JSON field order; preserve all question fragments as required context and only real answers as anchors. Prepared remarks remain paragraphs. Different known parents cannot borrow an unbound answer.
- ROOT authorized two narrow additions: `structure/contract.py` optional source_id passthrough, and `structure/__init__.py::_ExchangeView` correct question-to-answer relation direction.
- New `test_reading_structured_qa.py`: 16 meaningful behavioral cases; no previous oracle relaxed.
- No production original/config, live download/LLM, external lane, shared PWF or Git mutation.

## TDD and receipts

1. Initial 11 new cases: **10 failed, 1 passed, exit 1**. `structured-qa-red.log`.
2. First focused 106 cases: **105 passed, 1 failed, exit 1**; existing relation oracle detected the old `_ExchangeView` interpretation of question anchors. `structured-qa-green-focused.log`.
3. After ROOT-authorized relation migration and source boundary tests: **111 passed, 12.20s, exit 0**. `structured-qa-final-focused.log`.
4. Ruff: exit 0. Mypy four changed source modules: exit 0. Owned-file `git diff --check`: exit 0.

Focused command:

```text
python -m pytest -q tests/unit/document_understanding_selection/test_reading_structured_qa.py tests/unit/document_understanding_structure tests/unit/document_understanding_root/test_du_root_integration.py tests/unit/document_understanding_root/test_du_root_qa_roles.py tests/unit/document_understanding_root/test_du_root_selectability_wiring.py
```

The real official export replay uses `official_batch_state`, not synthetic mocked parser output: two issuers, two actual parents each, four native field spans each, two complete Q&A groups each. It verifies original `(source_id, locator, text)` equality, both real roles and no cross-parent group. Fixture checks source/config bytes and restores its entire initial directory snapshot. Repeated equal strings with different original parents remain distinct evidence.

## Host-only temporary-directory incident

An early `tmp_path` setup failed before the test with `OSError: could not create numbered dir ... after 10 tries`: **108 assertions passed, 1 setup error, exit 1**. The isolated real replay now uses standard-library `TemporaryDirectory` with its normal system temporary root and fixture finally restoration, not a fixed production/test path.

The sandbox standard Temp also stalled during the standalone replay. The exact owned Python process (PID 74060) was stopped; **exit -1**, `structured-qa-standard-temp.log`. CIM access in sandbox was denied; normal host process stop was allowed. Normal host replay of the identical test under `--timeout=60` succeeded: **1 passed, 2.80s, exit 0**, `structured-qa-standard-temp-escalated.log`. Its fixture cleanup and unchanged-original assertions passed. The inaccessible virtual sandbox Temp path did not resolve on the host; no broad deletion was attempted.

The final normal-environment command:

```text
python -m pytest -q --timeout=60 tests/unit/document_understanding_selection/test_reading_structured_qa.py::test_real_official_export_adapter_keeps_two_actual_parents_and_native_fields
```

## Integration handoff

ROOT's reading bridge must trust actual QA package answer anchors, including neutral `company_filing` marker-based answers; only legacy missing-field input may use role fallback. This is covered by the new neutral source case and ROOT implements it independently.

`production_contract_review` was notified after the 111-case green node and is running the seven formal production E2E cases. This handoff does not claim those reviewer results.
