# Production selection TDD handoff

Owner: reading_production_tdd. Scope: only the assigned test file and this receipt directory. No production code, external lane, shared PWF or Git changes.

- Initial real RED: 15 collected; 10 PASS / 5 FAIL, exit 1, pytest 2.13 seconds. Production adapter was being written concurrently by ROOT and already present; this is behavior RED, not import-placeholder RED. See red.log/red.json.
- Failures: generic English regional service expansion; both Chinese 2–7 and 12–18 month qualification projects; fully readable pure-financial quarterly skip; actual overseas-channel progress in a financial note.
- Shared cause observed: generic original paragraphs route to unknown/background, which old business detector may not admit; semantic structure complete=false was being treated as unread native coverage. Test oracles preserve source-read/semantic-classification distinction.
- Already passing: actual unit-scope priority affects winners; old fixed topic gets no reserved slot; shared header and footnote span closure, independent groups, single original cost; not enough span budget defers whole fact; equal text at distinct locators; management negation/question role; source coordinates/parser/raw unchanged; explicit old 0.8 default replay.
- Added 16th test stresses real 48,000-character production bound with approximately 28k shared original context. It PASSED alone (1 PASS / 15 deselected, exit 0, pytest 1.10 seconds). Duplicate package character charging would fail this case.
- Ruff --no-cache PASS. Temporary source/sentinel directories removed; config SHA/mtime/size guard passed on completed test runs. Zero provider/model calls. No committed artifacts by this agent.
- Await ROOT's implementation update before one full 16-test rerun. RED receipts remain unchanged.
