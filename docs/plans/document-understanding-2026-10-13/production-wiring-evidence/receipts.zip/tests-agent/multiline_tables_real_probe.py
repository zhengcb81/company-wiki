import collections,hashlib,json,sys,time
from dataclasses import replace
from pathlib import Path
sys.path.insert(0,'src')
from company_wiki.source_catalog.narrative_evidence import parse_pdf,select_narrative_evidence
from company_wiki.source_catalog.narrative_business_policy import detect_reading_business_fact
from company_wiki.document_understanding import understand_units
from company_wiki.source_contract import source_id_for_sha256
manifest=json.loads(Path('docs/plans/document-understanding-2026-10-13/sample_manifest.json').read_text(encoding='utf-8'))
chosen={'cn-equity':{62,63},'hk-annual':{12},'hk-interim':{10,11,19}}
rows=[]
for sample in manifest['samples']:
 if sample['id'] not in chosen:continue
 path=Path(sample['path'])
 if not path.is_file():
  rows.append({'sample_id':sample['id'],'status':'MISSING_ORIGINAL'});continue
 before=(hashlib.sha256(path.read_bytes()).hexdigest(),path.stat().st_mtime_ns,path.stat().st_size)
 assert before[0]==sample['sha256']
 sid=source_id_for_sha256(before[0])
 start=time.perf_counter()
 parsed=parse_pdf(path,source_id=sid,source_sha256=before[0],language='zh',table_pages=sorted(chosen[sample['id']]))
 scoped=replace(parsed,units=tuple(u for u in parsed.units if u.coordinates.page_number in chosen[sample['id']]),pages_read=len(chosen[sample['id']]))
 title=path.name
 p=understand_units(scoped.units,source_id=sid,source_sha256=before[0],title=title,declared_kind=sample['expected_family'],language='zh',native_scan='partial')
 r=select_narrative_evidence(scoped,title=title,existing_kind=sample['expected_family'],max_selected=96,selector_version='0.9.0')
 selected_ids={(s.coordinates,s.raw_text) for s in r.evidence_spans}
 by_id={u.unit_id:u for u in scoped.units}
 traces=[]
 for pkg in p['packages']['packages']:
  if pkg['kind'] not in {'project','operating_table'}:continue
  anchors=[by_id[uid] for uid in pkg['anchor_unit_ids'] if uid in by_id]
  traces.append({'package_id':pkg['package_id'],'kind':pkg['kind'],'member_count':len(pkg['member_unit_ids']),'anchor_text':[u.raw_text[:130] for u in anchors],'anchor_reading_roles':[p['reading_plan']['unit_profiles'][u.unit_id]['section_role'] for u in anchors],'anchor_fact_eligible':[detect_reading_business_fact(u.raw_text).eligible for u in anchors],'selected_member_count':sum((by_id[uid].coordinates,by_id[uid].raw_text) in selected_ids for uid in pkg['member_unit_ids'] if uid in by_id),'completeness':pkg['completeness']})
 after=(hashlib.sha256(path.read_bytes()).hexdigest(),path.stat().st_mtime_ns,path.stat().st_size)
 assert before==after
 rows.append({'sample_id':sample['id'],'real_original':True,'limited_page_scope':sorted(chosen[sample['id']]),'source_sha256':before[0],'original_unchanged':before==after,'parsed_all_units':len(parsed.units),'scoped_units':len(scoped.units),'unit_kinds':dict(collections.Counter(u.unit_kind for u in scoped.units)),'reading_family':p['route']['family'],'semantic_packages':dict(collections.Counter(q['kind'] for q in p['packages']['packages'])),'selected_count':len(r.evidence_spans),'table_rows_total':sum(u.unit_kind=='pdf_table_row' for u in scoped.units),'table_rows_selected':sum(u.unit_kind=='pdf_table_row' and (u.coordinates,u.raw_text) in selected_ids for u in scoped.units),'table_row_examples':[{'text':u.raw_text[:110],'selected':(u.coordinates,u.raw_text) in selected_ids,'reading_role':p['reading_plan']['unit_profiles'][u.unit_id]['section_role']} for u in scoped.units if u.unit_kind=='pdf_table_row'][:12],'selected_groups':dict(collections.Counter(q['kind'] for q in r.reading_context['groups'])),'status':r.status,'deferred_count':len(r.reading_context['deferred']),'actual_package_traces':traces[:10],'selected_original_excerpt':[s.raw_text[:180] for s in r.evidence_spans[:5]],'seconds':round(time.perf_counter()-start,3)})
result={'schema_version':'reading-real-anchor-probe/1','scope':'Existing actual original parsed units in bounded pages; semantic/selection adapter review, not whole-document recall or model-summary acceptance','samples':rows,'model_calls':0,'provider_calls':0,'new_downloads':0,'raw_copies':0}
Path('.planning/shared-reading-production/tests-agent/multiline-tables-real.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(result,ensure_ascii=False))


