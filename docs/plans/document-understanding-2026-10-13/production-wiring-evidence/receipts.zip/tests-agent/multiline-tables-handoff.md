# ROOT shared multiline-table implementation handoff

## Scope and code

Changed only src/company_wiki/document_understanding/structure/tables.py and the new tests/unit/document_understanding_selection/test_reading_multiline_tables.py for this continuation. Prior production-selection TDD file remains as ROOT's accepted test input. No registry, budget, reading adapter, geometry subpackage, shared PWF or Git writes.

The table builder now indexes actual typed table scopes once by page and supplied table ID. A neutral first date row cannot decide purpose; original subsequent period/year rows and operating labels establish the scope's purpose. Actual typed body rows are anchors. Original caption, all header layers and footnotes are mandatory context. It never creates fine cells, changes text/locators, or joins neighbouring tables/pages/sources by a loose page caption. Untyped legacy tables use only contiguous header-started local runs.

Financial balance accounts remain financial even when their labels mention stores. Simplified/traditional/English account names share the recognizer. Footnote operating words cannot classify an accounting table. Date detection does not reinterpret body quantities such as 2021 as a year, or a per-year delivery rate as a period header. Repeated header-set construction and purpose scans were removed; caller work-budget stop is diagnostic and remains visible to ROOT.

## TDD and checks

- First 13 cases: 10 FAIL / 3 PASS, real exit 1 (multiline-tables-red.log).
- Added real counterexamples during review: quantity/year-body ambiguity, standalone 2021, English/traditional store lease liabilities. All RED logs remain.
- Final affected node: 120 PASS, exit 0, pytest 10.59 seconds (multiline-tables-final-affected.log). Includes 18 new tests, 47 structure tests, production DU pipeline/selection bridge/summary closure/DU2 integration.
- Ruff --no-cache PASS; mypy PASS; git diff --check PASS. No older assertion was relaxed.

## Actual originals

Read existing manifest originals only; SHA/mtime/size verified before and after. Zero downloads/model/provider calls/raw copies.

- 2024 HK annual physical page 12: previous semantic engine formed zero operating tables and omitted all 24 typed rows. Current engine forms 2 scoped tables (15 and 9 members); production 0.9 selects 24/24 original typed rows, including exact values and original period/labels.
- 2025 HK interim physical pages 10/11/19: current engine selects 21/21 typed rows. This is a different source/document family/period with the SAME issuer; it is not a different-company holdout.
- CN equity offering physical pages 62/63: original project/construction packages retained; 13 investment-amount table rows remain unselected. They were not promoted as operating metrics.

Receipts: multiline-tables-real.json and multiline-tables-real-final.log. Finely resolved cells/columns remain unavailable, count tables lacking a separate unit caption remain explicitly partial, and the original narrow page scope remains partial. These checks prove original evidence retention, not full-document recall, paid summary entailment, or economic forecast quality.

## ROOT remaining integration

Use the true table body anchor IDs. Numeric body rows without their own operating keyword should be admitted when the authentic table structure has positively established purpose and mandatory context; do not reinstate body regex admission. Current real HK scopes already bind management_discussion and therefore pass.

ROOT owns final selection/generation/cache/model/remote publication/PWF and Phase C same-budget actual summaries plus different-company holdout. This component does not close those nodes. No source or test edits needed from this worker remain; ready for ROOT review and commit.
