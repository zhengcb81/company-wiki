"""One focused A/B node; logs owned here, test lakes always restored."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import tempfile
import time

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent / "root"
OUT.mkdir(exist_ok=True)

def run(label, args):
    started = time.perf_counter()
    process = subprocess.run([sys.executable, "-B", "-X", "utf8", *args], cwd=ROOT,
                             capture_output=True, text=True, encoding="utf-8")
    (OUT / (label + ".log")).write_text(process.stdout + process.stderr, encoding="utf-8")
    record = {"command": args, "exit_code": process.returncode,
              "seconds": round(time.perf_counter() - started, 3)}
    (OUT / (label + ".json")).write_text(json.dumps(record, indent=2), encoding="utf-8")
    print(json.dumps({"label": label, **record}), flush=True)
    print((process.stdout + process.stderr)[-3000:], flush=True)
    return process.returncode

if __name__ == "__main__":
    mode = sys.argv[1]
    production = ROOT / "config/source_catalog.yaml"
    before = (hashlib.sha256(production.read_bytes()).hexdigest(), production.stat().st_mtime_ns)
    with tempfile.TemporaryDirectory(prefix="cwReadingAB-") as temp:
        lake = Path(temp)
        sentinel = lake / "sentinel.txt"
        sentinel.write_bytes(b"preexisting test data must remain unchanged")
        if mode == "unit":
            paths = ["tests/unit/" + name for name in (
                "document_understanding_profiles", "document_understanding_structure",
                "document_understanding_root", "document_understanding_layout_hints",
                "document_understanding_selection",
                "test_narrative_reading_transport.py", "test_narrative_reading_generation_store.py",
                "test_narrative_run_store.py",
                "test_narrative_artifact_store.py", "test_narrative_worker_factory.py",
                "test_narrative_verify_handler.py", "test_narrative_select_handler.py",
                "test_narrative_selector_binding.py", "test_narrative_transport_contracts.py",
                "test_automation_store_atomic.py",
                "test_shared_reading_cache_precheck.py", "test_reading_batch_version.py",
                "test_narrative_batch.py", "test_narrative_batch_request.py",
                "test_narrative_generation.py", "test_narrative_model_request.py",
                "test_narrative_model_caller.py", "test_narrative_model_aliases.py",
                "test_narrative_model_usage.py", "test_narrative_model_config.py",
                "test_narrative_selection_architecture.py", "test_n6_budget_selection.py",
                "test_n6_dedup_context_safety.py", "test_s7_operating_fact_semantics.py",
                "test_s7_adoption_project_context.py", "test_automation_migrations.py",
                "test_automation_migrations_v2.py", "test_automation_migrations_v3.py",
                "test_automation_store.py", "test_narrative_run_ownership.py",
            )]
        elif mode == "e2e":
            # Seven new production cases are independently run by the reviewer;
            # ROOT runs the historical reuse carriers once, without duplication.
            paths = ["tests/integration/test_narrative_generation_reuse.py"]
        else:
            raise ValueError(mode)
        code = run(mode, ["-m", "pytest", "-q", "-p", "no:cacheprovider", "--basetemp",
                          str(lake / "pytest"), "--junitxml", str(OUT / (mode + ".xml")), *paths])
        assert sentinel.read_bytes() == b"preexisting test data must remain unchanged"
        assert before == (hashlib.sha256(production.read_bytes()).hexdigest(), production.stat().st_mtime_ns)
    assert not lake.exists()
    (OUT / (mode + "-restore.json")).write_text(json.dumps({"temp_restored": True,
        "sentinel_preserved": True, "production_config_unchanged": True,
        "supplier_calls": 0, "external_model_calls": 0, "new_paid_usage": 0}), encoding="utf-8")
    sys.exit(code)
