"""Same-original whole native selection diagnostic; no model/quality certification."""
from dataclasses import replace
from pathlib import Path
import gzip
import hashlib
import json
import sys
import time

ROOT = Path.cwd()
sys.path.insert(0, str(ROOT / "src"))
from company_wiki.source_contract import source_id_for_sha256
from company_wiki.source_catalog.narrative_evidence import parse_pdf_bytes, select_narrative_evidence
from company_wiki.source_catalog.narrative_normalization import NarrativeNormalization
from company_wiki.document_normalization import normalize_document

OUT = Path(__file__).parent / "root"
OUT.mkdir(exist_ok=True)
manifest = json.loads((ROOT / "docs/plans/document-understanding-2026-10-13/sample_manifest.json").read_text(encoding="utf-8"))
rows = []
for sample in manifest["samples"]:
    if sample["id"] not in {"cn-annual", "hk-annual", "us-10k"}:
        continue
    path = Path(sample["path"])
    if not path.is_absolute():
        path = ROOT / path
    if not path.is_file():
        rows.append({"sample_id": sample["id"], "status": "MISSING_ORIGINAL"})
        continue
    print("START " + sample["id"], flush=True)
    data = path.read_bytes()
    before = (hashlib.sha256(data).hexdigest(), path.stat().st_size, path.stat().st_mtime_ns)
    assert before[0] == sample["sha256"]
    mime = "application/pdf" if path.suffix.casefold() == ".pdf" else "text/html"
    started = time.perf_counter()
    sid = source_id_for_sha256(before[0])
    if mime == "application/pdf":
        parsed = parse_pdf_bytes(data, source_id=sid, source_sha256=before[0], language="zh")
    else:
        normalized = normalize_document(data, source_id=sid, source_sha256=before[0], mime_type=mime)
        parsed = NarrativeNormalization.language_structure(normalized, "en")
    parsed = replace(parsed, mime_type=mime)
    row = {"sample_id": sample["id"], "source_sha256": before[0], "source_bytes": before[1],
           "parse_count": 1, "unit_count": len(parsed.units), "parse_seconds": round(time.perf_counter()-started, 3),
           "read_scope": "whole native parser; honest opaque/table deferrals", "variants": []}
    for version in ("0.8.0", "0.9.0"):
        start = time.perf_counter()
        result = select_narrative_evidence(parsed, title=path.name, existing_kind=sample["expected_family"],
                                          selector_version=version)
        spans = [span.to_dict() for span in result.evidence_spans]
        units = {(u.source_id, u.coordinates, u.raw_text) for u in parsed.units}
        assert all((span.source_id, span.coordinates, span.raw_text) in units for span in result.evidence_spans)
        row["variants"].append({"selector": version, "selected_count": len(spans),
            "selection_limit": result.selection_limit, "candidate_count": result.candidate_count,
            "status": result.status, "coverage_complete": result.coverage_complete,
            "selection_seconds": round(time.perf_counter()-start, 3),
            "selected_text_chars": sum(len(span.raw_text) for span in result.evidence_spans),
            "reading_context": result.reading_context, "selected_original_spans": spans,
            "critical_business_recall": "NOT_EVALUATED; external frozen gold still in construction",
            "summary_fidelity": "NOT_EVALUATED; no model called"})
        print("DONE", sample["id"], version, len(spans), result.status, flush=True)
    after = (hashlib.sha256(path.read_bytes()).hexdigest(), path.stat().st_size, path.stat().st_mtime_ns)
    assert before == after
    row["original_sha_size_mtime_unchanged"] = True
    rows.append(row)
    raw = json.dumps({"schema_version": "reading-native-selection-comparison/1", "samples": rows,
        "provider_calls": 0, "model_calls": 0, "raw_copies": 0, "production_writes": 0},
        ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    packed = gzip.compress(raw, mtime=0)
    assert gzip.decompress(packed) == raw
    (OUT / "native-comparison.json.gz").write_bytes(packed)
    (OUT / "native-comparison-storage.json").write_text(json.dumps({"raw_bytes": len(raw),
        "compressed_bytes": len(packed), "roundtrip_verified": True,
        "raw_sha256": hashlib.sha256(raw).hexdigest(), "packed_sha256": hashlib.sha256(packed).hexdigest()},
        indent=2), encoding="utf-8")
