# 层级策略绑定 findings

## 接收实现

扁平 alias 会把 Part I/II、Item 1/1A 混合；同 role 首项 priority 不是实际 policy 优先级。binder 根据实际 parent_id 祖先路径末段匹配，path 层内 OR/层间 AND、ASCII 词边界；未匹配 deep heading 继承准确父条目与 priority。新 section_rules 失败不 flat 兜底，旧 API 保持兼容。same-pid 不同 child 范围使用 reading_profile_key，窄范围优先/等范围歧义/外链未读原规则保留。

unit_profiles 实际 chosen policy_components、reading_questions（全局与条目）、context_requirements、family_policy、negative_hints、semantic_units 均 deepcopy；used_profiles 只记录实际 chosen 集合。原输入/ID/locator 不变，没有第二 loader、registry 或许可链。

## 真实接点发现与修复路径

VRSK us-10q 原件 SHA：5afe631934fce5d3e23b6aa393ec599cd89b290cde1fc1667ebe22025d2479eb。Dayu 原件只读。

before：公共 normalizer 2274 units → adapter → structure 15 sections → scoped 命中 0；不能用纯 synthetic 绿取代此失败。
Part I/II 正文 ordinal 96/2166 是 paragraph，native metadata 有 dom_path；TOC 表有重复 Part；正文 Item 编号与标题拆成 table cells。layout owner 修复公共 structure/adapter 接点，binder 未虚构 section。

after1：17 sections / 3 命中，Part II 正确，Part I 被 year/address 表格伪数字 heading 弹栈，FAIL。
after2：30 sections / 3 命中，表格误标题已消失，但真实 financial Notes 1–16 是 level1，仍弹出 Part I，FAIL。
layout owner 保留真实 Notes/IDs，修正 Part→Item→Notes 相对层级，下一 Item 回到 Part 下；没有删除真实章节或让 path 跳层。

after3：30 sections / 5 命中 / 6 checks PASS / 0.807s。MD&A 与 Controls 均在 Part I；Legal/Risk 在 Part II；Mine Safety 不误判 Controls；year/address 表格不是 headings。输入深度比较与原文 SHA/mtime 一致。各次失败报告均保留，验收条件未放宽。

真实 Management’s 与 spec Management's 的差异仅在 matcher presentation view 归一：NFKC、空白、casefold、左右 curly single quotes 转 ASCII apostrophe。保留 raw text；chemical/math prime 不转换，有专门反例。

## 测试与限制

最终 18 focused PASS（0.37s），最终 scoped Ruff PASS；临时 test 目录恢复，无 paid/model/network/raw/config 写入。早期 integration-pending 的 25 PASS / 3 FAIL 仅记录其它 scope 的 layout_bridge 在制缺文件，非最终全集结果。
本包证明真实 normalized → structure → policy binding 接点；生产 LLM 摘要事实完整性、最终 sent-only policy 指令与跨仓端到端由 ROOT 集中验收，不据此宣称语义完成。
