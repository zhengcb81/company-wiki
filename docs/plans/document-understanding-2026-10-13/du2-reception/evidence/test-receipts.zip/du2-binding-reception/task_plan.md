# DU2 层级策略绑定接收

PLAN_ID=du2-binding-reception。仅 strategy_binding.py、新 test_du2_strategy_binding.py 与本 PWF；ROOT 统一 Git。

## 阶段

A：complete。首批 12 项行为 RED 为 9 FAIL / 3 PASS；另有 child 隔离、legacy native-role priority 与真实 curly apostrophe 反例先失败留证。
B：complete。实际 parent_id（兼容 parent_section_id）、path 层内 OR / 层间 AND、ASCII 编号边界、实际 rule priority、祖先继承、same-pid 范围 key、实际 chosen 组件/问题/上下文/family 状态透传。最终 18 focused PASS / 0.37s；最终 scoped Ruff PASS。
C：complete。固定原始 SHA 的真实 VRSK 10-Q 经 public normalizer → adapter → structure → binder；2274 units / 30 sections / 5 scoped rule 命中，6 项真实正反例全部 PASS / 0.807s。原始 0→3→3 的失败回放保留。

## Next Step

STOP，等待 ROOT 集中联测、独立审查与 Git 并线。本包不改 shared pipeline/summary、作者树、原件和配置，不操作 Git index。

## 接口

实际 DU/1 parent_id，兼容 parent_section_id。section_rules 完整保留 role/section_role、aliases、heading_path、priority、questions；有 scoped rules 时 path 失败不能 flat 兜底。连续父子路径保持，未跳过中间层。
child 以 reading_profile_key 或 pid 查实际 policy，输出 profile_id 保留真实 ID。unit_profiles deepcopy actual policy_components / reading_questions / context_requirements / family_policy / negative_hints / semantic_units；ROOT 从最终 sent 单位汇总。

## 验证边界

最终 focused 18 项与同 SHA 真实结构/绑定直链绿。integration-pending 保留早期组合 25 PASS / 3 FAIL：当时 3 个 pipeline 测试因其它 agent 在制 layout_bridge 缺文件而失败，不代表最终联测结果。最终整体 pipeline/summary 与模型事实语义由 ROOT 负责，本包未声称其已通过。零模型/付费/network/raw/config 写入。

## Errors 与共用根因

- child fallback 曾读已绑定 role，改 immutable original_roles。
- legacy native-role priority RED 后恢复无 scoped rules 的旧行为；有 scoped rules 不 flat。
- 显示型 curly apostrophe 在匹配视图统一；原文/ID/locator 不改，chemical/math prime 不替换。
- 真实 0-hit 揭露上游 Part/Item、拆分 table heading、TOC 边界。
- after1/2 揭露普通 year/address 表格伪标题与真实 Notes 弹出 Part 层级；交 layout owner 通用修复，未在 binder 弱化路径规则。
