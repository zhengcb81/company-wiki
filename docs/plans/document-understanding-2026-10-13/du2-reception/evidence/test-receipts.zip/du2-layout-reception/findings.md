# Findings

Author HEAD 8cfd069c, scope clean. Initial receipt offline 34 PASS / 6 real SKIP.
Probes: opaque/deferred pages still complete=true; max_work=120 requested 231 charges and froze used=121 while high groups emitted; late column exhaustion missed diagnostic; 400 single-page short units produced 160000 neighbour scans but reported 1970 work; three-page continuation lost original title/unit/header by page 3.
Repairs must stop actual computation at the single budget, index neighbours, carry inherited context transitively, and preserve granularity/locator boundaries.

## Repair findings

Strict failure propagation was needed, rather than another diagnostic after ignored charge returns. On exhaustion the whole unfinished hint result is deferred, because publishing a half-built context dependency graph can produce confident wrong readings.
Old scale sample distributed units over many short pages and therefore hid per-page all-pairs heading work. New test counts bbox accesses on 400 units in one page without fragile elapsed-time assertions. Local graph lookup also replaces groups×all-continuations.
Inherited continuation context includes original title/unit/header and qualifying footnotes. Ambiguous matched tables are not joined. Parser-declared aggregate geometry is a capability limitation, not permission; raw reading remains possible downstream.
Four-source replay retains sufficient-span 3/4/6-column tables, 0-table narrative negative, and all explicitly coarse inputs with 0 claimed columns/partial. Test-only probe IDs are not production locators.
