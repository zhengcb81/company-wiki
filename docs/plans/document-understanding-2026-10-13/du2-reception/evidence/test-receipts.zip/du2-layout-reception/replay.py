"""Read-only four-source geometry replay. Local source bindings stay untracked."""
import argparse
import json
import sys
import tempfile
import time
from pathlib import Path

root=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(root/"src"))
sys.path.insert(0,str(root/"tests/fixtures/document_understanding_layout_hints"))
import real_probe
from company_wiki.document_understanding.layout_hints import derive_layout_hints

parser=argparse.ArgumentParser();parser.add_argument("--bindings",required=True);args=parser.parse_args()
bindings=json.loads(Path(args.bindings).read_text(encoding="utf8"))
records=[];start=time.monotonic()
with tempfile.TemporaryDirectory(prefix="du2-layout-replay-") as scratch:
    scratch=Path(scratch);sentinel=scratch/"sentinel";sentinel.write_bytes(b"owned")
    for spec in real_probe.PROBE_SAMPLES:
        path=Path(bindings[spec["sample_id"]]);before=(real_probe.sha256_of(path),path.stat().st_mtime_ns,path.stat().st_size)
        modes=[]
        for mode in ("span","row_collapse"):
            probe=real_probe.load_probe_input(bindings,spec["sample_id"],mode=mode)
            assert probe["status"]=="ok",probe.get("reason")
            result=derive_layout_hints(probe["observation"])
            ids={u["unit_id"]for page in probe["observation"]["pages"]for u in page["units"]}
            assert all(set(g["member_unit_ids"])<=ids and set(g["required_context_unit_ids"])<=ids for g in result["groups"])
            regions=[g for g in result["groups"]if g["kind"]=="table_region"]
            columns=[c["column"]for g in result["groups"]for c in g["cells"]if c["column"]is not None]
            if mode=="row_collapse":
                assert not columns and result["coverage"]["complete"]is False
            if spec["sample_id"]=="hk-miniso-annual-store-table" and mode=="span":
                assert len(regions)==2 and max(columns,default=-1)>=2
            if spec["sample_id"]=="cn-amec-annual-narrative":
                assert regions==[]
            modes.append({"mode":mode,"units":len(ids),"regions":len(regions),"max_columns":max(columns,default=-1)+1,
                          "coverage":result["coverage"],"work":int(next(d["detail"]for d in result["diagnostics"]if d["code"]=="WORK_UNITS"))})
        after=(real_probe.sha256_of(path),path.stat().st_mtime_ns,path.stat().st_size);assert before==after
        records.append({"sample_id":spec["sample_id"],"source_sha256":spec["sha256"],"source_unchanged":True,"modes":modes})
    assert sentinel.read_bytes()==b"owned"
result={"status":"PASS","samples":records,"elapsed_seconds":round(time.monotonic()-start,3),"sentinel_unchanged":True,
        "tmp_removed":not scratch.exists(),"model_calls":0,"paid_usd":0,"production_locator_tested":False}
(root/".planning/du2-layout-reception/real-replay.json").write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding="utf8")
print(json.dumps(result,ensure_ascii=False))
