# DU2-LAYOUT 接收修复

Owner: ROOT delegated reception; base 78fecefa; only owned layout module/tests/fixtures/this ledger changed. No Git mutations.

## Stages
1. RED — complete: initial 5 behaviour tests failed as expected, red.xml; explicit coarse-row declaration also RED, coarse-red.xml.
2. Common roots — complete: strict private budget stop boundary; indexed conservative heading neighbours; active table-column sweep; indexed lanes/footnotes; counted cell/context/continuation work; unique continuation matching with transitive header/title/unit/footnote context; honest upstream and aggregate geometry coverage. Default ceilings unchanged.
3. Validation — complete: one module regression 41 PASS / 6 real SKIP (7.68s); after final explicit-granularity additions, 8 targeted behaviour tests PASS (1.14s); 4 originals × span/coarse modes replay PASS (0.525s), raw SHA/mtime/size unchanged, sentinel/tmp restored, scoped ruff green.

## Next Step
Core reception ready for ROOT combined integration test/commit. Production PDF geometry bridge is a separate delegated owned scope; no core permission or deployment gate added.
