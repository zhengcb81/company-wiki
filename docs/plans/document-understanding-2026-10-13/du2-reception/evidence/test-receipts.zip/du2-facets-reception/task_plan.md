# DU2-FACETS ROOT接收修复

PLAN_ID=du2-facets-reception；范围仅 deliverables/facets/** 与本计划。ROOT统一git。

## 目标
修复条件式必要上下文与完整事实支持的共用根因，保留业务关注点与可选数字；设计正文不冒充raw。

## 阶段
1. A：complete。10项RED全失败，保存red.txt。
2. B：complete。4条定性规则移除金额槽位且拆数量规则；8条变动records为1.2.0；新增2合法反例；校准支持、计划/实际、可选GMV、否定N/A与consumption缺样。
3. C：complete。356PASS/1.47s；22完整锚点/6原件SHA+mtime复核，source与交付数据未变、sentinel恢复、tmp移除。Ruff PASS。0模型/费用。

## Next Step
STOP，交ROOT集中集成、测试、提交、并线。ROOT最终observer必须从原件公共解析器恢复unit/locator，不能用手工text或gold作observed。

## 边界
生产业务选择/LLM摘要语义仍NOT_RUN_ROOT_INTEGRATION；不建checker/DSL/registry或审批；未改作者树、src、共享计划/config或Git。

## Errors
首轮完整锚点计算的猜测边界不存在，在写出前停止；回到原件61页读取真文本后纠正。记录该错误，未重复猜建设期。
