# ROOT接收发现与修复

## 共用根因
1. 条件式约束混用定性/数量：4处project/always/condition触发了quantity/unit；现已按断言分开。普通计数范围不是数学分母。
2. 完整事实没有完整支持：IR数字不在u2、阶段OR的u4缺送样/订单信息、替换产能定义不在返利测算短句。现保留IR可选事实并新增u2n真实数字句；替换定义新增u3p，AND支持；阶段OR仅用u1。
3. 时态依赖日期而非原文：合成一期显式已建成；真实恒锋建设周期不被推成已全部完成，二期预计与条件保留。
4. 可选与必留冲突：门店事实去掉强制GMV，其correctness_if_emitted保留；否定VC生产stage不适用；Consumer客群不证明consumption计费，证据行留missing。
5. 设计正文冒充原文风险：真实unit.text显式text_status/text_source/runtime_raw=false；原始锚点扩为完整段落/表格并按原件验真；HTML引用复用公共前端，TXT核声明行。22锚点分别对应6原件，无翻译/复制。

## 实际验证
356项data结构PASS并非模型语义PASS。既有CLI独立TMP输出22/22引用核实，SHA/mtime6/6未变，哨兵/临时目录恢复。每source引文：cn-convertible2520、cn-equity2916、cn-ir4321、hk-annual4417、us-txt2319、us-release1165字节，均<8KiB。

## ROOT接线
唯一registry导入records；按当前断言消费条件、不要全局强制每个槽位。恢复实际source units后映射完整OR/AND支持；手工text只读设计语境，不能作observed。行业统计/明确用量计费/生物医药CDMO/募投delta缺样仍公开记录。最终生产语义由ROOT集成节点验证。
