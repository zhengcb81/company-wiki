# 单catalog策略实现交接

新24个TDD与旧181项profile=205PASS，2.39s；Ruff和compiler --check均PASS。

- 真正唯一runtime reading_catalog（24用途/14阅读面/15兼容ID），无_build_profiles或runtime docs加载。
- full section_rules保留层级/优先级；strong router约束、有界probe、正交生命周期与unknown fallback。
- content局部fingerprint含所有实际采用公共与文档指令；不因其他catalog项变化失效。
- facet实际从最终原文members匹配，返回精简指令/出处hint，不造事实、计费机制或数量。
- 原件/config零访问零写，0模型/网络/费用，tmp哨兵/目录恢复；无Git操作。

ROOT负责接口接pipeline/model/绑定、package-data、真实原文parser端到端与集中Git；本包STOP。详细接口与测试留findings/handoff.json/red.txt/final.xml。
