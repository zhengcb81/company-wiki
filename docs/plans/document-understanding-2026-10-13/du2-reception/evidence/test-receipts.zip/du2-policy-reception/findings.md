# 设计判断

- 运行只加载一次打包catalog，不从docs读取。compiler校验/生成单asset，--check检测漂移。
- 旧15ID只是catalog数据绑定投影；完整section_rules保留同role多条heading_path。
- resolve先沿既有有界probe与route family/regime/form，不能覆盖强路由，未知不靠单一弱信号升级；extent/revision不联合筛选。
- 采用component内容摘要进入profile_version；未采用family/facet变化不使当前文档缓存失效。
- facet从最终原文members做关键词提示选择，输出阅读配置而非提炼事实，Consumer不证明consumption。

## 最终运行界面

- reading_catalog.json 为唯一runtime策略库（24 family/14 facet/覆盖状态/15 legacy-ID绑定/通用fallback）。reading_defaults.json只供compiler输入，运行不加载。
- legacy_alias_supplements仅补旧wire显示；没有第二套family识别/章节优先级/问题库。新ReadingPlan仅section_rules完整原section（附section_role兼容role别名）；同role不同path保留。
- resolve_reading_profile 返回原键加section_rules/policy_components/reading_questions/context_requirements/family_policy/modifiers/policy_probe/policy_diagnostics。strong route family/regime/form作约束，unknown或歧义走通用策略，诊断不阻断。
- policy_components:[kind,id,version,content_digest]；profile_version基于实际section_rules/focus/negative/questions/context/semantic_units+采用components，未采用文档/阅读面改动不影响此hash。共有focus改动会正确失效。
- select_business_facets返回id/version/business_questions/applicable_mechanisms/summary_focus/required_context/absence_rules/content_digest/selection_basis；不输出事实、观察机制或数量，不发送合成confusions数字/case_ids/完整positive_evidence。Consumer不等于consumption。
- 如真实原文没出现某个signal，facet不选；选中的词仅提示阅读面，不证明相应事实。actual final member Unicode归一只做一次，再对提示匹配；字符probe预算沿既有公平分配器，不另外选择原件。
- 数据coverage的proposed/synthetic/real状态是策略设计与参考案例状态，不等于当前原件内容读取/模型摘要质量已通过。
- compiler --check比较同asset内容，漂移时只报错不改文件，不增加人工许可链。
