# DU2 单运行阅读策略目录

只写 profiles/**、tools/import_reading_policies.py、自有 test_du2_policy_registry.py 与本计划。ROOT写生产/摘要/绑定；无Git操作。

## Goal
从24用途/14阅读面编译唯一打包catalog，消除特定文档_build_profiles；保留15旧ID投影和route。新增纯有界resolve和最终原文facet选择，component局部hash。

## Phases
1. 测试先行与RED（complete）
2. compiler/单资产registry/有界消费（complete）
3. 集中新旧契约测试、compiler一致性和交接（complete）

## Next Step
本包完成并STOP；ROOT接实际pipeline/summary/绑定与package-data，再做大节点联调和并线。
