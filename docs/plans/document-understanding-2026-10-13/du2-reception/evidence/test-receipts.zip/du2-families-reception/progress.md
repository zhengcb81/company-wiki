# 接收修复日志

- 开始独立数据修复；全程0模型/0网络/0费用。ROOT统一Git index。

- RED：8 FAIL /1 PASS，原事实不变检查已PASS；其余失败对应原问题。
- 修复完成：24 specs版本1.0.1，10-Q路径/数组适用轴/正交overlay/66事实分类/UTF8配额/README统计/行提示诊断；待集中验收。

- GREEN：94 PASS（pytest3.39s，wrapper8.025s）；原件引文97/97 PASS（19.055s）。
- 20原件与13生产config的size/mtime_ns/SHA前后一致；哨兵未改、系统临时目录和pytest重定位目录清理。
- 66原fact字段及importance/support内容SHA仍861dc4141511eb98d72b8d7b8e979c5245337c7cb68f52b9845f60c66704d129；只新增target_kind。
- C工具 --bindings 只读外部作者本机绑定，不复制原件；行输出明确document_quote(line_hint,not_exact_range)。
- 本包未接生产、未测真实parser正式locator/语义召回/模型摘要，不增加人工门禁。ROOT统一Git提交。
