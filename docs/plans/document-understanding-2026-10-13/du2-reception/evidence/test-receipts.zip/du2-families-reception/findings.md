# 接收发现

- 原作者 HEAD b48b6ede；24 specs、39 cases（31 real /8 synthetic）、20来源、66 facts。
- us-10q 原件：Controls=Part I Item4；Legal=Part II Item1；原规格错放Part II和Item3。
- 生命周期overlay原字段summary/amended与自己的supplement case冲突；适用轴必须是允许值，不改变观察值。
- 8KiB原helper按字符计数；原摘录实测最大UTF-8 1333 bytes。
- 当前ROOT阅读引擎未消费新数据；结构绿不代表语义/生产绿。
- 原 facts 规范化 SHA-256（排除后续新增target_kind前）：861dc4141511eb98d72b8d7b8e979c5245337c7cb68f52b9845f60c66704d129

## 完成后的接线界面

- 全records version1.0.1；modifiers.allowed arrays（不是当前文档的已观测extent/revision，不赋值）。
- 10-Q 同administrative role有两条独立Part范围，不能按role吞掉heading_path。
- 目标分类{"required_business": 39, "disposition_context": 24, "correctness_if_emitted": 3}；普通表格仅输出才核查，实际业务事实要求保留。
- 31真实case来自20原件；设计excerpt不是正式SourceRef。HTML行提示不当成精确定位。
- 保留原39case/66fact及重要性、所有缺样清单；接入与语义状态仍NOT_RUN_ROOT_INTEGRATION。
