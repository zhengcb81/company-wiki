# DU2-FAMILIES ROOT 接收修复

PLAN_ID=du2-families-reception；基线 78fecefa；只写 families deliverables 与本 PWF，Git 由 ROOT 统一处理。

## Goal
纠正真实10-Q章节错误、生命周期适用轴、引文字节配额和统计，并补事实目标分类；保留真实 facts、重要性与支持。不实现第二router，不改原件、配置或其他包。

## Phases
1. RED：行为与数据不变量验收测试（complete）。
2. 修复规格/测试helper/证据说明，版本升级（complete）。
3. 一次集中数据测试及有界引文复核，SHA/mtime/临时目录恢复，ROOT交接（complete）。

## Next Step
本包接收修复完成；ROOT将数据导入唯一registry并做实际引擎消费与真实parser定位测试。
