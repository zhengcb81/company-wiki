# Progress

- Initial core reception repair completed separately in ../du2-layout-reception; bounded work, unique adjacency indexing, continuation dependency closure and coarse coverage honesty.
- Public integration RED preserved then resolved: source geometry/fonts + pure helper APIs; actual DOM metadata + generic SEC display-heading references; fake numeric/table heading suppression; missing context-budget stop propagation; genuine Notes relative depth; rotated page-frame metadata; indexed font runs.
- Final scoped test node: `final-target.xml`: **45 PASS /1.26s**, 15 new bridge +30 affected legacy adapter tests. Scoped ruff PASS. No all-repository CI rerun here.
- Binding agent VRSK same raw SHA: **2274 units, 30 sections, 5 scoped rules, 6 checks PASS /0.807s**; earlier failures retained in its PWF; final exact report `../du2-binding-reception/real_10q_after3.json`. This verifies real Part/Item MD&A and Controls parent matching without flattening scope.
- Final public replay, once: `public_pdf_replay.json`: **4 PASS /87.019s**, raw SHA/mtime/size unchanged, 28,255 parsed units, 160 bounded final packages, 658 canonical original-byte spans verified, 0 failed. Source font dimensions available; aggregate geometry remains honestly partial. Sentinel unchanged; owned temporary directory removed; 0 raw copies/network/models/paid costs/config writes.
- Font indexed-work evidence: `font-index-resource.json`: 10,000 style runs→13 index reads +2 run reads for one fragment, no per-fragment whole-block scan.
- Source code FROZEN. PWF finalized. ROOT owns the one joint test/commit/push. STOP.

## Test environment note

The focused pytest invocation used the standard repository conftest/temp behavior and disabled pytest cache/bytecode; no raw originals or production config were changed. The original replay separately used an owned TemporaryDirectory with a sentinel and explicit finally cleanup, which was verified removed. We do not claim to have deleted unrelated pytest temp history.
