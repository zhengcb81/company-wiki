# DU2 layout public integration reception — COMPLETE / STOP

Owner: ROOT delegated layout worker; acceptance tree only. No Git operations.

## Completed large nodes

1. **A: deterministic RED / public API ownership.** Actual fitz PDF fonts/page dimensions, unchanged legacy three-tuple text/ID/locator; DOM heading/depth; same-source context mapping. Initial four RED preserved in `red.xml`.
2. **B: integration and shared root causes.** One `apply_layout_hints` call; duplicate gutter inference removed. Context binding genuinely reserves every operation including empty-requirement member traversal; zero cap yields partial diagnostics. SEC Part→Item→relative numbered Notes grammar with native DOM priority; single-row Item-label/title tables reference original IDs, TOC/multirow/financial amount tables remain data. Numeric years/addresses/quantity paragraphs no longer become headings. Font style runs indexed once per block; dimensions from the same unrotated dict snapshot. RED evidence: `sec-hierarchy-red.xml`, `numeric-heading-red.xml`, `binding-budget-red.xml`, `notes-depth-red.xml`, `frame-font-red.xml`.
3. **C: scoped GREEN and final true originals.** 15 bridge +30 prior root integration tests =45 PASS/1.26s (`final-target.xml`), scoped ruff GREEN. Independent binding agent same-SHA VRSK 10-Q after3: 2274 units/30 sections/5 scoped policy hits, 6 checks PASS. Four originals public parse→pipeline→summary→original-byte locator replay: 28,255 units, 160 final packages, 658 true spans PASS/87.019s. No model/paid/network/raw/config writes; owned replay temporary directory removed.

## Frozen interfaces

- `apply_layout_hints(observation, *, limits=None) -> (new_observation, layout_hints)` — pure copy, original source identity/text/unit IDs/locators preserved, source font/bbox/dimensions only. Missing/coarse geometry diagnoses partial without removing readable text/DOM.
- `bind_layout_context(structure, layout_hints) -> new_structure` — existing raw-unit references only, strict source/hash and membership correctness, transitive requirements; failure to reserve bounded work publishes no unprocessed bindings and marks partial.
- Existing `parse_pdf_bytes` remains the PDF frontend. `_pdf_text_blocks(page, *, geometry_out=None)` still returns legacy three-tuples; one `get_text(dict)` call supplies additive `pdf-geometry/1` metadata. Parser/rawUnit version unchanged.
- Layout feature version `1.1.0`; no second parser, new locator namespace, authorization file, model validator, or mutable storage.

## Honest residual gaps

All four true PDFs still expose aggregate block/table-region bboxes. They correctly produce zero fine table column/cell assignments, zero actual column lanes, partial layout coverage. MINISO target p12 added font headings=0. Source font-heading counts are capability counters, **not independently scored precision or full semantic recall**. Unscanned table pages and one MINISO opaque page remain explicit. No claim of solved fine-cell geometry, fully read tables, production activation, paid-model summary quality or HTML/PPTX/DOCX geometry.

## ROOT next step

Run the single joint big-node suite, receive the stable handoff, commit/push once. Do not rerun four originals unless a concrete parser/locator change needs validation. This worker is FROZEN/STOP; no more source writes or Git operations.
