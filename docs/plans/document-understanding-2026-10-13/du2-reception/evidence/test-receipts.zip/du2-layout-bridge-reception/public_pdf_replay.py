"""One read-only public PDF->DU->summary->original-byte replay, no model."""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import sys
import tempfile
import time
import traceback

root = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(root / "src"))
sys.path.insert(0, str(root / "tests/fixtures/document_understanding_layout_hints"))
from real_probe import PROBE_SAMPLES
from company_wiki.source_catalog.narrative_evidence import parse_pdf_bytes, verify_pdf_evidence_spans_bytes, _make_unit
from company_wiki.document_understanding import understand_units
from company_wiki.document_understanding.summary_input import build_summary_input
from company_wiki.document_understanding.observation_adapter import build_observation

args = argparse.ArgumentParser()
args.add_argument("--bindings", required=True)
bindings = json.loads(Path(args.parse_args().bindings).read_text(encoding="utf8"))
records = []
start = time.monotonic()
with tempfile.TemporaryDirectory(prefix="du2-public-pdf-") as scratch:
    scratch = Path(scratch)
    sentinel = scratch / "sentinel"
    sentinel.write_bytes(b"owned-pristine")
    for spec in PROBE_SAMPLES:
        path = Path(bindings[spec["sample_id"]])
        before = (hashlib.sha256(path.read_bytes()).hexdigest(), path.stat().st_mtime_ns, path.stat().st_size)
        record = {"sample_id": spec["sample_id"], "source_sha256": spec["sha256"], "status": "FAIL"}
        item_start = time.monotonic()
        try:
            assert before[0] == spec["sha256"]
            data = path.read_bytes()
            source = "urn:company-wiki:source:sha256:" + before[0]
            parsed = parse_pdf_bytes(data, source_id=source, source_sha256=before[0])
            record.update(units=len(parsed.units), pages=parsed.page_count,
                          source_font_units=sum(u.metadata.get("font_size") is not None for u in parsed.units),
                          source_dimension_units=sum(u.metadata.get("page_width") is not None and u.metadata.get("page_height") is not None for u in parsed.units),
                          parser_complete=parsed.coverage_complete, opaque_pages=list(parsed.opaque_pages), deferred_table_page_count=len(parsed.deferred_table_pages))
            before_obs = build_observation(parsed.units, source_id=source, source_sha256=before[0])
            kind = "annual" if "annual" in spec["sample_id"] else "offering"
            pipeline = understand_units(parsed.units, source_id=source, source_sha256=before[0],
                declared_kind=kind, title=spec["label"], native_scan="complete" if parsed.coverage_complete else "partial",
                opaque_pages=parsed.opaque_pages, deferred_pages=parsed.deferred_table_pages)
            summary = build_summary_input(pipeline)
            sent = {m["unit_id"]: m for e in summary["evidence_packages"] for m in e["members"]}
            assert sent, "No summary evidence was materialised"
            by_id = {u.unit_id: u for u in parsed.units}
            spans = []
            for uid, member in sent.items():
                unit = by_id[uid]
                assert member["locator"] == unit.coordinates.locator()
                assert member["text"] == unit.raw_text
                spans.append(unit.to_evidence_span(topics=["read_only_du2_replay"], selection_reasons=["public_summary_member"]))
            # Additive geometry must not alter source identity, historical text,
            # locator or parser version. No second implementation of the parser.
            for unit in parsed.units:
                legacy = _make_unit(source_id=unit.source_id, parser_version=unit.parser_version,
                    coordinates=unit.coordinates, raw_text=unit.raw_text, unit_kind=unit.unit_kind,
                    source_role=unit.source_role, language=unit.language,
                    metadata={k:v for k,v in unit.metadata.items() if k not in {"font_size", "font_weight", "page_width", "page_height", "geometry_feature_version", "geometry_granularity"}})
                assert legacy.unit_id == unit.unit_id
            verified, failed = verify_pdf_evidence_spans_bytes(data, source_id=source,
                source_sha256=before[0], evidence_spans=spans)
            assert not failed, str(failed[:3])
            assert set(verified) == {span.span_id for span in spans}
            post_units = pipeline["observation"]["units"]
            pre = {u["unit_id"]:u for u in before_obs["units"]}
            new_headings = [u for u in post_units if u.get("hints", {}).get("heading_level") is not None and pre[u["unit_id"]].get("hints", {}).get("heading_level") is None]
            layout = pipeline["layout_hints"]
            fine_columns = [c.get("column") for g in layout.get("groups", ()) for c in g.get("cells", ()) if c.get("column") is not None]
            assert not fine_columns, "Aggregate parser boxes must not become fine table cells"
            record.update(status="PASS", route_family=pipeline["route"].get("family"),
                sections=len(pipeline["structure"]["sections"]), materialised_packages=len(summary["evidence_packages"]),
                materialised_units=len(sent), summary_chars=summary["budget"]["chars_used"], replayed_spans=len(verified),
                added_font_headings=len(new_headings), selected_probe_page_added_headings=sum(u.get("page") in spec["pages"] for u in new_headings),
                actual_column_lane_units=sum(u.get("hints", {}).get("column_lane") is not None for u in post_units),
                invented_fine_table_columns=len(fine_columns), layout_complete=layout["coverage"]["complete"],
                layout_work=next((d.get("detail") for d in layout["diagnostics"] if d.get("code")=="WORK_UNITS"),None),
                diagnostics=dict(Counter(d.get("code") for d in pipeline.get("diagnostics", ()))))
        except Exception as exc:
            record.update(error=str(exc), traceback=traceback.format_exc(limit=5))
        finally:
            after = (hashlib.sha256(path.read_bytes()).hexdigest(), path.stat().st_mtime_ns, path.stat().st_size)
            record["source_unchanged"] = before == after
            assert before == after
            record["elapsed_seconds"] = round(time.monotonic()-item_start,3)
            records.append(record)
            print(json.dumps(record,ensure_ascii=False), flush=True)
    assert sentinel.read_bytes() == b"owned-pristine"
report = {"status": "PASS" if all(r["status"]=="PASS" for r in records) else "FAIL",
          "samples":records,"elapsed_seconds":round(time.monotonic()-start,3),
          "tmp_removed":not scratch.exists(),"sentinel_unchanged":True,"model_calls":0,"paid_usd":0,
          "raw_copies_written":0,"production_config_writes":0}
(root/".planning/du2-layout-bridge-reception/public_pdf_replay.json").write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding="utf8")
print(json.dumps({k:v for k,v in report.items() if k!="samples"},ensure_ascii=False),flush=True)
raise SystemExit(0 if report["status"]=="PASS" else 1)
