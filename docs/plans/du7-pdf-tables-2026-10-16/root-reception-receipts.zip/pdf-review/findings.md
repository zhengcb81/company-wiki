# DU7-PDF-TABLE 独立验收（冻结作者版本）

日期：2026-10-16。作者 HEAD `caca0eb61e657bead05609ec963e00c48502761f`，seed `f93507014f757591f2c55735b0895133d276cad9`，源码 base `04c7f1bc93386a5703693f9303c3a59bb7546025`。

## 结论

**REQUEST_CHANGES，尚不直接并线。** 排他源码范围、复用原binder、同预算实例、0预算入口提前返回、真实offset回切、unknown跨度和原件保全都已做到；以下共同根因由独立新控例明确暴露。旧套件通过不等于这些输入语义正确。

## 测试与真实数据

- 作者31项及原TABLE/layout/root相关回归，正常主机隔离Temp：**547 passed / 24 skipped / 0 failed，92.75秒 pytest（整进程139.22秒）**。`concentrated.log/xml`。
- 新增独立6控例：**6 failed**，`independent-red.log/xml`；这是保留的RED证据，不隐藏为基础失败。
- 真实名创2024双语年报p12，原件SHA `07f4937e0558fc31189a56236313ad93c1cef4182adb10ebaf4f355acb9bf1cf`：单次原parser→现adapter/layout→本组件→原binder；2表28格16measurements（12bound/4ambiguous），每项回切原文一致，2M预算下总1,162,939，其中组件10,284。组件complete≠binder完全无歧义。`real-hk-p12.json`。
- 原件SHA、作者组件/测试/E2E与生产config SHA+mtime全部未变。Temp删除、预存sentinel保留。0供应商调用、0生产写入。
- 沙箱Temp初次不能写sentinel（工具权限问题，无测试运行），改由正常主机运行；成功运行与失败尝试不混计。
- CodeGraph先尝试作者树context，未初始化；不为只读验收建大索引。随后用主仓CodeGraph查原binder结构，并直接读精确diff内已知新文件。

## 必修共同根因

### P1-A：partial_cell边界丢失，碎片变成两个已绑定完整数值

`adapter.py::_consume_cell_entry/_build_table` 忽略 `partial_cell/native_cell_char_start/end`，同一个原生格的不同原unit片段12、34分别进入text_refs，原binder将二者均标bound。组件也complete。现有作者测试只断言refs不拼接，没有断言**不能把数值碎片当完整数值**。

修复：保留原ref可追溯性，同时在已有DU4 presence语义表达whole-value不可用，不能新造1234或让12/34进入可信数值。禁止改原binder迎合新投影。对本质需要更多上游几何的信息继续unknown。

### P1-B：最左原生槽≠观察到行标签

`_build_table` 对每个多格数据行强制首格为label。独立两列2025/2024、数据10/20，无行标签观察：10静默变label从measurements删除，20带row_label=10且bound。作者交接承认转置表风险，但实现并非“缺失即unknown”。

修复：只使用可说明来源的行标签证据；至少所有纯数值/partial/不确定槽不可提升成label。无证据的值要保留为值或标unknown，不可为了旧新测试的样本形状猜语义。生产接口仍缺真实row-label观察时需向ROOT交明确残余缺口。

### P1-C：表准备先做未计费二次扫描，再发现余额用尽

`_build_table` 的missing_rows对每行扫描全scope.order，row_slots再次每行扫全格；排序/headers/context/index部分在任何charge前完成。公共入口以刚好支付索引的预算运行，余额0仍执行：200/400/800行分别**124,491 / 488,891 / 1,937,691**个adapter trace line（3次sorted），实际约0.105/0.365/1.608秒。新sentinel控例直接证明0余额时仍遍历slot。

修复：一次按真实row建索引，排序及可知长度批次先预付，遍历逐项收费；已有used和唯一WorkBudget不变。不是增大预算或按公司跳过表。

### P2-D：丢弃坏slot后仍complete

`CELL_SLOT_MISMATCH`发生但同一行还有其他格时，顶层/表truncated仍complete/false；`DEGRADING_CODES`定义但未参与状态决定。独立控例19错table被丢弃，18仍bound，组件complete。应有partial并保留分母/缺口，避免后续将丢失当完整。

### P2-E：fine.page与owner.page矛盾不检查

fine cell明示page9、owner/scope page1仍原样落入page1表、组件complete；无跨页诊断。原生page/table/parent一致性应在消费entry阶段处理，不能改写为owner位置。

### P2-F：header_for只处理from组，忽略to组作用域

把table-A的数据行作为header组、关系明确指向foreign parent的table-B；A仍被标header，所有自身数值被表头规则排除。应按真实(parent/table/page)目标关系闭合，不为不相容作用域推表头；新header证据不能仅依group_id出现。

## 尚未验收/不扩大本次范围

- 金禾可转债p223/224受上游64页fine捕获上限影响：原作者真实记录0表partial，本审查保留为**绑定质量NOT_RUN/OPEN**。p25/26不能替代深页holdout。
- 生产选择闭包、正式LLM摘要、缓存恢复、下游RF不是本卡组件C的通过内容。
- 作者将E2E放仓根`e2e/run_e2e.py`，ROOT并线应移动到自有计划e2e避免共享入口归属扩大，属于整理而非质量门。

## 下一步（ROOT已授权）

冻结以上RED与真实证据后，在 ROOT 独立 `company-wiki-du67-integration` 修组件和新增ROOT测试；不改作者树/原parser/binder/旧gold/生产配置，不Git提交。修后集中回归、原RED→GREEN与清理单独留证。当前报告不会因为后续修复覆盖历史作者结果。
