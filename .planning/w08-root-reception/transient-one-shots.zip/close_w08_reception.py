"""Publish concise ROOT facts; preserve historical reports and author inputs."""
from pathlib import Path
import hashlib
import json
import zipfile

ROOT=Path(__file__).resolve().parents[2]
PLAN=ROOT/'docs/plans/cross-market-rf-e2e-2026-10-08'
W08=PLAN/'phase6/w08_parallel_completion_2026-10-12'
HERE=Path(__file__).resolve().parent
RF='b9208a2117b8423f4b355dfca885aaf0d56a05bb'
AUDIT='e5189a0614477d4d84c9cd4e0237f9b2a64a059a'
archive=HERE/'rf/native-evidence.zip'
assert not archive.exists(), 'one-shot close: do not rerun'
files=[p for name in ['native-final','publish-final'] for p in (HERE/'rf'/name).iterdir() if p.is_file()]
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in files:z.write(p,p.relative_to(HERE/'rf').as_posix())
with zipfile.ZipFile(archive) as z:
    for p in files:assert z.read(p.relative_to(HERE/'rf').as_posix())==p.read_bytes()
raw_bytes=sum(p.stat().st_size for p in files)
for p in files:p.unlink()
for name in ['native-final','publish-final']:(HERE/'rf'/name).rmdir()
acceptance={
 'schema_version':'w08-root-acceptance/1','status':'ACCEPTED_ENGINEERING_SCOPE',
 'rf':{'main_sha':RF,'remote_sha':RF,'focused_passed':76,'focused_skipped':8,'focused_seconds':3.51,
       'native_cases':31,'native_pass':20,'native_reject_ok':11,'native_errors':0,'public_cli_cases':3,
       'native_seconds':2.988074,'pre_push_passed':390,'pre_push_subtests':36,'pre_push_seconds':46.25,
       'ci_run':38367459762,'ci_conclusion':'success','ci_url':'https://github.com/zhengcb81/revenue-forecast/actions/runs/38367459762',
       'owner_wip_files':150,'owner_wip_sha_mtime_unchanged':True,'core_files_changed':0,'install_needed':False},
 'audit':{'main_sha':AUDIT,'remote':'none','focused_passed':67,'focused_seconds':9.14,
       'full_passed':444,'full_subtests':122,'full_seconds':84.24,'real_cli_calls':14,
       'independent_review':'audit/independent-review/final-review.md','installed_changed_files_per_copy':6,
       'installed_package_files_per_copy':31,'installed_copies':2,'installed_cli_checks':6,
       'installed_cli_seconds':2.161965,'scratch_restored':True,'quality_status':'not_evaluated'},
 'archive':{'path':'rf/native-evidence.zip','bytes':archive.stat().st_size,'uncompressed_bytes':raw_bytes,
       'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'roundtrip_verified':True,'duplicate_files_removed':len(files)},
 'preservation':{'raw_originals_modified':0,'model_calls':0,'paid_calls':0,'du_worktrees_written':0,'authors_written':0},
 'limits':'Engineering tests do not prove real source truth, four-agent independence or economic forecast quality; mother G2/G4/G5 and DU integration remain open.'}
(HERE/'acceptance-2026-10-13.json').write_text(json.dumps(acceptance,ensure_ascii=False,indent=2)+'\n',encoding='utf8',newline='\n')
summary=f'''## W08 ROOT接收完成 — 2026-10-13

RF主线/远端 `{RF}`，精确CI [38367459762](https://github.com/zhengcb81/revenue-forecast/actions/runs/38367459762) success。76集中PASS/8专用路径scalar检查SKIP；31实际原生案例20PASS11REJECT_OK、3公开CLI、2.988秒，390＋36正常pre-push通过。真实dated ancestry、独立actual、公有snapshot/backtest已修；不改scripts/core。RF原150文件owner WIP SHA/mtime保持，未提交到main。

Audit本地主线 `{AUDIT}`（无remote，不创建公开remote）；444PASS＋122subtests、67集中、14真实CLI、独立agent最终反例全部收口。两安装副本各6定点变更/31文件一致，6fresh安装CLI通过2.162秒，临时根恢复。实读入口已接入SKILL/workflow；缺hash仅诊断，未知不认证，无新增人签/许可。

W08三包现均已接收并线（CWP前次已发布）。本轮0模型/费用/原件改动，DU三包/作者目录未写。RF两次大节点证据已逐字节验证ZIP归档{archive.stat().st_size}字节，删除{raw_bytes}字节自有重复JSON/MD，未删除原件。详[ROOT验收](../../../../.planning/w08-root-reception/acceptance-2026-10-13.json)。

本次关闭离线工程验收范围；真实来源/摘要/预测质量不由这些测试认证。完整母目标仍开放：ROOT下一步准备真实G2配置/输入与预算，三DU包交付后集中接线，复用G2/G4/G5真实验证与审计循环，不再重复派W08。

'''
for p in [W08/'README.md',W08/'task_plan.md',W08/'findings.md',W08/'progress.md']:
    raw=p.read_bytes();p.write_bytes(summary.encode('utf8')+raw)
for p in [PLAN/'task_plan.md',PLAN/'findings.md',PLAN/'progress.md']:
    short='## 2026-10-13 W08接收并线完成\n\nRF主线/远端b9208a21、精确CI38367459762绿；Audit主线e5189a0且两安装副本已实测。W08三包已关闭离线工程接收，详[当前接收结果](phase6/w08_parallel_completion_2026-10-12/README.md)。RF150文件WIP保持，DU三包仍各自独立施工；G2/G4/G5及完整母目标未完成。Next Step：准备真实G2输入/配置/预算及DU集成，使用一个大节点验证，不再派W08。\n\n'
    p.write_bytes(short.encode('utf8')+p.read_bytes())
p=PLAN/'phase6/w06_parallel_verification_2026-10-11/ROOT-reception-status.md'
prefix='> 2026-10-13最新：W08 RF/Audit均已验收并主线；RF b9208a21/精确CI38367459762绿，Audit e5189a0/两安装副本6CLI绿。W08三包完成，详[接收汇总](../w08_parallel_completion_2026-10-12/README.md)。DU三包仍独立施工；真实G2/G4/G5未完成。以下旧pending仅为历史。\n\n'
p.write_bytes(prefix.encode('utf8')+p.read_bytes())
p=W08/'dispatch.json';d=json.loads(p.read_text(encoding='utf8'));d['state']='ALL_W08_ENGINEERING_ACCEPTED'
for lane in d['lanes']:
    if lane['lane_id']=='W08-RF-COMBOS':lane.update(status='ACCEPTED_PUBLISHED',root_implementation_sha=RF,main_sha=RF,ci_run=38367459762)
    if lane['lane_id']=='W08-AUDIT-EVIDENCE':lane.update(status='ACCEPTED_MAIN_INSTALLED',root_implementation_sha=AUDIT,main_sha=AUDIT,installed_copies=2)
p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf8',newline='\n')
for name in ['task_plan.md','findings.md','progress.md']:
    p=HERE/name
    heading='## 2026-10-13 当前接收结果\n\nW08三包离线工程接收完成，RF main/origin b9208a21（精确CI38367459762绿）、Audit main e5189a0及两安装副本6CLI绿。详acceptance-2026-10-13.json及audit/independent-review/final-review.md。A/B/C本卡均完成，整个母目标仍开放。下一步G2准备/DU集成；旧pending为历史。\n\n'
    p.write_bytes(heading.encode('utf8')+p.read_bytes())
print(json.dumps({'archive_bytes':archive.stat().st_size,'owned_duplicate_bytes_removed':raw_bytes,'acceptance':str(HERE/'acceptance-2026-10-13.json')}))
