from pathlib import Path
import ast

AUDIT=Path('C:/Users/郑曾波/Projects/_harness_worktrees/w08-root/audit')
RF=Path('C:/Users/郑曾波/Projects/_harness_worktrees/w08-root/rf')

def replace_function(p,name,new):
    s=p.read_text(encoding='utf8');n=next(n for n in ast.walk(ast.parse(s)) if isinstance(n,ast.FunctionDef) and n.name==name);lines=s.splitlines(keepends=True)
    p.write_text(''.join(lines[:n.lineno-1])+new.rstrip()+'\n'+''.join(lines[n.end_lineno:]),encoding='utf8',newline='\n')

# Replace arithmetic-only W08 checks with actual malformed native compositions.
p=RF/'tools/tests/test_w08_model_combinations.py'
replace_function(p,'test_missing_quarter_is_never_zero_filled','''def test_missing_quarter_is_never_zero_filled(engine):
    from revenue_core import ForecastInputError
    data,_=CB._build_quality_zero_filled()
    derived=next(p for p in data["parameters"] if p["parameter_id"]=="dated_fy2026_base")
    assert derived["input_parameter_ids"]==["dated_post"]
    with pytest.raises(ForecastInputError,match="composition"):
        engine.run_forecast(data)
''')
replace_function(p,'test_same_flow_added_twice_is_detectable','''def test_same_flow_added_twice_is_detectable(engine):
    from revenue_core import ForecastInputError
    data,_=CB._build_quality_double_count()
    derived=next(p for p in data["parameters"] if p["parameter_id"]=="dated_fy2026_base")
    assert derived["input_parameter_ids"].count("dated_tail_base")==2
    with pytest.raises(ForecastInputError,match="double counts"):
        engine.run_forecast(data)
''')
s=p.read_text(encoding='utf8').replace('FYE 09-30 with a hand-planned two-quarter bridge: 36 + 55 = 91.','Shared baseline fixture: annual drivers 36 and 90 with FYE 09-30.');p.write_text(s,encoding='utf8',newline='\n')
p=RF/'tools/model_generalization_matrix/combinations.py';s=p.read_text(encoding='utf8')
tree=ast.parse(s);n=next(n for n in tree.body if isinstance(n,ast.AnnAssign) and isinstance(n.target,ast.Name) and n.target.id=='COMBINATION_CASES');lines=s.splitlines(keepends=True);changes=[]
for case in n.value.elts:
    key=next(k.value.value for k in case.keywords if k.arg=='case_id')
    if key not in {'C02-QGAP-C','C02-DBL-C'}:continue
    driver=next(k.value for k in case.keywords if k.arg=='drivers')
    new='{"control_window_value":12.,"missing_tail":True,"fiscal_year_end":"09-30"}' if key=='C02-QGAP-C' else '{"control_window_value":12.,"tail_value":24.,"tail_used_twice":True,"fiscal_year_end":"09-30"}'
    # Replace an entire keyword field, keeping the surrounding CaseSpec intact.
    prefix=lines[driver.lineno-1][:driver.col_offset];suffix=lines[driver.end_lineno-1][driver.end_col_offset:]
    changes.append((driver.lineno-1,driver.end_lineno,prefix+new+suffix))
for start,end,new in sorted(changes,reverse=True):lines[start:end]=[new]
p.write_text(''.join(lines),encoding='utf8',newline='\n')

# Small additive diagnostics for the independent reviewer four residual cases.
base=AUDIT/'skills/revenue-forecast-audit/scripts'
p=base/'review_evidence.py';s=p.read_text(encoding='utf8')
s=s.replace('def summarize_events(events, role, run_id):','def summarize_events(events, role, run_id, review_attempt=None):')
s=s.replace('"declared_outputs": [],','"declared_outputs": [],\n        "legacy_observation_events": 0,')
s=s.replace('            audit_run.parse_event_observation(json.dumps(record), role, run_id)',
'''            _, observation = audit_run.parse_event_observation(json.dumps(record), role, run_id)
            if observation["authority"] != "canonical":
                summary["legacy_observation_events"] += 1''')
s=s.replace('        cid = data.get("capture_id") or data.get("call_id")',
'''        if review_attempt is not None and "review_attempt" in data and data["review_attempt"] != review_attempt:
            summary["identity_mismatches"].append({"line":event["line"],"detail":"event review_attempt differs"})
            continue
        cid = data.get("capture_id") or data.get("call_id")''')
start=s.index('        result["numeric_observation"] = bool(',s.index('if shape == "line_range":'))
end=s.index('        return result',start)
s=s[:start]+'''        selected_text="\\n".join(lines[start-1:end])
        non_date_text=re.sub(r"\\b\\d{4}[-/]\\d{1,2}[-/]\\d{1,2}\\b", "", selected_text)
        result["numeric_observation"] = bool(
            re.fullmatch(r"[+-]?(?:\\d+(?:\\.\\d*)?|\\.\\d+)", non_date_text.strip())
            or "=" in non_date_text and re.search(r"\\d",non_date_text))
'''+s[end:]
p.write_text(s,encoding='utf8',newline='\n')
p=base/'review_evidence_reconcile.py';s=p.read_text(encoding='utf8')
s=s.replace('evidence.summarize_events(events, role, run_id)','evidence.summarize_events(events, role, run_id, review_attempt)')
s=s.replace('        if row["binding_status"] == "MISMATCH":',
'''        if row["binding_status"] == "UNKNOWN":
            unchecked.append(f"{role}: actual report run/role binding unknown")
        if row["binding_status"] == "MISMATCH":''')
s=s.replace('        if summary["identity_mismatches"]:',
'''        if summary["legacy_observation_events"]:
            unchecked.append(f"{role}: legacy events are observation-only; current run binding unknown")
        if summary["identity_mismatches"]:''')
p.write_text(s,encoding='utf8',newline='\n')
p=AUDIT/'tests/test_w08_root_evidence_boundaries.py';s=p.read_text(encoding='utf8')
s+='''

@pytest.mark.parametrize("mutation",["empty_report","legacy_run","old_attempt","date_line"])
def test_unknown_or_stale_observation_never_disappears(package,mutation):
    b,run=package
    if mutation=="empty_report":write_json(run/"reports/attempt-1/storage.json",{})
    elif mutation=="date_line":
        p=run/"execution/date.txt";p.write_text("Published 2026-10-13",encoding="utf8")
        b.payload["numeric_coverage"]["verified"][0]["recompute"]={"artifact":"execution/date.txt","locator":"line 1"}
    else:
        p=run/"roles/storage/events.jsonl";rows=[json.loads(x) for x in p.read_text(encoding="utf8").splitlines()]
        for row in rows:
            if mutation=="legacy_run":row.pop("run_id")
            else:row["data"]["review_attempt"]="old-attempt"
        p.write_text("\\n".join(json.dumps(r) for r in rows)+"\\n",encoding="utf8")
    out=b.reconcile(run)
    if mutation=="date_line":assert "V1" in out["numeric_reconciliation"]["unresolved_recompute_value_ids"]
    else:assert any("storage" in note for note in out["unchecked"])
'''
p.write_text(s,encoding='utf8',newline='\n')
print('Final four independent observations fixed; native C02 tests strengthened')
