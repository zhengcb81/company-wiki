"""One-shot evidence observation fixes in the isolated ROOT audit worktree."""
from pathlib import Path
import ast

ROOT=Path('C:/Users/郑曾波/Projects/_harness_worktrees/w08-root/audit')
BASE=ROOT/'skills/revenue-forecast-audit/scripts'

def function(path,name,new):
    text=path.read_text(encoding='utf8');node=next(n for n in ast.walk(ast.parse(text)) if isinstance(n,ast.FunctionDef) and n.name==name)
    lines=text.splitlines(keepends=True)
    path.write_text(''.join(lines[:node.lineno-1])+new.rstrip()+'\n'+''.join(lines[node.end_lineno:]),encoding='utf8',newline='\n')

p=BASE/'review_evidence.py';s=p.read_text(encoding='utf8').replace('import json\n','import json\nimport math\n',1);p.write_text(s,encoding='utf8',newline='\n')
function(p,'normalize_limits','''def normalize_limits(limits=None):
    """Positive finite limits within the documented engineering envelope."""
    result = dict(DEFAULT_LIMITS)
    for key, value in (limits or {}).items():
        audit_run.require(key in DEFAULT_LIMITS, f"unknown evidence limit: {key}")
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
            raise ValueError(f"evidence limit {key} must be finite")
        if key != "max_seconds" and type(value) is not int:
            raise ValueError(f"evidence limit {key} must be an integer")
        if not 0 < value <= DEFAULT_LIMITS[key]:
            raise ValueError(f"evidence limit {key} must be positive and at most {DEFAULT_LIMITS[key]}")
        result[key] = float(value) if key == "max_seconds" else value
    return result
''')
function(p,'read_bytes','''    def read_bytes(self, path):
        """Resolve once and read at most the byte envelope plus one probe byte."""
        path,kind,detail=self.resolve(str(path))
        if kind != "file":
            return {"body":None,"bytes":None,"sha256":None,"error":kind,"counted":False}
        if path in self._cache:
            return self._cache[path]
        refusal=self.budget.admit()
        record={"body":None,"bytes":None,"sha256":None,"error":refusal,"counted":False}
        if refusal is not None:
            self._cache[path]=record
            return record
        try:
            size=path.stat().st_size
            remaining=self.budget.limits["max_total_bytes"]-self.budget.bytes_read
            if size>self.budget.limits["max_file_bytes"]:
                record.update(bytes=size,error="file_byte_limit")
            elif size>remaining:
                record.update(bytes=size,error=self.budget.exhausted_or("total_byte_limit"))
            else:
                cap=min(self.budget.limits["max_file_bytes"],remaining)
                with path.open("rb") as stream:
                    body=stream.read(cap+1)
                self.budget.files_read+=1
                self.budget.bytes_read+=len(body)
                record.update(bytes=len(body),counted=True)
                if len(body)>cap:
                    record["error"]=("file_byte_limit" if cap==self.budget.limits["max_file_bytes"]
                        else self.budget.exhausted_or("total_byte_limit"))
                elif self.budget.elapsed()>=self.budget.limits["max_seconds"]:
                    record["error"]=self.budget.exhausted_or("time_limit")
                else:
                    record.update(body=body,sha256=hashlib.sha256(body).hexdigest(),error=None)
        except (OSError,ValueError) as exc:
            record["error"]=f"{type(exc).__name__}: {exc}"
        self._cache[path]=record
        return record
''')
s=p.read_text(encoding='utf8')
s=s.replace('            audit_contracts.resolve_json_pointer(document, pointer)',
'''            if len(pointer.split("/"))-1 > reader.budget.limits["max_pointer_tokens"]:
                raise ValueError("JSON pointer exceeds max_pointer_tokens")
            resolved_value = audit_contracts.resolve_json_pointer(document, pointer)''')
s=s.replace('        result["matrix_status"] = "resolved"\n        result["status"] = OBSERVED\n        result["reference_kind"] = "file_pointer"',
'''        result["matrix_status"] = "resolved"
        result["observed"]["resolved_type"] = type(resolved_value).__name__
        result["numeric_observation"] = (
            isinstance(resolved_value,(int,float)) and not isinstance(resolved_value,bool) and math.isfinite(resolved_value)
            or isinstance(resolved_value,str) and bool(re.fullmatch(r"[+-]?(?:\\d+(?:\\.\\d*)?|\\.\\d+)(?:[eE][+-]?\\d+)?",resolved_value.strip()))
            or isinstance(resolved_value,dict) and isinstance(resolved_value.get("expression"),str))
        result["status"] = OBSERVED
        result["reference_kind"] = "file_pointer"''')
s=s.replace('        result["reference_kind"] = "file_line_range"\n        return result',
'''        result["reference_kind"] = "file_line_range"
        result["numeric_observation"] = bool(re.search(r"\\d\\s*[-+*/=]|[-+*/=]\\s*\\d", "\\n".join(lines[start-1:end])))
        return result''')
p.write_text(s,encoding='utf8',newline='\n')
function(p,'summarize_events','''def summarize_events(events, role, run_id):
    """Pair actual run/role/capture observations; counts alone prove no pairing."""
    summary={"role":role,"event_count":len(events),"kinds":{},"capture_ids":[],"event_ids":[],"call_ids":[],
        "command_started":0,"command_finished":0,"output_complete_false":0,"nonzero_exit":0,"timed_out":0,
        "matched_calls":0,"unmatched_starts":[],"unmatched_finishes":[],"unknown_call_ids":0,"identity_mismatches":[],
        "declared_outputs":[]}
    starts,finishes={},{}
    for event in events:
        record=event["record"]
        try:
            audit_run.parse_event_observation(json.dumps(record),role,run_id)
        except (ValueError,TypeError,KeyError) as exc:
            summary["identity_mismatches"].append({"line":event["line"],"detail":str(exc)})
            continue
        kind=record.get("kind");summary["kinds"][kind]=summary["kinds"].get(kind,0)+1
        if isinstance(record.get("event_id"),str):summary["event_ids"].append(record["event_id"])
        data=record.get("data")
        if not isinstance(data,dict):continue
        cid=data.get("capture_id") or data.get("call_id")
        for field in ("capture_id","call_id"):
            if isinstance(data.get(field),str):summary[field+"s"].append(data[field])
        if kind not in {"command_started","command_finished"}:continue
        summary[kind]+=1
        if not isinstance(cid,str) or not cid:
            summary["unknown_call_ids"]+=1
            continue
        target=starts if kind=="command_started" else finishes
        target[cid]=target.get(cid,0)+1
        if kind=="command_finished":
            summary["output_complete_false"]+=data.get("output_complete") is False
            summary["nonzero_exit"]+=type(data.get("exit_code")) is int and data["exit_code"]!=0
            summary["timed_out"]+=data.get("timed_out") is True
            for field in ("stdout_artifact","stderr_artifact"):
                if isinstance(data.get(field),str):summary["declared_outputs"].append({"call_id":cid,"artifact":data[field]})
    for cid in sorted(set(starts)|set(finishes)):
        matches=min(starts.get(cid,0),finishes.get(cid,0))
        summary["matched_calls"]+=matches
        summary["unmatched_starts"].extend([cid]*(starts.get(cid,0)-matches))
        summary["unmatched_finishes"].extend([cid]*(finishes.get(cid,0)-matches))
    for field in ("capture_ids","call_ids","event_ids"):summary[field]=sorted(set(summary[field]))
    return summary
''')

p=BASE/'review_evidence_reconcile.py';s=p.read_text(encoding='utf8')
s=s.replace('        role_reports[role] = row',
'''        row["binding_status"]="UNKNOWN"
        row["binding_details"]=[]
        if row["json_status"]=="OBSERVED":
            path,_,_=reader.resolve(declared["json"])
            parsed,error=evidence.resolve_json_body(reader.decode_text(reader.read_bytes(path)["body"]))
            if isinstance(parsed,dict):
                mismatches=[]
                for field,want in (("run_id",run_id),("role",role),("review_attempt",review_attempt)):
                    if field in parsed and parsed[field]!=want:mismatches.append(field)
                row["binding_status"]="MISMATCH" if mismatches else "MATCH" if parsed.get("run_id")==run_id and parsed.get("role")==role else "UNKNOWN"
                row["binding_details"]=mismatches
            else:row["binding_details"]=["report JSON not parseable as object"]
        role_reports[role] = row''')
s=s.replace('    resolved_value_ids = []','    resolved_value_ids = []\n    resolved_references = {}')
s=s.replace('if row_kind == "recompute" and result["status"] == evidence.OBSERVED:',
 'if row_kind == "recompute" and result["status"] == evidence.OBSERVED and result.get("numeric_observation") is True:')
s=s.replace('            resolved_value_ids.append(row_id)',
'''            resolved_value_ids.append(row_id)
            key=(result["observed"]["resolved_artifact"],str(result["locator"]))
            resolved_references.setdefault(key,[]).append(row_id)''')
s=s.replace('        "unique_value_ids": len(seen_value_ids),',
'''        "unique_value_ids": len(seen_value_ids),
        "unique_resolved_references": len(resolved_references),
        "shared_reference_value_ids": [ids for ids in resolved_references.values() if len(ids)>1],''')
s=s.replace('if row["row_kind"] == "recompute" and row["status"] != evidence.OBSERVED',
 'if row["row_kind"] == "recompute" and row["row_id"] not in resolved_value_ids')
s=s.replace('"duplicate references never increase coverage; this tool "','"unique references and declared value IDs are separate observations; shared references do not prove distinct calculations; this tool "')
s=s.replace('        summary = event_summary[role]\n',
'''        if row["binding_status"]=="MISMATCH":
            unchecked.append(f"{role}: report contents differ from current run/role/attempt")
        summary = event_summary[role]
        if summary["identity_mismatches"]:
            unchecked.append(f"{role}: event run/role identity mismatch")
        if summary["unmatched_starts"] or summary["unmatched_finishes"] or summary["unknown_call_ids"]:
            unchecked.append(f"{role}: unmatched or unknown call ids; starts and finishes are not paired")
        for output in summary["declared_outputs"]:
            path,kind,_=reader.resolve(output["artifact"])
            if kind!="file":unchecked.append(f"{role}: declared call output artifact not observed")
''')
p.write_text(s,encoding='utf8',newline='\n')
# Synthetic legal fixture must actually contain the output it declares.
p=ROOT/'tests/test_w08_review_evidence.py';s=p.read_text(encoding='utf8')
s=s.replace('        if finished:\n            lines.append({',
'''        if finished:
            output=path.parent/"commands"/f"{role}-capture"/"stdout.txt"
            output.parent.mkdir(parents=True,exist_ok=True)
            output.write_text("synthetic fixture stdout\\n",encoding="utf8")
            lines.append({''')
p.write_text(s,encoding='utf8',newline='\n')
p=ROOT/'tests/test_w08_root_evidence_boundaries.py';s=p.read_text(encoding='utf8').replace('p.read_text()','p.read_text(encoding="utf8")').replace('p.write_text("\\n".join(json.dumps(r) for r in rows)+"\\n")','p.write_text("\\n".join(json.dumps(r) for r in rows)+"\\n",encoding="utf8")');p.write_text(s,encoding='utf8',newline='\n')
print('ROOT audit evidence observation fixes implemented')
