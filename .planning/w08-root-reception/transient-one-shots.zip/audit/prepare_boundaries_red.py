from pathlib import Path
ROOT=Path('C:/Users/郑曾波/Projects/_harness_worktrees/w08-root/audit')
p=ROOT/'tests/test_w08_root_evidence_boundaries.py'
assert not p.exists()
p.write_text('''"""ROOT counterexamples for execution evidence, not economic quality."""
import json
import sys
from pathlib import Path
import pytest
sys.path.insert(0,str(Path(__file__).resolve().parent))
from test_w08_review_evidence import PackageBuilder,EVIDENCE,write_json

@pytest.fixture
def package(tmp_path):
    b=PackageBuilder(tmp_path);return b,b.build()

@pytest.mark.parametrize("mutation",["capture","role"])
def test_real_call_identity_must_pair_not_just_counts(package,mutation):
    b,run=package;p=run/"roles/storage/events.jsonl"
    rows=[json.loads(line) for line in p.read_text().splitlines()]
    if mutation=="capture":rows[1]["data"]["capture_id"]="other"
    else:
        for row in rows:row["role"]="analyst"
    p.write_text("\\n".join(json.dumps(r) for r in rows)+"\\n")
    out=b.reconcile(run)
    assert any("storage" in note for note in out["unchecked"])
    assert out["events"]["storage"]["matched_calls"]==0

def test_current_report_actual_fields_detect_stale_content(package):
    b,run=package;p=run/"reports/attempt-1/storage.json"
    row=json.loads(p.read_text());row.update(run_id="old-run",role="analyst",review_attempt="old-attempt");write_json(p,row)
    out=b.reconcile(run)
    assert out["role_reports"]["storage"]["binding_status"]=="MISMATCH"
    assert any("storage" in note for note in out["unchecked"])

@pytest.mark.parametrize("locator",["invented result paragraph","/run_id"])
def test_opened_file_or_metadata_is_not_numeric_recompute(package,locator):
    b,run=package;b.payload["numeric_coverage"]["verified"][0]["recompute"]["locator"]=locator
    out=b.reconcile(run)
    assert "V1" in out["numeric_reconciliation"]["unresolved_recompute_value_ids"]
    assert out["numeric_reconciliation"]["recompute_rows_observed"]==2

def test_shared_reference_reports_unique_count_without_refusing_reuse(package):
    b,run=package;rows=b.payload["numeric_coverage"]["verified"];rows[1]["recompute"]=dict(rows[0]["recompute"])
    out=b.reconcile(run);n=out["numeric_reconciliation"]
    assert n["unique_resolved_references"]==2
    assert n["recompute_rows_observed"]==3
    assert n["shared_reference_value_ids"]

@pytest.mark.parametrize("limits",[{"max_seconds":float("nan")},{"max_seconds":float("inf")},{"max_files":.5},{"max_files":999999}])
def test_limits_reject_nonfinite_fractional_or_above_declared_envelope(limits):
    with pytest.raises(ValueError):EVIDENCE.normalize_limits(limits)

def test_growth_is_bounded_at_read_time(tmp_path,monkeypatch):
    p=tmp_path/"growth.txt";p.write_bytes(b"x")
    native=Path.open
    def growth(path,*args,**kwargs):
        if path==p:
            with native(path,"wb") as stream:stream.write(b"x"*40)
        return native(path,*args,**kwargs)
    monkeypatch.setattr(Path,"open",growth)
    reader=EVIDENCE.EvidenceReader(tmp_path,limits={"max_file_bytes":4,"max_total_bytes":8})
    row=reader.read_bytes(p)
    assert row["error"]=="file_byte_limit"
    assert row["body"] is None and row["sha256"] is None
    assert reader.budget.bytes_read<=5

def test_pointer_limit_is_applied_not_only_declared(tmp_path):
    p=tmp_path/"v.json";write_json(p,{"a":{"b":10}})
    reader=EVIDENCE.EvidenceReader(tmp_path,limits={"max_pointer_tokens":1})
    out=EVIDENCE.inspect_reference(reader,{"artifact":"v.json","locator":"/a/b"})
    assert out["status"]!="OBSERVED"

def test_valid_calls_pair_and_byte_diagnostics_remain_not_quality(package):
    b,run=package;out=b.reconcile(run)
    assert out["events"]["storage"]["matched_calls"]==1
    assert out["quality_status"]=="not_evaluated"
    assert out["numeric_reconciliation"]["recompute_rows_observed"]==3
''',encoding='utf8',newline='\n')
print(p)
