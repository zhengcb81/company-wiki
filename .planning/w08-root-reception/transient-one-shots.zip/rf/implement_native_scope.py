"""One-shot ROOT repair, confined to the new RF reception worktree."""
from pathlib import Path
import ast

ROOT=Path('C:/Users/郑曾波/Projects/_harness_worktrees/w08-root/rf')
BASE=ROOT/'tools/model_generalization_matrix'

def function(path,name,new):
    text=path.read_text(encoding='utf8');tree=ast.parse(text)
    node=next(n for n in ast.walk(tree) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name==name)
    lines=text.splitlines(keepends=True)
    path.write_text(''.join(lines[:node.lineno-1])+new.rstrip()+'\n'+''.join(lines[node.end_lineno:]),encoding='utf8',newline='\n')

p=BASE/'bootstrap.py'
s=p.read_text(encoding='utf8');start=s.index('    def evaluate_draft_scope(');end=s.index('    return SimpleNamespace(',start)
s=s[:start]+s[end:]
s=s.replace('from revenue_backtest import _summarize_records','from revenue_backtest import create_snapshot, evaluate_snapshot')
s=s.replace('        evaluate_draft_scope=evaluate_draft_scope,','        create_snapshot=create_snapshot,\n        evaluate_snapshot=evaluate_snapshot,')
p.write_text(s,encoding='utf8',newline='\n')
function(BASE/'native.py','evaluate_history','''    def evaluate_history(self, data: dict[str, Any], actuals: dict[str, Any]) -> dict[str, Any]:
        """Real public snapshot/backtest, entirely in an isolated test registry.

        The matrix forecasts remain draft. This one engineering-only fixture
        exercises the existing publication/snapshot interface; no production
        artifacts, source truth, or research conclusions are produced.
        """
        import os
        import tempfile

        snapshot_ref = NativeRef(entry="revenue_backtest.create_snapshot",
            request_sha256=_sha(data), request=copy.deepcopy(data))
        self.refs.append(snapshot_ref)
        previous = os.environ.get("REVENUE_PUBLICATION_REGISTRY")
        with tempfile.TemporaryDirectory(prefix="w08-backtest-") as directory:
            os.environ["REVENUE_PUBLICATION_REGISTRY"] = directory
            try:
                snapshot = self._rt.create_snapshot(copy.deepcopy(data), "w08-engineering")
                snapshot_ref.result = snapshot
                snapshot_ref.result_sha256 = _sha(snapshot)
                request = {"snapshot": copy.deepcopy(snapshot), "actuals": copy.deepcopy(actuals)}
                ref = NativeRef(entry="revenue_backtest.evaluate_snapshot",
                    request_sha256=_sha(request), request=request)
                self.refs.append(ref)
                try:
                    evaluation = self._rt.evaluate_snapshot(snapshot, copy.deepcopy(actuals))
                except Exception as exc:
                    ref.exception_type = type(exc).__name__
                    ref.exception_message = str(exc)
                    raise
                ref.result, ref.result_sha256 = evaluation, _sha(evaluation)
                return evaluation
            except Exception as exc:
                if snapshot_ref.result is None:
                    snapshot_ref.exception_type = type(exc).__name__
                    snapshot_ref.exception_message = str(exc)
                raise
            finally:
                if previous is None:
                    os.environ.pop("REVENUE_PUBLICATION_REGISTRY", None)
                else:
                    os.environ["REVENUE_PUBLICATION_REGISTRY"] = previous
''')

p=BASE/'combinations.py'
function(p,'_build_quality_wrong_fye','''def _build_quality_wrong_fye():
    data, observe = _build_dated_contribution()
    data["fiscal_year_end"] = "13-45"
    return data, observe
''')
function(p,'_build_quality_zero_filled','''def _build_quality_zero_filled():
    data, observe = _build_dated_contribution()
    for p in data["parameters"]:
        if p["parameter_id"].startswith("dated_fy2026_"):
            p.update(value=12.0, formula="x0", input_parameter_ids=["dated_post"], rationale="")
    return data, observe
''')
function(p,'_build_quality_double_count','''def _build_quality_double_count():
    data, observe = _build_dated_contribution()
    for p in data["parameters"]:
        if p["parameter_id"].startswith("dated_fy2026_"):
            scenario=p["scenario"]
            p.update(value=12.0+2*{"low":20.,"base":24.,"high":28.}[scenario],
                formula="x0+x1+x2", input_parameter_ids=["dated_post", f"dated_tail_{scenario}", f"dated_tail_{scenario}"])
    return data, observe
''')
function(p,'_build_actual_scope','''def _build_actual_scope():
    from test_recognition_bridge import forecast_document
    return forecast_document(), _annual_observe
''')
function(p,'_build_actual_coverage_counter','''def _build_actual_coverage_counter():
    return _build_actual_scope()
''')
s=p.read_text(encoding='utf8')
insert='''
def _build_dated_contribution():
    from test_w05_dated_contribution_contract import add_window_parameter, parameter
    data=_quality_document()
    data["schema_version"]="3.10"
    add_window_parameter(data,"dated_post",12.,"2026-05-31","2026-06-30",2026,
        definition="acquired entity contribution after control date")
    ids={}
    for scenario,tail in {"low":20.,"base":24.,"high":28.}.items():
        add_window_parameter(data,f"dated_tail_{scenario}",tail,"2026-07-01","2026-09-30",2026,
            kind="scenario_stress",claim=False,definition="remaining controlled fiscal-year contribution")
        parameter(data,f"dated_tail_{scenario}")["scenario"]=scenario
        fy=f"dated_fy2026_{scenario}"
        add_window_parameter(data,fy,12.+tail,"2025-10-01","2026-09-30",2026,
            kind="derived_fact",claim=False,formula="x0+x1",input_parameter_ids=["dated_post",f"dated_tail_{scenario}"],
            definition="full fiscal-year contribution after control date",rationale="Pre-control 2025-10-01..2026-05-30 outside consolidation scope, not missing or zero-filled; control begins 2026-05-31.")
        parameter(data,fy)["scenario"]=scenario
        next_id=f"dated_fy2027_{scenario}"
        add_window_parameter(data,next_id,{"low":50.,"base":60.,"high":70.}[scenario],"2026-10-01","2027-09-30",2027,
            kind="scenario_stress",claim=False,definition="next full fiscal-year acquired contribution")
        parameter(data,next_id)["scenario"]=scenario
        ids[scenario]=[fy,next_id]
    data["forecast_adjustments"]=[{"name":"acquired_entity","category":"acquisition_contribution","scenario_parameter_ids":ids}]
    def observe(result):
        out=_annual_observe(result)
        out["contribution"]={"2026": result["consolidated_forecast"]["base"]["annual_revenue"]["2026"]-91.,
                             "2027": result["consolidated_forecast"]["base"]["annual_revenue"]["2027"]-150.5}
        out["dated_windows"]=[{k:p.get(k) for k in ("parameter_id","period_start","period_end","input_parameter_ids")} for p in data["parameters"] if p["parameter_id"].startswith("dated_")]
        return out
    return data,observe

'''
s=s.replace('# --- C03 joint volume/price',insert+'# --- C03 joint volume/price',1)
# Update only new W08 CaseSpecs; frozen W07 list and all original checks stay.
tree=ast.parse(s);cases=next(n for n in tree.body if isinstance(n,ast.AnnAssign) and isinstance(n.target,ast.Name) and n.target.id=='COMBINATION_CASES')
lines=s.splitlines(keepends=True)
changes={}
for node in cases.value.elts:
    key=next(k.value.value for k in node.keywords if k.arg=='case_id')
    if key not in {'C02-FY-L','C02-QGAP-C','C02-DBL-C','C05-ACT-L'}:continue
    chunk=''.join(lines[node.lineno-1:node.end_lineno])
    if key=='C02-FY-L':
        chunk=chunk.replace('build=_build_quality_cleaned','build=_build_dated_contribution')
        chunk=chunk.replace('"2026": 91.0, "2027": 150.5','"2026": 127.0, "2027": 210.5')
        chunk=chunk.replace('"fy2026_q1": 36.0, "fy2026_q2": 36.0','"fy2026_control_window": 12.0, "fy2026_tail": 24.0')
        chunk=chunk.replace('"2026": 36.0 + 55.0, "2027": 90.0 + 60.5','"2026": 36.0 + 55.0 + 12.0 + 24.0, "2027": 90.0 + 60.5 + 60.0')
    elif key in {'C02-QGAP-C','C02-DBL-C'}:
        chunk=chunk.replace('expected=_e({"annual": {"2026": 91.0, "2027": 150.5}})','expected=_e({}, reject=True, reject_reason="composition" if '+repr(key)+' == "C02-QGAP-C" else "double counts")')
    elif key=='C05-ACT-L':
        chunk=chunk.replace('"segment_names": ["Segment A", "Segment B"]','"segment_names": ["Segment A"]')
        chunk=chunk.replace('"future_years_registered_as_actual": [],','"future_years_registered_as_actual": [],\n                "wape": (5.+11.5)/(160.+170.),')
    changes[(node.lineno-1,node.end_lineno)]=chunk
for (start,end),chunk in sorted(changes.items(),reverse=True):lines[start:end]=[chunk]
s=''.join(lines)
s=s.replace('FY2026 recognized revenue is q1 + q2 (36 + 36 = 72 base); FY2027 is its own','This shared annual-driver fixture supplies FY2026=36; FY2027 is its own')
s=s.replace('Segment A FY2026 recognized revenue = Q1 2026 + Q2 2026 bridge','Segment A FY2026 annual recognized revenue (synthetic baseline)')
p.write_text(s,encoding='utf8',newline='\n')

function(BASE/'runner.py','_run_actual_scope','''def _run_actual_scope(spec, engine, res):
    from test_backtest import actuals_document
    data,_=spec.build()
    evaluation=engine.evaluate_history(data,actuals_document())
    years=sorted(evaluation["company_year_results"])
    cells=[f"{segment}|{year}" for segment,records in evaluation["segment_year_results"].items() for year in sorted(records)]
    res.observed={"company_name":evaluation["company_name"],"declared_years":years,
        "segment_cells":cells,"currency":evaluation["currency"],"unit":evaluation["unit"],
        "wape":evaluation["summary"]["wape"],"future_years_registered_as_actual":[]}
    res.assertions.extend(_compare_map("actual",spec.expected.values,res.observed))
    res.assertions.append(_compare_value("segment_names",spec.expected.values["segment_names"],list(evaluation["segment_year_results"])))
    # The observed company horizon and segment cells must come from actuals.
    res.assertions.append(_compare_value("actual_years",["2026","2027"],years))
    res.status="PASS" if all(a.passed for a in res.assertions) else "FAIL"
    return res
''')
function(BASE/'runner.py','_run_actual_coverage','''def _run_actual_coverage(spec, engine, res):
    from test_backtest import actuals_document
    from revenue_core import ForecastInputError
    data,_=spec.build()
    actuals=actuals_document()
    actuals["actual_company_revenue"].pop("2027")
    actuals["actual_segment_revenue"]["Segment A"].pop("2027")
    actuals["actual_segment_revenue"]["Segment B"]={}
    evaluation=engine.evaluate_history(data,actuals)
    bad=actuals_document()
    bad["sources"][0]["published_date"]="2026-05-20"
    rejection=None
    try:
        engine.evaluate_history(data,bad)
    except ForecastInputError as exc:
        rejection=str(exc)
    foreign=evaluation["segment_summaries"]["Segment B"]
    res.observed={"actual_company_years":sorted(evaluation["company_year_results"]),
        "actual_segment_cells":[f"{name}|{year}" for name,records in evaluation["segment_year_results"].items() for year in sorted(records)],
        "unobserved_wape":foreign["wape"],"foreign_scope_observations":foreign["observations"],
        "future_actual_rejection":rejection,
        "scope_interpretation":"observed actuals only; calibration effectiveness not evaluated"}
    res.assertions.extend([
        _compare_value("actual_company_years",["2026"],res.observed["actual_company_years"]),
        _compare_value("actual_segment_cells",["Segment A|2026"],res.observed["actual_segment_cells"]),
        _compare_value("unobserved_wape",None,foreign["wape"]),
        _compare_value("foreign_scope_observations",0,foreign["observations"]),
        Assertion("future_actual_rejection","predates fiscal year end",rejection,
            bool(rejection and "predates fiscal year end" in rejection),"reject")])
    res.status="PASS" if all(a.passed for a in res.assertions) else "FAIL"
    return res
''')
p=BASE/'runner.py';s=p.read_text(encoding='utf8');s=s.replace('"wape":evaluation["summary"]["wape"],"future_years_registered_as_actual":[]}',
 '"wape":evaluation["summary"]["wape"],"future_years_registered_as_actual":[],\n        "segment_names":list(evaluation["segment_year_results"])}')
p.write_text(s,encoding='utf8',newline='\n')
print('ROOT native RF tools repaired; no scripts/core changes')
