# Model Generalization Matrix (`model-generalization-matrix/1`)

- execution status: COMPLETE
- combination coverage: COMPLETE
- generated_at: 2026-10-13T07:52:16.661363+00:00
- wall_seconds: 2.544546
- source_truth_verified: False
- economic_reasonableness: not_evaluated

Finite cross-mechanism combination stress matrix over the native draft engine. Synthetic engineering vectors; no real company, no source truth, no buy-side conclusion.

## Counts

| total | passed | failed | reject_ok | reject_mismatch | errored | not_run |
|---|---|---|---|---|---|---|
| 31 | 20 | 0 | 11 | 0 | 0 | 0 |

## Class status

| class | status |
|---|---|
| C01 | PASS |
| C02 | PASS |
| C03 | PASS |
| C04 | PASS |
| C05 | PASS |
| M01 | PASS |
| M02 | PASS |
| M03 | PASS |
| M04 | PASS |
| M05 | PASS |
| M06 | PASS |
| M07 | PASS |
| M08 | PASS |

## Combination group coverage (C01-C05)

- status: COMPLETE
- open groups: []
- required cases: 31

| group | status | required | observed | missing |
|---|---|---|---|---|
| C01 | CLOSED | 4 | 4 | [] |
| C02 | CLOSED | 4 | 4 | [] |
| C03 | CLOSED | 2 | 2 | [] |
| C04 | CLOSED | 3 | 3 | [] |
| C05 | CLOSED | 2 | 2 | [] |

## Cases

### M01-L — PASS

- class: M01  vector: legal  mode: draft
- boundary: quantity x price computes revenue at an explicit currency/unit label
- expected: `{"values": {"revenue": {"2026": 50.0, "2027": 60.0}}, "reject": false, "reject_reason": null, "unknown_fields": []}`
- observed: `{"revenue": {"2026": 50.0, "2027": 60.0}}`
  - ✓ input_driver[units] (input): expected=[10.0, 12.0] observed=[10.0, 12.0]
  - ✓ input_driver[unit_revenue] (input): expected=[5.0, 5.0] observed=[5.0, 5.0]
  - ✓ conversion[5.0 usd_million->usd_thousand] (value): expected=5000.0 observed=5000.0
  - ✓ revenue.2026 (value): expected=50.0 observed=50.0
  - ✓ revenue.2027 (value): expected=60.0 observed=60.0

### M01-C — REJECT_OK

- class: M01  vector: counter  mode: draft
- boundary: mixed currency/units are refused or explicitly converted, never auto-FX
- expected: `{"values": {}, "reject": true, "reject_reason": "incompatible unit conversion", "unknown_fields": []}`
- observed: `{"attempts": ["usd_million->rmb_million: ForecastInputError: incompatible unit conversion: usd_million -> rmb_million", "percent->usd_million: ForecastInputError: incompatible unit conversion: percent -> usd_million"], "all_rejected": true}`
  - ✓ mixed_units_rejected (reject): expected=True observed=True

### M02-L — PASS

- class: M02  vector: legal  mode: draft
- boundary: closing ARR is not full-year revenue; revenue follows the committed bridge
- expected: `{"values": {"revenue": {"2026": 105.0, "2027": 136.25}}, "reject": false, "reject_reason": null, "unknown_fields": []}`
- observed: `{"revenue": {"2026": 105.0, "2027": 136.25}}`
  - ✓ input_driver[opening_arr] (input): expected=[100.0, 125.0] observed=[100.0, 125.0]
  - ✓ input_driver[new_arr] (input): expected=[20.0, 30.0] observed=[20.0, 30.0]
  - ✓ revenue.2026 (value): expected=105.0 observed=105.0
  - ✓ revenue.2027 (value): expected=136.25 observed=136.25

### M02-C — REJECT_OK

- class: M02  vector: counter  mode: draft
- boundary: a missing ARR driver is refused, never zero-filled
- expected: `{"values": {}, "reject": true, "reject_reason": null, "unknown_fields": []}`
- observed: `{"exception": "ForecastInputError: research parameter_id subscription_arr_bridge_new_arr_2026_base for growth_curve is not used by the revenue model"}`
  - ✓ reject_reason (reject): expected=(any non-empty contract reason) observed=research parameter_id subscription_arr_bridge_new_arr_2026_base for growth_curve is not used by the revenue model

### M03-L — PASS

- class: M03  vector: legal  mode: draft
- boundary: demand is capped by capacity; the launch fraction is applied exactly once
- expected: `{"values": {"revenue": {"2026": 80.0, "2027": 480.0}}, "reject": false, "reject_reason": null, "unknown_fields": []}`
- observed: `{"revenue": {"2026": 80.0, "2027": 480.0}}`
  - ✓ input_driver[eligible_units] (input): expected=[1000.0, 1200.0] observed=[1000.0, 1200.0]
  - ✓ input_driver[annual_supply_capacity] (input): expected=[80.0, 300.0] observed=[80.0, 300.0]
  - ✓ revenue.2026 (value): expected=80.0 observed=80.0
  - ✓ revenue.2027 (value): expected=480.0 observed=480.0

### M03-C — PASS

- class: M03  vector: counter  mode: draft
- boundary: zero capacity yields finite zero revenue, never unbounded growth
- expected: `{"values": {"revenue": {"2026": 0.0, "2027": 0.0}}, "reject": false, "reject_reason": null, "unknown_fields": []}`
- observed: `{"revenue": {"2026": 0.0, "2027": 0.0}}`
  - ✓ input_driver[annual_supply_capacity] (input): expected=[0.0, 0.0] observed=[0.0, 0.0]
  - ✓ revenue.2026 (value): expected=0.0 observed=0.0
  - ✓ revenue.2027 (value): expected=0.0 observed=0.0

### M04-L — PASS

- class: M04  vector: legal  mode: draft
- boundary: a calendar H1 evidence flow keeps six-month coverage and is not added to the annual forecast
- expected: `{"values": {"months": 6.0, "annual": {"2026": 165.0, "2027": 181.50000000000003}}, "reject": false, "reject_reason": null, "unknown_fields": []}`
- observed: `{"months": 6.0, "annual": {"2026": 165.00000000000003, "2027": 181.50000000000003}}`
  - ✓ months (value): expected=6.0 observed=6.0
  - ✓ annual.2026 (value): expected=165.0 observed=165.00000000000003
  - ✓ annual.2027 (value): expected=181.50000000000003 observed=181.50000000000003

### M04-C — REJECT_OK

- class: M04  vector: counter  mode: draft
- boundary: a dated flow outside its declared FY window is refused, not zero-filled
- expected: `{"values": {}, "reject": true, "reject_reason": "must lie within the FY2026 window", "unknown_fields": []}`
- observed: `{"exception": "ForecastInputError: seg_bad: period_flow dates must lie within the FY2026 window (2026-01-01..2026-12-31) implied by fiscal_year_end 12-31"}`
  - ✓ reject_reason (reject): expected=must lie within the FY2026 window observed=seg_bad: period_flow dates must lie within the FY2026 window (2026-01-01..2026-12-31) implied by fiscal_year_end 12-31

### M05-L — PASS

- class: M05  vector: legal  mode: draft
- boundary: zero-base launch revenue is computable
- expected: `{"values": {"cagr": null, "terminal": 480.0, "annual": {"2026": 80.0, "2027": 480.0}}, "reject": false, "reject_reason": null, "unknown_fields": ["cagr"]}`
- observed: `{"cagr": null, "terminal": 480.0, "annual": {"2026": 80.0, "2027": 480.0}}`
  - ✓ unknown[cagr] (unknown): expected=None observed=None
  - ✓ cagr (value): expected=None observed=None
  - ✓ terminal (value): expected=480.0 observed=480.0
  - ✓ annual.2026 (value): expected=80.0 observed=80.0
  - ✓ annual.2027 (value): expected=480.0 observed=480.0

### M05-C — PASS

- class: M05  vector: unknown  mode: draft
- boundary: CAGR from a zero base is undefined=null, not 0 growth nor a bad forecast
- expected: `{"values": {"cagr": null}, "reject": false, "reject_reason": null, "unknown_fields": ["cagr"]}`
- observed: `{"cagr": null, "terminal": 480.0, "annual": {"2026": 80.0, "2027": 480.0}}`
  - ✓ unknown[cagr] (unknown): expected=None observed=None
  - ✓ cagr (value): expected=None observed=None

### M06-L — PASS

- class: M06  vector: legal  mode: draft
- boundary: a shared shock propagates once; the joint volume/price path conserves the delta
- expected: `{"values": {"delta_2026": -20.0, "delta_2027": 15.0, "delta_sum": -5.0}, "reject": false, "reject_reason": null, "unknown_fields": []}`
- observed: `{"delta_2026": -20.0, "delta_2027": 14.999999999999972, "delta_sum": -5.000000000000028, "baseline_annual": {"2026": 165.00000000000003, "2027": 181.50000000000003}, "stressed_annual": {"2026": 145.00000000000003, "2027": 196.5}}`
  - ✓ delta_2026 (value): expected=-20.0 observed=-20.0
  - ✓ delta_2027 (value): expected=15.0 observed=14.999999999999972
  - ✓ delta_sum (value): expected=-5.0 observed=-5.000000000000028
  - ✓ shock_applied_once (conservation): expected=-20.0 observed=-20.0

### M06-C — REJECT_OK

- class: M06  vector: counter  mode: draft
- boundary: a fixed shared cap that would force Low<=Base<=High is refused, not reordered
- expected: `{"values": {}, "reject": true, "reject_reason": "scenario ordering", "unknown_fields": []}`
- observed: `{"exception": "ForecastInputError: segment scenario ordering failed for Segment A/2027"}`
  - ✓ reject_reason (reject): expected=scenario ordering observed=segment scenario ordering failed for Segment A/2027

### M07-L — PASS

- class: M07  vector: legal  mode: draft
- boundary: a comparable annual target keeps its own value and basis
- expected: `{"values": {"comparison_value": 144.0, "measurement_basis": "annual_period"}, "reject": false, "reject_reason": null, "unknown_fields": []}`
- observed: `{"comparison_value": 144.0, "measurement_basis": "annual_period"}`
  - ✓ comparison_value (value): expected=144.0 observed=144.0
  - ✓ measurement_basis (value): expected=annual_period observed=annual_period

### M07-C — REJECT_OK

- class: M07  vector: counter  mode: draft
- boundary: a run-rate/period-end target is not re-labelled as the current annual figure
- expected: `{"values": {}, "reject": true, "reject_reason": "requires explicit annual recognized revenue conversion", "unknown_fields": []}`
- observed: `{"exception": "ForecastInputError: run_rate_at_period_end target requires explicit annual recognized revenue conversion: five_year_revenue_goal"}`
  - ✓ reject_reason (reject): expected=requires explicit annual recognized revenue conversion observed=run_rate_at_period_end target requires explicit annual recognized revenue conversion: five_year_revenue_goal

### M08-L — PASS

- class: M08  vector: legal  mode: draft
- boundary: support is scoped per segment/year/scenario; one calibrated cell never presumes another
- expected: `{"values": {"cells": {"Segment A|low|2026": "supported", "Segment A|base|2026": "supported", "Segment A|high|2026": "supported", "Segment A|base|2027": "unsupported", "Segment B|base|2026": "unsupported"}, "economic_truth_inferred": false}, "reject": false, "reject_reason": null, "unknown_fields": []}`
- observed: `{"cells": {"Segment A|low|2026": "supported", "Segment A|low|2027": "unsupported", "Segment A|base|2026": "supported", "Segment A|base|2027": "unsupported", "Segment A|high|2026": "supported", "Segment A|high|2027": "unsupported", "Segment B|low|2026": "unsupported", "Segment B|low|2027": "unsupported", "Segment B|base|2026": "unsupported", "Segment B|base|2027": "unsupported", "Segment B|high|2026": "unsupported", "Segment B|high|2027": "unsupported"}, "economic_truth_inferred": false}`
  - ✓ cells.Segment A|low|2026 (value): expected=supported observed=supported
  - ✓ cells.Segment A|base|2026 (value): expected=supported observed=supported
  - ✓ cells.Segment A|high|2026 (value): expected=supported observed=supported
  - ✓ cells.Segment A|base|2027 (value): expected=unsupported observed=unsupported
  - ✓ cells.Segment B|base|2026 (value): expected=unsupported observed=unsupported
  - ✓ economic_truth_inferred (value): expected=False observed=False

### M08-C — PASS

- class: M08  vector: unknown  mode: draft
- boundary: an unknown observed range/actual stays null, never coerced to 0
- expected: `{"values": {"unknown_stays_null": true}, "reject": false, "reject_reason": null, "unknown_fields": ["observed_range"]}`
- observed: `{"observed_range": null, "adequacy_status": "unverified"}`
  - ✓ observed_range_stays_null (unknown): expected=None observed=None
  - ✓ adequacy_unverified (unknown): expected=unverified observed=unverified

### C01-USD-L — PASS

- class: C01  vector: legal  mode: draft
- boundary: USD millions quantity x price and a same-family 1e6/1e3 scale stay the same money
- expected: `{"values": {}, "reject": false, "reject_reason": null, "unknown_fields": []}`
- observed: `{"annual": {"2026": 91.0, "2027": 150.5}}`
  - ✓ conversion[5.0 usd_million->usd_thousand] (value): expected=5000.0 observed=5000.0

### C01-CNY-L — PASS

- class: C01  vector: legal  mode: draft
- boundary: CNY 100m (1e8) and CNY million (1e6) are the same currency at a 100x scale
- expected: `{"values": {"engine_value": 725.0, "scale_applied": 100.0}, "reject": false, "reject_reason": null, "unknown_fields": []}`
- observed: `{"engine_value": 725.0, "input_unit": "rmb_100m", "engine_unit": "rmb_million", "conversion": "7.25 rmb_100m x 100 = 725 rmb_million"}`
  - ✓ engine_value (value): expected=725.0 observed=725.0
  - ✓ not_wrong_scale[x100] (conservation): expected=!= 72500.0 observed=725.0
  - ✓ not_wrong_scale[x1000] (conservation): expected=!= 725000.0 observed=725.0

### C01-HKD-C — REJECT_OK

- class: C01  vector: counter  mode: draft
- boundary: an unwritten unit name is an unknown unit, never a guessed FX rate or alias
- expected: `{"values": {}, "reject": true, "reject_reason": "unknown input_unit", "unknown_fields": []}`
- observed: `{"exception": "ForecastInputError: unknown input_unit: hkd_million"}`
  - ✓ reject_reason (reject): expected=unknown input_unit observed=unknown input_unit: hkd_million

### C01-CROSS-C — REJECT_OK

- class: C01  vector: counter  mode: draft
- boundary: a missing currency name never silently auto-converts between currencies
- expected: `{"values": {}, "reject": true, "reject_reason": "incompatible unit conversion", "unknown_fields": []}`
- observed: `{"exception": "ForecastInputError: incompatible unit conversion: usd_million -> rmb_million"}`
  - ✓ reject_reason (reject): expected=incompatible unit conversion observed=incompatible unit conversion: usd_million -> rmb_million

### C02-FY-L — PASS

- class: C02  vector: legal  mode: draft
- boundary: non-12-31 FYE plus a two-quarter dated bridge produce the real annual revenue
- expected: `{"values": {"annual": {"2026": 127.0, "2027": 210.5}}, "reject": false, "reject_reason": null, "unknown_fields": []}`
- observed: `{"annual": {"2026": 127.0, "2027": 210.5}, "contribution": {"2026": 36.0, "2027": 60.0}, "dated_windows": [{"parameter_id": "dated_post", "period_start": "2026-05-31", "period_end": "2026-06-30", "input_parameter_ids": null}, {"parameter_id": "dated_tail_low", "period_start": "2026-07-01", "period_end": "2026-09-30", "input_parameter_ids": null}, {"parameter_id": "dated_fy2026_low", "period_start": "2025-10-01", "period_end": "2026-09-30", "input_parameter_ids": ["dated_post", "dated_tail_low"]}, {"parameter_id": "dated_fy2027_low", "period_start": "2026-10-01", "period_end": "2027-09-30", "input_parameter_ids": null}, {"parameter_id": "dated_tail_base", "period_start": "2026-07-01", "period_end": "2026-09-30", "input_parameter_ids": null}, {"parameter_id": "dated_fy2026_base", "period_start": "2025-10-01", "period_end": "2026-09-30", "input_parameter_ids": ["dated_post", "dated_tail_base"]}, {"parameter_id": "dated_fy2027_base", "period_start": "2026-10-01", "period_end": "2027-09-30", "input_parameter_ids": null}, {"parameter_id": "dated_tail_high", "period_start": "2026-07-01", "period_end": "2026-09-30", "input_parameter_ids": null}, {"parameter_id": "dated_fy2026_high", "period_start": "2025-10-01", "period_end": "2026-09-30", "input_parameter_ids": ["dated_post", "dated_tail_high"]}, {"parameter_id": "dated_fy2027_high", "period_start": "2026-10-01", "period_end": "2027-09-30", "input_parameter_ids": null}]}`
  - ✓ input_driver[revenue] (input): expected=[36.0, 90.0] observed=[36.0, 90.0]
  - ✓ annual.2026 (value): expected=127.0 observed=127.0
  - ✓ annual.2027 (value): expected=210.5 observed=210.5

### C02-FYE-C — REJECT_OK

- class: C02  vector: counter  mode: draft
- boundary: an impossible fiscal-year-end label is refused, never silently windowed
- expected: `{"values": {}, "reject": true, "reject_reason": "fiscal_year_end", "unknown_fields": []}`
- observed: `{"exception": "ForecastInputError: fiscal_year_end is not a valid month-day"}`
  - ✓ reject_reason (reject): expected=fiscal_year_end observed=fiscal_year_end is not a valid month-day

### C02-QGAP-C — REJECT_OK

- class: C02  vector: counter  mode: draft
- boundary: a missing quarter stays a real gap: q1+q3 never reconstructs the annual total
- expected: `{"values": {}, "reject": true, "reject_reason": "composition", "unknown_fields": []}`
- observed: `{"exception": "ForecastInputError: dated_fy2026_low: full-year dated composition has unexplained gaps; missing flows cannot be zero-filled"}`
  - ✓ input_driver[revenue] (input): expected=[36.0, 90.0] observed=[36.0, 90.0]
  - ✓ reject_reason (reject): expected=composition observed=dated_fy2026_low: full-year dated composition has unexplained gaps; missing flows cannot be zero-filled

### C02-DBL-C — REJECT_OK

- class: C02  vector: counter  mode: draft
- boundary: the same economic flow is never added twice into the annual result
- expected: `{"values": {}, "reject": true, "reject_reason": "double counts", "unknown_fields": []}`
- observed: `{"exception": "ForecastInputError: dated_fy2026_low: dated composition double counts the same economic flow in overlapping inputs dated_tail_low and dated_tail_low"}`
  - ✓ input_driver[revenue] (input): expected=[36.0, 90.0] observed=[36.0, 90.0]
  - ✓ reject_reason (reject): expected=double counts observed=dated_fy2026_low: dated composition double counts the same economic flow in overlapping inputs dated_tail_low and dated_tail_low

### C03-JOINT-L — PASS

- class: C03  vector: legal  mode: draft
- boundary: one frozen shock moves quantity and price together; neither leg carries it twice
- expected: `{"values": {"revenue_2026": 50.0, "revenue_2027": 48.6, "single_leg_only_2027": 54.0, "double_leg_2027": 43.74}, "reject": false, "reject_reason": null, "unknown_fields": []}`
- observed: `{"annual": {"2026": 50.0, "2027": 48.6}, "per_scenario_2027": {"low": 34.56, "base": 48.6, "high": 66.0}}`
  - ✓ revenue_2026 (value): expected=50.0 observed=50.0
  - ✓ revenue_2027 (value): expected=48.6 observed=48.6
  - ✓ not_single_leg_only (conservation): expected=!= 54.0 observed=48.6
  - ✓ not_double_shocked (conservation): expected=!= 39.366 observed=48.6
  - ✓ joint[low] (value): expected=34.56 observed=34.56
  - ✓ joint[base] (value): expected=48.6 observed=48.6
  - ✓ joint[high] (value): expected=66.0 observed=66.0

### C03-ORDER-C — REJECT_OK

- class: C03  vector: counter  mode: draft
- boundary: a joint shock that breaks the scenario order is refused, never silently re-sorted
- expected: `{"values": {}, "reject": true, "reject_reason": "scenario ordering", "unknown_fields": []}`
- observed: `{"exception": "ForecastInputError: segment scenario ordering failed for Core segment/2027"}`
  - ✓ reject_reason (reject): expected=scenario ordering observed=segment scenario ordering failed for Core segment/2027

### C04-CUM-L — PASS

- class: C04  vector: legal  mode: draft
- boundary: a cumulative target sums every registered measurement period
- expected: `{"values": {"modeled_value": 264.0, "attainment_ratio": 1.0153846153846153, "measurement_basis": "cumulative_periods"}, "reject": false, "reject_reason": null, "unknown_fields": []}`
- observed: `{"measurement_basis": "cumulative_periods", "modeled_value": 264.0, "period_sum": 264.0, "attainment_ratio": 1.0153846153846153}`
  - ✓ modeled_value (value): expected=264.0 observed=264.0
  - ✓ attainment_ratio (value): expected=1.0153846153846153 observed=1.0153846153846153
  - ✓ measurement_basis (value): expected=cumulative_periods observed=cumulative_periods

### C04-NET-L — PASS

- class: C04  vector: legal  mode: draft
- boundary: consolidated net = gross segment revenue + one signed elimination, exactly once
- expected: `{"values": {"segment_gross_2026": 165.0, "adjustment_2026": -10.0, "consolidated_2026": 155.0}, "reject": false, "reject_reason": null, "unknown_fields": []}`
- observed: `{"segment_gross_2026": 165.00000000000003, "adjustment_2026": -10.0, "consolidated_2026": 155.00000000000003}`
  - ✓ segment_gross_2026 (value): expected=165.0 observed=165.00000000000003
  - ✓ adjustment_2026 (value): expected=-10.0 observed=-10.0
  - ✓ consolidated_2026 (value): expected=155.0 observed=155.00000000000003

### C04-CUM-C — PASS

- class: C04  vector: counter  mode: draft
- boundary: a cumulative/period-end figure is never relabelled as one annual figure
- expected: `{"values": {}, "reject": false, "reject_reason": null, "unknown_fields": ["annual_total"]}`
- observed: `{"measurement_basis": "cumulative_periods", "measured_periods": ["FY2026", "FY2027"], "periods_are_distinct": true, "annual_total": null}`
  - ✓ unknown[annual_total] (unknown): expected=None observed=None

### C05-ACT-L — PASS

- class: C05  vector: legal  mode: draft
- boundary: draft output plus the shipped error interface, scoped to segment/year/scenario
- expected: `{"values": {"segment_names": ["Segment A"], "future_years_registered_as_actual": [], "wape": 0.05}, "reject": false, "reject_reason": null, "unknown_fields": []}`
- observed: `{"company_name": "Test Co", "declared_years": ["2026", "2027"], "segment_cells": ["Segment A|2026", "Segment A|2027"], "currency": "USD", "unit": "million", "wape": 0.05000000000000017, "future_years_registered_as_actual": [], "segment_names": ["Segment A"]}`
  - ✓ actual.segment_names (value): expected=['Segment A'] observed=['Segment A']
  - ✓ actual.future_years_registered_as_actual (value): expected=[] observed=[]
  - ✓ actual.wape (value): expected=0.05 observed=0.05000000000000017
  - ✓ segment_names (value): expected=['Segment A'] observed=['Segment A']
  - ✓ actual_years (value): expected=['2026', '2027'] observed=['2026', '2027']

### C05-COV-C — PASS

- class: C05  vector: counter  mode: draft
- boundary: future assumptions, unobserved actuals and cross-scope calibration stay refused/null
- expected: `{"values": {"future_assumption_used_as_actual": false, "unobserved_actual_zero_filled": false, "foreign_scope_calibration_supported": false}, "reject": false, "reject_reason": null, "unknown_fields": ["unobserved_wape"]}`
- observed: `{"actual_company_years": ["2026"], "actual_segment_cells": ["Segment A|2026"], "unobserved_wape": null, "foreign_scope_observations": 0, "future_actual_rejection": "actual source predates fiscal year end: 2027", "scope_interpretation": "observed actuals only; calibration effectiveness not evaluated"}`
  - ✓ actual_company_years (value): expected=['2026'] observed=['2026']
  - ✓ actual_segment_cells (value): expected=['Segment A|2026'] observed=['Segment A|2026']
  - ✓ unobserved_wape (value): expected=None observed=None
  - ✓ foreign_scope_observations (value): expected=0 observed=0
  - ✓ future_actual_rejection (reject): expected=predates fiscal year end observed=actual source predates fiscal year end: 2027

## Cleanup / residuals

- cleanup: `{"scratch_path": "C:\\Users\\郑曾波\\Projects\\company-wiki\\.planning\\w08-root-reception\\rf\\scratch-native-final\\w07-a5223359e95b4fd8ad1fbf0b522b9992", "baseline": {"existed": false, "sentinel": null}, "restored_absent": true, "owned_root_baseline": {"existed": false, "sentinel": null}, "owned_root_restored": true, "readonly_unchanged": true}`
- residuals: []
